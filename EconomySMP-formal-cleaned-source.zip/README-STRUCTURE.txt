DonutSMPCore decompiled source cleanup

Java sources are under src/main/java. YAML/resources are grouped under src/main/resources/core/<feature>/, with config.yml and plugin.yml retained at the resource root. Donut-prefixed resource filenames were normalized where possible.

Some Java names are best-effort guesses based on class signatures and use sites, not recovered original names. Decompiled variables/methods may remain obfuscated. This source has not been compiled or runtime-tested.
