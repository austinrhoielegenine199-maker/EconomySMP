package org.mz.donutsmpcore.crossserver;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class CrossServerRedisBridge {

   private CrossServerRedisBridge() {
   }

   public static List<String> allOnlineNames(CommandSender var0, String var1, boolean var2) {
      int var90 = 1963192414 ^ 16126602 ^ 237175533;
      var90 = 504521741 ^ var90;
      String var68;
      if (var1 == null) {
         var90 = 76055600 ^ var90;
         var68 = xvtohiytzs(luagrapvneyxqju(), wzcmyracfqpwvem(), var90);

         label336:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
               case 209920331:
                  var90 ^= 339414918;
                  break label336;
               case 430565085:
               default:
                  throw new IllegalAccessException();
               case 782985310:
                  break;
               case 1766250442:
                  break label336;
            }
         }
      } else {
         label326:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
               case 86812128:
                  var90 ^= 184946605;
                  break label326;
               case 826384749:
               default:
                  throw new IllegalAccessException();
               case 1852897144:
                  break;
               case 2115032406:
                  break label326;
            }
         }

         Locale var81 = Locale.ROOT;
         var68 = var1.toLowerCase(var81);
         var90 = 464880667 ^ var90;
      }

      String var5;
      String var16;
      label316: {
         var5 = var68;
         var90 = 1539319860 ^ var90;
         if (var2 != (783755190 ^ var90)) {
            var90 = 298120784 ^ var90;
            byte var15 = var0 instanceof Player;
            if (var15 != (1064554982 ^ var90)) {
               var90 = 126740602 ^ var90;
               Player var66 = (Player)var0;
               var16 = var66.getName();

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                     case 242005856:
                        var90 ^= 497177622;
                        break label316;
                     case 553848971:
                        break;
                     case 1605690028:
                     default:
                        throw new IllegalAccessException();
                     case 1763860213:
                        break label316;
                  }
               }
            }

            var90 = zzyrkloogzpzomeo(var90, 555540979);
         } else {
            label314:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                  case 144739562:
                  default:
                     throw new IllegalAccessException();
                  case 176353863:
                     var90 ^= 819468195;
                  case 267257567:
                     break label314;
                  case 1473022767:
               }
            }
         }

         var16 = null;
         var90 = 993222047 ^ var90;
      }

      String var6 = var16;
      var90 = 1901583880 ^ var90;
      byte var4 = (byte)(1410053026 ^ var90);
      HashSet var17 = new HashSet(var4);
      HashSet var7 = var17;
      var90 = 1884383863 ^ var90;
      byte var82 = (byte)(609933797 ^ var90);
      ArrayList var18 = new ArrayList(var82);
      ArrayList var8 = var18;
      var90 = 1415853805 ^ var90;
      CrossServerPlayerTracker var19 = CrossServerPlayerTracker.getInstance();
      CrossServerPlayerTracker var9 = var19;
      var90 = 2114478259 ^ var90;
      if (var19 != null) {
         var90 = 246945041 ^ var90;
         byte var22 = var19.isConnected();
         if (var22 != (9345722 ^ var90)) {
            label343: {
               var90 = 1436685160 ^ var90;

               label344: {
                  label286: {
                     Iterator var10;
                     try {
                        List var24 = var9.getAllOnlineNames();
                        Iterator var25 = var24.iterator();
                        var10 = var25;
                        var90 ^= 1132799752;
                     } catch (Throwable var95) {
                        boolean var10001 = false;
                        break label286;
                     }

                     label283:
                     while(true) {
                        label281:
                        while(true) {
                           label279:
                           while(true) {
                              String var87;
                              try {
                                 byte var27 = var10.hasNext();
                                 if (var27 == (380219098 ^ var90)) {
                                    break label344;
                                 }

                                 var90 = 253680403 ^ var90;
                                 Object var49 = var10.next();
                                 String var50 = (String)var49;
                                 var87 = var50;
                                 var90 = 1721847683 ^ var90;
                                 if (var50 == null) {
                                    break label281;
                                 }

                                 var90 = 2039843634 ^ var90;
                                 byte var53 = var50.isEmpty();
                                 if (var53 != (109293944 ^ var90)) {
                                    var90 = 1896811800 ^ var90;
                                    break;
                                 }
                              } catch (Throwable var94) {
                                 boolean var122 = false;
                                 break label283;
                              }

                              label267:
                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                                    case 102461667:
                                       var90 ^= 413117969;
                                       break label267;
                                    case 791002422:
                                    default:
                                       throw new IllegalAccessException();
                                    case 1572248884:
                                       break label267;
                                    case 1911934266:
                                 }
                              }

                              label347: {
                                 label256: {
                                    label255: {
                                       try {
                                          if (var6 != null) {
                                             var90 = 1183396105 ^ var90;
                                             byte var56 = var6.equalsIgnoreCase(var87);
                                             if (var56 == (1486171744 ^ var90)) {
                                                break label255;
                                             }

                                             var90 = 1584072129 ^ var90;
                                             break label347;
                                          }
                                       } catch (Throwable var93) {
                                          boolean var123 = false;
                                          break label283;
                                       }

                                       while(true) {
                                          switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                                             case 173433543:
                                                var90 ^= 758014296;
                                             case 766253901:
                                                break label256;
                                             case 928476831:
                                             default:
                                                throw new IllegalAccessException();
                                             case 1541100449:
                                          }
                                       }
                                    }

                                    var90 = 1806127185 ^ var90;
                                 }

                                 label349: {
                                    try {
                                       Locale var76 = Locale.ROOT;
                                       String var59 = var87.toLowerCase(var76);
                                       byte var60 = var59.startsWith(var5);
                                       if (var60 == (858947121 ^ var90)) {
                                          var90 = 1149084836 ^ var90;
                                          break label349;
                                       }
                                    } catch (Throwable var92) {
                                       boolean var124 = false;
                                       break label283;
                                    }

                                    var90 = zzyrkloogzpzomeo(var90, 922780387);

                                    label225: {
                                       try {
                                          Locale var84 = Locale.ROOT;
                                          String var79 = var87.toLowerCase(var84);
                                          byte var62 = var7.add(var79);
                                          if (var62 != (70450386 ^ var90)) {
                                             var90 = 343831358 ^ var90;
                                             boolean var64 = var8.add(var87);
                                             var90 = 464626009 ^ var90;
                                             break label225;
                                          }
                                       } catch (Throwable var91) {
                                          boolean var125 = false;
                                          break label283;
                                       }

                                       label219:
                                       while(true) {
                                          switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                                             case 66046262:
                                                var90 ^= 265278055;
                                                break label219;
                                             case 414948789:
                                                break;
                                             case 1329671838:
                                             default:
                                                throw new IllegalAccessException();
                                             case 1978370423:
                                                break label219;
                                          }
                                       }
                                    }

                                    var90 = zzyrkloogzpzomeo(var90, 492077167);
                                    continue;
                                 }

                                 var90 = zzyrkloogzpzomeo(var90, 1642493007);
                                 continue;
                              }

                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                                    case 109989400:
                                       var90 ^= 274171259;
                                       continue label279;
                                    case 235383553:
                                       break;
                                    case 1422141920:
                                       continue label279;
                                    case 1436061265:
                                    default:
                                       throw new IllegalAccessException();
                                 }
                              }
                           }

                           var90 = zzyrkloogzpzomeo(var90, 1629819578);
                        }

                        var90 = 1774163088 ^ var90;
                     }
                  }

                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var90)) {
                     case -2107343008 -> var90 = 746216326 ^ var90;
                     case -1718357623 -> var90 = 251963995 ^ var90;
                     case -1453044078 -> var90 = 1763335608 ^ var90;
                     case -1253214512 -> var90 = zzyrkloogzpzomeo(var90, 715094704);
                     case -1166093141 -> var90 = zzyrkloogzpzomeo(var90, 1266224895);
                     case -1134173437 -> var90 = zzyrkloogzpzomeo(var90, 1270507530);
                     case -995527934 -> var90 = zzyrkloogzpzomeo(var90, 1688467978);
                     case -843338168 -> var90 = 629252515 ^ var90;
                     case -253691064 -> var90 = 573229827 ^ var90;
                     case -122564013 -> var90 = zzyrkloogzpzomeo(var90, 1126231584);
                     case 563603088 -> var90 = 939796664 ^ var90;
                     case 874351552 -> var90 = 984966418 ^ var90;
                     case 938564872 -> var90 = zzyrkloogzpzomeo(var90, 986251211);
                     case 1609135528 -> var90 = 936114911 ^ var90;
                     default -> throw new IllegalAccessException("Error in hash");
                  }

                  var90 = 1661846334 ^ var90;
                  break label343;
               }

               var90 = 2013863624 ^ var90;

               label193:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                     case 106380162:
                        var90 ^= 832284486;
                        break label193;
                     case 1418971663:
                     default:
                        throw new IllegalAccessException();
                     case 1670714600:
                        break;
                     case 2127823952:
                        break label193;
                  }
               }
            }
         } else {
            label184:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                  case 8761728:
                     var90 ^= 1605733870;
                  case 96272417:
                     break label184;
                  case 650837618:
                     break;
                  case 1964296484:
                  default:
                     throw new IllegalAccessException();
               }
            }
         }
      } else {
         var90 = 1359845631 ^ var90;
      }

      Collection var28 = Bukkit.getOnlinePlayers();
      Iterator var29 = var28.iterator();
      Iterator var85 = var29;
      var90 = 509662524 ^ var90;

      label174:
      while(true) {
         byte var31 = var85.hasNext();
         if (var31 == (1096532584 ^ var90)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                  case 245467634:
                     var90 = 417021340 ^ var90;
                     return var8;
                  case 945951999:
                  default:
                     throw new IllegalAccessException();
                  case 1359262058:
                     break;
                  case 1644582754:
                     return var8;
               }
            }
         }

         var90 = 1441726890 ^ var90;
         Object var34 = var85.next();
         Player var35 = (Player)var34;
         var90 = 419235292 ^ var90;
         String var37 = var35.getName();
         var90 = 211243885 ^ var90;
         if (var6 != null) {
            var90 = 1704227585 ^ var90;
            byte var40 = var6.equalsIgnoreCase(var37);
            if (var40 != (1699407474 ^ var90)) {
               var90 = 545400232 ^ var90;
               var90 = zzyrkloogzpzomeo(var90, 76743090);
               continue;
            }

            var90 = zzyrkloogzpzomeo(var90, 1646850734);
         } else {
            var90 = 129794479 ^ var90;
         }

         Locale var70 = Locale.ROOT;
         String var42 = var37.toLowerCase(var70);
         byte var43 = var42.startsWith(var5);
         if (var43 == (123868380 ^ var90)) {
            var90 ^= 1801337965;

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                  case 28631786:
                     var90 ^= 761785049;
                     continue label174;
                  case 420869296:
                  default:
                     throw new IllegalAccessException();
                  case 1082611835:
                     break;
                  case 1319513104:
                     continue label174;
               }
            }
         } else {
            label169:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                  case 116126956:
                     var90 ^= 1388194141;
                  case 202798550:
                     break label169;
                  case 437805986:
                  default:
                     throw new IllegalAccessException();
                  case 594315767:
               }
            }

            Locale var83 = Locale.ROOT;
            String var73 = var37.toLowerCase(var83);
            byte var45 = var7.add(var73);
            if (var45 != (1440497025 ^ var90)) {
               var90 = 1161309929 ^ var90;
               var8.add(var37);
               var90 = 722113000 ^ var90;
            } else {
               label158:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                     case 106619637:
                        var90 ^= 1848819457;
                        break label158;
                     case 192385113:
                     default:
                        throw new IllegalAccessException();
                     case 1191475220:
                        break label158;
                     case 1788486244:
                  }
               }
            }

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                  case 69084982:
                     var90 ^= 2058698984;
                     continue label174;
                  case 827299161:
                  default:
                     throw new IllegalAccessException();
                  case 1094862146:
                     break;
                  case 1847311434:
                     continue label174;
               }
            }
         }
      }
   }

   public static List<String> allOnlineNamesExcludingSender(CommandSender var0, String var1) {
      int var8 = 198772017 ^ 2121469608 ^ 237175533;
      var8 = 1420672212 ^ var8;
      byte var4 = (byte)(790934945 ^ var8);
      List var5 = allOnlineNames(var0, var1, (boolean)var4);
      return var5;
   }

   public static List<String> allOnlineNamesIncludingSender(CommandSender var0, String var1) {
      int var8 = 1876248564 ^ 218354919 ^ 237175533;
      var8 = 871428852 ^ var8;
      byte var4 = (byte)(1594188554 ^ var8);
      List var5 = allOnlineNames(var0, var1, (boolean)var4);
      return var5;
   }

   public static List<String> filterPrefix(String var0, String... var1) {
      int var8 = 1675573054 ^ 1184419838 ^ 237175533;
      var8 = 1755230849 ^ var8;
      List var5 = Arrays.asList(var1);
      List var4 = filterPrefix(var0, var5);
      return var4;
   }

   public static List<String> filterPrefix(String var0, List<String> var1) {
      int var32 = 1890784751 ^ 2038282502 ^ 237175533;
      var32 = 951634733 ^ var32;
      String var25;
      if (var0 == null) {
         var32 = 2107828605 ^ var32;
         var25 = xvtohiytzs(rnqmilbvgmpjmhs(), wzcmyracfqpwvem(), var32);
         var32 = 1714317054 ^ var32;
      } else {
         var32 = 752216458 ^ var32;
         Locale var3 = Locale.ROOT;
         var25 = var0.toLowerCase(var3);
         var32 = 928605705 ^ var32;
      }

      String var5 = var25;
      var32 = 889923605 ^ var32;
      int var29 = var1.size();
      ArrayList var10 = new ArrayList(var29);
      ArrayList var6 = var10;
      var32 = 1601790727 ^ var32;
      Iterator var12 = var1.iterator();
      Iterator var7 = var12;
      var32 = 658174917 ^ var32;

      while(true) {
         byte var14 = var7.hasNext();
         if (var14 != (1771131517 ^ var32)) {
            var32 = 469562365 ^ var32;
            Object var17 = var7.next();
            String var18 = (String)var17;
            var32 = 670043742 ^ var32;
            if (var18 != null) {
               var32 ^= 122926521;
               Locale var26 = Locale.ROOT;
               String var21 = var18.toLowerCase(var26);
               byte var22 = var21.startsWith(var5);
               if (var22 != (1389238887 ^ var32)) {
                  var32 = 353402293 ^ var32;
                  var6.add(var18);
                  var32 = 92241114 ^ var32;
               } else {
                  label38:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var32)) {
                        case 7274985:
                           var32 ^= 275710319;
                           break label38;
                        case 532699618:
                        default:
                           throw new IllegalAccessException();
                        case 1228055358:
                           break;
                        case 1534222727:
                           break label38;
                     }
                  }
               }
            } else {
               label51:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var32)) {
                     case 98685219:
                        var32 ^= 389854422;
                        break label51;
                     case 158924495:
                     default:
                        throw new IllegalAccessException();
                     case 608897008:
                        break;
                     case 858177743:
                        break label51;
                  }
               }
            }
         } else {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var32)) {
                  case 210363971:
                     var32 = 1314006781 ^ var32;
                     return var6;
                  case 1228061938:
                     break;
                  case 1382002855:
                  default:
                     throw new IllegalAccessException();
                  case 2007680817:
                     return var6;
               }
            }
         }

         var32 = zzyrkloogzpzomeo(var32, 724584821);
      }
   }

   public static String xvtohiytzs(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] wzcmyracfqpwvem() {
      return new byte[]{32, 2, 31, 63, 108, 85};
   }

   private static byte[] luagrapvneyxqju() {
      return new byte[0];
   }

   private static byte[] rnqmilbvgmpjmhs() {
      return new byte[0];
   }

   private static int zzyrkloogzpzomeo(int var0, int var1) {
      return var0 ^ var1;
   }

   static {
   }
}
