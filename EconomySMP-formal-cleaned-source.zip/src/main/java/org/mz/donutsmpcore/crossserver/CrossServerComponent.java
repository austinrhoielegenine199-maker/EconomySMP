package org.mz.donutsmpcore.crossserver;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.PluginManager;
import org.mz.donutsmpcore.DonutSMPCore;
import org.mz.donutsmpcore.auction.KKo0o0oOK;
import skido.Ko0Ko0KoOK;
import skido.KoOo0KKoOK;
import skido.o0KoOK;
import skido.o0o0Ko0oOK;
import skido.o0o0oOoOoOoOK;
import skido.o0oOo0o0o0K;
import skido.o0oOo0oOo0K;
import skido.o0oOoOK;
import skido.oOKo0o0oOoOK;
import skido.oOKoOo0K;
import skido.oOoOKKo0K;
import skido.oOoOo0KKoOK;
import skido.oOoOo0oOo0K;
import skido.oOoOoOoOKoOK;

public class CrossServerComponent {
   private static boolean initialized;

   public static void init(DonutSMPCore var0) {
      int var203 = 355475675 ^ 1319231072 ^ 2122528657;
      var203 = 1602434303 ^ var203;
      byte var1 = initialized;
      if (var1 != (2056388053 ^ var203)) {
         var203 = 593528498 ^ var203;
      } else {
         var203 = 1426946229 ^ var203;
         Logger var9 = var0.getLogger();
         String var2 = ljhzayfbam(sofblweimfoitrc(), cqsypbmqaqxabut(), var203);
         var9.info(var2);
         var203 = 676793803 ^ var203;
         FileConfiguration var11 = var0.getConfig();
         String var127 = ljhzayfbam(yarcvnjucrslhdp(), cqsypbmqaqxabut(), var203);
         String var3 = ljhzayfbam(dghucuvzxleaqma(), cqsypbmqaqxabut(), var203);
         String var12 = var11.getString(var127, var3);
         var203 = 1287392688 ^ var203;
         Logger var14 = var0.getLogger();
         String var129 = "[CrossServer] Server ID: " + var12;
         var14.info(var129);
         var203 = 1112609721 ^ var203;
         FileConfiguration var16 = var0.getConfig();
         String var130 = ljhzayfbam(adibevnqqrrcbxd(), cqsypbmqaqxabut(), var203);
         byte var184 = (byte)(153523874 ^ var203);
         byte var17 = var16.getBoolean(var130, (boolean)var184);
         var203 = 1746217136 ^ var203;
         if (var17 == (1630780946 ^ var203)) {
            var203 = 908699711 ^ var203;
            Logger var20 = var0.getLogger();
            String var131 = ljhzayfbam(qyaictxijfpkjsq(), cqsypbmqaqxabut(), var203);
            var20.info(var131);
            var203 = 1886737578 ^ var203;
            byte var21 = (byte)(661602950 ^ var203);
            initialized = (boolean)var21;
            var203 = 2085820467 ^ var203;
         } else {
            var203 = zdsrxvnrgdagzdeu(var203, 741027618);
            byte var23 = SharedRedisPool.init(var0);
            if (var23 == (1293455664 ^ var203)) {
               var203 = 993330147 ^ var203;
               Logger var125 = var0.getLogger();
               String var183 = ljhzayfbam(plzirpclsbpmucs(), cqsypbmqaqxabut(), var203);
               var125.severe(var183);
               var203 = 1116450210 ^ var203;
               byte var126 = (byte)(883310448 ^ var203);
               initialized = (boolean)var126;
               var203 = 657719377 ^ var203;
            } else {
               var203 = 1157741019 ^ var203;

               label445: {
                  label505: {
                     label442: {
                        label455: {
                           Exception var10000;
                           label440: {
                              label456: {
                                 label438: {
                                    try {
                                       o0oOo0o0o0K.init(var0);
                                       var203 = 1614877374 ^ var203;
                                       KoOo0KKoOK.init(var0);
                                       var203 = 294776201 ^ var203;
                                       oOoOo0oOo0K.init(var0);
                                       var203 = 1043910799 ^ var203;
                                       KoOo0KKoOK var27 = KoOo0KKoOK.getInstance();
                                       byte var28 = var27.connect();
                                       if (var28 == (1206978387 ^ var203)) {
                                          break label438;
                                       }

                                       var203 = 1123458273 ^ var203;
                                       Logger var30 = var0.getLogger();
                                       String var132 = ljhzayfbam(reootihcsogjepa(), cqsypbmqaqxabut(), var203);
                                       var30.info(var132);
                                       var203 = 1680946563 ^ var203;
                                       PluginManager var31 = Bukkit.getPluginManager();
                                       oOKo0o0oOoOK var133 = new oOKo0o0oOoOK(var0);
                                       var31.registerEvents(var133, var0);
                                    } catch (Exception var222) {
                                       var10000 = var222;
                                       boolean var10001 = false;
                                       break label440;
                                    }

                                    while(true) {
                                       switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                                          case 207196232:
                                             var203 ^= 1210071258;
                                          case 734524143:
                                             break label456;
                                          case 935443271:
                                          default:
                                             throw new IOException();
                                          case 1893381730:
                                       }
                                    }
                                 }

                                 var203 = zdsrxvnrgdagzdeu(var203, 1450359384);

                                 try {
                                    Logger var123 = var0.getLogger();
                                    String var182 = ljhzayfbam(snvrcoskxchszwx(), cqsypbmqaqxabut(), var203);
                                    var123.warning(var182);
                                    var203 ^= 949300192;
                                 } catch (Exception var221) {
                                    var10000 = var221;
                                    boolean var298 = false;
                                    break label440;
                                 }
                              }

                              try {
                                 o0o0Ko0oOK.migrate();
                                 var203 = 684643503 ^ var203;
                                 break label455;
                              } catch (Exception var220) {
                                 var10000 = var220;
                                 boolean var299 = false;
                              }
                           }

                           switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var203)) {
                              case -1944197032 -> var203 = zdsrxvnrgdagzdeu(var203, 2009582226);
                              case -833700125 -> var203 = zdsrxvnrgdagzdeu(var203, 529375301);
                              case 162886027 -> var203 = 124967336 ^ var203;
                              case 675077520 -> var203 = 1665395755 ^ var203;
                              case 1065892506 -> var203 = zdsrxvnrgdagzdeu(var203, 565539018);
                              case 1086932824 -> var203 = 1851613042 ^ var203;
                              case 1119998635 -> var203 = 236735948 ^ var203;
                              case 1219802969 -> var203 = zdsrxvnrgdagzdeu(var203, 1330831730);
                              default -> throw new IOException("Error in hash");
                           }

                           Exception var119 = var10000;
                           var203 = 865603360 ^ var203;
                           Logger var121 = var0.getLogger();
                           String var180 = var119.getMessage();
                           String var181 = "[CrossServer] Homes initialization failed: " + var180;
                           var121.warning(var181);
                           var203 = 716808955 ^ var203;
                           break label442;
                        }

                        label416:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                              case 29016007:
                                 var203 ^= 2126354438;
                                 break label416;
                              case 1056721280:
                                 break;
                              case 1524780272:
                                 break label416;
                              case 1785757336:
                              default:
                                 throw new IOException();
                           }
                        }
                     }

                     label406: {
                        label405: {
                           label457: {
                              Exception var290;
                              label403: {
                                 try {
                                    o0oOoOK.init(var0);
                                    var203 ^= 2086331053;
                                    o0oOoOK var33 = o0oOoOK.getInstance();
                                    byte var34 = var33.connectRedis();
                                    if (var34 != (54474991 ^ var203)) {
                                       var203 = 1825779705 ^ var203;
                                       Logger var117 = var0.getLogger();
                                       String var177 = ljhzayfbam(hejhslmygxrzqxk(), cqsypbmqaqxabut(), var203);
                                       var117.info(var177);
                                       var203 = 136668440 ^ var203;
                                       PluginManager var118 = Bukkit.getPluginManager();
                                       o0o0oOoOoOoOK var178 = new o0o0oOoOoOoOK(var0);
                                       var118.registerEvents(var178, var0);
                                       break label457;
                                    }
                                 } catch (Exception var219) {
                                    var290 = var219;
                                    boolean var300 = false;
                                    break label403;
                                 }

                                 label396:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                                       case 51070559:
                                          var203 ^= 296515423;
                                       case 782136871:
                                          try {
                                             Logger var36 = var0.getLogger();
                                             String var134 = ljhzayfbam(eaeaptmpttxyjez(), cqsypbmqaqxabut(), var203);
                                             var36.warning(var134);
                                             var203 = 1360530921 ^ var203;
                                             break label405;
                                          } catch (Exception var218) {
                                             var290 = var218;
                                             boolean var301 = false;
                                             break label396;
                                          }
                                       case 519065251:
                                          break;
                                       case 1721896190:
                                       default:
                                          throw new IOException();
                                    }
                                 }
                              }

                              switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var203)) {
                                 case -1801814656 -> var203 = zdsrxvnrgdagzdeu(var203, 2029669650);
                                 case -80817645 -> var203 = zdsrxvnrgdagzdeu(var203, 353163488);
                                 case 435799928 -> var203 = zdsrxvnrgdagzdeu(var203, 1767258701);
                                 case 1045139571 -> var203 = 228618412 ^ var203;
                                 case 2137045171 -> var203 = 92607924 ^ var203;
                                 default -> throw new IOException("Error in hash");
                              }

                              Exception var113 = var290;
                              var203 = 217460896 ^ var203;
                              Logger var115 = var0.getLogger();
                              String var175 = var113.getMessage();
                              String var176 = "[CrossServer] TPA initialization failed: " + var175;
                              var115.warning(var176);
                              var203 = 1776287203 ^ var203;
                              break label406;
                           }

                           var203 = zdsrxvnrgdagzdeu(var203, 608317527);
                        }

                        var203 = zdsrxvnrgdagzdeu(var203, 1288408504);
                     }

                     label384: {
                        label383: {
                           label458: {
                              Exception var291;
                              label459: {
                                 try {
                                    o0oOo0oOo0K.init(var0);
                                    var203 = 264336459 ^ var203;
                                    o0oOo0oOo0K var38 = o0oOo0oOo0K.getInstance();
                                    byte var39 = var38.connectRedis();
                                    if (var39 != (8502186 ^ var203)) {
                                       var203 = 426621439 ^ var203;
                                       Logger var41 = var0.getLogger();
                                       String var135 = ljhzayfbam(anbsebamuwevooo(), cqsypbmqaqxabut(), var203);
                                       var41.info(var135);
                                       var203 = 2104678181 ^ var203;
                                       PluginManager var42 = Bukkit.getPluginManager();
                                       Ko0Ko0KoOK var136 = new Ko0Ko0KoOK(var0);
                                       var42.registerEvents(var136, var0);
                                       break label458;
                                    }
                                 } catch (Exception var217) {
                                    var291 = var217;
                                    boolean var302 = false;
                                    break label459;
                                 }

                                 var203 = 1927183239 ^ var203;

                                 try {
                                    Logger var112 = var0.getLogger();
                                    String var173 = ljhzayfbam(lirdybvooamduix(), cqsypbmqaqxabut(), var203);
                                    var112.warning(var173);
                                    var203 = 1445592968 ^ var203;
                                    break label383;
                                 } catch (Exception var216) {
                                    var291 = var216;
                                    boolean var303 = false;
                                 }
                              }

                              switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var203)) {
                                 case -1828847253 -> var203 = zdsrxvnrgdagzdeu(var203, 901674945);
                                 case -815787352 -> var203 = 1577956793 ^ var203;
                                 case 68017488 -> var203 = 1197476934 ^ var203;
                                 case 620145539 -> var203 = zdsrxvnrgdagzdeu(var203, 595550876);
                                 case 2047246088 -> var203 = 1218541581 ^ var203;
                                 default -> throw new IOException("Error in hash");
                              }

                              Exception var108 = var291;
                              var203 = 375123417 ^ var203;
                              Logger var110 = var0.getLogger();
                              String var171 = var108.getMessage();
                              String var172 = "[CrossServer] Spawns initialization failed: " + var171;
                              var110.warning(var172);
                              var203 = 990865867 ^ var203;
                              break label384;
                           }

                           var203 = 1089006293 ^ var203;
                        }

                        label369:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                              case 24184622:
                              default:
                                 throw new IOException();
                              case 111492921:
                                 var203 ^= 1321405531;
                                 break label369;
                              case 990558866:
                                 break;
                              case 1057250135:
                                 break label369;
                           }
                        }
                     }

                     label359: {
                        label358: {
                           label460: {
                              Exception var292;
                              label461: {
                                 try {
                                    KKo0o0oOK.init(var0);
                                    var203 = 1346307660 ^ var203;
                                    KKo0o0oOK var44 = KKo0o0oOK.getInstance();
                                    byte var45 = var44.connectRedis();
                                    if (var45 != (982136242 ^ var203)) {
                                       var203 = 1385025060 ^ var203;
                                       Logger var107 = var0.getLogger();
                                       String var169 = ljhzayfbam(rfnvjqxnzmllngj(), cqsypbmqaqxabut(), var203);
                                       var107.info(var169);
                                       break label460;
                                    }
                                 } catch (Exception var215) {
                                    var292 = var215;
                                    boolean var304 = false;
                                    break label461;
                                 }

                                 var203 = 1675544535 ^ var203;

                                 try {
                                    Logger var47 = var0.getLogger();
                                    String var137 = ljhzayfbam(ihssqelhwnszctv(), cqsypbmqaqxabut(), var203);
                                    var47.warning(var137);
                                    var203 = 1306362642 ^ var203;
                                    break label358;
                                 } catch (Exception var214) {
                                    var292 = var214;
                                    boolean var305 = false;
                                 }
                              }

                              switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var203)) {
                                 case -894987478 -> var203 = 1168635746 ^ var203;
                                 case -732844655 -> var203 = zdsrxvnrgdagzdeu(var203, 645476533);
                                 case 1077927091 -> var203 = 1962213009 ^ var203;
                                 case 1437179891 -> var203 = 1984313081 ^ var203;
                                 default -> throw new IllegalAccessException("Error in hash");
                              }

                              Exception var48 = var292;
                              var203 = 1734474354 ^ var203;
                              Logger var50 = var0.getLogger();
                              String var139 = var48.getMessage();
                              String var140 = "[CrossServer] Auction sync initialization failed: " + var139;
                              var50.warning(var140);
                              var203 = 1000650479 ^ var203;
                              break label359;
                           }

                           var203 = 2089716449 ^ var203;
                        }

                        label344:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                              case 130703199:
                                 var203 ^= 1421818093;
                              case 423957054:
                                 break label344;
                              case 1529442088:
                                 break;
                              case 2039457745:
                              default:
                                 throw new IOException();
                           }
                        }
                     }

                     label334: {
                        label333: {
                           label462: {
                              Exception var293;
                              label331: {
                                 try {
                                    CrossServerPlayerTracker.init(var0);
                                    var203 ^= 1093648423;
                                    CrossServerPlayerTracker var52 = CrossServerPlayerTracker.getInstance();
                                    byte var53 = var52.connectRedis();
                                    if (var53 != (18450877 ^ var203)) {
                                       int var259 = 254617824 ^ var203;
                                       PluginManager var54 = Bukkit.getPluginManager();
                                       CrossServerPlayerTracker var141 = CrossServerPlayerTracker.getInstance();
                                       var54.registerEvents(var141, var0);
                                       var203 = 219497980 ^ var259;
                                       Logger var56 = var0.getLogger();
                                       String var142 = ljhzayfbam(ltlhuuhyadpljgv(), cqsypbmqaqxabut(), var203);
                                       var56.info(var142);
                                       break label462;
                                    }
                                 } catch (Exception var213) {
                                    var293 = var213;
                                    boolean var306 = false;
                                    break label331;
                                 }

                                 label324:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                                       case 17297464:
                                          var203 ^= 372985971;
                                       case 807377364:
                                          try {
                                             Logger var105 = var0.getLogger();
                                             String var168 = ljhzayfbam(wzxhlqusyypwuox(), cqsypbmqaqxabut(), var203);
                                             var105.warning(var168);
                                             var203 = 939055605 ^ var203;
                                             break label333;
                                          } catch (Exception var212) {
                                             var293 = var212;
                                             boolean var307 = false;
                                             break label324;
                                          }
                                       case 1700984097:
                                       default:
                                          throw new IOException();
                                       case 1785436859:
                                    }
                                 }
                              }

                              switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var203)) {
                                 case -1189687696 -> var203 = 594456952 ^ var203;
                                 case 28462290 -> var203 = 1954160940 ^ var203;
                                 case 147607016 -> var203 = 894820619 ^ var203;
                                 case 420422920 -> var203 = 929926167 ^ var203;
                                 case 1906641640 -> var203 = zdsrxvnrgdagzdeu(var203, 980994539);
                                 default -> throw new IllegalAccessException("Error in hash");
                              }

                              Exception var101 = var293;
                              var203 = 1865820019 ^ var203;
                              Logger var103 = var0.getLogger();
                              String var166 = var101.getMessage();
                              String var167 = "[CrossServer] Player tracker initialization failed: " + var166;
                              var103.warning(var167);
                              var203 = 1024738642 ^ var203;
                              break label334;
                           }

                           var203 = 603710618 ^ var203;
                        }

                        var203 = zdsrxvnrgdagzdeu(var203, 1186204332);
                     }

                     label312: {
                        label463: {
                           Exception var294;
                           label310: {
                              label464: {
                                 try {
                                    o0KoOK.init(var0);
                                    var203 = 1987370279 ^ var203;
                                    o0KoOK var58 = o0KoOK.getInstance();
                                    byte var59 = var58.connectRedis();
                                    if (var59 != (270194608 ^ var203)) {
                                       var203 = 1967169430 ^ var203;
                                       Logger var100 = var0.getLogger();
                                       String var164 = ljhzayfbam(sdlkkpkmgrrymkl(), cqsypbmqaqxabut(), var203);
                                       var100.info(var164);
                                       break label464;
                                    }
                                 } catch (Exception var211) {
                                    var294 = var211;
                                    boolean var308 = false;
                                    break label310;
                                 }

                                 var203 = zdsrxvnrgdagzdeu(var203, 1534158942);

                                 try {
                                    Logger var61 = var0.getLogger();
                                    String var143 = ljhzayfbam(rlqswzrykagsroc(), cqsypbmqaqxabut(), var203);
                                    var61.warning(var143);
                                    var203 = 1275642201 ^ var203;
                                    break label463;
                                 } catch (Exception var210) {
                                    var294 = var210;
                                    boolean var309 = false;
                                    break label310;
                                 }
                              }

                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                                    case 7860375:
                                    default:
                                       throw new IOException();
                                    case 73305747:
                                       var203 ^= 1647916689;
                                    case 1003339295:
                                       break label463;
                                    case 1341693091:
                                 }
                              }
                           }

                           switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var203)) {
                              case -2133410432 -> var203 = 976337310 ^ var203;
                              case 718422323 -> var203 = 1332815368 ^ var203;
                              case 862999739 -> var203 = 1279616185 ^ var203;
                              case 1532886898 -> var203 = 1631637952 ^ var203;
                              default -> throw new IOException("Error in hash");
                           }

                           Exception var96 = var294;
                           var203 = 240894967 ^ var203;
                           Logger var98 = var0.getLogger();
                           String var162 = var96.getMessage();
                           String var163 = "[CrossServer] Duel manager initialization failed: " + var162;
                           var98.warning(var163);
                           var203 = 429653728 ^ var203;
                           break label312;
                        }

                        var203 = zdsrxvnrgdagzdeu(var203, 982003086);
                     }

                     label287: {
                        label465: {
                           Exception var295;
                           label285: {
                              label284: {
                                 try {
                                    oOKoOo0K.init(var0);
                                    var203 ^= 1294019029;
                                    oOKoOo0K var63 = oOKoOo0K.getInstance();
                                    byte var64 = var63.connectRedis();
                                    if (var64 != (1892317932 ^ var203)) {
                                       int var270 = 1019485099 ^ var203;
                                       PluginManager var65 = Bukkit.getPluginManager();
                                       oOoOoOoOKoOK var144 = new oOoOoOoOKoOK(var0);
                                       var65.registerEvents(var144, var0);
                                       var203 = 809905715 ^ var270;
                                       Logger var67 = var0.getLogger();
                                       String var145 = ljhzayfbam(olqymgdmriflyja(), cqsypbmqaqxabut(), var203);
                                       var67.info(var145);
                                       break label284;
                                    }
                                 } catch (Exception var209) {
                                    var295 = var209;
                                    boolean var310 = false;
                                    break label285;
                                 }

                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                                       case 176701155:
                                          var203 ^= 1033099850;
                                       case 1983311460:
                                          try {
                                             Logger var95 = var0.getLogger();
                                             String var160 = ljhzayfbam(knjeofqdghcpifu(), cqsypbmqaqxabut(), var203);
                                             var95.info(var160);
                                             var203 = 1579945862 ^ var203;
                                             break label465;
                                          } catch (Exception var208) {
                                             var295 = var208;
                                             boolean var311 = false;
                                             break label285;
                                          }
                                       case 889935683:
                                          break;
                                       case 1228840187:
                                       default:
                                          throw new IOException();
                                    }
                                 }
                              }

                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                                    case 13395384:
                                       var203 ^= 1866326100;
                                       break label465;
                                    case 296225076:
                                    default:
                                       throw new IOException();
                                    case 497112377:
                                       break;
                                    case 862634991:
                                       break label465;
                                 }
                              }
                           }

                           switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var203)) {
                              case -2041325725 -> var203 = 927541315 ^ var203;
                              case -498959453 -> var203 = zdsrxvnrgdagzdeu(var203, 1003167195);
                              case -279275063 -> var203 = zdsrxvnrgdagzdeu(var203, 2053636502);
                              case 1618151994 -> var203 = 193803240 ^ var203;
                              case 1791821106 -> var203 = zdsrxvnrgdagzdeu(var203, 182120969);
                              default -> throw new IllegalAccessException("Error in hash");
                           }

                           Exception var68 = var295;
                           var203 = 40555644 ^ var203;
                           Logger var70 = var0.getLogger();
                           String var147 = var68.getMessage();
                           String var148 = "[CrossServer] RTP initialization failed: " + var147;
                           var70.warning(var148);
                           var203 = 1657560985 ^ var203;
                           break label287;
                        }

                        var203 = zdsrxvnrgdagzdeu(var203, 877688426);
                     }

                     label256: {
                        label255: {
                           label466: {
                              Exception var296;
                              label467: {
                                 try {
                                    oOoOKKo0K.init(var0);
                                    var203 = 1222016344 ^ var203;
                                    oOoOKKo0K var72 = oOoOKKo0K.getInstance();
                                    byte var73 = var72.connectRedis();
                                    if (var73 != (1878238226 ^ var203)) {
                                       var203 = 1943667514 ^ var203;
                                       Logger var75 = var0.getLogger();
                                       String var149 = ljhzayfbam(rwkiqtfeeamkxtp(), cqsypbmqaqxabut(), var203);
                                       var75.info(var149);
                                       break label466;
                                    }
                                 } catch (Exception var207) {
                                    var296 = var207;
                                    boolean var312 = false;
                                    break label467;
                                 }

                                 var203 = 1573742661 ^ var203;

                                 try {
                                    Logger var93 = var0.getLogger();
                                    String var159 = ljhzayfbam(uvuykaocatpawdx(), cqsypbmqaqxabut(), var203);
                                    var93.info(var159);
                                    var203 = 828191457 ^ var203;
                                    break label255;
                                 } catch (Exception var206) {
                                    var296 = var206;
                                    boolean var313 = false;
                                 }
                              }

                              switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var203)) {
                                 case -1846123847 -> var203 = 209941423 ^ var203;
                                 case -515032768 -> var203 = zdsrxvnrgdagzdeu(var203, 580131024);
                                 case 959367761 -> var203 = 429418162 ^ var203;
                                 case 2141003923 -> var203 = zdsrxvnrgdagzdeu(var203, 1364073450);
                                 default -> throw new RuntimeException("Error in hash");
                              }

                              Exception var89 = var296;
                              var203 = 1746602153 ^ var203;
                              Logger var91 = var0.getLogger();
                              String var157 = var89.getMessage();
                              String var158 = "[CrossServer] Combat initialization failed: " + var157;
                              var91.warning(var158);
                              var203 = 804805938 ^ var203;
                              break label256;
                           }

                           var203 = 524966302 ^ var203;
                        }

                        var203 = 2050823381 ^ var203;
                     }

                     Exception var297;
                     label240: {
                        label468: {
                           try {
                              oOoOo0KKoOK.init(var0);
                              var203 ^= 641922060;
                              oOoOo0KKoOK var77 = oOoOo0KKoOK.getInstance();
                              byte var78 = var77.connectRedis();
                              if (var78 != (1595678319 ^ var203)) {
                                 var203 = 1986463250 ^ var203;
                                 Logger var80 = var0.getLogger();
                                 String var150 = ljhzayfbam(cbupfgwhewytxfz(), cqsypbmqaqxabut(), var203);
                                 var80.info(var150);
                                 break label468;
                              }
                           } catch (Exception var205) {
                              var297 = var205;
                              boolean var314 = false;
                              break label240;
                           }

                           label228:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                                 case 138814955:
                                    var203 ^= 281292135;
                                    break label228;
                                 case 1272213458:
                                    break;
                                 case 1527161331:
                                    break label228;
                                 case 2018850419:
                                 default:
                                    throw new IOException();
                              }
                           }

                           try {
                              Logger var88 = var0.getLogger();
                              String var155 = ljhzayfbam(soydwdfotyeyxon(), cqsypbmqaqxabut(), var203);
                              var88.info(var155);
                              var203 = 1893209548 ^ var203;
                              break label505;
                           } catch (Exception var204) {
                              var297 = var204;
                              boolean var315 = false;
                              break label240;
                           }
                        }

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var203)) {
                              case 6182409:
                                 var203 ^= 377175737;
                                 break label505;
                              case 125068521:
                              default:
                                 throw new IOException();
                              case 1260317988:
                                 break label505;
                              case 1643575257:
                           }
                        }
                     }

                     switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var203)) {
                        case -889760997 -> var203 = 1791881091 ^ var203;
                        case -119475334 -> var203 = 1284447119 ^ var203;
                        case 1272497129 -> var203 = zdsrxvnrgdagzdeu(var203, 988290461);
                        case 2126616642 -> var203 = zdsrxvnrgdagzdeu(var203, 1548433128);
                        default -> throw new IOException("Error in hash");
                     }

                     Exception var84 = var297;
                     var203 = 1667132263 ^ var203;
                     Logger var86 = var0.getLogger();
                     String var153 = var84.getMessage();
                     String var154 = "[CrossServer] EnderChest initialization failed: " + var153;
                     var86.warning(var154);
                     var203 = 1953056963 ^ var203;
                     break label445;
                  }

                  var203 = zdsrxvnrgdagzdeu(var203, 1000603776);
               }

               byte var81 = (byte)(77866565 ^ var203);
               initialized = (boolean)var81;
               var203 = 2053274991 ^ var203;
               Logger var83 = var0.getLogger();
               String var151 = ljhzayfbam(smclnphondvypfm(), cqsypbmqaqxabut(), var203);
               var83.info(var151);
               var203 = 1878614501 ^ var203;
            }
         }
      }
   }

   public static void shutdown() {
      int var88 = 1669622939 ^ 221108819 ^ 2122528657;
      var88 = 106611279 ^ var88;
      byte var0 = initialized;
      if (var0 == (376455958 ^ var88)) {
         var88 = 412927270 ^ var88;
      } else {
         var88 = zdsrxvnrgdagzdeu(var88, 803564741);

         label335: {
            label334: {
               label352: {
                  Exception var10000;
                  label353: {
                     label331: {
                        try {
                           KoOo0KKoOK var3 = KoOo0KKoOK.getInstance();
                           if (var3 != null) {
                              var88 = 342969589 ^ var88;
                              KoOo0KKoOK var4 = KoOo0KKoOK.getInstance();
                              var4.disconnect();
                              var88 = 1859456939 ^ var88;
                              break label331;
                           }
                        } catch (Exception var100) {
                           var10000 = var100;
                           boolean var10001 = false;
                           break label353;
                        }

                        label330:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var88)) {
                              case 261174589:
                                 var88 ^= 2057585502;
                                 break label330;
                              case 1123174587:
                                 break;
                              case 1759605060:
                                 break label330;
                              case 1889800603:
                              default:
                                 throw new IOException();
                           }
                        }
                     }

                     label316: {
                        try {
                           oOoOo0oOo0K var5 = oOoOo0oOo0K.getInstance();
                           if (var5 != null) {
                              var88 = 785293413 ^ var88;
                              oOoOo0oOo0K var6 = oOoOo0oOo0K.getInstance();
                              var6.shutdown();
                              var88 = 1694925111 ^ var88;
                              break label316;
                           }
                        } catch (Exception var99) {
                           var10000 = var99;
                           boolean var153 = false;
                           break label353;
                        }

                        var88 = zdsrxvnrgdagzdeu(var88, 1271406930);
                     }

                     try {
                        o0oOo0o0o0K var7 = o0oOo0o0o0K.getInstance();
                        if (var7 != null) {
                           var88 = 1338511619 ^ var88;
                           o0oOo0o0o0K var8 = o0oOo0o0o0K.getInstance();
                           var8.clearAllCache();
                           var88 = 1631897906 ^ var88;
                           break label334;
                        }
                        break label352;
                     } catch (Exception var98) {
                        var10000 = var98;
                        boolean var154 = false;
                     }
                  }

                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                     case -861307239 -> var88 = zdsrxvnrgdagzdeu(var88, 1903582740);
                     case 428565610 -> var88 = 198319434 ^ var88;
                     case 965404386 -> var88 = 265432347 ^ var88;
                     case 1204449016 -> var88 = zdsrxvnrgdagzdeu(var88, 1075461144);
                     case 1864571185 -> var88 = zdsrxvnrgdagzdeu(var88, 1694962401);
                     case 1878943555 -> var88 = 622640431 ^ var88;
                     default -> throw new RuntimeException("Error in hash");
                  }

                  Exception var45 = var10000;
                  var88 = 655058316 ^ var88;
                  Logger var46 = Bukkit.getLogger();
                  String var75 = var45.getMessage();
                  String var76 = "[CrossServer] Homes shutdown error: " + var75;
                  var46.warning(var76);
                  var88 = 2040884339 ^ var88;
                  break label335;
               }

               label306:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var88)) {
                     case 23268889:
                        var88 ^= 780982321;
                        break label306;
                     case 447780352:
                        break;
                     case 714602370:
                        break label306;
                     case 770813968:
                     default:
                        throw new IOException();
                  }
               }
            }

            var88 = zdsrxvnrgdagzdeu(var88, 809037270);
         }

         label293: {
            label292: {
               try {
                  o0oOoOK var9 = o0oOoOK.getInstance();
                  if (var9 != null) {
                     var88 = 579619710 ^ var88;
                     o0oOoOK var10 = o0oOoOK.getInstance();
                     var10.disconnect();
                     var88 = 1904213757 ^ var88;
                     break label292;
                  }
               } catch (Exception var97) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                     case -1509320143 -> var88 = 640028570 ^ var88;
                     case -1301560896 -> var88 = zdsrxvnrgdagzdeu(var88, 78267620);
                     default -> throw new IllegalAccessException("Error in hash");
                  }

                  var88 = 262522912 ^ var88;
                  Logger var12 = Bukkit.getLogger();
                  String var47 = var97.getMessage();
                  String var48 = "[CrossServer] TPA shutdown error: " + var47;
                  var12.warning(var48);
                  var88 = 1458402972 ^ var88;
                  break label293;
               }

               var88 = zdsrxvnrgdagzdeu(var88, 1408480643);
            }

            var88 = zdsrxvnrgdagzdeu(var88, 236015579);
         }

         label279: {
            label278: {
               try {
                  o0oOo0oOo0K var13 = o0oOo0oOo0K.getInstance();
                  if (var13 != null) {
                     var88 = 988899963 ^ var88;
                     o0oOo0oOo0K var14 = o0oOo0oOo0K.getInstance();
                     var14.disconnect();
                     var88 = 1901386625 ^ var88;
                     break label278;
                  }
               } catch (Exception var96) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                     case -1963507493 -> var88 = 1637083147 ^ var88;
                     case 1568412418 -> var88 = 1533182576 ^ var88;
                     default -> throw new RuntimeException("Error in hash");
                  }

                  var88 = 1874578088 ^ var88;
                  Logger var44 = Bukkit.getLogger();
                  String var72 = var96.getMessage();
                  String var73 = "[CrossServer] Spawns shutdown error: " + var72;
                  var44.warning(var73);
                  var88 = 1700001558 ^ var88;
                  break label279;
               }

               label272:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var88)) {
                     case 44320565:
                        var88 ^= 1269150202;
                        break label272;
                     case 240171694:
                     default:
                        throw new IOException();
                     case 515519152:
                        break;
                     case 1452241167:
                        break label272;
                  }
               }
            }

            var88 = 439291444 ^ var88;
         }

         label256: {
            label255: {
               try {
                  KKo0o0oOK var15 = KKo0o0oOK.getInstance();
                  if (var15 != null) {
                     var88 = 1676087321 ^ var88;
                     KKo0o0oOK var16 = KKo0o0oOK.getInstance();
                     var16.disconnect();
                     var88 = 660943683 ^ var88;
                     break label255;
                  }
               } catch (Exception var95) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                     case -837718597 -> var88 = 1978998325 ^ var88;
                     case -785781392 -> var88 = 370282028 ^ var88;
                     default -> throw new RuntimeException("Error in hash");
                  }

                  var88 = 1923472832 ^ var88;
                  Logger var18 = Bukkit.getLogger();
                  String var50 = var95.getMessage();
                  String var51 = "[CrossServer] Auction sync shutdown error: " + var50;
                  var18.warning(var51);
                  var88 = 1654032966 ^ var88;
                  break label256;
               }

               label249:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var88)) {
                     case 44580260:
                        var88 ^= 1149379418;
                        break label249;
                     case 283124105:
                     default:
                        throw new IOException();
                     case 309502237:
                        break;
                     case 815297933:
                        break label249;
                  }
               }
            }

            var88 = zdsrxvnrgdagzdeu(var88, 1118010096);
         }

         label233: {
            label232: {
               try {
                  o0KoOK var19 = o0KoOK.getInstance();
                  if (var19 != null) {
                     var88 = 371695616 ^ var88;
                     o0KoOK var20 = o0KoOK.getInstance();
                     var20.disconnect();
                     var88 = 1690054167 ^ var88;
                     break label232;
                  }
               } catch (Exception var94) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                     case -534568928 -> var88 = 1884485827 ^ var88;
                     case 1360928800 -> var88 = 1718966467 ^ var88;
                     default -> throw new RuntimeException("Error in hash");
                  }

                  var88 = 1129805983 ^ var88;
                  Logger var42 = Bukkit.getLogger();
                  String var69 = var94.getMessage();
                  String var70 = "[CrossServer] Duel manager shutdown error: " + var69;
                  var42.warning(var70);
                  var88 = 168420641 ^ var88;
                  break label233;
               }

               var88 = zdsrxvnrgdagzdeu(var88, 1922797079);
            }

            var88 = zdsrxvnrgdagzdeu(var88, 1268247402);
         }

         label219: {
            label218: {
               try {
                  CrossServerPlayerTracker var21 = CrossServerPlayerTracker.getInstance();
                  if (var21 != null) {
                     var88 = 1162076668 ^ var88;
                     CrossServerPlayerTracker var22 = CrossServerPlayerTracker.getInstance();
                     var22.disconnect();
                     var88 = 1669742536 ^ var88;
                     break label218;
                  }
               } catch (Exception var93) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                     case 39781419 -> var88 = zdsrxvnrgdagzdeu(var88, 964908260);
                     case 675285961 -> var88 = 2093004056 ^ var88;
                     default -> throw new RuntimeException("Error in hash");
                  }

                  var88 = 362821674 ^ var88;
                  Logger var24 = Bukkit.getLogger();
                  String var53 = var93.getMessage();
                  String var54 = "[CrossServer] Player tracker shutdown error: " + var53;
                  var24.warning(var54);
                  var88 = 1048461203 ^ var88;
                  break label219;
               }

               var88 = zdsrxvnrgdagzdeu(var88, 650501684);
            }

            var88 = zdsrxvnrgdagzdeu(var88, 1910205589);
         }

         label205: {
            label204: {
               try {
                  oOKoOo0K var25 = oOKoOo0K.getInstance();
                  if (var25 != null) {
                     var88 = 1846606667 ^ var88;
                     oOKoOo0K var26 = oOKoOo0K.getInstance();
                     var26.disconnect();
                     var88 = 584658832 ^ var88;
                     break label204;
                  }
               } catch (Exception var92) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                     case -1867145533 -> var88 = 532311430 ^ var88;
                     case -533576552 -> var88 = zdsrxvnrgdagzdeu(var88, 1907005133);
                     default -> throw new IllegalAccessException("Error in hash");
                  }

                  var88 = 815462254 ^ var88;
                  Logger var40 = Bukkit.getLogger();
                  String var66 = var92.getMessage();
                  String var67 = "[CrossServer] RTP shutdown error: " + var66;
                  var40.warning(var67);
                  var88 = 1606823167 ^ var88;
                  break label205;
               }

               var88 = zdsrxvnrgdagzdeu(var88, 1288295643);
            }

            var88 = zdsrxvnrgdagzdeu(var88, 1009738444);
         }

         label191: {
            label190: {
               try {
                  oOoOKKo0K var27 = oOoOKKo0K.getInstance();
                  if (var27 != null) {
                     var88 = 1788833623 ^ var88;
                     oOoOKKo0K var28 = oOoOKKo0K.getInstance();
                     var28.disconnect();
                     var88 = 962844689 ^ var88;
                     break label190;
                  }
               } catch (Exception var91) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                     case 394276472 -> var88 = 688272802 ^ var88;
                     case 1132156099 -> var88 = 1134123765 ^ var88;
                     default -> throw new RuntimeException("Error in hash");
                  }

                  var88 = 1246866363 ^ var88;
                  Logger var38 = Bukkit.getLogger();
                  String var63 = var91.getMessage();
                  String var64 = "[CrossServer] Combat shutdown error: " + var63;
                  var38.warning(var64);
                  var88 = 377498078 ^ var88;
                  break label191;
               }

               var88 = 1409070918 ^ var88;
            }

            var88 = 640352385 ^ var88;
         }

         label177: {
            label176: {
               try {
                  oOoOo0KKoOK var29 = oOoOo0KKoOK.getInstance();
                  if (var29 != null) {
                     var88 = 656957575 ^ var88;
                     oOoOo0KKoOK var30 = oOoOo0KKoOK.getInstance();
                     var30.disconnect();
                     var88 = 1167457229 ^ var88;
                     break label176;
                  }
               } catch (Exception var90) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                     case -2139188102 -> var88 = 489814263 ^ var88;
                     case -1187147709 -> var88 = 974755952 ^ var88;
                     default -> throw new RuntimeException("Error in hash");
                  }

                  var88 = 824296488 ^ var88;
                  Logger var36 = Bukkit.getLogger();
                  String var60 = var90.getMessage();
                  String var61 = "[CrossServer] EnderChest shutdown error: " + var60;
                  var36.warning(var61);
                  var88 = 1384302239 ^ var88;
                  break label177;
               }

               var88 = zdsrxvnrgdagzdeu(var88, 1656593226);
            }

            var88 = zdsrxvnrgdagzdeu(var88, 990314893);
         }

         label163: {
            try {
               SharedRedisPool.shutdown();
               var88 = 1226091362 ^ var88;
            } catch (Exception var89) {
               switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var88)) {
                  case 1961444985:
                     var88 = zdsrxvnrgdagzdeu(var88, 1227081065);
                     var88 = 94427452 ^ var88;
                     Logger var34 = Bukkit.getLogger();
                     String var57 = var89.getMessage();
                     String var58 = "[CrossServer] SharedRedisPool shutdown error: " + var57;
                     var34.warning(var58);
                     var88 = 1223712548 ^ var88;
                     break label163;
                  default:
                     throw new IOException("Error in hash");
               }
            }

            label156:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var88)) {
                  case 144312470:
                     var88 ^= 1298655251;
                     break label156;
                  case 276536987:
                     break;
                  case 323254434:
                     break label156;
                  case 714556175:
                  default:
                     throw new IOException();
               }
            }
         }

         byte var31 = (byte)(720268222 ^ var88);
         initialized = (boolean)var31;
         var88 = 1877433833 ^ var88;
         Logger var32 = Bukkit.getLogger();
         String var55 = ljhzayfbam(gcktzoumnlmhtcg(), cqsypbmqaqxabut(), var88);
         var32.info(var55);
         var88 = 1888781003 ^ var88;
      }
   }

   public static boolean isHomesEnabled() {
      int var6 = 1792865959 ^ 506855061 ^ 2122528657;
      var6 = 1488674533 ^ var6;
      KoOo0KKoOK var0 = KoOo0KKoOK.getInstance();
      byte var3;
      if (var0 != null) {
         var6 ^= 35346239;
         KoOo0KKoOK var1 = KoOo0KKoOK.getInstance();
         byte var2 = var1.isConnected();
         if (var2 != (1355429497 ^ var6)) {
            var6 = 193950230 ^ var6;
            var3 = (byte)(1531266158 ^ var6);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var6)) {
                  case 14053330:
                     var6 = 791765490 ^ var6;
                     return (boolean)var3;
                  case 826030106:
                     break;
                  case 921254087:
                  default:
                     throw new IOException();
                  case 1350634644:
                     return (boolean)var3;
               }
            }
         }

         label46:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var6)) {
               case 98815044:
                  break;
               case 210213184:
                  var6 ^= 654736346;
               case 539656511:
                  break label46;
               case 1868394427:
               default:
                  throw new IOException();
            }
         }
      } else {
         label37:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var6)) {
               case 7732902:
                  var6 ^= 622669029;
                  break label37;
               case 978961944:
                  break;
               case 1217392123:
                  break label37;
               case 1898145261:
               default:
                  throw new IOException();
            }
         }
      }

      var3 = (byte)(2009877923 ^ var6);
      var6 = 62416958 ^ var6;
      return (boolean)var3;
   }

   public static boolean isTPAEnabled() {
      int var6 = 1961002609 ^ 734062557 ^ 2122528657;
      var6 = 902877113 ^ var6;
      o0oOoOK var0 = o0oOoOK.getInstance();
      byte var3;
      if (var0 != null) {
         var6 = 989548702 ^ var6;
         o0oOoOK var1 = o0oOoOK.getInstance();
         byte var2 = var1.isConnected();
         if (var2 != (780847386 ^ var6)) {
            var6 = 2118802042 ^ var6;
            var3 = (byte)(1354797921 ^ var6);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var6)) {
                  case 192348460:
                     break;
                  case 209014090:
                     var6 = 1259378058 ^ var6;
                     return (boolean)var3;
                  case 315836594:
                     return (boolean)var3;
                  case 1335925043:
                  default:
                     throw new RuntimeException();
               }
            }
         }

         var6 = 1298950128 ^ var6;
      } else {
         label37:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var6)) {
               case 127667486:
                  var6 ^= 2006398830;
               case 461006897:
                  break label37;
               case 1615767210:
                  break;
               case 1657710661:
               default:
                  throw new RuntimeException();
            }
         }
      }

      var3 = (byte)(1676062442 ^ var6);
      var6 = 2016847872 ^ var6;
      return (boolean)var3;
   }

   public static boolean isSpawnsEnabled() {
      int var6 = 1522576919 ^ 1609611794 ^ 2122528657;
      var6 = 163940790 ^ var6;
      o0oOo0oOo0K var0 = o0oOo0oOo0K.getInstance();
      byte var3;
      if (var0 != null) {
         var6 = 1739221109 ^ var6;
         o0oOo0oOo0K var1 = o0oOo0oOo0K.getInstance();
         byte var2 = var1.isConnected();
         if (var2 != (366789207 ^ var6)) {
            var6 = 1497553144 ^ var6;
            var3 = (byte)(1285429934 ^ var6);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var6)) {
                  case 74587949:
                     var6 = 476739364 ^ var6;
                     return (boolean)var3;
                  case 1016535808:
                     return (boolean)var3;
                  case 1279877394:
                     break;
                  case 1482597930:
                  default:
                     throw new RuntimeException();
               }
            }
         }

         label36:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var6)) {
               case 173780308:
                  var6 ^= 701521260;
               case 1161594628:
                  break label36;
               case 1423521733:
                  break;
               case 1617896505:
               default:
                  throw new RuntimeException();
            }
         }
      } else {
         var6 = zdsrxvnrgdagzdeu(var6, 1316631833);
      }

      var3 = (byte)(1007460155 ^ var6);
      var6 = 1828254384 ^ var6;
      return (boolean)var3;
   }

   public static String getServerId() {
      int var7 = 1677307986 ^ 1421707345 ^ 2122528657;
      var7 = 245070412 ^ var7;
      DonutSMPCore var0 = DonutSMPCore.getInstance();
      FileConfiguration var3 = var0.getConfig();
      String var1 = ljhzayfbam(cvphbksipsvlrak(), cqsypbmqaqxabut(), var7);
      String var2 = ljhzayfbam(yznybizjqardknl(), cqsypbmqaqxabut(), var7);
      String var4 = var3.getString(var1, var2);
      return var4;
   }

   static {
      int var3 = 1810362627 ^ 413397560 ^ Integer.parseInt("597992413");
      var3 = 2045376342 ^ var3;
      byte var0 = (byte)(688478128 ^ var3);
      initialized = (boolean)var0;
      var3 = 1493103048 ^ var3;
   }

   public static String ljhzayfbam(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] cqsypbmqaqxabut() {
      return new byte[]{14, 76, 105, 72, 53, 50, 20, 123, 61, 18, 87, 51, 57, 78, 22, 1, 40, 117, 35, 100, 68, 31, 25, 105, 124, 32, 44, 7, 91, 77, 86, 80, 57, 55, 61, 3, 73, 38, 88, 124, 60, 100, 58, 4, 29, 76, 12, 108, 53, 12, 21, 64, 120, 76, 78, 17, 33, 84, 104, 37, 86, 8, 108, 73, 89, 70, 66, 70, 21, 26, 13, 29, 67, 109, 108, 106, 3, 106, 87, 75, 53, 97, 111, 66, 14, 51, 18, 115, 2, 8, 7, 65, 102, 72};
   }

   private static byte[] cbupfgwhewytxfz() {
      return new byte[]{-58, -118, 92, 42, 6, 66, 36, 60, 14, 75, 110, 117, 0, 14, 37, 98, 29, 35, 21, 47, 113, 80, 42, 63, 76, 103, 31, 108, 98, 88, 111, 38, 10, 105, 8, 84, 127, 122, 109, 55, 15, 20, 10, 89, 46, 31, 53, 42, 12, 75, 38, 74, 77, 95, 120, 122, 20, 8, 91, 114, 102, 84, 95, 12, 96, 83, 123, 22, 38, 69, 56, 64, 117, 58, 89, 54, 48, 58, 103, 10, 6, 50, 86, 19, 55, 32, 1, 87, 55, 27, 49, 27, 83, 25, 61, 26, 89, 14, 6, 112, 45, 110, 4, 66, 100, 108, 12, 19, 32, 76, 29, 41, 16, 57, 116, 94, 42, 44, 69, 53, 21, 82, 104, 18, 99, 15, 15, 98, 8, 85, 122, 98, 104, 105, 15, 34, 3, 93, 36, 30, 63, 37, 0, 90, 35, 11, 77, 6, 125, 2, 17, 0, 91, 112, 111, 79, 85, 21, 106, 5, 119, 6, 35, 3, 56, 87, 112, 59, 92, 45, 48, 42, 110, 27, 12, 32, 92, 1, 59, 46};
   }

   private static byte[] qyaictxijfpkjsq() {
      return new byte[]{-63, -121, 95, 34, 6, 67, 35, 61, 13, 72, 102, 116, 15, 12, 37, 96, 31, 36, 19, 35, 117, 93, 47, 61, 79, 96, 27, 110, 107, 88, 103, 54, 15, 99, 14, 85, 126, 123, 104, 58, 13, 112, 12, 92, 46, 13, 59, 120, 5, 93, 36, 29, 78, 14, 125, 66, 22, 2, 88, 124, 103, 89, 90, 28, 106, 90, 117, 82, 37, 125, 60, 92, 117, 50, 95, 54, 52, 55, 103, 16, 4, 50, 89, 83, 61, 104, 37, 41, 50, 29, 54, 6, 80, 16, 61, 16, 94, 27, 5, 107, 37, 42, 11, 14, 100, 114, 14, 31, 38, 70, 25, 55, 21, 48, 119, 95, 46, 125, 76, 120, 29, 92, 109, 24, 101, 7, 14, 45};
   }

   private static byte[] eaeaptmpttxyjez() {
      return new byte[]{-61, -126, 88, 37, 1, 69, 36, 49, 13, 78, 102, 113, 15, 9, 34, 98, 16, 32, 16, 39, 117, 95, 45, 56, 76, 106, 28, 105, 106, 92, 96, 48, 13, 87, 5, 114, 122, 45, 105, 106, 8, 2, 10, 89, 45, 27, 61, 52, 3, 75, 33, 80, 64, 31, 125, 79, 16, 12, 92, 127, 102, 85, 92, 25, 104, 3, 116, 27, 33, 69, 53, 67, 112, 124, 93, 58, 55, 63, 103, 26, 5, 62, 94, 22, 56, 99, 38, 109};
   }

   private static byte[] rwkiqtfeeamkxtp() {
      return new byte[]{-60, -124, 91, 39, 12, 64, 44, 56, 11, 73, 96, 114, 13, 4, 39, 106, 25, 38, 23, 33, 118, 93, 32, 61, 68, 99, 26, 110, 108, 95, 98, 42, 8, 96, 12, 88, 125, 115, 106, 41, 5, 33, 2, 15, 43, 88, 59, 12, 1, 80, 36, 28, 73, 19, 122, 85, 19, 64, 81, 119, 110, 86, 90, 19, 110, 26, 118, 26, 36, 65, 60, 95, 119, 63, 94, 58, 58, 123, 79, 110, 3, 117, 88, 19, 58, 101, 35, 38, 51, 92, 51, 23, 84, 8, 55, 93, 81, 13, 3, 111, 35, 36, 9, 78, 102, 121, 8, 88, 34, 69, 26, 56, 26, 59, 124, 77, 47, 46, 75, 50, 24, 95, 106, 22, 103, 20, 13, 111, 15, 68, 112, 100, 96, 109, 10, 35, 13, 83, 41, 7, 61, 34, 4, 95, 33, 5, 74, 11, 119, 14};
   }

   private static byte[] uvuykaocatpawdx() {
      return new byte[]{-56, -121, 91, 42, 2, 71, 39, 61, 14, 69, 99, 114, 0, 10, 32, 97, 28, 35, 27, 34, 118, 80, 46, 58, 79, 102, 31, 98, 111, 95, 111, 36, 15, 107, 9, 93, 113, 112, 106, 36, 11, 38, 9, 10, 46, 84, 56, 61, 12, 73, 35, 28, 76, 12, 118, 86, 19, 64, 95, 96, 101, 89, 95, 3, 109, 2, 123, 20, 35, 91, 57, 14, 123, 52, 94, 60, 52, 56, 100, 26, 6, 121, 91, 20, 55, 109, 36, 51, 54, 90, 63, 23, 84, 29, 57, 31, 90, 24, 6, 42, 32, 38, 4, 87, 97, 32, 13, 47, 46, 80, 26, 40, 20, 59, 119, 88, 42, 113, 72, 103, 21, 94, 109, 31, 98, 21, 1, 98, 15, 83, 126, 124, 107, 41, 15, 62, 14, 90, 36, 30, 58, 127, 33, 43, 45, 84, 74, 6, 121, 78, 18, 14, 91, 122, 98, 86, 85, 27, 111, 88, 118, 6, 45, 75, 63, 86, 116, 45, 95, 59, 48, 32, 99, 89, 12, 57, 89, 31, 58, 108, 42, 62, 48, 31};
   }

   private static byte[] ltlhuuhyadpljgv() {
      return new byte[]{-59, -127, 92, 38, 7, 73, 34, 60, 8, 79, 98, 117, 11, 5, 32, 103, 29, 34, 22, 35, 118, 81, 47, 57, 73, 96, 25, 111, 105, 85, 96, 53, 12, 105, 8, 87, 123, 103, 110, 44, 9, 36, 15, 17, 47, 0, 58, 43, 0, 95, 32, 22, 74, 31, 120, 65, 20, 20, 93, 42, 100, 16, 90, 46, 108, 17, 119, 23, 39, 75, 59, 91, 118, 127, 89, 60, 49, 61, 97, 16, 0, 61, 90, 18, 60, 104, 36, 50, 55, 95, 50, 16, 84, 81};
   }

   private static byte[] soydwdfotyeyxon() {
      return new byte[]{-63, -128, 90, 42, 0, 71, 44, 48, 13, 73, 102, 115, 10, 4, 35, 100, 16, 41, 19, 34, 117, 90, 42, 53, 73, 100, 20, 99, 107, 89, 103, 38, 10, 96, 8, 81, 113, 122, 104, 58, 13, 20, 9, 85, 40, 31, 52, 38, 5, 76, 36, 73, 75, 85, 123, 68, 25, 31, 88, 126, 103, 72, 95, 3, 108, 93, 122, 12, 37, 75, 60, 92, 112, 34, 89, 57, 59, 33, 103, 95, 4, 63, 92, 20, 59, 97, 42, 47, 50, 28, 54, 22, 85, 24, 59, 9, 81, 16, 5, 100, 37, 36, 14, 78, 98, 97, 1, 87, 38, 90, 25, 52, 16, 125, 113, 123, 33, 53, 76, 112, 29, 93, 104, 7, 99, 70, 1, 123, 13, 89, 120, 116, 107, 51, 9, 51, 2, 84, 45, 20, 61, 62, 6, 87, 32, 26, 64, 16, 126, 5, 48, 115, 91, 60, 99, 77, 84, 25, 105, 28, 115, 18, 38, 79, 56, 78, 123, 121, 92, 45, 50, 60, 100, 0, 0, 33, 87, 30, 62, 117, 35, 96, 49, 94, 50, 25, 94, 29, 62, 1, 88, 85};
   }

   private static byte[] lirdybvooamduix() {
      return new byte[]{-63, -118, 88, 43, 13, 70, 35, 62, 9, 76, 102, 121, 8, 5, 46, 101, 31, 39, 23, 39, 117, 80, 40, 52, 68, 101, 27, 109, 111, 92, 103, 58, 8, 127, 5, 85, 126, 102, 108, 35, 13, 46, 11, 6, 37, 91, 59, 9, 1, 88, 36, 29, 73, 29, 118, 85, 22, 67, 92, 119, 103, 94, 93, 31, 97, 31, 117, 20, 33, 72, 60, 80, 114, 60, 84, 50, 52, 51, 99, 90, 4, 62, 94, 27, 54, 109, 37, 40, 54, 92, 54, 28, 87, 94};
   }

   private static byte[] anbsebamuwevooo() {
      return new byte[]{-60, -128, 93, 43, 12, 70, 32, 48, 14, 73, 100, 116, 1, 4, 33, 102, 17, 35, 23, 37, 112, 81, 32, 59, 72, 107, 31, 110, 104, 89, 110, 58, 14, 115, 4, 81, 125, 98, 108, 42, 5, 32, 14, 7, 46, 88, 63, 10, 13, 80, 34, 16, 65, 22, 122, 81, 21, 76, 81, 113, 98, 94, 95, 19, 106, 28, 122, 26, 34, 77, 52, 90, 119, 59, 88, 54, 58, 124};
   }

   private static byte[] sofblweimfoitrc() {
      return new byte[]{-57, -118, 81, 36, 13, 71, 45, 56, 15, 74, 110, 120, 14, 5, 32, 107, 25, 34, 20, 47, 124, 94, 33, 58, 69, 99, 30, 109, 98, 85, 97, 33, 15, 96, 12, 88, 126, 107, 96, 34, 4, 51, 3, 89, 47, 18, 53, 46, 2, 93, 35, 23, 73, 25, 121, 8, 25, 0, 80, 97, 111, 86, 94, 13, 96, 13, 117, 83, 35, 80, 60, 74, 116, 38, 84, 43, 59, 57, 110, 8, 7, 118, 86, 23, 57, 100, 36, 46, 51, 79, 48, 20, 94, 26, 54, 84, 80, 87, 7, 43};
   }

   private static byte[] plzirpclsbpmucs() {
      return new byte[]{-63, -118, 81, 33, 3, 72, 44, 56, 4, 72, 102, 121, 1, 15, 32, 107, 16, 33, 26, 35, 117, 80, 33, 62, 74, 107, 20, 107, 98, 88, 103, 47, 1, 100, 11, 83, 113, 123, 97, 44, 13, 57, 2, 22, 43, 1, 52, 50, 12, 25, 36, 16, 64, 16, 120, 65, 25, 17, 81, 121, 103, 80, 84, 23, 111, 22, 122, 13, 44, 74, 60, 4, 123, 44, 90, 59, 59, 58, 110, 12, 4, 61, 87, 20, 56, 42, 42, 16, 59, 88, 54, 28, 94, 19, 56, 6, 81, 89, 12, 119, 37, 45, 5, 79, 97, 102, 1, 81, 47, 20, 25, 15, 27, 36, 114, 73, 33, 43, 69, 102, 29, 19, 99, 12, 96, 12, 1, 116, 4, 64, 120, 122, 96, 60, 10, 125, 2, 83, 36, 28, 61, 52, 13, 74, 35, 12, 64, 15, 119, 65, 16, 30, 80, 55, 96, 85, 84, 17, 96, 0, 115, 30, 45, 74, 59, 72, 123, 57, 85, 59, 50, 125};
   }

   private static byte[] wzxhlqusyypwuox() {
      return new byte[]{-61, -117, 81, 34, 0, 72, 45, 60, 13, 78, 111, 120, 8, 8, 47, 107, 29, 32, 16, 46, 124, 88, 44, 53, 69, 103, 28, 105, 99, 85, 103, 53, 0, 98, 8, 82, 122, 103, 96, 40, 9, 47, 3, 17, 45, 11, 52, 38, 4, 88, 44, 26, 77, 23, 125, 76, 25, 23, 93, 38, 111, 29, 92, 40, 97, 27, 115, 23, 44, 74, 56, 94, 112, 117, 84, 56, 54, 60, 110, 16, 5, 60, 87, 31, 63, 101, 43, 62, 55, 81, 52, 22, 94, 23, 59, 85, 80, 27, 5, 96, 44, 42, 12, 75, 110, 111, 12, 26, 37, 23};
   }

   private static byte[] hejhslmygxrzqxk() {
      return new byte[]{-63, -117, 94, 36, 2, 69, 39, 58, 5, 79, 102, 120, 14, 10, 33, 102, 27, 35, 27, 36, 117, 81, 46, 59, 75, 102, 31, 105, 99, 95, 103, 60, 14, 80, 10, 118, 122, 47, 96, 110, 13, 14, 13, 86, 42, 28, 63, 54, 13, 77, 36, 88, 79, 24, 121, 74, 18, 9, 80, 121, 103, 85, 91, 29, 110, 6, 113, 16, 45, 76, 60, 4};
   }

   private static byte[] snvrcoskxchszwx() {
      return new byte[]{-62, -118, 90, 43, 1, 71, 38, 49, 14, 79, 110, 115, 1, 9, 32, 96, 16, 35, 17, 47, 119, 81, 45, 58, 78, 106, 31, 104, 98, 94, 110, 44, 15, 106, 5, 93, 123, 122, 107, 55, 8, 104, 8, 28, 46, 44, 53, 58, 13, 92, 35, 27, 64, 12, 124, 8, 18, 15, 92, 124, 100, 94, 95, 21, 96, 16, 122, 17, 35, 92, 53, 71, 113, 59, 95, 60, 55, 124, 101, 21, 6, 50, 86, 24, 54, 107, 36, 36, 58, 95, 53, 86};
   }

   private static byte[] reootihcsogjepa() {
      return new byte[]{-56, -121, 90, 43, 1, 71, 45, 57, 5, 73, 100, 120, 13, 11, 47, 98, 16, 36, 16, 46, 112, 95, 32, 60, 68, 102, 31, 98, 111, 91, 111, 40, 1, 108, 14, 86, 125, 117, 97, 63, 4, 106, 9, 28, 41, 40, 53, 57, 13, 92, 38, 17, 76, 9, 119, 1, 25, 3, 91, 114, 98, 80, 85, 23, 97, 23, 113, 29, 33, 88, 52, 72, 123, 61, 95, 115};
   }

   private static byte[] yarcvnjucrslhdp() {
      return new byte[]{-63, -128, 89, 12, 2, 110, 39, 57, 10, 85, 100, 102, 14, 11, 47, 31, 24, 43, 18, 51};
   }

   private static byte[] dghucuvzxleaqma() {
      return new byte[]{-63, -128, 89, 12, 2, 110, 39, 57, 10, 85, 100, 102, 14, 11, 47, 31, 24, 115};
   }

   private static byte[] smclnphondvypfm() {
      return new byte[]{-62, -126, 91, 37, 12, 67, 44, 63, 5, 78, 101, 113, 11, 11, 47, 96, 16, 38, 27, 37, 118, 88, 43, 58, 69, 96, 20, 108, 99, 94, 100, 34, 11, 115, 4, 94, 113, 99, 96, 60, 14, 120, 8, 65, 36, 27, 52, 40, 13, 73, 39, 20, 74, 8, 119, 3, 25, 15, 80, 121, 100, 93, 94, 10, 96, 24, 122, 21, 45, 9, 63, 69, 113, 53, 85, 49, 59, 40, 111, 17, 7, 49, 93, 24, 55, 104, 42, 63, 58, 94, 53, 20, 84, 95};
   }

   private static byte[] ihssqelhwnszctv() {
      return new byte[]{-63, -121, 80, 43, 2, 66, 45, 58, 13, 76, 102, 116, 0, 5, 33, 97, 17, 35, 19, 39, 117, 93, 32, 52, 75, 97, 21, 105, 107, 92, 103, 37, 0, 122, 10, 83, 112, 97, 104, 36, 13, 63, 3, 82, 42, 69, 53, 127, 5, 111, 36, 17, 65, 16, 121, 75, 24, 20, 88, 52, 103, 95, 85, 30, 110, 27, 123, 27, 37, 78, 60, 74, 122, 33, 91, 48, 58, 54, 103, 20, 4, 117, 86, 28, 57, 97, 43, 41, 50, 85, 54, 16, 95, 20, 57, 81};
   }

   private static byte[] olqymgdmriflyja() {
      return new byte[]{-62, -125, 81, 38, 4, 64, 39, 62, 12, 75, 101, 112, 1, 8, 39, 99, 27, 39, 18, 32, 118, 89, 33, 57, 77, 99, 31, 109, 106, 91, 100, 50, 1, 86, 12, 98, 122, 43, 105, 106, 14, 6, 2, 84, 44, 25, 63, 50, 4, 73, 39, 80, 64, 26, 127, 79, 18, 13, 89, 125, 100, 93, 84, 31, 104, 3, 113, 20, 36, 72, 63, 12};
   }

   private static byte[] rfnvjqxnzmllngj() {
      return new byte[]{-63, -124, 93, 38, 6, 68, 39, 63, 15, 79, 102, 119, 13, 8, 37, 103, 27, 38, 17, 36, 117, 94, 45, 57, 79, 103, 31, 108, 105, 95, 103, 38, 13, 119, 14, 85, 122, 100, 106, 39, 13, 60, 14, 95, 46, 67, 63, 122, 7, 108, 36, 18, 76, 29, 125, 77, 18, 17, 90, 55, 103, 92, 88, 19, 106, 29, 113, 30, 39, 77, 60, 73, 119, 44, 95, 58, 48, 56, 101, 88};
   }

   private static byte[] sdlkkpkmgrrymkl() {
      return new byte[]{-63, -124, 89, 35, 1, 64, 33, 60, 15, 75, 102, 119, 9, 13, 34, 99, 29, 37, 17, 32, 117, 94, 41, 60, 72, 99, 25, 111, 105, 91, 103, 35, 9, 114, 9, 87, 124, 127, 106, 106, 13, 62, 10, 85, 41, 19, 57, 56, 7, 93, 36, 18, 72, 14, 122, 26, 20, 65, 90, 65, 103, 90, 92, 29, 109, 30, 119, 0, 39, 12, 60, 73, 115, 50, 88, 53, 54, 49, 101, 24, 4, 53, 95, 6, 58, 103, 39, 34, 48, 31};
   }

   private static byte[] adibevnqqrrcbxd() {
      return new byte[]{-63, -122, 90, 15, 7, 100, 44, 40, 9, 74, 98, 115, 12, 82, 37, 92, 31, 47, 18, 48, 119, 72, 43, 54, 68, 114, 24, 82};
   }

   private static byte[] knjeofqdghcpifu() {
      return new byte[]{-63, -127, 80, 36, 2, 64, 45, 61, 11, 79, 102, 114, 0, 10, 33, 99, 17, 36, 21, 36, 117, 91, 32, 59, 75, 99, 21, 110, 109, 95, 103, 48, 0, 84, 10, 98, 112, 40, 110, 110, 13, 4, 3, 86, 42, 25, 53, 49, 3, 77, 36, 82, 65, 21, 121, 79, 24, 20, 94, 55, 103, 95, 85, 16, 110, 22, 123, 16, 35, 68, 60, 74, 122, 62, 91, 123, 58, 49, 97, 11, 4, 115, 86, 22, 57, 109, 43, 41, 52, 84, 54, 22, 95, 28, 57, 9, 80, 21, 3, 111, 37, 39, 4, 5, 96, 100, 0, 27, 32, 90, 25, 43, 26, 54, 115, 74, 32, 115, 74, 50, 29, 102, 98, 19, 97, 15, 0, 100, 11, 93, 120, 113, 97, 102, 11, 38, 3, 85, 43, 12, 61, 40, 12, 94, 34, 3, 65, 88, 120, 78, 16, 9, 81, 118, 97, 92, 85, 83};
   }

   private static byte[] rlqswzrykagsroc() {
      return new byte[]{-63, -127, 95, 38, 6, 68, 38, 63, 5, 75, 102, 114, 15, 8, 37, 103, 26, 38, 27, 32, 117, 91, 47, 57, 79, 103, 30, 108, 99, 91, 103, 38, 15, 119, 14, 83, 123, 124, 96, 106, 13, 59, 12, 80, 46, 23, 62, 59, 13, 93, 36, 23, 78, 11, 125, 30, 19, 66, 80, 65, 103, 95, 90, 24, 106, 26, 112, 3, 45, 12, 60, 76, 117, 55, 95, 49, 49, 50, 111, 24, 4, 48, 89, 3, 61, 111, 32, 42, 58, 80, 54, 83, 80, 27, 61, 24, 91, 23, 13, 104, 37, 44, 11, 67, 100, 40};
   }

   private static byte[] gcktzoumnlmhtcg() {
      return new byte[]{-63, -126, 92, 43, 7, 66, 37, 63, 14, 68, 102, 113, 12, 5, 36, 97, 25, 38, 16, 47, 117, 88, 44, 52, 78, 97, 29, 108, 104, 84, 103, 34, 12, 125, 15, 95, 120, 99, 107, 54, 13, 120, 15, 79, 47, 26, 61, 40, 6, 67, 36, 20, 77, 6, 124, 2, 16, 15, 91, 115, 103, 93, 89, 4, 107, 25, 115, 21, 38, 3, 60, 95, 118, 61, 94, 44, 50, 40, 100, 22, 4, 63, 90, 13, 60, 110, 35, 101, 49, 82, 54, 31, 83, 29, 60, 15, 88, 18, 6, 110, 37, 62, 8, 79, 101, 46};
   }

   private static byte[] cvphbksipsvlrak() {
      return new byte[]{-63, -126, 80, 12, 7, 99, 37, 49, 15, 86, 102, 103, 0, 11, 36, 24, 25, 36, 17, 50};
   }

   private static byte[] yznybizjqardknl() {
      return new byte[]{-63, -126, 80, 12, 7, 99, 37, 49, 15, 86, 102, 103, 0, 11, 36, 24, 25, 124};
   }

   private static int zdsrxvnrgdagzdeu(int var0, int var1) {
      return var0 ^ var1;
   }
}
