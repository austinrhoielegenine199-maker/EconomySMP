package org.mz.donutsmpcore.crossserver;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.mz.donutsmpcore.DonutSMPCore;
import org.mz.donutsmpcore.libs.jedis.DefaultJedisClientConfig;
import org.mz.donutsmpcore.libs.jedis.HostAndPort;
import org.mz.donutsmpcore.libs.jedis.Jedis;
import org.mz.donutsmpcore.libs.jedis.JedisPool;

public class SharedRedisPool {
   private static JedisPool pool;
   private static boolean initialized;
   private static String host;
   private static int port;
   private static int timeout;
   private static String password;

   public static boolean init(DonutSMPCore param0) {
   }

   public static Jedis getResource() {
      int var12 = 367350554 ^ 2075203370 ^ 1796035766;
      var12 = 80136733 ^ var12;
      byte var0 = verified();
      if (var0 == (27253403 ^ var12)) {
         var12 = 1486921666 ^ var12;
         String var1 = gtggxklmib(sbftlakxiigltmo(), vkbebleiwjhqwwk(), var12);
         IllegalStateException var2 = new IllegalStateException(var1);
         throw var2;
      } else {
         var12 = 363680613 ^ var12;
         JedisPool var3 = pool;
         if (var3 != null) {
            var12 = 761338988 ^ var12;
            JedisPool var4 = pool;
            byte var5 = var4.isClosed();
            if (var5 == (961779090 ^ var12)) {
               var12 = 826232841 ^ var12;
               JedisPool var6 = pool;
               Jedis var7 = var6.getResource();
               return var7;
            }

            var12 = 545313864 ^ var12;
         } else {
            label26:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                  case 119668590:
                     var12 ^= 232900644;
                     break label26;
                  case 179918486:
                  default:
                     throw new IllegalAccessException();
                  case 489077092:
                     break label26;
                  case 1910303952:
               }
            }
         }

         String var9 = gtggxklmib(bsldpakfssqtedi(), vkbebleiwjhqwwk(), var12);
         IllegalStateException var8 = new IllegalStateException(var9);
         throw var8;
      }
   }

   public static Jedis subscriber() {
      int var26 = 842903565 ^ 1313405069 ^ 1796035766;
      var26 = 231206197 ^ var26;
      byte var0 = verified();
      if (var0 == (448786691 ^ var26)) {
         var26 = 646237369 ^ var26;
         String var1 = gtggxklmib(jdjlqattckgfgiu(), vkbebleiwjhqwwk(), var26);
         IllegalStateException var5 = new IllegalStateException(var1);
         throw var5;
      } else {
         var26 = xbdobgihngtpvafm(var26, 167021085);
         JedisPool var6 = pool;
         if (var6 != null) {
            var26 = 1657133619 ^ var26;
            JedisPool var7 = pool;
            byte var8 = var7.isClosed();
            if (var8 == (1905172781 ^ var26)) {
               DefaultJedisClientConfig.Builder var10;
               label43:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var26)) {
                     case 66225398:
                     default:
                        throw new IllegalAccessException();
                     case 201599433:
                        var26 ^= 1906832171;
                     case 673142149:
                        DefaultJedisClientConfig.Builder var9 = DefaultJedisClientConfig.builder();
                        int var18 = timeout;
                        var10 = var9.timeoutMillis(var18);
                        var26 = 634990416 ^ var26;
                        String var11 = password;
                        if (var11 == null) {
                           var26 = xbdobgihngtpvafm(var26, 399421665);
                           break label43;
                        }

                        var26 = 1718525885 ^ var26;
                        String var12 = password;
                        byte var13 = var12.isEmpty();
                        if (var13 == (1134486251 ^ var26)) {
                           var26 = 926398387 ^ var26;
                           String var19 = password;
                           var10.password(var19);
                           var26 = 1184340207 ^ var26;
                           break label43;
                        }

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var26)) {
                              case 50566201:
                                 var26 = 1906323292 ^ var26;
                                 break label43;
                              case 632309409:
                                 break;
                              case 1660013214:
                              default:
                                 throw new IllegalAccessException();
                              case 2140385255:
                                 break label43;
                           }
                        }
                     case 668427533:
                  }
               }

               String var2 = host;
               int var3 = port;
               HostAndPort var20 = new HostAndPort(var2, var3);
               DefaultJedisClientConfig var23 = var10.build();
               Jedis var16 = new Jedis(var20, var23);
               return var16;
            }

            var26 = 384488303 ^ var26;
         } else {
            var26 = xbdobgihngtpvafm(var26, 1949239644);
         }

         String var21 = gtggxklmib(dlceatkyoosgmpy(), vkbebleiwjhqwwk(), var26);
         IllegalStateException var17 = new IllegalStateException(var21);
         throw var17;
      }
   }

   private static boolean verified() {
      int var11 = 1643660904 ^ 1480243094 ^ 1796035766;
      var11 = 586415401 ^ var11;

      label53: {
         byte var7;
         label52: {
            label51: {
               label50: {
                  try {
                     DonutSMPCore var0 = DonutSMPCore.getInstance();
                     var11 = 1338106173 ^ var11;
                     if (var0 != null) {
                        var11 = 360125877 ^ var11;
                        byte var4 = var0.hasSyncAddon();
                        if (var4 == (713731305 ^ var11)) {
                           break label50;
                        }

                        var11 = 1364342198 ^ var11;
                        var7 = (byte)(2077792606 ^ var11);
                        break label52;
                     }
                  } catch (Throwable var13) {
                     boolean var10001 = false;
                     break label53;
                  }

                  var11 = 2037188298 ^ var11;
                  break label51;
               }

               var11 = xbdobgihngtpvafm(var11, 1813648255);
            }

            try {
               var7 = (byte)(1183891350 ^ var11);
               var11 = 347400654 ^ var11;
               return (boolean)var7;
            } catch (Throwable var12) {
               boolean var22 = false;
               break label53;
            }
         }

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var11)) {
               case 267637488:
                  var11 = 704433927 ^ var11;
                  return (boolean)var7;
               case 769446351:
               default:
                  throw new IllegalAccessException();
               case 1305144571:
                  return (boolean)var7;
               case 1855994405:
            }
         }
      }

      switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var11)) {
         case -2115845365 -> var11 = 1961197655 ^ var11;
         case -557528325 -> var11 = xbdobgihngtpvafm(var11, 2130788713);
         case -1193247 -> var11 = xbdobgihngtpvafm(var11, 992239978);
         case 881196210 -> var11 = 1112106912 ^ var11;
         case 1414883145 -> var11 = 777221343 ^ var11;
         default -> throw new IllegalAccessException("Error in hash");
      }

      var11 = 285166963 ^ var11;
      byte var6 = (byte)(338072901 ^ var11);
      return (boolean)var6;
   }

   public static JedisPool getPool() {
      int var4 = 749487956 ^ 221581901 ^ 1796035766;
      var4 = 283918365 ^ var4;
      byte var0 = verified();
      JedisPool var1;
      if (var0 != (1517830578 ^ var4)) {
         var4 = 849272385 ^ var4;
         var1 = pool;
         var4 = 527976703 ^ var4;
         return var1;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var4)) {
               case 256419120:
                  var4 ^= 1547754465;
               case 1506018061:
                  var1 = null;
                  var4 = 1906724191 ^ var4;
                  return var1;
               case 581462358:
                  break;
               case 1477233072:
               default:
                  throw new IllegalAccessException();
            }
         }
      }
   }

   public static boolean isInitialized() {
      int var8 = 941534012 ^ 730447922 ^ 1796035766;
      var8 = 1378602376 ^ var8;
      byte var0 = verified();
      byte var5;
      if (var0 != (716304944 ^ var8)) {
         var8 = 1559707906 ^ var8;
         byte var1 = initialized;
         if (var1 != (1984344882 ^ var8)) {
            var8 = 728820227 ^ var8;
            JedisPool var2 = pool;
            if (var2 != null) {
               var8 = 1004878059 ^ var8;
               JedisPool var3 = pool;
               byte var4 = var3.isClosed();
               if (var4 == (1725129178 ^ var8)) {
                  var8 = 209269788 ^ var8;
                  var5 = (byte)(1789547975 ^ var8);
                  var8 = 266658806 ^ var8;
                  return (boolean)var5;
               }

               var8 = 1796674624 ^ var8;
            } else {
               label30:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var8)) {
                     case 77140472:
                        var8 ^= 1358048427;
                     case 616865862:
                        break label30;
                     case 1068574912:
                        break;
                     case 2051195185:
                     default:
                        throw new RuntimeException();
                  }
               }
            }
         } else {
            var8 = 2072168104 ^ var8;
         }
      } else {
         var8 = 662013866 ^ var8;
      }

      var5 = (byte)(230978970 ^ var8);
      var8 = 1753924522 ^ var8;
      return (boolean)var5;
   }

   public static void shutdown() {
      int var7 = 82827043 ^ 1602700704 ^ 1796035766;
      var7 = 756180964 ^ var7;
      byte var0 = (byte)(494379473 ^ var7);
      initialized = (boolean)var0;
      var7 = 1325886172 ^ var7;
      JedisPool var1 = pool;
      if (var1 != null) {
         var7 = 1256048942 ^ var7;
         JedisPool var2 = pool;
         byte var3 = var2.isClosed();
         if (var3 == (413991459 ^ var7)) {
            var7 = 246530844 ^ var7;
            JedisPool var4 = pool;
            var4.close();
            var7 = 1048190150 ^ var7;
         } else {
            var7 = xbdobgihngtpvafm(var7, 818667482);
         }
      } else {
         var7 = xbdobgihngtpvafm(var7, 2048268020);
      }

   }

   static {
      int var3 = 338739204 ^ 665684059 ^ Integer.parseInt("1532209106");
      var3 = 156816494 ^ var3;
      byte var0 = (byte)(1637235683 ^ var3);
      initialized = (boolean)var0;
   }

   public static String gtggxklmib(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] vkbebleiwjhqwwk() {
      return new byte[]{22, 2, 118, 10, 46, 102, 41, 12, 79, 13, 68, 55, 30, 74, 80, 31, 61, 127, 23, 75, 67, 110, 17, 69, 44, 104, 39, 125, 44, 115, 58, 112, 74, 64, 118, 100, 35, 61, 58, 20, 37, 56, 103, 82, 29, 8, 21, 116, 6, 67, 45, 80, 37, 44, 28, 70, 104, 87, 77, 127, 34, 95, 120, 3, 98, 104, 80, 95, 94, 103, 6, 100, 106, 76, 22, 87, 41, 117, 82, 78, 65, 94, 11, 80, 105, 19, 83, 13, 7, 78, 58, 86, 4, 19, 21, 46, 75, 124, 100, 54, 12, 43, 27, 35, 48, 78, 11, 37, 16, 33, 58, 10, 94, 7, 114, 105, 59, 67, 22, 62, 5, 79, 96, 117, 60};
   }

   private static byte[] omwifdjewkzxykg() {
      return new byte[]{-37, -51, 69, 79, 27, 55, 27, 94, 119, 87, 116, 119, 41, 81, 100, 69, 11, 40, 36, 8, 112, 45};
   }

   private static byte[] jcsqxmdlgcukzdw() {
      return new byte[]{-37, -51, 69, 81, 27, 61, 27, 89, 119, 95, 116, 104, 41, 23, 100, 66, 11, 52, 36, 15};
   }

   private static byte[] jqnthaitsqvhgcq() {
      return new byte[]{-38, -51, 69, 73, 26, 55, 29, 91, 125, 82, 118, 116, 45, 85, 100, 95, 9, 37, 37, 16, 113, 59, 34, 27, 24, 41, 19, 58};
   }

   private static byte[] itjcyqtcwivmaai() {
      return new byte[]{-39, -55, 71, 77, 28, 59, 29, 91, 118, 93, 117, 112, 47, 81, 98, 87, 9, 45, 46, 1, 114, 41, 32, 7, 30, 63, 19, 60, 21, 46};
   }

   private static byte[] ipiuksdqwcyygxe() {
      return new byte[0];
   }

   private static byte[] mdfowyylrjgqaxz() {
      return new byte[]{-35, -53, 71, 76, 25, 48, 31, 93, 120, 81, 114, 117, 42, 83, 99, 89, 8, 39, 34, 15, 114, 46};
   }

   private static byte[] klvxnjpuoqcxyrj() {
      return new byte[]{-36, -56, 66, 99, 25, 2, 27, 83, 120, 88, 113, 113, 44, 24, 103, 73, 10, 26, 35, 27, 119, 56, 38, 27, 30, 44, 16, 20, 25, 103, 8, 1, 125, 19, 65, 58, 23, 100, 14, 67, 18, 107, 85, 69, 42, 72, 32, 47, 52, 84, 26, 1, 18, 116, 40, 29, 92, 11, 122, 45, 16, 11, 79, 67, 87, 124, 98, 28, 105, 58, 49, 115, 94, 43, 34, 0, 30, 38, 96, 16, 118, 25};
   }

   private static byte[] fywsleppxnewukm() {
      return new byte[]{-36, -50, 69, 100, 22, 3, 27, 84, 123, 95, 119, 112, 38, 25, 98, 75, 9, 30, 36, 27, 123, 60, 35, 28, 24, 40, 20, 21, 20, 101, 8, 4, 126, 28, 69, 63, 27, 126, 8, 80, 17, 88, 84, 30, 37, 80, 39, 39, 50, 49, 30, 1, 29, 126, 46, 25, 92, 10, 126, 106, 26, 7, 74, 92, 86, 47, 99, 74, 102, 33, 52, 38, 94, 26, 37, 17, 17, 38, 96, 16, 117, 25, 56, 69, 113, 49, 97, 29, 51, 30, 9, 17, 60, 74, 39, 109, 127, 60, 87, 46, 52, 110, 41, 118, 4, 15, 56, 102, 40, 114, 8, 72, 106, 20, 65, 58, 3, 16, 36, 111, 49, 8, 83, 53, 4, 82, 48, 35, 62, 110, 85, 60, 52, 24, 63, 6, 3, 72, 121, 69, 39, 111, 77, 78, 127, 3, 93, 69, 125, 120, 90, 123, 73, 122, 64, 107, 72, 82};
   }

   private static byte[] bsldpakfssqtedi() {
      return new byte[]{-36, -50, 69, 107, 25, 59, 26, 88, 123, 75, 119, 97, 44, 25, 101, 126, 8, 46, 35, 28, 112, 53, 38, 3, 31, 13, 19, 38, 31, 47, 8, 43, 127, 83, 67, 57, 23, 125, 9, 6, 18, 99, 84, 8, 41, 72, 38, 103, 52, 29, 24, 13, 16, 113, 40, 1, 91, 12, 122, 43, 17, 6, 76, 94, 81, 33, 98, 13, 107, 48, 51, 112, 94, 16, 37, 23, 30, 96, 97, 19, 117, 11, 56, 16, 91, 4, 102, 92, 50, 31, 14, 0, 55, 79, 34, 59, 120, 42, 80, 110, 63, 119, 41, 103, 5, 24, 62, 117};
   }

   private static byte[] sbftlakxiigltmo() {
      return new byte[]{-39, -55, 79, 126, 29, 37, 17, 84, 123, 75, 117, 112, 39, 80, 99, 93, 5, 45, 35, 12, 114, 44, 40, 23, 31, 43, 31, 106, 24, 52, 11, 33, 115, 6, 69, 32, 27, 99, 14, 83, 20, 105, 94, 22, 46, 25, 45, 55, 50, 30, 28, 1, 28, 59, 47, 51, 80, 15, 121, 36, 19, 30, 65, 64, 81, 10, 104, 17, 106, 60, 55, 51, 83, 58, 37, 2, 17, 38, 102, 20, 112, 4, 50, 71, 90, 10, 107, 84, 51, 20, 11, 22, 61, 4, 38, 118, 115, 37, 80, 112, 61, 107, 34, 117, 3, 19, 51, 126, 36, 113, 11, 90, 103, 31, 65, 46, 3, 17, 34, 121, 52, 18, 89, 36, 15, 78, 58, 36, 62, 127, 87, 52};
   }

   private static byte[] jdjlqattckgfgiu() {
      return new byte[]{-39, -51, 71, 121, 27, 37, 28, 80, 119, 72, 117, 116, 47, 87, 101, 93, 8, 41, 47, 15, 114, 40, 32, 16, 25, 43, 18, 110, 20, 55, 11, 37, 123, 1, 67, 32, 22, 103, 2, 80, 20, 109, 86, 17, 40, 25, 32, 51, 62, 29, 28, 5, 20, 60, 41, 51, 93, 11, 117, 39, 19, 26, 73, 71, 87, 10, 101, 21, 102, 63, 55, 55, 91, 61, 35, 2, 28, 34, 106, 23, 112, 0, 58, 64, 92, 10, 102, 80, 63, 23, 11, 18, 53, 3, 32, 118, 126, 33, 92, 115, 61, 111, 42, 114, 5, 19, 62, 122, 40, 114, 11, 94, 111, 24, 71, 46, 14, 21, 46, 122, 52, 22, 81, 35, 9, 78, 55, 32, 50, 124, 87, 48};
   }

   private static byte[] dlceatkyoosgmpy() {
      return new byte[]{-39, -54, 69, 109, 24, 61, 31, 93, 118, 71, 117, 101, 45, 26, 102, 126, 11, 42, 46, 23, 114, 48, 34, 2, 26, 11, 17, 34, 21, 36, 11, 43, 121, 84, 64, 62, 21, 126, 3, 12, 20, 97, 84, 9, 43, 79, 35, 100, 63, 18, 28, 9, 22, 113, 42, 1, 94, 14, 116, 38, 19, 4, 75, 94, 84, 33, 102, 10, 103, 59, 55, 115, 89, 23, 32, 22, 31, 101, 107, 30, 112, 8, 56, 23, 95, 0, 101, 95, 62, 19, 11, 4, 55, 73, 35, 61, 125, 47, 93, 98, 61, 115, 40, 100, 6, 24, 61, 113};
   }

   private static int xbdobgihngtpvafm(int var0, int var1) {
      return var1 ^ var0;
   }
}
