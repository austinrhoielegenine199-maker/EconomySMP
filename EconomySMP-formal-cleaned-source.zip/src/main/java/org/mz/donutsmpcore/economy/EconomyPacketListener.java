package org.mz.donutsmpcore.economy;

import io.netty.channel.Channel;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelPromise;
import io.netty.channel.EventLoop;
import io.papermc.paper.event.player.PlayerTrackEntityEvent;
import io.papermc.paper.event.player.PlayerUntrackEntityEvent;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;
import java.util.function.Function;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.PluginManager;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.KKoOoOo0oOK;
import skido.KoOo0Ko0oOK;
import skido.o0oOKKoOoOK;
import skido.oOo0KKoOoOK;
import skido.oOo0o0oOo0oOK;
import skido.oOoOKo0oOoOK;

public final class EconomyPacketListener implements Listener {
   public static final int SETTING_SLOT = 54;
   private static final String LEGACY_TAG_KEY = "money_nametag";
   private static final float DEFAULT_Y_OFFSET = 0.95F;
   private static EconomyPacketListener instance;
   private static final String HANDLER = "donut_money_nametag";
   private final Map<UUID, oO> tags;
   private final Map<Integer, Set<oO>> byVehicle;
   private final Map<UUID, Channel> channels;
   private final Map<UUID, K> guards;
   private final Map<UUID, String> names;
   private final Set<String> tagged;
   private final Map<UUID, UUID> worlds;
   private final Map<UUID, Object> connections;
   private volatile boolean running;
   private NamespacedKey legacyKey;
   private static String rnxdxkcynl;

   private EconomyPacketListener() {
      ConcurrentHashMap var2 = new ConcurrentHashMap();
      this.tags = var2;
      ConcurrentHashMap var11 = new ConcurrentHashMap();
      this.byVehicle = var11;
      ConcurrentHashMap var12 = new ConcurrentHashMap();
      this.channels = var12;
      ConcurrentHashMap var13 = new ConcurrentHashMap();
      this.guards = var13;
      ConcurrentHashMap var14 = new ConcurrentHashMap();
      this.names = var14;
      ConcurrentHashMap.KeySetView var15 = ConcurrentHashMap.newKeySet();
      this.tagged = var15;
      ConcurrentHashMap var16 = new ConcurrentHashMap();
      this.worlds = var16;
      ConcurrentHashMap var17 = new ConcurrentHashMap();
      this.connections = var17;
   }

   public static synchronized EconomyPacketListener getInstance() {
      EconomyPacketListener var0 = instance;
      if (var0 == null) {
         EconomyPacketListener var1 = new EconomyPacketListener();
         instance = var1;
      }

      EconomyPacketListener var2 = instance;
      return var2;
   }

   private static boolean enabled() {
      try {
         DonutSMPCore var0 = DonutSMPCore.getInstance();
         FileConfiguration var4 = var0.getConfig();
         String var1 = cavimrpiqp(feljhgrrzwfmqcc(), 827581549);
         boolean var2 = true;
         boolean var5 = var4.getBoolean(var1, var2);
         return var5;
      } catch (Throwable var8) {
         boolean var7 = false;
         return var7;
      }
   }

   private static boolean hideVanilla() {
      try {
         DonutSMPCore var0 = DonutSMPCore.getInstance();
         FileConfiguration var4 = var0.getConfig();
         String var1 = cavimrpiqp(jtdvkkwqzmcpqyq(), 1449109068);
         boolean var2 = true;
         boolean var5 = var4.getBoolean(var1, var2);
         return var5;
      } catch (Throwable var8) {
         boolean var7 = true;
         return var7;
      }
   }

   private static float yOffset() {
      try {
         DonutSMPCore var0 = DonutSMPCore.getInstance();
         FileConfiguration var5 = var0.getConfig();
         String var1 = cavimrpiqp(vkztvraxizvtzkl(), 427545674);
         double var2 = (double)0.95F;
         double var6 = var5.getDouble(var1, var2);
         float var8 = (float)var6;
         return var8;
      } catch (Throwable var11) {
         float var10 = 0.95F;
         return var10;
      }
   }

   public void start() {
      boolean var7 = this.running;
      if (!var7) {
         boolean var8 = enabled();
         if (var8) {
            boolean var9 = EconomyTransactionManager.init();
            if (var9) {
               boolean var2 = true;
               this.running = var2;
               DonutSMPCore var3 = DonutSMPCore.getInstance();
               String var4 = cavimrpiqp(ohbfuymkquifxzy(), 710339406);
               NamespacedKey var25 = new NamespacedKey(var3, var4);
               this.legacyKey = var25;
               PluginManager var12 = Bukkit.getPluginManager();
               DonutSMPCore var33 = DonutSMPCore.getInstance();
               var12.registerEvents(this, var33);
               Collection var13 = Bukkit.getOnlinePlayers();
               Iterator var14 = var13.iterator();
               Iterator var5 = var14;

               while(true) {
                  boolean var16 = var5.hasNext();
                  if (!var16) {
                     byte var17 = 10;
                     DonutSMPCore var27 = DonutSMPCore.getInstance();
                     FileConfiguration var28 = var27.getConfig();
                     String var34 = cavimrpiqp(lfnfslhdvqbrrza(), 588520430);
                     byte var39 = 20;
                     int var29 = var28.getInt(var34, var39);
                     int var18 = Math.max(var17, var29);
                     KKoOoOo0oOK var19 = KKoOoOo0oOK.getInstance();
                     Runnable var31 = this::tick;
                     long var35 = 40L;
                     long var42 = (long)var18;
                     var19.runTimer(var31, var35, var42);
                     return;
                  }

                  Object var22 = var5.next();
                  Player var23 = (Player)var22;
                  KKoOoOo0oOK var24 = KKoOoOo0oOK.getInstance();
                  Runnable var38 = () -> {
                     this.cacheConnection(var23);
                     this.clearLegacy(var23);
                  };
                  var24.runAtEntity(var23, var38);
               }
            }
         }
      }

   }

   private void tick() {
      boolean var10 = this.running;
      if (var10) {
         boolean var33;
         label35: {
            boolean var11 = hideVanilla();
            if (var11) {
               boolean var12 = EconomyTransactionManager.teamsReady();
               if (var12) {
                  var33 = true;
                  break label35;
               }
            }

            var33 = false;
         }

         boolean var5 = var33;
         Collection var13 = Bukkit.getOnlinePlayers();
         Iterator var14 = var13.iterator();
         Iterator var6 = var14;

         while(true) {
            boolean var16 = var6.hasNext();
            if (!var16) {
               return;
            }

            Object var18 = var6.next();
            Player var19 = (Player)var18;
            Set var21 = this.tagged;
            String var35 = var19.getName();
            var21.add(var35);
            KKoOoOo0oOK var23 = KKoOoOo0oOK.getInstance();
            Runnable var41 = () -> this.update(var19);
            var23.runAtEntity(var19, var41);
            Map var25 = this.guards;
            UUID var38 = var19.getUniqueId();
            Object var26 = var25.get(var38);
            K var27 = (K)var26;
            if (var27 != null) {
               boolean var34;
               label26: {
                  if (var5) {
                     oOo0o0oOo0oOK var30 = oOo0o0oOo0oOK.getInstance();
                     byte var42 = 54;
                     boolean var31 = var30.isEnabled(var19, var42);
                     if (var31) {
                        var34 = true;
                        break label26;
                     }
                  }

                  var34 = false;
               }

               var27.syncLater(var34);
            }
         }
      }
   }

   private void update(Player var1) {
   }

   private void showTo(Player var1, UUID var2) {
      boolean var13 = this.running;
      if (var13) {
         boolean var15 = var1.isOnline();
         if (var15) {
            boolean var17 = var1.isDead();
            if (!var17) {
               oO var19 = this.tagFor(var1);
               oO var9 = var19;
               Player var21 = Bukkit.getPlayer(var2);
               String var23 = var19.text;
               if (var23 != null && var21 != null) {
                  Collection var26 = o0oOKKoOoOK.trackedBy(var1);
                  boolean var27 = var26.contains(var21);
                  if (var27) {
                     boolean var29 = wants(var21, var1);
                     if (var29) {
                        Map var31 = this.connections;
                        Object var32 = var31.get(var2);
                        Object var11 = var32;
                        if (var32 != null) {
                           Set var35 = var19.shown;
                           boolean var36 = var35.add(var2);
                           if (var36) {
                              try {
                                 Object var38 = EconomyTransactionManager.handle(var1);
                                 int var52 = EconomyTransactionManager.entityId(var38);
                                 this.index(var9, var52);
                                 int var54 = var9.id;
                                 String var56 = var9.text;
                                 float var59 = var9.offset;
                                 Object var55 = EconomyTransactionManager.dataPacket(var54, var56, var59);
                                 int var61 = var9.id;
                                 Object var58 = EconomyTransactionManager.passengersPacket(var38, var61);
                                 spawn(var11, var9, var1, var55, var58);
                              } catch (Throwable var63) {
                                 Set var43 = var19.shown;
                                 var43.remove(var2);
                              }

                              return;
                           }
                        }

                        return;
                     }
                  }

                  return;
               }

               return;
            }
         }
      }

   }

   private static void spawn(Object var0, oO var1, Player var2, Object var3, Object var4) {
      try {
         int var13 = var1.id;
         UUID var17 = var1.uuid;
         Location var18 = var2.getLocation();
         Object var14 = EconomyTransactionManager.spawnPacket(var13, var17, var18);
         EconomyTransactionManager.send(var0, var14);
         EconomyTransactionManager.send(var0, var3);
         EconomyTransactionManager.send(var0, var4);
      } catch (Throwable var19) {
      }

   }

   private static void despawn(Object var0, oO var1) {
      if (var0 != null) {
         try {
            int var7 = var1.id;
            Object var8 = EconomyTransactionManager.removePacket(var7);
            EconomyTransactionManager.send(var0, var8);
         } catch (Throwable var9) {
         }

      }
   }

   private static boolean wants(Player var0, Player var1) {
      oOo0o0oOo0oOK var2 = oOo0o0oOo0oOK.getInstance();
      byte var4 = 54;
      boolean var5 = var2.isEnabled(var0, var4);
      return var5;
   }

   private static String render(Player var0) {
      String var7 = var0.getDisplayName();
      String var8 = oOo0KKoOoOK.strip(var7);
      String var9 = cavimrpiqp(anpdwsqxoyrbdns(), 966245654);
      String var2 = cavimrpiqp(kaehbhvuxhpgeqt(), 966245654);
      String var10 = KoOo0Ko0oOK.get(var9, var2);
      String var19 = cavimrpiqp(drdisykzlccllxq(), 2111406619);
      String var11 = var10.replace(var19, var8);
      String var12 = oOo0KKoOoOK.color(var11);
      String var13 = cavimrpiqp(yhifjrfswytmele(), 1729279253);
      String var20 = cavimrpiqp(jprfwblbguwesom(), 1729279253);
      String var14 = KoOo0Ko0oOK.get(var13, var20);
      String var21 = cavimrpiqp(yoguqzhujicxyjs(), 760294566);
      String var24 = balanceOf(var0);
      String var15 = var14.replace(var21, var24);
      String var16 = oOo0KKoOoOK.color(var15);
      String var18 = var12 + "\n" + var16;
      return var18;
   }

   private void cacheConnection(Player var1) {
      Map var6 = this.connections;
      UUID var13 = var1.getUniqueId();
      boolean var7 = var6.containsKey(var13);
      if (!var7) {
         try {
            Map var9 = this.connections;
            UUID var15 = var1.getUniqueId();
            Object var17 = EconomyTransactionManager.connection(var1);
            var9.put(var15, var17);
         } catch (Throwable var18) {
         }

         this.inject(var1);
      }
   }

   private void index(oO var1, int var2) {
      int var6 = var1.vehicle;
      if (var6 != var2) {
         this.unindex(var1);
         var1.vehicle = var2;
         Map var10 = this.byVehicle;
         Integer var17 = var2;
         Function var5 = (var0) -> {
            ConcurrentHashMap.KeySetView var1 = ConcurrentHashMap.newKeySet();
            return var1;
         };
         Object var11 = var10.computeIfAbsent(var17, var5);
         Set var12 = (Set)var11;
         var12.add(var1);
      }
   }

   private void unindex(oO var1) {
      int var6 = var1.vehicle;
      byte var3 = -1;
      if (var6 != var3) {
         Map var9 = this.byVehicle;
         Integer var13 = var6;
         BiFunction var15 = (var1x, var2) -> {
            boolean var5 = var2.remove(var1);
            boolean var7 = var2.isEmpty();
            Set var8;
            if (var7) {
               var8 = null;
            } else {
               var8 = var2;
            }

            return var8;
         };
         var9.computeIfPresent(var13, var15);
         byte var14 = -1;
         var1.vehicle = var14;
      }
   }

   private void inject(Player var1) {
      UUID var11 = var1.getUniqueId();
      UUID var8 = var11;
      Map var13 = this.names;
      String var50 = var1.getName();
      var13.put(var11, var50);
      Set var16 = this.tagged;
      String var41 = var1.getName();
      var16.add(var41);
      Map var19 = this.worlds;
      World var52 = var1.getWorld();
      UUID var53 = var52.getUID();
      var19.put(var11, var53);
      Map var22 = this.channels;
      boolean var23 = var22.containsKey(var11);
      if (!var23) {
         try {
            Channel var25 = EconomyTransactionManager.channel(var1);
            if (var25 == null) {
               return;
            }

            Map var28 = this.channels;
            var28.put(var8, var25);
            K var30 = new K;
            boolean var5 = EconomyTransactionManager.teamsReady();
            EconomyManager var60;
            if (var5) {
               Set var61 = this.tagged;
               var60 = new EconomyManager(var61);
            } else {
               var60 = null;
            }

            var30.<init>(var8, var60, var25);
            Map var32 = this.guards;
            var32.put(var8, var30);
            EventLoop var35 = var25.eventLoop();
            Runnable var47 = () -> {
               try {
                  ChannelPipeline var7 = var25.pipeline();
                  String var3 = cavimrpiqp(pytyaokyjsuwmyy(), 1414759626);
                  ChannelHandler var8 = var7.get(var3);
                  if (var8 == null) {
                     ChannelPipeline var10 = var25.pipeline();
                     String var16 = cavimrpiqp(xlxgiedbmmrkuwf(), 71298703);
                     ChannelHandler var11 = var10.get(var16);
                     if (var11 != null) {
                        ChannelPipeline var13 = var25.pipeline();
                        String var17 = cavimrpiqp(rnalduawevapukn(), 740507889);
                        String var4 = cavimrpiqp(urznihdtiqhbffn(), 740507889);
                        var13.addBefore(var17, var4, var30);
                     }
                  }
               } catch (Throwable var18) {
               }

            };
            var35.execute(var47);
            EconomyManager var37 = var30.teams;
            if (var37 != null) {
               KKoOoOo0oOK var38 = KKoOoOo0oOK.getInstance();
               Runnable var49 = () -> {
                  boolean var8 = var1.isOnline();
                  Map var13;
                  if (var8) {
                     var13 = EconomyTransactionManager.clientTeams(var1);
                  } else {
                     var13 = Map.of();
                  }

                  Map var6 = var13;

                  try {
                     EventLoop var11 = var25.eventLoop();
                     Runnable var14 = () -> {
                        EconomyManager var4 = var30.teams;
                        var4.seed(var6);
                     };
                     var11.execute(var14);
                  } catch (Throwable var15) {
                  }

               };
               var38.runGlobal(var49);
            }
         } catch (Throwable var63) {
         }

      }
   }

   private void uninject(UUID var1) {
      Map var8 = this.channels;
      Object var9 = var8.remove(var1);
      Channel var10 = (Channel)var9;
      Channel var5 = var10;
      Map var12 = this.guards;
      Object var13 = var12.remove(var1);
      K var14 = (K)var13;
      K var6 = var14;
      if (var10 != null) {
         try {
            EventLoop var17 = var5.eventLoop();
            Runnable var21 = () -> {
               try {
                  if (var6 != null) {
                     boolean var6x = var5.isActive();
                     if (var6x) {
                        boolean var3 = false;
                        var6.sync(var3);
                     }
                  }

                  ChannelPipeline var9 = var5.pipeline();
                  String var15 = cavimrpiqp(ljbsrdtwsmmbxdt(), 1794870154);
                  ChannelHandler var10 = var9.get(var15);
                  if (var10 != null) {
                     ChannelPipeline var12 = var5.pipeline();
                     String var16 = cavimrpiqp(mlnnrkxighpuabz(), 58132101);
                     var12.remove(var16);
                  }
               } catch (Throwable var17) {
               }

            };
            var17.execute(var21);
         } catch (Throwable var22) {
         }

      }
   }

   private Object rewrite(UUID var1, Object var2) throws Throwable {
      boolean var13 = this.running;
      if (var13) {
         Map var15 = this.byVehicle;
         boolean var16 = var15.isEmpty();
         if (!var16) {
            Class var18 = var2.getClass();
            Class var4 = EconomyTransactionManager.passengersClass;
            if (var18 == var4) {
               Object var21 = this.guardPassengers(var1, var2);
               return var21;
            }

            Class var75 = EconomyTransactionManager.removeClass;
            if (var18 == var75) {
               Object var24 = this.guardRemove(var1, var2);
               return var24;
            }

            Class var77 = EconomyTransactionManager.addEntityClass;
            if (var18 == var77) {
               this.guardAdd(var1, var2);
               return var2;
            }

            Class var28 = EconomyTransactionManager.bundleClass;
            boolean var29 = var28.isInstance(var2);
            if (!var29) {
               return var2;
            }

            boolean var30 = false;
            boolean var7 = var30;
            Iterable var32 = EconomyTransactionManager.subPackets(var2);
            Iterator var33 = var32.iterator();
            Iterator var8 = var33;

            while(true) {
               boolean var35 = var8.hasNext();
               if (!var35) {
                  break;
               }

               Object var37 = var8.next();
               Class var39 = var37.getClass();
               Class var80 = EconomyTransactionManager.passengersClass;
               if (var39 != var80) {
                  Class var81 = EconomyTransactionManager.removeClass;
                  if (var39 != var81) {
                     Class var82 = EconomyTransactionManager.addEntityClass;
                     if (var39 != var82) {
                        continue;
                     }
                  }
               }

               boolean var43 = true;
               var7 = var43;
               break;
            }

            if (!var7) {
               return var2;
            }

            ArrayList var46 = new ArrayList();
            ArrayList var95 = var46;
            Iterable var48 = EconomyTransactionManager.subPackets(var2);
            Iterator var49 = var48.iterator();
            Iterator var96 = var49;

            while(true) {
               boolean var51 = var96.hasNext();
               if (!var51) {
                  boolean var52 = false;
                  boolean var97 = var52;
                  byte var53 = 0;
                  int var98 = var53;

                  while(true) {
                     int var84 = var95.size();
                     if (var98 >= var84) {
                        Object var57;
                        if (var97) {
                           var57 = EconomyTransactionManager.bundle(var95);
                        } else {
                           var57 = var2;
                        }

                        return var57;
                     }

                     Object var59 = var95.get(var98);
                     Class var60 = EconomyTransactionManager.bundleClass;
                     boolean var61 = var60.isInstance(var59);
                     if (!var61) {
                        Object var63 = this.rewrite(var1, var59);
                        if (var63 != var59) {
                           var95.set(var98, var63);
                           boolean var67 = true;
                           var97 = var67;
                        }
                     }

                     ++var98;
                  }
               }

               Object var69 = var96.next();
               var95.add(var69);
            }
         }
      }

      return var2;
   }

   private Object guardPassengers(UUID var1, Object var2) throws Throwable {
      int var17 = EconomyTransactionManager.vehicleOf(var2);
      Map var19 = this.byVehicle;
      Integer var54 = var17;
      Object var20 = var19.get(var54);
      Set var21 = (Set)var20;
      if (var21 == null) {
         return var2;
      } else {
         int[] var24 = EconomyTransactionManager.passengersOf(var2);
         int[] var9 = var24;
         Iterator var27 = var21.iterator();
         Iterator var10 = var27;

         while(true) {
            boolean var29 = var10.hasNext();
            if (!var29) {
               Object var53;
               if (var9 == var24) {
                  var53 = var2;
               } else {
                  var53 = EconomyTransactionManager.passengers(var17, var9);
               }

               return var53;
            }

            Object var31 = var10.next();
            oO var32 = (oO)var31;
            oO var11 = var32;
            Set var34 = var32.shown;
            boolean var35 = var34.contains(var1);
            if (var35) {
               boolean var36 = false;
               boolean var12 = var36;
               int[] var13 = var9;
               int var39 = var9.length;
               int var14 = var39;
               byte var40 = 0;

               for(int var15 = var40; var15 < var14; ++var15) {
                  int var43 = var13[var15];
                  int var59 = var11.id;
                  if (var43 == var59) {
                     boolean var45 = true;
                     var12 = var45;
                     break;
                  }
               }

               if (!var12) {
                  int var61 = var9.length;
                  byte var5 = 1;
                  int var62 = var61 + var5;
                  int[] var48 = Arrays.copyOf(var9, var62);
                  var9 = var48;
                  int var64 = var48.length;
                  byte var68 = 1;
                  int var65 = var64 - var68;
                  int var70 = var11.id;
                  var48[var65] = var70;
               }
            }
         }
      }
   }

   private Object guardRemove(UUID var1, Object var2) throws Throwable {
      Collection var13 = EconomyTransactionManager.removedIds(var2);
      Object var14 = null;
      ArrayList var7 = (ArrayList)var14;
      Iterator var16 = var13.iterator();
      Iterator var8 = var16;

      while(true) {
         boolean var18 = var8.hasNext();
         if (!var18) {
            if (var7 == null) {
               return var2;
            }

            int var43 = var13.size();
            int var73 = var7.size();
            int var44 = var43 + var73;
            int[] var45 = new int[var44];
            int[] var79 = var45;
            byte var46 = 0;
            int var80 = var46;
            Iterator var48 = var13.iterator();
            Iterator var81 = var48;

            while(true) {
               boolean var50 = var81.hasNext();
               if (!var50) {
                  Iterator var52 = var7.iterator();
                  Iterator var82 = var52;

                  while(true) {
                     boolean var54 = var82.hasNext();
                     if (!var54) {
                        Object var56 = EconomyTransactionManager.removePacket(var79);
                        return var56;
                     }

                     Object var58 = var82.next();
                     Integer var59 = (Integer)var58;
                     int var60 = var59;
                     int var74 = var80++;
                     var79[var74] = var60;
                  }
               }

               Object var63 = var81.next();
               int var75 = var80++;
               Number var77 = (Number)var63;
               int var78 = var77.intValue();
               var79[var75] = var78;
            }
         }

         Object var20 = var8.next();
         Map var22 = this.byVehicle;
         Number var65 = (Number)var20;
         int var66 = var65.intValue();
         Integer var67 = var66;
         Object var23 = var22.get(var67);
         Set var24 = (Set)var23;
         if (var24 != null) {
            Iterator var27 = var24.iterator();
            Iterator var11 = var27;

            while(true) {
               boolean var29 = var11.hasNext();
               if (!var29) {
                  break;
               }

               Object var31 = var11.next();
               oO var32 = (oO)var31;
               Set var34 = var32.shown;
               boolean var35 = var34.remove(var1);
               if (var35) {
                  if (var7 == null) {
                     ArrayList var37 = new ArrayList();
                     var7 = var37;
                  }

                  int var70 = var32.id;
                  Integer var71 = var70;
                  boolean var39 = var7.add(var71);
               }
            }
         }
      }
   }

   private void guardAdd(UUID var1, Object var2) throws Throwable {
      Map var13 = this.byVehicle;
      int var40 = EconomyTransactionManager.addedId(var2);
      Integer var41 = var40;
      Object var14 = var13.get(var41);
      Set var15 = (Set)var14;
      if (var15 != null) {
         Map var18 = this.worlds;
         Object var19 = var18.get(var1);
         UUID var20 = (UUID)var19;
         UUID var9 = var20;
         if (var20 != null) {
            Iterator var23 = var15.iterator();
            Iterator var10 = var23;

            while(true) {
               boolean var25 = var10.hasNext();
               if (!var25) {
                  return;
               }

               Object var27 = var10.next();
               oO var28 = (oO)var27;
               UUID var30 = var28.world;
               boolean var31 = var30.equals(var9);
               if (var31) {
                  Set var33 = var28.shown;
                  var33.remove(var1);
                  UUID var36 = var28.owner;
                  Player var37 = Bukkit.getPlayer(var36);
                  if (var37 != null) {
                     KKoOoOo0oOK var39 = KKoOoOo0oOK.getInstance();
                     Runnable var46 = () -> this.showTo(var37, var1);
                     var39.runAtEntity(var37, var46);
                  }
               }
            }
         }
      }
   }

   private void clearLegacy(Player var1) {
      NamespacedKey var8 = this.legacyKey;
      if (var8 != null) {
         List var10 = var1.getPassengers();
         Iterator var11 = var10.iterator();
         Iterator var5 = var11;

         while(true) {
            boolean var13 = var5.hasNext();
            if (!var13) {
               return;
            }

            Object var15 = var5.next();
            Entity var16 = (Entity)var15;
            boolean var18 = var16 instanceof TextDisplay;
            if (var18) {
               TextDisplay var20 = (TextDisplay)var16;
               PersistentDataContainer var22 = var20.getPersistentDataContainer();
               NamespacedKey var27 = this.legacyKey;
               PersistentDataType var4 = PersistentDataType.STRING;
               boolean var23 = var22.has(var27, var4);
               if (var23) {
                  var1.removePassenger(var20);
                  var20.remove();
               }
            }
         }
      }
   }

   private oO tagFor(Player var1) {
      World var11 = var1.getWorld();
      UUID var12 = var11.getUID();
      Map var14 = this.tags;
      UUID var42 = var1.getUniqueId();
      Object var15 = var14.get(var42);
      oO var16 = (oO)var15;
      oO var8 = var16;
      if (var16 != null) {
         UUID var19 = var16.world;
         boolean var20 = var19.equals(var12);
         if (var20) {
            return var16;
         }
      }

      if (var16 != null) {
         Set var24 = var16.shown;
         Iterator var25 = var24.iterator();
         Iterator var9 = var25;

         while(true) {
            boolean var27 = var9.hasNext();
            if (!var27) {
               Set var29 = var8.shown;
               var29.clear();
               this.unindex(var8);
               break;
            }

            Object var37 = var9.next();
            UUID var38 = (UUID)var37;
            Map var40 = this.connections;
            Object var41 = var40.get(var38);
            despawn(var41, var8);
         }
      }

      World var49 = var1.getWorld();
      int var50 = oOoOKo0oOoOK.next(var49);
      UUID var52 = var1.getUniqueId();
      oO var31 = new oO(var50, var12, var52);
      Map var33 = this.tags;
      UUID var46 = var1.getUniqueId();
      var33.put(var46, var31);
      return var31;
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onTrack(PlayerTrackEntityEvent var1) {
      Entity var10 = var1.getEntity();
      boolean var12 = var10 instanceof Player;
      if (var12) {
         Player var14 = (Player)var10;
         Map var16 = this.tags;
         UUID var28 = var14.getUniqueId();
         Object var17 = var16.get(var28);
         oO var18 = (oO)var17;
         if (var18 != null) {
            Player var21 = var1.getPlayer();
            UUID var22 = var21.getUniqueId();
            Set var24 = var18.shown;
            var24.remove(var22);
            KKoOoOo0oOK var26 = KKoOoOo0oOK.getInstance();
            Runnable var31 = () -> this.showTo(var14, var22);
            long var32 = 2L;
            var26.runAtEntityLater(var14, var31, var32);
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onUntrack(PlayerUntrackEntityEvent var1) {
      Entity var6 = var1.getEntity();
      boolean var8 = var6 instanceof Player;
      if (var8) {
         Player var10 = (Player)var6;
         Map var12 = this.tags;
         UUID var22 = var10.getUniqueId();
         Object var13 = var12.get(var22);
         oO var14 = (oO)var13;
         if (var14 != null) {
            Set var17 = var14.shown;
            Player var24 = var1.getPlayer();
            UUID var25 = var24.getUniqueId();
            boolean var18 = var17.remove(var25);
            if (var18) {
               Map var20 = this.connections;
               Player var27 = var1.getPlayer();
               UUID var28 = var27.getUniqueId();
               Object var21 = var20.get(var28);
               despawn(var21, var14);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onDeath(PlayerDeathEvent var1) {
      Map var5 = this.tags;
      Player var8 = var1.getEntity();
      UUID var9 = var8.getUniqueId();
      Object var6 = var5.get(var9);
      oO var7 = (oO)var6;
      this.hide(var7);
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onRespawn(PlayerRespawnEvent var1) {
      Player var7 = var1.getPlayer();
      KKoOoOo0oOK var8 = KKoOoOo0oOK.getInstance();
      Runnable var10 = () -> this.update(var7);
      long var11 = 3L;
      var8.runAtEntityLater(var7, var10, var11);
   }

   private void hide(oO var1) {
      if (var1 != null) {
         Set var7 = var1.shown;
         Iterator var8 = var7.iterator();
         Iterator var4 = var8;

         while(true) {
            boolean var10 = var4.hasNext();
            if (!var10) {
               Set var18 = var1.shown;
               var18.clear();
               return;
            }

            Object var12 = var4.next();
            UUID var13 = (UUID)var12;
            Map var15 = this.connections;
            Object var16 = var15.get(var13);
            despawn(var16, var1);
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onJoin(PlayerJoinEvent var1) {
      Player var5 = var1.getPlayer();
      this.cacheConnection(var5);
      Player var7 = var1.getPlayer();
      this.clearLegacy(var7);
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onQuit(PlayerQuitEvent var1) {
      Player var4 = var1.getPlayer();
      UUID var5 = var4.getUniqueId();
      this.remove(var5);
   }

   public void remove(UUID var1) {
      Map var7 = this.tags;
      Object var8 = var7.remove(var1);
      oO var9 = (oO)var8;
      oO var4 = var9;
      if (var9 != null) {
         Set var12 = var9.shown;
         Iterator var13 = var12.iterator();
         Iterator var5 = var13;

         while(true) {
            boolean var15 = var5.hasNext();
            if (!var15) {
               Set var23 = var4.shown;
               var23.clear();
               this.unindex(var4);
               break;
            }

            Object var17 = var5.next();
            UUID var18 = (UUID)var17;
            Map var20 = this.connections;
            Object var21 = var20.get(var18);
            despawn(var21, var4);
         }
      }

      Map var26 = this.tags;
      Collection var27 = var26.values();
      Iterator var28 = var27.iterator();
      Iterator var61 = var28;

      while(true) {
         boolean var30 = var61.hasNext();
         if (!var30) {
            this.uninject(var1);
            Map var33 = this.worlds;
            var33.remove(var1);
            Map var36 = this.names;
            Object var37 = var36.remove(var1);
            String var38 = (String)var37;
            if (var38 != null) {
               Set var41 = this.tagged;
               var41.remove(var38);
            }

            Map var44 = this.connections;
            var44.remove(var1);
            return;
         }

         Object var47 = var61.next();
         oO var48 = (oO)var47;
         Set var50 = var48.shown;
         var50.remove(var1);
      }
   }

   public void shutdown() {
      boolean var2 = false;
      this.running = var2;
      Map var9 = this.tags;
      Collection var10 = var9.values();
      Iterator var11 = var10.iterator();
      Iterator var4 = var11;

      while(true) {
         boolean var13 = var4.hasNext();
         if (!var13) {
            Map var15 = this.tags;
            var15.clear();
            Map var17 = this.byVehicle;
            var17.clear();
            Map var45 = this.channels;
            Set var46 = var45.keySet();
            ArrayList var18 = new ArrayList(var46);
            Iterator var19 = var18.iterator();
            Iterator var47 = var19;

            while(true) {
               boolean var21 = var47.hasNext();
               if (!var21) {
                  Map var27 = this.connections;
                  var27.clear();
                  return;
               }

               Object var23 = var47.next();
               UUID var24 = (UUID)var23;
               this.uninject(var24);
            }
         }

         Object var29 = var4.next();
         oO var30 = (oO)var29;
         oO var48 = var30;
         Set var32 = var30.shown;
         Iterator var33 = var32.iterator();
         Iterator var6 = var33;

         while(true) {
            boolean var35 = var6.hasNext();
            if (!var35) {
               break;
            }

            Object var37 = var6.next();
            UUID var38 = (UUID)var37;
            Map var40 = this.connections;
            Object var41 = var40.get(var38);
            despawn(var41, var48);
         }
      }
   }

   private static String balanceOf(Player var0) {
      try {
         DonutSMPCore var1 = DonutSMPCore.getInstance();
         Economy var4 = var1.getEconomy();
         double var5 = var4.getBalance(var0);
         String var7 = oOo0KKoOoOK.formatPrice(var5);
         return var7;
      } catch (Throwable var10) {
         String var9 = cavimrpiqp(vqaemgqqzutopqg(), 342851250);
         return var9;
      }
   }

   public static String cavimrpiqp(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = rnxdxkcynl;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] feljhgrrzwfmqcc() {
      return new byte[]{0, 0, 0, 22, 0, 0, 0, 0};
   }

   private static byte[] jtdvkkwqzmcpqyq() {
      return new byte[]{0, 0, 0, 32, 0, 0, 0, 22};
   }

   private static byte[] vkztvraxizvtzkl() {
      return new byte[]{0, 0, 0, 23, 0, 0, 0, 54};
   }

   private static byte[] anpdwsqxoyrbdns() {
      return new byte[]{0, 0, 0, 26, 0, 0, 0, 77};
   }

   private static byte[] kaehbhvuxhpgeqt() {
      return new byte[]{0, 0, 0, 15, 0, 0, 0, 103};
   }

   private static byte[] drdisykzlccllxq() {
      return new byte[]{0, 0, 0, 8, 0, 0, 0, 118};
   }

   private static byte[] yhifjrfswytmele() {
      return new byte[]{0, 0, 0, 21, 0, 0, 0, 126};
   }

   private static byte[] jprfwblbguwesom() {
      return new byte[]{0, 0, 0, 25, 0, 0, 0, -109};
   }

   private static byte[] yoguqzhujicxyjs() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, -84};
   }

   private static byte[] vqaemgqqzutopqg() {
      return new byte[]{0, 0, 0, 1, 0, 0, 0, -75};
   }

   private static byte[] mlnnrkxighpuabz() {
      return new byte[]{0, 0, 0, 19, 0, 0, 0, -74};
   }

   private static byte[] ljbsrdtwsmmbxdt() {
      return new byte[]{0, 0, 0, 19, 0, 0, 0, -55};
   }

   private static byte[] pytyaokyjsuwmyy() {
      return new byte[]{0, 0, 0, 19, 0, 0, 0, -36};
   }

   private static byte[] rnalduawevapukn() {
      return new byte[]{0, 0, 0, 14, 0, 0, 0, -17};
   }

   private static byte[] urznihdtiqhbffn() {
      return new byte[]{0, 0, 0, 19, 0, 0, 0, -3};
   }

   private static byte[] xlxgiedbmmrkuwf() {
      return new byte[]{0, 0, 0, 14, 0, 0, 1, 16};
   }

   private static byte[] ohbfuymkquifxzy() {
      return new byte[]{0, 0, 0, 13, 0, 0, 1, 30};
   }

   private static byte[] lfnfslhdvqbrrza() {
      return new byte[]{0, 0, 0, 36, 0, 0, 1, 43};
   }

   static {
      rnxdxkcynl = ByteBuffer.wrap(ovnvbbubacdsgby()).asCharBuffer().toString();
   }

   private static byte[] ovnvbbubacdsgby() {
      return new byte[]{56, 95, 55, 90, 56, 95, 53, 81, 57, 65, 50, 26, 53, 86, 49, 84, 52, 84, 56, 87, 55, 65, 56, 80, 53, 83, 57, 75, 50, 25, 53, 93, 49, 91, 52, 88, 56, 80, 55, 89, 56, 84, 53, 80, 49, 89, 52, 86, 49, 94, 57, 85, 54, 65, 49, 25, 52, 87, 49, 81, 57, 93, 54, 93, 49, 64, 52, 88, 49, 87, 57, 67, 54, 22, 49, 92, 52, 80, 49, 84, 57, 85, 54, 21, 49, 66, 52, 88, 49, 94, 57, 89, 54, 84, 49, 88, 52, 88, 49, 29, 57, 94, 54, 89, 49, 89, 52, 92, 52, 95, 55, 90, 52, 91, 54, 82, 52, 77, 50, 26, 53, 90, 53, 87, 55, 89, 52, 87, 55, 65, 52, 84, 54, 80, 52, 71, 50, 25, 53, 77, 53, 27, 55, 91, 52, 84, 55, 83, 52, 70, 54, 82, 52, 64, 57, 91, 54, 93, 52, 91, 54, 80, 52, 64, 54, 27, 50, 90, 53, 87, 53, 89, 57, 83, 54, 70, 52, 84, 54, 82, 52, 74, 54, 24, 50, 90, 53, 87, 53, 89, 57, 83, 54, 31, 52, 83, 54, 90, 52, 75, 54, 91, 50, 85, 53, 66, 57, 21, 54, 116, 52, 115, 54, 115, 52, 127, 54, 112, 50, 114, 53, 19, 53, 68, 57, 90, 54, 83, 52, 76, 54, 80, 52, 75, 54, 19, 50, 20, 49, 65, 52, 92, 54, 87, 49, 64, 50, 84, 49, 67, 52, 21, 49, 90, 50, 86, 50, 89, 57, 87, 53, 74, 49, 26, 50, 87, 50, 86, 57, 95, 53, 86, 49, 67, 50, 88, 50, 80, 57, 65, 53, 29, 49, 81, 50, 86, 50, 69, 57, 95, 53, 82, 49, 67, 49, 20, 50, 9, 50, 7, 57, 116, 53, 117, 49, 7, 50, 9, 50, 19, 57, 18, 53, 16, 49, 113, 50, 127, 50, 113, 57, 116, 53, 117, 49, 113, 50, 28, 50, 85, 57, 83, 53, 95, 49, 86, 50, 87, 50, 84, 57, 87, 53, 22, 55, 19, 48, 80, 57, 85, 53, 90, 54, 86, 54, 94, 50, 90, 52, 80, 54, 19, 51, 4, 53, 92, 49, 92, 50, 95, 48, 68, 53, 76, 49, 108, 50, 92, 48, 94, 53, 86, 49, 86, 50, 72, 48, 110, 53, 86, 49, 82, 50, 92, 48, 84, 53, 76, 49, 82, 50, 86, 49, 83, 57, 91, 56, 89, 48, 68, 53, 64, 49, 104, 57, 89, 56, 88, 48, 95, 53, 81, 49, 78, 57, 107, 56, 89, 48, 80, 53, 89, 49, 82, 57, 64, 56, 86, 48, 86, 49, 80, 49, 91, 55, 91, 57, 67, 50, 66, 49, 107, 49, 89, 55, 90, 57, 88, 50, 83, 49, 77, 49, 107, 55, 91, 57, 87, 50, 91, 49, 81, 49, 64, 55, 84, 57, 81, 55, 68, 48, 84, 48, 84, 56, 83, 57, 82, 52, 68, 53, 111, 55, 80, 56, 88, 55, 90, 48, 81, 48, 91, 56, 93, 57, 69, 55, 80, 48, 90, 48, 89, 56, 77, 57, 67, 52, 111, 53, 93, 55, 87, 56, 87, 55, 81, 48, 76, 48, 104, 56, 86, 57, 86, 52, 93, 53, 85, 55, 76, 56, 88, 55, 83, 55, 65, 50, 88, 56, 84, 48, 88, 55, 84, 50, 77, 56, 104, 48, 91, 55, 80, 50, 87, 56, 83, 48, 95, 55, 84, 50, 75, 55, 92, 48, 92, 51, 87, 52, 85, 54, 78, 49, 111, 51, 93, 57, 85, 48, 91, 55, 84, 48, 71, 51, 88, 52, 87, 53, 85, 56, 90, 50, 94, 52, 86, 48, 76, 56, 21, 53, 92, 48, 85, 51, 93, 53, 93, 56, 65, 50, 81, 52, 84, 48, 70, 56, 22, 53, 71, 48, 68, 51, 84, 53, 89, 56, 65, 50, 85, 52, 30, 48, 92, 56, 86, 53, 70, 48, 81, 51, 66, 53, 78, 56, 84, 50, 92, 52, 30, 48, 65, 56, 81, 53, 81, 48, 95, 51, 67};
   }

   public static final class K extends ChannelDuplexHandler {
      private final UUID viewer;
      final EconomyManager teams;
      private final Channel channel;
      private volatile ChannelHandlerContext ctx;
      private static byte[] inanuehmhj;

      public K(UUID var1, EconomyManager var2, Channel var3) {
         this.viewer = var1;
         this.teams = var2;
         this.channel = var3;
      }

      public void handlerAdded(ChannelHandlerContext var1) {
         this.ctx = var1;
      }

      void syncLater(boolean var1) {
         EconomyManager var6 = this.teams;
         if (var6 != null) {
            try {
               Channel var8 = this.channel;
               EventLoop var9 = var8.eventLoop();
               Runnable var11 = () -> this.sync(var1);
               var9.execute(var11);
            } catch (Throwable var12) {
            }

         }
      }

      void sync(boolean var1) {
         ChannelHandlerContext var8 = this.ctx;
         ChannelHandlerContext var4 = var8;
         EconomyManager var10 = this.teams;
         if (var10 != null && var8 != null) {
            ArrayList var12 = new ArrayList();
            ArrayList var5 = var12;

            try {
               EconomyManager var14 = this.teams;
               var14.sync(var1, var5);
            } catch (Throwable var33) {
            }

            boolean var16 = var12.isEmpty();
            if (!var16) {
               Iterator var18 = var12.iterator();
               Iterator var6 = var18;

               while(true) {
                  boolean var20 = var6.hasNext();
                  if (!var20) {
                     ChannelHandlerContext var22 = var4.flush();
                     return;
                  }

                  Object var24 = var6.next();
                  ChannelPromise var31 = var4.voidPromise();
                  var4.write(var24, var31);
               }
            }
         }
      }

      public void write(ChannelHandlerContext var1, Object var2, ChannelPromise var3) throws Exception {
         Object var12 = null;
         ArrayList var9 = (ArrayList)var12;

         Object var47;
         try {
            label33: {
               EconomyManager var14 = this.teams;
               if (var14 != null) {
                  Class var16 = var2.getClass();
                  Class var5 = EconomyTransactionManager.teamPacketClass;
                  if (var16 == var5) {
                     ArrayList var17 = new ArrayList();
                     var9 = var17;
                     EconomyManager var19 = this.teams;
                     Object var20 = var19.onPacket(var2, var17);
                     var47 = var20;
                     break label33;
                  }
               }

               EconomyPacketListener var36 = EconomyPacketListener.getInstance();
               UUID var42 = this.viewer;
               Object var37 = var36.rewrite(var42, var2);
               var47 = var37;
            }
         } catch (Throwable var49) {
            var47 = var2;
         }

         if (var47 == null) {
            boolean var23 = var3.trySuccess();
         } else {
            super.write(var1, var47, var3);
         }

         if (var9 != null) {
            Iterator var26 = var9.iterator();
            Iterator var10 = var26;

            while(true) {
               boolean var28 = var10.hasNext();
               if (!var28) {
                  break;
               }

               Object var30 = var10.next();
               ChannelPromise var44 = var1.voidPromise();
               var1.write(var30, var44);
            }
         }

      }

      public static String ncqhsjfwus(byte[] var0, int var1) {
         String var8 = Integer.toString(var1);
         byte[] var9 = var8.getBytes();
         byte[] var6 = var9;
         byte var10 = 0;
         int var7 = var10;

         while(true) {
            int var15 = var0.length;
            if (var7 >= var15) {
               Charset var29 = StandardCharsets.UTF_16;
               String var14 = new String(var0, var29);
               return var14;
            }

            byte var18 = var0[var7];
            int var33 = var6.length;
            int var30 = var7 % var33;
            byte var26 = var6[var30];
            int var19 = var18 ^ var26;
            byte var20 = (byte)var19;
            var0[var7] = var20;
            byte var21 = var0[var7];
            byte[] var27 = inanuehmhj;
            byte[] var34 = inanuehmhj;
            int var35 = var34.length;
            int var32 = var7 % var35;
            byte var28 = var27[var32];
            int var22 = var21 ^ var28;
            byte var23 = (byte)var22;
            var0[var7] = var23;
            ++var7;
         }
      }

      static {
         inanuehmhj = drdoyotcnxwhufa();
      }

      private static byte[] drdoyotcnxwhufa() {
         return new byte[]{112, 51, 20, 13, 49, 117, 125, 18, 62, 113, 4, 89, 56, 48, 82, 121, 125, 83, 6, 82, 96, 103, 58, 123, 97, 66, 105, 40, 2, 51, 58, 115, 61, 37, 40};
      }
   }

   private static final class oO {
      final int id;
      final UUID world;
      final UUID owner;
      final UUID uuid;
      volatile String text;
      volatile float offset;
      volatile int vehicle;
      final Set<UUID> shown;

      oO(int var1, UUID var2, UUID var3) {
         UUID var5 = UUID.randomUUID();
         this.uuid = var5;
         float var13 = Float.NaN;
         this.offset = var13;
         byte var14 = -1;
         this.vehicle = var14;
         ConcurrentHashMap.KeySetView var15 = ConcurrentHashMap.newKeySet();
         this.shown = var15;
         this.id = var1;
         this.world = var2;
         this.owner = var3;
      }

      static {
      }
   }
}
