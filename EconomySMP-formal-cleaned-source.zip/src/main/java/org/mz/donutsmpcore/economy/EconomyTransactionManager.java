package org.mz.donutsmpcore.economy;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.RecordComponent;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.joml.Vector3f;
import skido.KKKoOKoOK;

public final class EconomyTransactionManager {
   private static final Logger LOG;
   private static final MethodHandles.Lookup L;
   private static boolean ready;
   private static boolean tried;
   private static Object accText;
   private static Object accStyleFlags;
   private static Object accBillboard;
   private static Object accTranslation;
   private static Object accPosRotInterp;
   private static byte styleFlags;
   private static byte billboardCenter;
   private static Object textDisplayType;
   private static Object vec3Zero;
   private static MethodHandle dataValueCreate;
   private static MethodHandle setDataCtor;
   private static MethodHandle addEntityCtor;
   private static MethodHandle setPassengersCtor;
   private static MethodHandle removeCtor;
   private static MethodHandle getHandle;
   private static MethodHandle chatFromString;
   private static MethodHandle sendPacket;
   private static MethodHandle entityGetId;
   private static Field connectionField;
   private static Field passengersField;
   private static Field networkField;
   private static Field channelField;
   static Class<?> passengersClass;
   static Class<?> removeClass;
   static Class<?> addEntityClass;
   static Class<?> bundleClass;
   private static MethodHandle passengersVehicle;
   private static MethodHandle passengersIds;
   private static MethodHandle passengersFromBuf;
   private static MethodHandle removeIds;
   private static MethodHandle addEntityId;
   private static MethodHandle bundleSub;
   private static MethodHandle bundleCtor;
   private static MethodHandle bufCtor;
   private static MethodHandle bufVarInt;
   private static MethodHandle bufVarIntArray;
   static Class<?> teamPacketClass;
   private static boolean teamReady;
   private static Field teamMethodField;
   private static MethodHandle teamName;
   private static MethodHandle teamPlayers;
   private static MethodHandle teamParams;
   private static MethodHandle teamPacketCtor;
   private static MethodHandle paramsFromTeam;
   private static MethodHandle scoreboardCtor;
   private static MethodHandle playerTeamCtor;
   private static MethodHandle playerTeamName;
   private static MethodHandle playerTeamPlayers;
   private static MethodHandle setVisibility;
   private static MethodHandle scoreboardTeams;
   private static Object visibilityNever;
   private static Object unsafe;
   private static Method allocate;
   private static String pinznrqcls;

   private EconomyTransactionManager() {
   }

   public static synchronized boolean init() {
      boolean var0 = tried;
      if (var0) {
         boolean var218 = ready;
         return var218;
      } else {
         boolean var32 = true;
         tried = var32;

         try {
            label101: {
               String var33 = jomdjntnzp(qcyuagkwwpolsug(), 916768804);
               Class var34 = KKKoOKoOK.forName(var33);
               Class var5 = var34;
               String var35 = jomdjntnzp(zhgkvjnggvhvwtt(), 8146007);
               Class var36 = KKKoOKoOK.forName(var35);
               String var37 = jomdjntnzp(vghjnmnhfckbfoc(), 1795057115);
               Class var38 = KKKoOKoOK.forName(var37);
               String var39 = jomdjntnzp(ivjtnpylxhiqywj(), 1949682913);
               Class var40 = KKKoOKoOK.forName(var39);
               String var41 = jomdjntnzp(xzeminwjwallfha(), 830221061);
               Class var42 = KKKoOKoOK.forName(var41);
               String var43 = jomdjntnzp(bwubxtfmxtxuxey(), 1779131890);
               Class var44 = KKKoOKoOK.forName(var43);
               String var45 = jomdjntnzp(jibhbxdcdczjaax(), 2057459454);
               Class var46 = KKKoOKoOK.forName(var45);
               String var47 = jomdjntnzp(gqxaflelirpbvam(), 1103587253);
               Class var48 = KKKoOKoOK.forName(var47);
               String var49 = jomdjntnzp(zxnsmcfyhvtrxzb(), 63601141);
               Class var50 = KKKoOKoOK.forName(var49);
               String var51 = jomdjntnzp(rlojsftldxeqyoe(), 847036015);
               Class var52 = KKKoOKoOK.forName(var51);
               String var53 = jomdjntnzp(xqcjgfyjkqjxjfy(), 76594750);
               Class var54 = KKKoOKoOK.forName(var53);
               String var55 = jomdjntnzp(dyzwvcnuxaszxyr(), 1762602973);
               Class var56 = KKKoOKoOK.forName(var55);
               String var57 = jomdjntnzp(ozpawfpmbsvjsle(), 8353872);
               Class var58 = KKKoOKoOK.forName(var57);
               Class var17 = var58;
               String var59 = jomdjntnzp(chtkmyurwxqudhh(), 1772318591);
               Class var60 = KKKoOKoOK.forName(var59);

               Class var19;
               try {
                  String var61 = jomdjntnzp(cmscehsjclorerv(), 1362248918);
                  Class var62 = KKKoOKoOK.forName(var61);
                  var19 = var62;
               } catch (ClassNotFoundException var372) {
                  String var216 = jomdjntnzp(elyzsstczeacakf(), 1475204701);
                  Class var217 = KKKoOKoOK.forName(var216);
                  var19 = var217;
               }

               String var64 = jomdjntnzp(lcmcafgmecuvpjj(), 1669144681);
               Class var65 = KKKoOKoOK.forName(var64);
               String var66 = jomdjntnzp(uykaqndfrmblxbu(), 1068943416);
               Class var67 = KKKoOKoOK.forName(var66);
               String var1 = jomdjntnzp(nkdlowtwqfnsrzu(), 723806032);
               Object var69 = staticField(var36, var1);
               accText = var69;
               String var219 = jomdjntnzp(ekjymqoxecihpiu(), 1026240163);
               Object var71 = staticField(var36, var219);
               accStyleFlags = var71;
               String var220 = jomdjntnzp(cjlonjjlkrftoqp(), 854799628);
               Object var73 = staticField(var34, var220);
               accBillboard = var73;
               String var221 = jomdjntnzp(ofvfqhcggauqwrn(), 1423715149);
               Object var75 = staticField(var34, var221);
               accTranslation = var75;

               try {
                  String var222 = jomdjntnzp(rxlxzmdxxgdqarr(), 1848920772);
                  Object var77 = staticField(var5, var222);
                  accPosRotInterp = var77;
               } catch (NoSuchFieldException var371) {
                  Object var79 = null;
                  accPosRotInterp = var79;
               }

               String var223 = jomdjntnzp(ojlpqzgrausotzb(), 1444510239);
               Object var81 = staticField(var36, var223);
               Number var82 = (Number)var81;
               byte var83 = var82.byteValue();
               String var2 = jomdjntnzp(feqcdlxoswioslx(), 1444510239);
               Object var225 = staticField(var36, var2);
               Number var226 = (Number)var225;
               byte var227 = var226.byteValue();
               int var84 = var83 | var227;
               byte var85 = (byte)var84;
               styleFlags = var85;
               String var228 = jomdjntnzp(dmehmxewgfisrfh(), 525400506);
               Object var87 = staticField(var38, var228);
               String var229 = jomdjntnzp(voecdnlmagadndv(), 1340422829);
               byte var277 = 0;
               Class[] var278 = new Class[var277];
               Method var89 = KKKoOKoOK.method(var38, var229, var278);
               boolean var230 = true;
               var89.setAccessible(var230);
               byte var279 = 0;
               Object[] var280 = new Object[var279];
               Object var92 = var89.invoke(var87, var280);
               Number var93 = (Number)var92;
               byte var94 = var93.byteValue();
               billboardCenter = var94;
               Object var95 = null;
               Object var25 = var95;

               try {
                  String var96 = jomdjntnzp(ytdhewijgoylvfx(), 1514872417);
                  Class var97 = KKKoOKoOK.forName(var96);
                  String var232 = jomdjntnzp(dmmqbvxsvjsncxz(), 1514872417);
                  Object var98 = staticField(var97, var232);
                  var25 = var98;
               } catch (ReflectiveOperationException var370) {
               }

               if (var25 == null) {
                  String var233 = jomdjntnzp(vtsvfukvmmjybrh(), 604283440);
                  Object var102 = staticField(var46, var233);
                  var25 = var102;
               }

               textDisplayType = var25;
               String var234 = jomdjntnzp(eopoxowpqsjaalq(), 1366377504);
               Object var105 = staticField(var48, var234);
               vec3Zero = var105;
               String var235 = jomdjntnzp(edcajqurhiccblt(), 657622979);
               byte var281 = 2;
               Class[] var282 = new Class[var281];
               byte var3 = 0;
               var282[var3] = var40;
               byte var326 = 1;
               Class var350 = Object.class;
               var282[var326] = var350;
               Method var107 = KKKoOKoOK.method(var42, var235, var282);
               MethodHandle var108 = handle(var107);
               dataValueCreate = var108;
               byte var236 = 2;
               Class[] var237 = new Class[var236];
               byte var308 = 0;
               Class var327 = Integer.TYPE;
               var237[var308] = var327;
               byte var309 = 1;
               Class var328 = List.class;
               var237[var309] = var328;
               MethodHandle var110 = ctor(var52, var237);
               setDataCtor = var110;
               byte var238 = 11;
               Class[] var239 = new Class[var238];
               byte var310 = 0;
               Class var329 = Integer.TYPE;
               var239[var310] = var329;
               byte var311 = 1;
               Class var330 = UUID.class;
               var239[var311] = var330;
               byte var312 = 2;
               Class var331 = Double.TYPE;
               var239[var312] = var331;
               byte var313 = 3;
               Class var332 = Double.TYPE;
               var239[var313] = var332;
               byte var314 = 4;
               Class var333 = Double.TYPE;
               var239[var314] = var333;
               byte var315 = 5;
               Class var334 = Float.TYPE;
               var239[var315] = var334;
               byte var316 = 6;
               Class var335 = Float.TYPE;
               var239[var316] = var335;
               byte var317 = 7;
               var239[var317] = var46;
               byte var318 = 8;
               Class var337 = Integer.TYPE;
               var239[var318] = var337;
               byte var319 = 9;
               var239[var319] = var48;
               byte var320 = 10;
               Class var339 = Double.TYPE;
               var239[var320] = var339;
               MethodHandle var112 = ctor(var54, var239);
               addEntityCtor = var112;
               byte var240 = 1;
               Class[] var241 = new Class[var240];
               byte var321 = 0;
               var241[var321] = var44;
               MethodHandle var114 = ctor(var56, var241);
               setPassengersCtor = var114;
               byte var242 = 1;
               Class[] var243 = new Class[var242];
               byte var322 = 0;
               Class var341 = int[].class;
               var243[var322] = var341;
               MethodHandle var116 = ctor(var58, var243);
               MethodHandle var117 = var116.asFixedArity();
               removeCtor = var117;
               String var244 = jomdjntnzp(tqkeinznmzdhcnh(), 289396133);
               byte var283 = 0;
               Class[] var284 = new Class[var283];
               Method var119 = KKKoOKoOK.method(var65, var244, var284);
               MethodHandle var120 = handle(var119);
               getHandle = var120;
               String var245 = jomdjntnzp(rwguwybmsshlqwj(), 1326781880);
               byte var285 = 2;
               Class[] var286 = new Class[var285];
               byte var342 = 0;
               Class var351 = String.class;
               var286[var342] = var351;
               byte var343 = 1;
               Class var352 = Boolean.TYPE;
               var286[var343] = var352;
               Method var122 = KKKoOKoOK.method(var67, var245, var286);
               MethodHandle var123 = handle(var122);
               chatFromString = var123;
               String var246 = jomdjntnzp(petszwsiemjnmuk(), 205439279);
               byte var287 = 1;
               Class[] var288 = new Class[var287];
               byte var344 = 0;
               var288[var344] = var50;
               Method var125 = KKKoOKoOK.method(var19, var246, var288);
               MethodHandle var126 = handle(var125);
               sendPacket = var126;
               String var247 = jomdjntnzp(wwhxyyrraajuqmz(), 1544688782);
               byte var289 = 0;
               Class[] var290 = new Class[var289];
               Method var128 = KKKoOKoOK.method(var44, var247, var290);
               MethodHandle var129 = handle(var128);
               entityGetId = var129;
               String var248 = jomdjntnzp(jrjisupvocwjqpy(), 1710736449);
               Field var131 = KKKoOKoOK.field(var60, var248);
               connectionField = var131;
               String var249 = jomdjntnzp(oxyqodytvhecmnp(), 194793793);
               Field var133 = KKKoOKoOK.field(var56, var249);
               passengersField = var133;
               Field var134 = passengersField;
               boolean var250 = true;
               var134.setAccessible(var250);
               String var135 = jomdjntnzp(aikcgtsycpzhjeu(), 184820012);
               Class var136 = KKKoOKoOK.forName(var135);
               Class var359 = var136;

               Class var153;
               for(Class var27 = var19; var27 != null; var27 = var153) {
                  Field var139 = networkField;
                  if (var139 != null) {
                     break;
                  }

                  Field[] var141 = var27.getDeclaredFields();
                  Field[] var28 = var141;
                  int var143 = var141.length;
                  int var29 = var143;
                  byte var144 = 0;

                  for(int var30 = var144; var30 < var29; ++var30) {
                     Field var147 = var28[var30];
                     Class var149 = var147.getType();
                     if (var149 == var359) {
                        boolean var254 = true;
                        var147.setAccessible(var254);
                        networkField = var147;
                        break;
                     }
                  }

                  var153 = var27.getSuperclass();
               }

               Field[] var159 = var359.getDeclaredFields();
               Field[] var360 = var159;
               int var161 = var159.length;
               int var362 = var161;
               byte var162 = 0;

               for(int var364 = var162; var364 < var362; ++var364) {
                  Field var165 = var360[var364];
                  Class var166 = Channel.class;
                  Class var261 = var165.getType();
                  boolean var167 = var166.isAssignableFrom(var261);
                  if (var167) {
                     boolean var262 = true;
                     var165.setAccessible(var262);
                     channelField = var165;
                     break;
                  }
               }

               Field var170 = networkField;
               if (var170 != null) {
                  Field var171 = channelField;
                  if (var171 != null) {
                     String var172 = jomdjntnzp(ghyyelzummosykk(), 662817982);
                     Class var173 = KKKoOKoOK.forName(var172);
                     String var174 = jomdjntnzp(nhtyqkftrdzmtye(), 990154613);
                     Class var175 = KKKoOKoOK.forName(var174);
                     passengersClass = var56;
                     removeClass = var58;
                     addEntityClass = var54;
                     bundleClass = var175;
                     String var263 = jomdjntnzp(khlsizkguddfflf(), 2105571568);
                     byte var291 = 0;
                     Class[] var292 = new Class[var291];
                     Method var181 = KKKoOKoOK.method(var56, var263, var292);
                     MethodHandle var182 = handle(var181);
                     passengersVehicle = var182;
                     String var264 = jomdjntnzp(nxahmmsursuoznr(), 374795181);
                     byte var293 = 0;
                     Class[] var294 = new Class[var293];
                     Method var184 = KKKoOKoOK.method(var56, var264, var294);
                     MethodHandle var185 = handle(var184);
                     passengersIds = var185;
                     byte var265 = 1;
                     Class[] var266 = new Class[var265];
                     byte var323 = 0;
                     var266[var323] = var173;
                     MethodHandle var187 = ctor(var56, var266);
                     passengersFromBuf = var187;

                     Method var365;
                     try {
                        String var267 = jomdjntnzp(eoetpqnkiisunfp(), 1640769179);
                        byte var295 = 0;
                        Class[] var296 = new Class[var295];
                        Method var189 = KKKoOKoOK.method(var17, var267, var296);
                        var365 = var189;
                     } catch (NoSuchMethodException var369) {
                        String var276 = jomdjntnzp(wvuolebslriemhb(), 536040089);
                        byte var305 = 0;
                        Class[] var306 = new Class[var305];
                        Method var213 = KKKoOKoOK.method(var58, var276, var306);
                        var365 = var213;
                     }

                     MethodHandle var191 = handle(var365);
                     removeIds = var191;
                     String var268 = jomdjntnzp(cjlksahaczxmfqq(), 1900018520);
                     byte var297 = 0;
                     Class[] var298 = new Class[var297];
                     Method var193 = KKKoOKoOK.method(var54, var268, var298);
                     MethodHandle var194 = handle(var193);
                     addEntityId = var194;
                     String var195 = jomdjntnzp(ispgvrgdiebabqa(), 688704227);
                     Class var196 = KKKoOKoOK.forName(var195);
                     String var269 = jomdjntnzp(erbmvbssticpcpn(), 688704227);
                     byte var299 = 0;
                     Class[] var300 = new Class[var299];
                     Method var197 = KKKoOKoOK.method(var196, var269, var300);
                     MethodHandle var199 = handle(var197);
                     bundleSub = var199;
                     byte var270 = 1;
                     Class[] var271 = new Class[var270];
                     byte var324 = 0;
                     Class var346 = Iterable.class;
                     var271[var324] = var346;
                     MethodHandle var201 = ctor(var175, var271);
                     bundleCtor = var201;
                     byte var272 = 1;
                     Class[] var273 = new Class[var272];
                     byte var325 = 0;
                     Class var347 = ByteBuf.class;
                     var273[var325] = var347;
                     MethodHandle var203 = ctor(var173, var273);
                     bufCtor = var203;
                     String var274 = jomdjntnzp(iwqjogwxkgjsegs(), 1004056251);
                     byte var301 = 1;
                     Class[] var302 = new Class[var301];
                     byte var348 = 0;
                     Class var354 = Integer.TYPE;
                     var302[var348] = var354;
                     Method var205 = KKKoOKoOK.method(var173, var274, var302);
                     MethodHandle var206 = handle(var205);
                     bufVarInt = var206;
                     String var275 = jomdjntnzp(dagoqsgobwgcnpm(), 1800907529);
                     byte var303 = 1;
                     Class[] var304 = new Class[var303];
                     byte var349 = 0;
                     Class var355 = int[].class;
                     var304[var349] = var355;
                     Method var208 = KKKoOKoOK.method(var173, var275, var304);
                     MethodHandle var209 = handle(var208);
                     bufVarIntArray = var209;
                     boolean var210 = true;
                     ready = var210;
                     initTeams();
                     break label101;
                  }
               }

               String var307 = jomdjntnzp(rsyxvhknkdgedbo(), 1299207784);
               NoSuchFieldException var214 = new NoSuchFieldException(var307);
               throw var214;
            }
         } catch (Throwable var373) {
            Logger var155 = LOG;
            String var256 = String.valueOf(var373);
            String var257 = "[money-nametags] NMS unavailable on this server version, nametags disabled: " + var256;
            var155.warning(var257);
            boolean var156 = false;
            ready = var156;
         }

         boolean var157 = ready;
         return var157;
      }
   }

   private static void initTeams() {
      try {
         String var0 = jomdjntnzp(ojxvsqkagqbladi(), 765975590);
         Class var13 = KKKoOKoOK.forName(var0);
         String var14 = jomdjntnzp(cihomuouupnecrw(), 1430998345);
         Class var15 = KKKoOKoOK.forName(var14);
         String var16 = jomdjntnzp(jbsmphovyixdzqn(), 66724898);
         Class var17 = KKKoOKoOK.forName(var16);
         String var18 = jomdjntnzp(ygwlswidyolweva(), 161728218);
         Class var19 = KKKoOKoOK.forName(var18);
         String var20 = jomdjntnzp(fqolerqkxvzfnep(), 197286130);
         Class var21 = KKKoOKoOK.forName(var20);
         String var1 = jomdjntnzp(lfuluhdriaqjwko(), 690500621);
         Field var23 = KKKoOKoOK.field(var13, var1);
         teamMethodField = var23;
         Field var24 = teamMethodField;
         boolean var72 = true;
         var24.setAccessible(var72);
         String var73 = jomdjntnzp(dmibijesccsrsck(), 1234875129);
         byte var2 = 0;
         Class[] var96 = new Class[var2];
         Method var26 = KKKoOKoOK.method(var13, var73, var96);
         MethodHandle var27 = handle(var26);
         teamName = var27;
         String var74 = jomdjntnzp(svuhhsyuhrgfbbm(), 1232529812);
         byte var97 = 0;
         Class[] var98 = new Class[var97];
         Method var29 = KKKoOKoOK.method(var13, var74, var98);
         MethodHandle var30 = handle(var29);
         teamPlayers = var30;
         String var75 = jomdjntnzp(jginfikbvqwdplf(), 1105830264);
         byte var99 = 0;
         Class[] var100 = new Class[var99];
         Method var32 = KKKoOKoOK.method(var13, var75, var100);
         MethodHandle var33 = handle(var32);
         teamParams = var33;
         byte var76 = 4;
         Class[] var77 = new Class[var76];
         byte var3 = 0;
         Class var4 = String.class;
         var77[var3] = var4;
         byte var111 = 1;
         Class var117 = Integer.TYPE;
         var77[var111] = var117;
         byte var112 = 2;
         Class var118 = Optional.class;
         var77[var112] = var118;
         byte var113 = 3;
         Class var119 = Collection.class;
         var77[var113] = var119;
         MethodHandle var35 = ctor(var13, var77);
         teamPacketCtor = var35;
         byte var78 = 1;
         Class[] var79 = new Class[var78];
         byte var114 = 0;
         var79[var114] = var19;
         MethodHandle var37 = ctor(var15, var79);
         paramsFromTeam = var37;
         byte var80 = 0;
         Class[] var81 = new Class[var80];
         MethodHandle var39 = ctor(var17, var81);
         scoreboardCtor = var39;
         byte var82 = 2;
         Class[] var83 = new Class[var82];
         byte var115 = 0;
         var83[var115] = var17;
         byte var116 = 1;
         Class var122 = String.class;
         var83[var116] = var122;
         MethodHandle var41 = ctor(var19, var83);
         playerTeamCtor = var41;
         String var84 = jomdjntnzp(mzxmpkxlemjitsm(), 1399703943);
         byte var101 = 0;
         Class[] var102 = new Class[var101];
         Method var43 = KKKoOKoOK.method(var19, var84, var102);
         MethodHandle var44 = handle(var43);
         playerTeamName = var44;
         String var85 = jomdjntnzp(kfpggcvwtejagsr(), 1602298356);
         byte var103 = 0;
         Class[] var104 = new Class[var103];
         Method var46 = KKKoOKoOK.method(var19, var85, var104);
         MethodHandle var47 = handle(var46);
         playerTeamPlayers = var47;
         String var86 = jomdjntnzp(kvsbbjwzlnayibz(), 980831755);
         byte var105 = 1;
         Class[] var106 = new Class[var105];
         byte var123 = 0;
         var106[var123] = var21;
         Method var49 = KKKoOKoOK.method(var19, var86, var106);
         MethodHandle var50 = handle(var49);
         setVisibility = var50;
         String var87 = jomdjntnzp(qlowntvjiwxvxwj(), 356290493);
         byte var107 = 0;
         Class[] var108 = new Class[var107];
         Method var52 = KKKoOKoOK.method(var17, var87, var108);
         MethodHandle var53 = handle(var52);
         scoreboardTeams = var53;
         String var88 = jomdjntnzp(tqugcgtjagttmcv(), 287129940);
         Object var55 = enumConstant(var21, var88);
         visibilityNever = var55;
         boolean var57 = var15.isRecord();
         if (!var57) {
            String var58 = jomdjntnzp(sjbgmuilfchabkd(), 2008871334);
            Class var59 = Class.forName(var58);
            String var89 = jomdjntnzp(edceffrwsjelmlq(), 1603626083);
            Field var61 = KKKoOKoOK.field(var59, var89);
            boolean var90 = true;
            var61.setAccessible(var90);
            Object var91 = null;
            Object var64 = var61.get(var91);
            unsafe = var64;
            String var92 = jomdjntnzp(wbeadkfqimyxhfq(), 810824663);
            byte var109 = 1;
            Class[] var110 = new Class[var109];
            byte var124 = 0;
            Class var125 = Class.class;
            var110[var124] = var125;
            Method var66 = KKKoOKoOK.method(var59, var92, var110);
            allocate = var66;
         }

         teamPacketClass = var13;
         boolean var68 = true;
         teamReady = var68;
      } catch (Throwable var127) {
         Logger var70 = LOG;
         String var94 = String.valueOf(var127);
         String var95 = "[money-nametags] team override unavailable: " + var94;
         var70.warning(var95);
         boolean var71 = false;
         teamReady = var71;
      }

   }

   private static Object enumConstant(Class<?> var0, String var1) {
      Enum var4 = Enum.valueOf(var0, var1);
      return var4;
   }

   public static boolean teamsReady() {
      boolean var0 = teamReady;
      return var0;
   }

   public static int teamMethod(Object var0) throws Throwable {
      Field var1 = teamMethodField;
      int var3 = var1.getInt(var0);
      return var3;
   }

   public static String teamName(Object var0) throws Throwable {
      MethodHandle var1 = teamName;
      String var3 = var1.invoke(var0);
      return var3;
   }

   public static Collection<String> teamPlayers(Object var0) throws Throwable {
      MethodHandle var1 = teamPlayers;
      Object var4 = var1.invoke(var0);
      Object var7;
      if (var4 == null) {
         var7 = List.of();
      } else {
         var7 = (Collection)var4;
      }

      return (Collection<String>)var7;
   }

   public static Object teamParams(Object var0) throws Throwable {
      MethodHandle var1 = teamParams;
      Optional var3 = var1.invoke(var0);
      Object var5 = null;
      Object var4 = var3.orElse(var5);
      return var4;
   }

   public static Object teamPacket(String var0, int var1, Object var2, Collection<String> var3) throws Throwable {
      MethodHandle var4 = teamPacketCtor;
      Optional var10 = Optional.ofNullable(var2);
      Object var9 = var4.invoke(var0, var1, var10, var3);
      return var9;
   }

   public static Object neverTeamParams(String var0) throws Throwable {
      MethodHandle var1 = playerTeamCtor;
      MethodHandle var2 = scoreboardCtor;
      Object var9 = var2.invoke();
      Object var5 = var1.invoke(var9, var0);
      MethodHandle var6 = setVisibility;
      Object var12 = visibilityNever;
      var6.invoke(var5, var12);
      MethodHandle var7 = paramsFromTeam;
      Object var8 = var7.invoke(var5);
      return var8;
   }

   private static boolean isVisibility(String var0) {
      Locale var2 = Locale.ROOT;
      String var3 = var0.toLowerCase(var2);
      String var5 = jomdjntnzp(kviunyugeoapffb(), 1068780761);
      boolean var4 = var3.contains(var5);
      return var4;
   }

   private static Object never(Class<?> var0) {
      Class var2 = String.class;
      Object var3;
      if (var0 == var2) {
         var3 = jomdjntnzp(tklgodwutddapgv(), 550361867);
      } else {
         var3 = visibilityNever;
      }

      return var3;
   }

   public static boolean isNever(Object var0) {
      if (var0 == null) {
         boolean var31 = false;
         return var31;
      } else {
         try {
            Class var9 = var0.getClass();
            Field[] var10 = var9.getDeclaredFields();
            Field[] var3 = var10;
            int var12 = var10.length;
            int var4 = var12;
            byte var13 = 0;

            for(int var5 = var13; var5 < var4; ++var5) {
               Field var16 = var3[var5];
               int var18 = var16.getModifiers();
               boolean var19 = Modifier.isStatic(var18);
               if (!var19) {
                  String var21 = var16.getName();
                  boolean var22 = isVisibility(var21);
                  if (var22) {
                     boolean var34 = true;
                     var16.setAccessible(var34);
                     Object var25 = var16.get(var0);
                     Object var36 = visibilityNever;
                     boolean var32;
                     if (var25 != var36) {
                        String var27 = jomdjntnzp(nalulzutvbuefki(), 1862538461);
                        boolean var28 = var27.equals(var25);
                        if (!var28) {
                           var32 = false;
                           return var32;
                        }
                     }

                     var32 = true;
                     return var32;
                  }
               }
            }
         } catch (Throwable var39) {
         }

         boolean var30 = false;
         return var30;
      }
   }

   public static Object neverCopy(Object var0) throws Throwable {
      Class var13 = var0.getClass();
      boolean var15 = var13.isRecord();
      if (var15) {
         RecordComponent[] var17 = var13.getRecordComponents();
         RecordComponent[] var8 = var17;
         int var19 = var17.length;
         Class[] var20 = new Class[var19];
         Class[] var9 = var20;
         int var22 = var17.length;
         Object[] var23 = new Object[var22];
         Object[] var10 = var23;
         byte var24 = 0;
         int var11 = var24;

         while(true) {
            int var53 = var8.length;
            if (var11 >= var53) {
               Constructor var33 = var13.getDeclaredConstructor(var9);
               boolean var59 = true;
               var33.setAccessible(var59);
               Object var36 = var33.newInstance(var10);
               return var36;
            }

            RecordComponent var66 = var8[var11];
            Class var67 = var66.getType();
            var9[var11] = var67;
            RecordComponent var28 = var8[var11];
            Method var29 = var28.getAccessor();
            boolean var56 = true;
            var29.setAccessible(var56);
            RecordComponent var69 = var8[var11];
            String var70 = var69.getName();
            boolean var71 = isVisibility(var70);
            Object var84;
            if (var71) {
               Class var73 = var9[var11];
               var84 = never(var73);
            } else {
               byte var5 = 0;
               Object[] var89 = new Object[var5];
               var84 = var29.invoke(var0, var89);
            }

            var10[var11] = var84;
            ++var11;
         }
      } else {
         Method var37 = allocate;
         Object var61 = unsafe;
         byte var75 = 1;
         Object[] var76 = new Object[var75];
         byte var90 = 0;
         var76[var90] = var13;
         Object var38 = var37.invoke(var61, var76);
         Object var91 = var38;
         Field[] var40 = var13.getDeclaredFields();
         Field[] var92 = var40;
         int var42 = var40.length;
         int var93 = var42;
         byte var43 = 0;

         for(int var95 = var43; var95 < var93; ++var95) {
            Field var46 = var92[var95];
            int var48 = var46.getModifiers();
            boolean var49 = Modifier.isStatic(var48);
            if (!var49) {
               boolean var64 = true;
               var46.setAccessible(var64);
               String var78 = var46.getName();
               boolean var79 = isVisibility(var78);
               Object var83;
               if (var79) {
                  Class var82 = var46.getType();
                  var83 = never(var82);
               } else {
                  var83 = var46.get(var0);
               }

               var46.set(var91, var83);
            }
         }

         return var91;
      }
   }

   public static Map<String, Object[]> clientTeams(Player var0) {
      HashMap var1 = new HashMap();
      HashMap var7 = var1;
      boolean var12 = teamReady;
      if (!var12) {
         return var1;
      } else {
         try {
            Object var13 = null;
            Object var8 = var13;

            try {
               Class var15 = var0.getClass();
               String var46 = jomdjntnzp(vtwnyjemcmqpbnc(), 2144046931);
               byte var2 = 0;
               Class[] var58 = new Class[var2];
               Method var16 = KKKoOKoOK.method(var15, var46, var58);
               byte var59 = 0;
               Object[] var60 = new Object[var59];
               Object var17 = var16.invoke(var0, var60);
               Class var19 = var17.getClass();
               String var48 = jomdjntnzp(qexkkcfvyksmgkg(), 338495807);
               byte var61 = 0;
               Class[] var62 = new Class[var61];
               Method var20 = KKKoOKoOK.method(var19, var48, var62);
               byte var63 = 0;
               Object[] var64 = new Object[var63];
               Object var21 = var20.invoke(var17, var64);
               var8 = var21;
            } catch (Throwable var83) {
            }

            if (var8 == null) {
               Server var23 = Bukkit.getServer();
               Class var24 = var23.getClass();
               String var50 = jomdjntnzp(ghlizmjfvbnmbts(), 1543309764);
               byte var65 = 0;
               Class[] var66 = new Class[var65];
               Method var25 = KKKoOKoOK.method(var24, var50, var66);
               Server var51 = Bukkit.getServer();
               byte var67 = 0;
               Object[] var68 = new Object[var67];
               Object var26 = var25.invoke(var51, var68);
               Class var28 = var26.getClass();
               String var52 = jomdjntnzp(hymaajwqtiqrfxs(), 449392989);
               byte var69 = 0;
               Class[] var70 = new Class[var69];
               Method var29 = KKKoOKoOK.method(var28, var52, var70);
               byte var71 = 0;
               Object[] var72 = new Object[var71];
               Object var30 = var29.invoke(var26, var72);
               var8 = var30;
            }

            MethodHandle var31 = scoreboardTeams;
            Collection var32 = var31.invoke(var8);
            Iterator var33 = var32.iterator();
            Iterator var81 = var33;

            while(true) {
               boolean var35 = var81.hasNext();
               if (!var35) {
                  break;
               }

               Object var38 = var81.next();
               MethodHandle var39 = playerTeamPlayers;
               Collection var40 = var39.invoke(var38);
               MethodHandle var56 = playerTeamName;
               String var57 = var56.invoke(var38);
               byte var74 = 2;
               Object[] var75 = new Object[var74];
               byte var3 = 0;
               MethodHandle var4 = paramsFromTeam;
               Object var77 = var4.invoke(var38);
               var75[var3] = var77;
               byte var76 = 1;
               ArrayList var78 = new ArrayList(var40);
               var75[var76] = var78;
               var7.put(var57, var75);
            }
         } catch (Throwable var84) {
         }

         return var7;
      }
   }

   private static Object staticField(Class<?> var0, String var1) throws ReflectiveOperationException {
      Field var5 = KKKoOKoOK.field(var0, var1);
      boolean var9 = true;
      var5.setAccessible(var9);
      Object var10 = null;
      Object var8 = var5.get(var10);
      return var8;
   }

   private static MethodHandle ctor(Class<?> var0, Class<?>... var1) throws ReflectiveOperationException {
      Constructor var5 = var0.getDeclaredConstructor(var1);
      boolean var9 = true;
      var5.setAccessible(var9);
      MethodHandles.Lookup var7 = L;
      MethodHandle var8 = var7.unreflectConstructor(var5);
      return var8;
   }

   private static MethodHandle handle(Method var0) throws IllegalAccessException {
      boolean var2 = true;
      var0.setAccessible(var2);
      MethodHandles.Lookup var3 = L;
      MethodHandle var4 = var3.unreflect(var0);
      return var4;
   }

   public static Object handle(Player var0) throws Throwable {
      MethodHandle var1 = getHandle;
      Object var3 = var1.invoke(var0);
      return var3;
   }

   public static Object connection(Player var0) throws Throwable {
      Field var1 = connectionField;
      Object var4 = handle(var0);
      Object var3 = var1.get(var4);
      return var3;
   }

   public static void send(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         try {
            MethodHandle var7 = sendPacket;
            var7.invoke(var0, var1);
         } catch (Throwable var9) {
         }

      }
   }

   public static Object spawnPacket(int var0, UUID var1, Location var2) throws Throwable {
      MethodHandle var3 = addEntityCtor;
      double var17 = var2.getX();
      double var19 = var2.getY();
      double var21 = var2.getZ();
      float var9 = 0.0F;
      float var10 = 0.0F;
      Object var11 = textDisplayType;
      byte var12 = 0;
      Object var13 = vec3Zero;
      double var14 = (double)0.0F;
      Object var16 = var3.invoke(var0, var1, var17, var19, var21, var9, var10, var11, var12, var13, var14);
      return var16;
   }

   public static Object dataPacket(int var0, String var1, float var2) throws Throwable {
      MethodHandle var3 = chatFromString;
      boolean var5 = true;
      Object var12 = var3.invoke(var1, var5);
      byte var38 = 5;
      ArrayList var13 = new ArrayList(var38);
      MethodHandle var27 = dataValueCreate;
      Object var39 = accText;
      Object var28 = var27.invoke(var39, var12);
      boolean var15 = var13.add(var28);
      MethodHandle var29 = dataValueCreate;
      Object var40 = accStyleFlags;
      byte var45 = styleFlags;
      Object var30 = var29.invoke(var40, var45);
      var13.add(var30);
      MethodHandle var31 = dataValueCreate;
      Object var41 = accBillboard;
      byte var46 = billboardCenter;
      Object var32 = var31.invoke(var41, var46);
      var13.add(var32);
      MethodHandle var33 = dataValueCreate;
      Object var42 = accTranslation;
      float var7 = 0.0F;
      float var9 = 0.0F;
      Vector3f var47 = new Vector3f(var7, var2, var9);
      Object var34 = var33.invoke(var42, var47);
      var13.add(var34);
      Object var22 = accPosRotInterp;
      if (var22 != null) {
         MethodHandle var35 = dataValueCreate;
         Object var43 = accPosRotInterp;
         byte var48 = 0;
         Object var36 = var35.invoke(var43, var48);
         boolean var24 = var13.add(var36);
      }

      MethodHandle var25 = setDataCtor;
      Object var26 = var25.invoke(var0, var13);
      return var26;
   }

   public static Object passengersPacket(Object var0, int var1) throws Throwable {
      MethodHandle var2 = setPassengersCtor;
      Object var13 = var2.invoke(var0);
      Field var14 = passengersField;
      Object var15 = var14.get(var13);
      int[] var16 = (int[])var15;
      int[] var9 = var16;
      int var19 = var16.length;
      int var10 = var19;
      byte var20 = 0;

      for(int var11 = var20; var11 < var10; ++var11) {
         int var31 = var9[var11];
         if (var31 == var1) {
            return var13;
         }
      }

      int var23 = var16.length;
      byte var36 = 1;
      int var24 = var23 + var36;
      int[] var25 = new int[var24];
      byte var37 = 0;
      byte var5 = 0;
      int var45 = var16.length;
      System.arraycopy(var16, var37, var25, var5, var45);
      int var39 = var16.length;
      var25[var39] = var1;
      Field var28 = passengersField;
      var28.set(var13, var25);
      return var13;
   }

   public static Object removePacket(int var0) throws Throwable {
      MethodHandle var1 = removeCtor;
      byte var2 = 1;
      int[] var6 = new int[var2];
      byte var3 = 0;
      var6[var3] = var0;
      Object var5 = var1.invoke(var6);
      return var5;
   }

   public static Object removePacket(int[] var0) throws Throwable {
      MethodHandle var1 = removeCtor;
      Object var3 = var1.invoke(var0);
      return var3;
   }

   public static Channel channel(Player var0) throws Throwable {
      Field var1 = channelField;
      Field var2 = networkField;
      Object var7 = connection(var0);
      Object var6 = var2.get(var7);
      Object var4 = var1.get(var6);
      Channel var5 = (Channel)var4;
      return var5;
   }

   public static int vehicleOf(Object var0) throws Throwable {
      MethodHandle var1 = passengersVehicle;
      int var3 = var1.invoke(var0);
      return var3;
   }

   public static int[] passengersOf(Object var0) throws Throwable {
      MethodHandle var1 = passengersIds;
      int[] var3 = var1.invoke(var0);
      return var3;
   }

   public static Object passengers(int var0, int[] var1) throws Throwable {
      ByteBuf var2 = Unpooled.buffer();
      ByteBuf var5 = var2;

      Object var7;
      try {
         MethodHandle var9 = bufCtor;
         Object var10 = var9.invoke(var5);
         MethodHandle var11 = bufVarInt;
         var11.invoke(var10, var0);
         MethodHandle var12 = bufVarIntArray;
         var12.invoke(var10, var1);
         MethodHandle var13 = passengersFromBuf;
         Object var14 = var13.invoke(var10);
         var7 = var14;
      } catch (Throwable var26) {
         boolean var20 = var2.release();
         throw var26;
      }

      boolean var16 = var2.release();
      return var7;
   }

   public static Collection<?> removedIds(Object var0) throws Throwable {
      MethodHandle var1 = removeIds;
      Collection var3 = var1.invoke(var0);
      return var3;
   }

   public static int addedId(Object var0) throws Throwable {
      MethodHandle var1 = addEntityId;
      int var3 = var1.invoke(var0);
      return var3;
   }

   public static Iterable<?> subPackets(Object var0) throws Throwable {
      MethodHandle var1 = bundleSub;
      Iterable var3 = var1.invoke(var0);
      return var3;
   }

   public static Object bundle(List<Object> var0) throws Throwable {
      MethodHandle var1 = bundleCtor;
      Object var3 = var1.invoke(var0);
      return var3;
   }

   public static int entityId(Object var0) throws Throwable {
      MethodHandle var1 = entityGetId;
      int var3 = var1.invoke(var0);
      return var3;
   }

   static {
      pinznrqcls = ByteBuffer.wrap(nvjjnbknqjxmliu()).asCharBuffer().toString();
      String var0 = jomdjntnzp(sslkfhyxeyuxgwo(), 1191813687);
      Logger var1 = Logger.getLogger(var0);
      LOG = var1;
      MethodHandles.Lookup var2 = MethodHandles.lookup();
      L = var2;
   }

   public static String jomdjntnzp(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = pinznrqcls;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] sslkfhyxeyuxgwo() {
      return new byte[]{0, 0, 0, 12, 0, 0, 0, 0};
   }

   private static byte[] qcyuagkwwpolsug() {
      return new byte[]{0, 0, 0, 34, 0, 0, 0, 12};
   }

   private static byte[] nhtyqkftrdzmtye() {
      return new byte[]{0, 0, 0, 59, 0, 0, 0, 46};
   }

   private static byte[] lcmcafgmecuvpjj() {
      return new byte[]{0, 0, 0, 41, 0, 0, 0, 105};
   }

   private static byte[] dyzwvcnuxaszxyr() {
      return new byte[]{0, 0, 0, 66, 0, 0, 0, -110};
   }

   private static byte[] nkdlowtwqfnsrzu() {
      return new byte[]{0, 0, 0, 12, 0, 0, 0, -44};
   }

   private static byte[] ivjtnpylxhiqywj() {
      return new byte[]{0, 0, 0, 48, 0, 0, 0, -32};
   }

   private static byte[] ofvfqhcggauqwrn() {
      return new byte[]{0, 0, 0, 19, 0, 0, 1, 16};
   }

   private static byte[] zxnsmcfyhvtrxzb() {
      return new byte[]{0, 0, 0, 37, 0, 0, 1, 35};
   }

   private static byte[] cmscehsjclorerv() {
      return new byte[]{0, 0, 0, 59, 0, 0, 1, 72};
   }

   private static byte[] wwhxyyrraajuqmz() {
      return new byte[]{0, 0, 0, 5, 0, 0, 1, -125};
   }

   private static byte[] elyzsstczeacakf() {
      return new byte[]{0, 0, 0, 57, 0, 0, 1, -120};
   }

   private static byte[] eopoxowpqsjaalq() {
      return new byte[]{0, 0, 0, 4, 0, 0, 1, -63};
   }

   private static byte[] zhgkvjnggvhvwtt() {
      return new byte[]{0, 0, 0, 46, 0, 0, 1, -59};
   }

   private static byte[] ojlpqzgrausotzb() {
      return new byte[]{0, 0, 0, 11, 0, 0, 1, -13};
   }

   private static byte[] feqcdlxoswioslx() {
      return new byte[]{0, 0, 0, 27, 0, 0, 1, -2};
   }

   private static byte[] cjlksahaczxmfqq() {
      return new byte[]{0, 0, 0, 5, 0, 0, 2, 25};
   }

   private static byte[] cjlonjjlkrftoqp() {
      return new byte[]{0, 0, 0, 36, 0, 0, 2, 30};
   }

   private static byte[] uykaqndfrmblxbu() {
      return new byte[]{0, 0, 0, 44, 0, 0, 2, 66};
   }

   private static byte[] xzeminwjwallfha() {
      return new byte[]{0, 0, 0, 57, 0, 0, 2, 110};
   }

   private static byte[] iwqjogwxkgjsegs() {
      return new byte[]{0, 0, 0, 11, 0, 0, 2, -89};
   }

   private static byte[] edcajqurhiccblt() {
      return new byte[]{0, 0, 0, 6, 0, 0, 2, -78};
   }

   private static byte[] tqkeinznmzdhcnh() {
      return new byte[]{0, 0, 0, 9, 0, 0, 2, -72};
   }

   private static byte[] dagoqsgobwgcnpm() {
      return new byte[]{0, 0, 0, 16, 0, 0, 2, -63};
   }

   private static byte[] rwguwybmsshlqwj() {
      return new byte[]{0, 0, 0, 16, 0, 0, 2, -47};
   }

   private static byte[] eoetpqnkiisunfp() {
      return new byte[]{0, 0, 0, 12, 0, 0, 2, -31};
   }

   private static byte[] dmehmxewgfisrfh() {
      return new byte[]{0, 0, 0, 6, 0, 0, 2, -19};
   }

   private static byte[] xqcjgfyjkqjxjfy() {
      return new byte[]{0, 0, 0, 62, 0, 0, 2, -13};
   }

   private static byte[] rlojsftldxeqyoe() {
      return new byte[]{0, 0, 0, 66, 0, 0, 3, 49};
   }

   private static byte[] gqxaflelirpbvam() {
      return new byte[]{0, 0, 0, 29, 0, 0, 3, 115};
   }

   private static byte[] wvuolebslriemhb() {
      return new byte[]{0, 0, 0, 9, 0, 0, 3, -112};
   }

   private static byte[] rxlxzmdxxgdqarr() {
      return new byte[]{0, 0, 0, 38, 0, 0, 3, -103};
   }

   private static byte[] jibhbxdcdczjaax() {
      return new byte[]{0, 0, 0, 37, 0, 0, 3, -65};
   }

   private static byte[] petszwsiemjnmuk() {
      return new byte[]{0, 0, 0, 4, 0, 0, 3, -28};
   }

   private static byte[] ytdhewijgoylvfx() {
      return new byte[]{0, 0, 0, 38, 0, 0, 3, -24};
   }

   private static byte[] dmmqbvxsvjsncxz() {
      return new byte[]{0, 0, 0, 12, 0, 0, 4, 14};
   }

   private static byte[] ghyyelzummosykk() {
      return new byte[]{0, 0, 0, 37, 0, 0, 4, 26};
   }

   private static byte[] bwubxtfmxtxuxey() {
      return new byte[]{0, 0, 0, 33, 0, 0, 4, 63};
   }

   private static byte[] aikcgtsycpzhjeu() {
      return new byte[]{0, 0, 0, 32, 0, 0, 4, 96};
   }

   private static byte[] rsyxvhknkdgedbo() {
      return new byte[]{0, 0, 0, 18, 0, 0, 4, -128};
   }

   private static byte[] oxyqodytvhecmnp() {
      return new byte[]{0, 0, 0, 10, 0, 0, 4, -110};
   }

   private static byte[] khlsizkguddfflf() {
      return new byte[]{0, 0, 0, 10, 0, 0, 4, -100};
   }

   private static byte[] ozpawfpmbsvjsle() {
      return new byte[]{0, 0, 0, 67, 0, 0, 4, -90};
   }

   private static byte[] vghjnmnhfckbfoc() {
      return new byte[]{0, 0, 0, 55, 0, 0, 4, -23};
   }

   private static byte[] nxahmmsursuoznr() {
      return new byte[]{0, 0, 0, 13, 0, 0, 5, 32};
   }

   private static byte[] chtkmyurwxqudhh() {
      return new byte[]{0, 0, 0, 39, 0, 0, 5, 45};
   }

   private static byte[] voecdnlmagadndv() {
      return new byte[]{0, 0, 0, 5, 0, 0, 5, 84};
   }

   private static byte[] vtsvfukvmmjybrh() {
      return new byte[]{0, 0, 0, 12, 0, 0, 5, 89};
   }

   private static byte[] ekjymqoxecihpiu() {
      return new byte[]{0, 0, 0, 19, 0, 0, 5, 101};
   }

   private static byte[] jrjisupvocwjqpy() {
      return new byte[]{0, 0, 0, 10, 0, 0, 5, 120};
   }

   private static byte[] ispgvrgdiebabqa() {
      return new byte[]{0, 0, 0, 43, 0, 0, 5, -126};
   }

   private static byte[] erbmvbssticpcpn() {
      return new byte[]{0, 0, 0, 10, 0, 0, 5, -83};
   }

   private static byte[] sjbgmuilfchabkd() {
      return new byte[]{0, 0, 0, 15, 0, 0, 5, -73};
   }

   private static byte[] qlowntvjiwxvxwj() {
      return new byte[]{0, 0, 0, 14, 0, 0, 5, -58};
   }

   private static byte[] wbeadkfqimyxhfq() {
      return new byte[]{0, 0, 0, 16, 0, 0, 5, -44};
   }

   private static byte[] cihomuouupnecrw() {
      return new byte[]{0, 0, 0, 77, 0, 0, 5, -28};
   }

   private static byte[] mzxmpkxlemjitsm() {
      return new byte[]{0, 0, 0, 7, 0, 0, 6, 49};
   }

   private static byte[] ojxvsqkagqbladi() {
      return new byte[]{0, 0, 0, 66, 0, 0, 6, 56};
   }

   private static byte[] ygwlswidyolweva() {
      return new byte[]{0, 0, 0, 37, 0, 0, 6, 122};
   }

   private static byte[] jginfikbvqwdplf() {
      return new byte[]{0, 0, 0, 13, 0, 0, 6, -97};
   }

   private static byte[] kfpggcvwtejagsr() {
      return new byte[]{0, 0, 0, 10, 0, 0, 6, -84};
   }

   private static byte[] edceffrwsjelmlq() {
      return new byte[]{0, 0, 0, 9, 0, 0, 6, -74};
   }

   private static byte[] dmibijesccsrsck() {
      return new byte[]{0, 0, 0, 7, 0, 0, 6, -65};
   }

   private static byte[] kvsbbjwzlnayibz() {
      return new byte[]{0, 0, 0, 20, 0, 0, 6, -58};
   }

   private static byte[] lfuluhdriaqjwko() {
      return new byte[]{0, 0, 0, 6, 0, 0, 6, -38};
   }

   private static byte[] svuhhsyuhrgfbbm() {
      return new byte[]{0, 0, 0, 10, 0, 0, 6, -32};
   }

   private static byte[] tqugcgtjagttmcv() {
      return new byte[]{0, 0, 0, 5, 0, 0, 6, -22};
   }

   private static byte[] jbsmphovyixdzqn() {
      return new byte[]{0, 0, 0, 37, 0, 0, 6, -17};
   }

   private static byte[] fqolerqkxvzfnep() {
      return new byte[]{0, 0, 0, 42, 0, 0, 7, 20};
   }

   private static byte[] kviunyugeoapffb() {
      return new byte[]{0, 0, 0, 10, 0, 0, 7, 62};
   }

   private static byte[] tklgodwutddapgv() {
      return new byte[]{0, 0, 0, 5, 0, 0, 7, 72};
   }

   private static byte[] nalulzutvbuefki() {
      return new byte[]{0, 0, 0, 5, 0, 0, 7, 77};
   }

   private static byte[] ghlizmjfvbnmbts() {
      return new byte[]{0, 0, 0, 9, 0, 0, 7, 82};
   }

   private static byte[] vtwnyjemcmqpbnc() {
      return new byte[]{0, 0, 0, 13, 0, 0, 7, 91};
   }

   private static byte[] qexkkcfvyksmgkg() {
      return new byte[]{0, 0, 0, 9, 0, 0, 7, 104};
   }

   private static byte[] hymaajwqtiqrfxs() {
      return new byte[]{0, 0, 0, 13, 0, 0, 7, 113};
   }

   private static byte[] nvjjnbknqjxmliu() {
      return new byte[]{49, 117, 57, 94, 56, 95, 51, 67, 56, 67, 49, 98, 57, 124, 56, 97, 51, 117, 56, 88, 49, 67, 57, 84, 57, 95, 54, 82, 54, 76, 56, 30, 52, 84, 49, 95, 55, 88, 56, 93, 48, 87, 57, 67, 54, 86, 54, 94, 56, 68, 52, 23, 49, 65, 55, 89, 56, 74, 48, 88, 57, 85, 54, 25, 54, 93, 56, 94, 52, 77, 49, 95, 55, 66, 56, 65, 48, 26, 57, 117, 54, 94, 54, 75, 56, 64, 52, 85, 49, 87, 55, 79, 57, 87, 48, 84, 53, 64, 54, 31, 51, 84, 57, 89, 49, 91, 52, 83, 49, 80, 57, 75, 48, 80, 53, 82, 54, 69, 51, 23, 57, 94, 49, 80, 52, 66, 49, 68, 57, 86, 48, 67, 53, 95, 54, 31, 51, 73, 57, 66, 49, 90, 52, 66, 49, 92, 57, 90, 48, 94, 53, 88, 54, 31, 51, 94, 57, 81, 49, 88, 52, 83, 49, 29, 57, 122, 48, 93, 53, 93, 54, 84, 51, 87, 57, 68, 49, 87, 52, 89, 49, 70, 57, 87, 48, 85, 53, 118, 54, 68, 51, 87, 57, 84, 49, 89, 52, 83, 49, 99, 57, 88, 48, 82, 53, 95, 54, 84, 51, 77, 49, 89, 54, 75, 49, 83, 52, 24, 56, 83, 49, 67, 54, 82, 49, 95, 52, 95, 56, 69, 49, 24, 54, 90, 49, 70, 52, 87, 56, 87, 49, 66, 54, 91, 49, 65, 52, 93, 56, 90, 49, 95, 54, 77, 49, 26, 52, 83, 56, 95, 49, 66, 54, 80, 49, 64, 52, 79, 56, 31, 49, 117, 54, 75, 49, 85, 52, 80, 56, 69, 49, 102, 54, 85, 49, 85, 52, 79, 56, 84, 49, 68, 49, 89, 54, 87, 54, 68, 50, 23, 55, 94, 49, 94, 54, 92, 54, 85, 50, 90, 55, 65, 49, 86, 54, 84, 54, 68, 50, 23, 55, 93, 49, 82, 54, 70, 54, 71, 50, 86, 55, 65, 49, 92, 54, 28, 54, 64, 50, 75, 55, 92, 49, 67, 54, 93, 54, 83, 50, 86, 55, 95, 49, 25, 54, 85, 54, 81, 50, 84, 55, 86, 49, 25, 54, 113, 54, 92, 50, 80, 55, 86, 49, 89, 54, 70, 54, 82, 50, 86, 55, 70, 49, 89, 54, 86, 54, 99, 50, 92, 55, 71, 49, 103, 54, 83, 54, 67, 50, 74, 55, 86, 49, 89, 54, 85, 54, 85, 50, 75, 55, 64, 49, 103, 54, 83, 54, 83, 50, 82, 55, 86, 49, 67, 55, 118, 51, 121, 48, 98, 48, 114, 50, 104, 50, 103, 56, 117, 54, 104, 51, 102, 55, 109, 51, 113, 48, 114, 49, 87, 52, 92, 54, 76, 50, 23, 49, 94, 49, 80, 52, 87, 54, 93, 50, 90, 49, 65, 49, 88, 52, 95, 54, 76, 50, 23, 49, 93, 49, 92, 52, 77, 54, 79, 50, 86, 49, 65, 49, 82, 52, 23, 54, 75, 50, 64, 49, 93, 49, 90, 52, 81, 54, 93, 50, 75, 49, 29, 49, 124, 52, 87, 54, 76, 50, 80, 49, 71, 49, 64, 52, 125, 54, 89, 50, 77, 49, 82, 49, 120, 52, 90, 54, 91, 50, 92, 49, 64, 49, 74, 52, 86, 54, 74, 49, 112, 50, 114, 55, 101, 53, 112, 52, 102, 49, 96, 50, 97, 55, 112, 53, 127, 52, 106, 49, 120, 50, 114, 55, 101, 53, 120, 52, 118, 49, 122, 50, 108, 55, 120, 53, 117, 54, 93, 54, 85, 49, 69, 52, 31, 54, 94, 54, 89, 49, 95, 52, 84, 54, 80, 54, 66, 49, 80, 52, 87, 54, 71, 54, 30, 49, 95, 52, 84, 54, 71, 54, 71, 49, 94, 52, 67, 54, 88, 54, 30, 49, 65, 52, 67, 54, 92, 54, 68, 49, 94, 52, 82, 54, 92, 54, 92, 49, 31, 52, 97, 54, 82, 54, 83, 49, 90, 52, 84, 54, 71, 49, 93, 54, 87, 50, 64, 56, 23, 49, 85, 49, 90, 54, 92, 50, 81, 56, 90, 49, 74, 49, 82, 54, 84, 50, 64, 56, 23, 49, 75, 49, 86, 54, 64, 50, 66, 56, 92, 49, 74, 49, 29, 54, 92, 50, 81, 56, 77, 49, 79, 49, 92, 54, 64, 50, 95, 56, 23, 49, 107, 49, 86, 54, 64, 50, 66, 56, 92, 49, 74, 49, 112, 54, 93, 50, 89, 56, 84, 49, 87, 49, 93, 54, 98, 50, 85, 56, 90, 49, 83, 49, 86, 54, 70, 50, 120, 56, 80, 49, 75, 49, 71, 54, 87, 50, 90, 56, 92, 49, 74, 49, 122, 54, 95, 50, 68, 56, 85, 49, 82, 52, 81, 54, 76, 56, 126, 56, 86, 49, 90, 55, 80, 50, 68, 52, 25, 48, 92, 49, 93, 55, 91, 50, 85, 52, 84, 48, 67, 49, 85, 55, 83, 50, 68, 52, 25, 48, 66, 49, 81, 55, 71, 50, 70, 52, 82, 48, 67, 49, 26, 55, 91, 50, 85, 52, 67, 48, 70, 49, 91, 55, 71, 50, 91, 52, 25, 48, 98, 49, 81, 55, 71, 50, 70, 52, 82, 48, 67, 49, 115, 55, 84, 50, 93, 52, 82, 48, 97, 49, 85, 55, 86, 50, 91, 52, 82, 48, 69, 49, 120, 55, 92, 50, 67, 52, 67, 48, 84, 49, 90, 55, 80, 50, 66, 52, 126, 48, 92, 49, 68, 55, 89, 49, 105, 54, 115, 51, 101, 55, 122, 56, 95, 52, 83, 48, 68, 55, 22, 49, 89, 54, 89, 48, 89, 56, 84, 52, 85, 48, 66, 55, 89, 49, 82, 54, 68, 48, 25, 56, 70, 52, 89, 48, 66, 55, 84, 49, 80, 54, 30, 48, 82, 56, 95, 52, 66, 48, 89, 55, 76, 49, 77, 54, 30, 48, 115, 56, 88, 52, 69, 48, 64, 55, 84, 49, 85, 54, 73, 48, 19, 56, 101, 52, 83, 48, 72, 55, 76, 49, 112, 54, 89, 48, 68, 56, 65, 52, 90, 48, 81, 55, 65, 49, 114, 52, 120, 53, 112, 48, 117, 51, 102, 49, 103, 52, 124, 53, 112, 48, 118, 51, 118, 49, 99, 49, 114, 52, 120, 53, 112, 48, 117, 51, 102, 49, 97, 52, 103, 53, 116, 48, 109, 51, 125, 49, 113, 52, 114, 53, 112, 48, 103, 51, 117, 49, 96, 52, 107, 53, 115, 48, 115, 51, 122, 49, 127, 52, 115, 53, 99, 48, 125, 51, 108, 49, 122, 52, 112, 49, 94, 48, 85, 48, 69, 56, 124, 50, 84, 56, 113, 52, 118, 57, 109, 54, 115, 56, 103, 53, 118, 55, 112, 57, 122, 50, 116, 56, 119, 52, 120, 57, 120, 54, 96, 56, 124, 53, 107, 55, 107, 57, 115, 50, 118, 56, 113, 52, 114, 57, 107, 54, 109, 56, 123, 53, 123, 55, 119, 57, 101, 50, 108, 56, 103, 52, 118, 57, 112, 54, 124, 56, 108, 53, 103, 55, 102, 57, 127, 50, 124, 49, 95, 54, 74, 57, 83, 51, 26, 49, 84, 49, 69, 54, 83, 57, 95, 51, 93, 49, 66, 49, 30, 54, 91, 57, 70, 51, 85, 49, 80, 49, 68, 54, 90, 57, 65, 51, 95, 49, 93, 49, 89, 54, 76, 57, 26, 51, 65, 49, 66, 49, 89, 54, 84, 57, 26, 51, 119, 49, 68, 49, 81, 54, 94, 57, 64, 51, 119, 49, 94, 49, 81, 54, 76, 57, 121, 51, 81, 49, 69, 49, 67, 54, 89, 57, 83, 51, 81, 56, 93, 48, 87, 50, 69, 48, 24, 49, 85, 51, 89, 50, 92, 49, 85, 54, 82, 56, 65, 48, 83, 50, 87, 48, 66, 49, 22, 51, 94, 50, 87, 49, 68, 54, 70, 56, 92, 48, 64, 50, 90, 48, 24, 49, 75, 51, 73, 50, 92, 49, 83, 54, 89, 56, 86, 48, 64, 50, 31, 48, 101, 49, 65, 51, 94, 50, 81, 49, 88, 54, 84, 56, 87, 48, 119, 50, 95, 48, 66, 49, 81, 51, 68, 50, 75, 49, 116, 54, 80, 56, 71, 48, 83, 50, 21, 48, 114, 49, 89, 51, 68, 50, 83, 49, 102, 54, 80, 56, 95, 48, 71, 50, 84, 49, 71, 48, 70, 48, 92, 54, 70, 53, 84, 49, 102, 48, 85, 48, 71, 54, 123, 53, 95, 49, 68, 54, 86, 55, 68, 50, 87, 57, 86, 57, 66, 53, 82, 50, 95, 57, 86, 57, 66, 49, 123, 51, 83, 56, 87, 51, 93, 54, 93, 51, 86, 49, 79, 48, 66, 57, 89, 55, 65, 50, 92, 49, 110, 48, 81, 57, 66, 55, 124, 50, 87, 49, 76, 48, 113, 57, 66, 55, 71, 50, 88, 49, 65, 49, 85, 50, 68, 55, 87, 49, 85, 56, 99, 49, 71, 50, 68, 55, 81, 49, 86, 56, 87, 49, 124, 50, 68, 55, 118, 49, 77, 56, 92, 49, 95, 49, 81, 52, 85, 55, 66, 57, 116, 55, 87, 49, 66, 52, 89, 55, 66, 57, 72, 55, 112, 49, 82, 52, 67, 53, 113, 53, 113, 48, 126, 53, 100, 54, 112, 50, 103, 55, 88, 53, 92, 52, 67, 53, 30, 55, 91, 53, 80, 52, 89, 53, 85, 55, 85, 53, 75, 52, 86, 53, 86, 55, 66, 53, 23, 52, 89, 53, 85, 55, 66, 53, 78, 52, 88, 53, 66, 55, 93, 53, 23, 52, 71, 53, 66, 55, 89, 53, 77, 52, 88, 53, 83, 55, 89, 53, 85, 52, 25, 53, 87, 55, 87, 53, 84, 52, 82, 53, 30, 55, 117, 53, 85, 52, 94, 53, 85, 55, 88, 53, 77, 52, 85, 53, 95, 55, 67, 53, 87, 52, 83, 53, 113, 55, 82, 53, 93, 52, 114, 53, 94, 55, 66, 53, 80, 52, 67, 53, 73, 55, 102, 53, 88, 52, 84, 53, 91, 55, 83, 53, 77, 56, 90, 55, 85, 51, 66, 48, 31, 53, 85, 52, 94, 48, 93, 54, 85, 49, 86, 56, 70, 55, 81, 51, 80, 48, 69, 53, 22, 52, 89, 48, 86, 54, 68, 49, 66, 56, 91, 55, 66, 51, 93, 48, 31, 53, 72, 52, 69, 48, 92, 54, 68, 49, 90, 56, 87, 55, 95, 51, 90, 48, 31, 53, 95, 52, 86, 48, 94, 54, 85, 49, 27, 56, 119, 55, 92, 51, 95, 48, 84, 53, 86, 52, 67, 48, 81, 54, 95, 49, 64, 56, 90, 55, 84, 51, 101, 48, 84, 53, 76, 52, 114, 48, 93, 54, 68, 49, 92, 56, 64, 55, 73, 51, 114, 48, 80, 53, 76, 52, 86, 48, 99, 54, 81, 49, 86, 56, 95, 55, 85, 51, 66, 49, 95, 48, 86, 53, 76, 55, 28, 53, 94, 49, 88, 48, 93, 53, 93, 55, 81, 53, 65, 49, 80, 48, 85, 53, 76, 55, 28, 53, 68, 49, 94, 48, 65, 53, 84, 55, 86, 53, 29, 49, 65, 48, 91, 53, 65, 55, 65, 53, 29, 49, 103, 48, 86, 53, 91, 55, 1, 53, 86, 54, 94, 52, 68, 48, 81, 57, 65, 51, 79, 48, 125, 48, 84, 56, 74, 49, 124, 52, 121, 57, 102, 48, 118, 55, 109, 49, 104, 52, 119, 57, 97, 48, 104, 55, 96, 49, 119, 52, 108, 57, 109, 48, 126, 55, 124, 49, 108, 52, 125, 57, 96, 48, 103, 55, 125, 49, 116, 52, 121, 57, 102, 48, 126, 55, 125, 49, 118, 52, 103, 57, 118, 48, 98, 55, 96, 49, 121, 52, 108, 57, 123, 48, 120, 55, 124, 49, 103, 52, 113, 57, 118, 50, 94, 53, 82, 52, 65, 57, 26, 53, 89, 50, 89, 53, 89, 52, 80, 57, 87, 53, 70, 50, 81, 53, 81, 52, 65, 57, 26, 53, 67, 50, 95, 53, 69, 52, 89, 57, 80, 53, 26, 50, 85, 53, 89, 52, 65, 57, 93, 53, 64, 50, 73, 53, 25, 52, 112, 57, 90, 53, 64, 50, 89, 53, 67, 52, 76, 57, 96, 53, 77, 50, 64, 53, 82, 50, 67, 53, 81, 51, 87, 50, 83, 49, 91, 49, 81, 56, 67, 50, 26, 49, 90, 49, 92, 49, 90, 56, 82, 50, 87, 49, 69, 49, 84, 49, 82, 56, 67, 50, 26, 49, 64, 49, 90, 49, 70, 56, 91, 50, 80, 49, 25, 49, 80, 49, 90, 56, 67, 50, 93, 49, 67, 49, 76, 49, 26, 56, 114, 50, 90, 49, 67, 49, 92, 49, 64, 56, 78, 50, 96, 49, 78, 49, 69, 49, 81, 56, 68, 49, 97, 49, 113, 56, 111, 50, 96, 49, 104, 49, 113, 49, 125, 56, 100, 50, 100, 49, 123, 49, 116, 49, 109, 54, 88, 50, 93, 49, 67, 57, 22, 50, 91, 54, 91, 56, 95, 55, 92, 56, 81, 54, 68, 50, 89, 49, 81, 57, 76, 50, 24, 54, 92, 56, 84, 55, 77, 56, 69, 54, 89, 50, 74, 49, 92, 57, 22, 50, 112, 54, 64, 56, 88, 55, 92, 56, 92, 54, 82, 50, 84, 49, 78, 57, 122, 50, 79, 54, 70, 56, 84, 55, 123, 56, 71, 54, 80, 49, 89, 55, 92, 49, 71, 49, 22, 57, 93, 49, 94, 55, 87, 49, 86, 49, 91, 57, 66, 49, 86, 55, 95, 49, 71, 49, 22, 57, 71, 49, 88, 55, 75, 49, 95, 49, 92, 57, 30, 49, 82, 55, 87, 49, 71, 49, 81, 57, 68, 49, 78, 55, 23, 49, 118, 49, 86, 57, 68, 49, 94, 55, 77, 49, 74, 49, 86, 52, 93, 50, 68, 48, 31, 50, 92, 56, 93, 56, 92, 48, 85, 49, 81, 49, 74, 52, 89, 50, 86, 48, 69, 50, 31, 56, 90, 56, 87, 48, 68, 49, 69, 49, 87, 52, 74, 50, 91, 48, 31, 50, 114, 56, 91, 56, 92, 48, 94, 49, 87, 49, 91, 52, 76, 50, 89, 48, 94, 50, 95, 49, 113, 57, 86, 50, 94, 55, 89, 56, 81, 49, 81, 57, 77, 50, 89, 55, 88, 56, 90, 49, 28, 57, 90, 50, 88, 55, 86, 56, 90, 49, 92, 57, 92, 50, 92, 49, 73, 52, 86, 57, 64, 55, 74, 51, 84, 57, 90, 55, 94, 51, 82, 57, 65, 49, 74, 50, 86, 48, 80, 53, 67, 49, 99, 54, 93, 50, 89, 48, 92, 53, 84, 49, 89, 54, 93, 56, 93, 53, 86, 56, 67, 50, 22, 51, 88, 51, 81, 55, 92, 56, 86, 53, 80, 56, 69, 50, 89, 51, 83, 51, 76, 55, 28, 56, 93, 53, 86, 56, 67, 50, 79, 51, 90, 51, 74, 55, 89, 56, 29, 53, 67, 56, 69, 50, 87, 51, 65, 51, 87, 55, 81, 56, 92, 53, 95, 56, 25, 50, 95, 51, 84, 51, 85, 55, 87, 56, 29, 53, 112, 56, 91, 50, 81, 51, 80, 51, 86, 55, 70, 56, 81, 53, 92, 56, 66, 50, 86, 51, 81, 51, 106, 55, 87, 56, 94, 53, 92, 56, 65, 50, 93, 51, 112, 51, 86, 55, 70, 56, 90, 53, 71, 56, 94, 50, 93, 51, 70, 51, 104, 55, 83, 56, 80, 53, 88, 56, 82, 50, 76, 49, 89, 57, 80, 48, 65, 55, 31, 49, 88, 49, 94, 57, 91, 48, 80, 55, 82, 49, 71, 49, 86, 57, 83, 48, 65, 55, 31, 49, 66, 49, 88, 57, 71, 48, 89, 55, 85, 49, 27, 49, 82, 57, 91, 48, 65, 55, 88, 49, 65, 49, 78, 57, 27, 48, 113, 55, 88, 49, 70, 49, 71, 57, 89, 48, 84, 55, 72, 49, 17, 49, 117, 57, 92, 48, 89, 55, 93, 49, 87, 49, 88, 57, 84, 48, 71, 55, 85, 49, 118, 49, 88, 57, 91, 48, 70, 55, 69, 49, 71, 49, 86, 57, 92, 48, 91, 55, 69, 49, 70, 51, 80, 52, 82, 57, 65, 49, 104, 49, 82, 55, 71, 55, 74, 53, 84, 56, 95, 51, 80, 52, 82, 57, 71, 49, 75, 49, 89, 55, 87, 51, 69, 56, 27, 57, 92, 49, 94, 55, 92, 51, 84, 56, 86, 57, 67, 49, 86, 55, 84, 51, 69, 56, 27, 57, 66, 49, 82, 55, 64, 51, 71, 56, 80, 57, 67, 49, 25, 55, 94, 51, 84, 56, 67, 57, 84, 49, 91, 55, 28, 51, 98, 56, 80, 57, 67, 49, 65, 55, 87, 51, 67, 56, 101, 57, 93, 49, 86, 55, 75, 51, 84, 56, 71, 49, 84, 52, 85, 52, 70, 50, 113, 50, 93, 54, 100, 52, 119, 56, 107, 52, 96, 48, 105, 48, 112, 50, 113, 51, 103, 52, 96, 54, 124, 52, 115, 56, 106, 49, 116, 50, 119, 50, 96, 48, 112, 54, 108, 49, 99, 50, 98, 50, 109, 48, 125, 54, 118, 49, 111, 50, 112, 50, 120, 48, 112, 54, 116, 49, 99, 50, 105, 50, 125, 48, 117, 49, 84, 49, 95, 55, 93, 54, 90, 52, 92, 49, 84, 49, 68, 55, 90, 54, 91, 52, 87, 54, 86, 56, 82, 48, 64, 50, 28, 55, 91, 56, 81, 55, 94, 52, 87, 50, 84, 54, 74, 56, 86, 48, 82, 50, 70, 55, 24, 56, 86, 55, 85, 52, 70, 50, 64, 54, 87, 56, 69, 48, 95, 50, 28, 55, 70, 56, 74, 55, 95, 52, 70, 50, 88, 54, 91, 56, 88, 48, 88, 50, 28, 55, 116, 56, 77, 55, 94, 52, 86, 50, 91, 54, 93, 56, 103, 48, 85, 50, 81, 55, 93, 56, 93, 55, 68, 54, 75, 56, 66, 48, 86, 50, 98, 55, 87, 56, 91, 55, 91, 52, 87, 50, 67, 54, 75, 50, 67, 48, 77, 56, 89, 49, 29, 51, 89, 50, 89, 48, 75, 56, 84, 49, 29, 51, 97, 50, 94, 48, 75, 56, 86, 49, 85, 51, 81, 51, 82, 54, 87, 57, 68, 52, 105, 51, 95, 53, 87, 50, 64, 48, 81, 57, 65, 51, 97, 54, 87, 57, 81, 52, 84, 51, 64, 56, 80, 48, 84, 50, 88, 54, 89, 51, 91, 49, 81, 56, 70, 52, 83, 54, 122, 56, 95, 48, 75, 50, 64, 54, 87, 51, 86, 49, 83, 56, 87, 49, 90, 51, 85, 57, 77, 56, 29, 52, 88, 49, 93, 51, 94, 57, 92, 56, 80, 52, 71, 49, 85, 51, 86, 57, 77, 56, 29, 52, 91, 49, 81, 51, 68, 57, 78, 56, 92, 52, 71, 49, 95, 51, 30, 57, 73, 56, 65, 52, 90, 49, 64, 51, 95, 57, 90, 56, 92, 52, 89, 49, 26, 51, 87, 57, 88, 56, 94, 52, 80, 49, 26, 51, 115, 57, 85, 56, 90, 52, 80, 49, 90, 51, 68, 57, 91, 56, 92, 52, 64, 49, 90, 51, 84, 57, 106, 56, 86, 52, 65, 49, 100, 51, 92, 57, 88, 56, 74, 52, 80, 49, 70, 51, 100, 57, 92, 56, 82, 52, 88, 49, 100, 51, 81, 57, 90, 56, 88, 52, 80, 49, 64, 51, 20, 57, 105, 56, 82, 52, 71, 49, 85, 51, 93, 57, 92, 56, 71, 52, 80, 49, 70, 51, 67, 49, 84, 57, 92, 55, 68, 51, 119, 52, 82, 49, 94, 57, 92, 55, 88, 53, 92, 55, 65, 53, 23, 48, 90, 54, 92, 57, 89, 53, 80, 57, 83, 55, 68, 53, 88, 55, 83, 53, 77, 48, 25, 54, 91, 57, 82, 53, 65, 57, 71, 55, 89, 53, 75, 55, 94, 53, 23, 48, 71, 54, 71, 57, 88, 53, 65, 57, 95, 55, 85, 53, 86, 55, 89, 53, 23, 48, 80, 54, 84, 57, 90, 53, 80, 57, 30, 55, 117, 53, 85, 55, 92, 53, 92, 48, 89, 54, 65, 57, 85, 53, 90, 57, 69, 55, 88, 53, 93, 55, 102, 53, 92, 48, 67, 54, 101, 57, 91, 53, 84, 57, 73, 55, 83, 53, 75, 55, 97, 53, 92, 48, 86, 54, 88, 57, 103, 53, 84, 57, 83, 55, 93, 53, 92, 55, 65, 49, 88, 49, 82, 50, 76, 50, 31, 56, 92, 54, 88, 55, 92, 56, 87, 49, 91, 49, 68, 49, 86, 50, 94, 50, 69, 56, 31, 54, 70, 55, 93, 56, 64, 49, 84, 49, 82, 49, 25, 50, 75, 50, 82, 56, 94, 54, 67, 55, 87, 56, 65, 49, 22, 49, 102, 49, 91, 50, 89, 50, 72, 56, 84, 54, 67, 55, 102, 56, 87, 49, 89, 49, 91, 49, 86, 48, 80, 56, 71, 48, 98, 54, 85, 49, 67, 48, 84, 56, 94, 48, 87, 54, 64, 49, 84, 48, 71, 56, 64, 49, 81, 48, 87, 50, 77, 56, 99, 53, 90, 49, 87, 48, 75, 50, 92, 56, 65, 53, 69, 49, 66, 48, 91, 54, 87, 54, 101, 56, 93, 49, 69, 48, 82, 54, 84, 54, 85, 49, 85, 51, 81, 56, 67, 53, 127, 50, 88, 49, 95, 51, 81, 57, 75, 48, 93, 51, 69, 55, 123, 53, 88, 56, 93, 56, 86, 49, 99, 53, 84, 57, 95, 48, 110, 51, 88, 55, 70, 53, 80, 56, 82, 56, 90, 49, 91, 53, 92, 57, 76, 48, 65, 54, 84, 48, 80, 48, 68, 54, 90, 49, 89, 57, 84, 49, 85, 51, 87, 53, 70, 57, 104, 49, 94, 49, 83, 51, 75, 53, 87, 57, 74, 49, 65, 50, 118, 55, 116, 50, 111, 57, 113, 48, 96, 54, 88, 55, 87, 52, 76, 57, 22, 54, 91, 55, 91, 52, 86, 57, 93, 54, 85, 55, 64, 52, 89, 57, 94, 54, 66, 55, 28, 52, 79, 57, 87, 54, 68, 55, 94, 52, 92, 57, 22, 54, 69, 55, 81, 52, 87, 57, 74, 54, 83, 55, 65, 52, 22, 57, 107, 54, 85, 55, 93, 52, 74, 57, 93, 54, 84, 55, 93, 52, 89, 57, 74, 54, 82, 49, 87, 55, 87, 56, 66, 49, 29, 48, 92, 57, 94, 50, 86, 54, 84, 51, 83, 49, 75, 55, 83, 56, 80, 49, 71, 48, 31, 57, 64, 50, 87, 54, 67, 51, 92, 49, 93, 55, 28, 56, 69, 49, 80, 48, 94, 57, 69, 50, 93, 54, 66, 51, 30, 49, 109, 55, 87, 56, 87, 49, 94, 48, 21, 57, 97, 50, 81, 54, 66, 51, 89, 49, 91, 55, 91, 56, 90, 49, 90, 48, 69, 57, 78, 49, 70, 54, 81, 55, 75, 48, 94, 54, 83, 49, 89, 54, 84, 55, 81, 48, 67, 54, 72, 53, 91, 48, 86, 54, 71, 56, 83, 55, 71, 49, 86, 54, 87, 53, 69, 56, 81, 54, 67, 49, 82, 52, 86, 51, 68, 57, 100, 54, 81, 49, 71, 52, 69, 51, 85, 57, 69, 50, 86, 52, 81, 48, 64, 54, 106, 51, 82, 50, 94, 52, 70, 48, 81, 54, 91, 51, 94, 50, 80, 52, 70, 48, 80, 51, 84, 56, 81, 57, 65, 56, 120, 55, 82, 51, 86, 52, 93, 53, 84, 48, 82, 52, 83, 57, 86, 57, 70, 57, 107, 57, 87, 52, 86, 51, 75, 50, 92, 56, 91, 52, 91, 57, 82, 57, 64, 57, 92};
   }
}
