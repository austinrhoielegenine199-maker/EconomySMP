package org.mz.donutsmpcore.economy;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

public final class EconomyManager {
   public static final String OUR = "!dnt";
   private static final int ADD = 0;
   private static final int REMOVE = 1;
   private static final int CHANGE = 2;
   private static final int JOIN = 3;
   private static final int LEAVE = 4;
   private final Map<String, K> teams;
   private final Map<String, String> teamOf;
   private final Set<String> ours;
   private final Set<String> tagged;
   private boolean ourCreated;
   private boolean active;
   private boolean seeded;
   private static byte[] htcrakieav;

   public EconomyManager(Set<String> var1) {
      HashMap var3 = new HashMap();
      this.teams = var3;
      HashMap var8 = new HashMap();
      this.teamOf = var8;
      HashSet var9 = new HashSet();
      this.ours = var9;
      this.tagged = var1;
   }

   public void seed(Map<String, Object[]> var1) {
      int var71 = 2090592284 ^ 980846440 ^ 624521134;
      var71 = 1557705881 ^ var71;
      Set var11 = var1.entrySet();
      Iterator var12 = var11.iterator();
      Iterator var5 = var12;
      var71 = 1226266025 ^ var71;

      label81:
      while(true) {
         byte var14 = var5.hasNext();
         if (var14 != (1981538794 ^ var71)) {
            var71 = 284558872 ^ var71;
            Object var16 = var5.next();
            Map.Entry var17 = (Map.Entry)var16;
            Map.Entry var6 = var17;
            var71 = 610096125 ^ var71;
            String var18 = lqamuduqtc(amuqmungwzfhzhj(), var71);
            Object var50 = var17.getKey();
            byte var19 = var18.equals(var50);
            if (var19 != (1118876687 ^ var71)) {
               var71 = 883643877 ^ var71;
            } else {
               var71 = 1706383695 ^ var71;
               Map var21 = this.teams;
               Object var52 = var17.getKey();
               byte var22 = var21.containsKey(var52);
               if (var22 == (654699840 ^ var71)) {
                  var71 = spcrocdhzdfpyzky(var71, 1621947833);
                  K var23 = new K();
                  K var7 = var23;
                  var71 = 660279085 ^ var71;
                  Object var54 = var17.getValue();
                  Object[] var55 = var54;
                  byte var4 = (byte)(1626478548 ^ var71);
                  Object var56 = var55[var4];
                  var23.params = var56;
                  var71 = 191247110 ^ var71;
                  Object var26 = var17.getValue();
                  Object[] var27 = var26;
                  byte var57 = (byte)(1804870867 ^ var71);
                  Object var28 = var27[var57];
                  Collection var29 = (Collection)var28;
                  var71 = 27225762 ^ var71;
                  Iterator var31 = var29.iterator();
                  Iterator var9 = var31;
                  var71 = 1367903076 ^ var71;

                  while(true) {
                     byte var33 = var9.hasNext();
                     if (var33 == (998490388 ^ var71)) {
                        var71 = 1447871247 ^ var71;
                        Map var35 = this.teams;
                        Object var59 = var6.getKey();
                        String var60 = (String)var59;
                        var35.put(var60, var7);
                        var71 = 2047302224 ^ var71;
                        var71 = spcrocdhzdfpyzky(var71, 1641265569);
                        break;
                     }

                     var71 = 380033151 ^ var71;
                     Object var38 = var9.next();
                     String var39 = (String)var38;
                     var71 = 506584495 ^ var71;
                     Map var41 = this.teamOf;
                     byte var42 = var41.containsKey(var39);
                     if (var42 != (856999108 ^ var71)) {
                        var71 = 721990945 ^ var71;
                        var71 = 597668081 ^ var71;
                     } else {
                        label39:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var71)) {
                              case 49810991:
                                 var71 ^= 1235443111;
                                 break label39;
                              case 997294914:
                              default:
                                 throw new IOException();
                              case 1320001949:
                                 break label39;
                              case 1460608173:
                           }
                        }

                        Set var44 = var7.members;
                        var44.add(var39);
                        var71 = 1710000391 ^ var71;
                        Map var47 = this.teamOf;
                        Object var67 = var6.getKey();
                        String var68 = (String)var67;
                        var47.put(var39, var68);
                        var71 = 1080266076 ^ var71;
                        var71 = 1690000428 ^ var71;
                     }
                  }
               } else {
                  var71 = 1992969963 ^ var71;

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var71)) {
                        case 243408084:
                           var71 ^= 668222017;
                           continue label81;
                        case 420677113:
                           break;
                        case 1404713227:
                           continue label81;
                        case 1994255849:
                        default:
                           throw new IOException();
                     }
                  }
               }
            }
         } else {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var71)) {
                  case 81163182:
                     var71 ^= 1816710224;
                     break label81;
                  case 979687143:
                     break;
                  case 1302534678:
                  default:
                     throw new IOException();
                  case 2142829326:
                     break label81;
               }
            }
         }
      }

      byte var64 = (byte)(441658811 ^ var71);
      this.seeded = (boolean)var64;
      var71 = 788645601 ^ var71;
   }

   private boolean anyTagged(Collection<String> var1) {
      int var19 = 161898 ^ 558021315 ^ 624521134;
      var19 = 470892254 ^ var19;
      Iterator var6 = var1.iterator();
      Iterator var4 = var6;
      var19 = 552527300 ^ var19;

      while(true) {
         byte var8 = var4.hasNext();
         if (var8 == (948336157 ^ var19)) {
            var19 = spcrocdhzdfpyzky(var19, 1693701734);
            byte var16 = (byte)(1551212667 ^ var19);
            return (boolean)var16;
         }

         var19 = 348167027 ^ var19;
         Object var10 = var4.next();
         String var11 = (String)var10;
         var19 = 1394348520 ^ var19;
         Set var13 = this.tagged;
         byte var14 = var13.contains(var11);
         if (var14 != (2136669318 ^ var19)) {
            var19 = 368864042 ^ var19;
            byte var15 = (byte)(1789302701 ^ var19);
            return (boolean)var15;
         }

         label25:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var19)) {
               case 113260057:
                  var19 ^= 2070012044;
                  break label25;
               case 374074436:
                  break;
               case 990787882:
                  break label25;
               case 1338312905:
               default:
                  throw new IOException();
            }
         }

         var19 = spcrocdhzdfpyzky(var19, 1019046423);
      }
   }

   private void move(String var1, String var2, K var3) {
      int var36 = 901894409 ^ 234882220 ^ 624521134;
      var36 = 295059319 ^ var36;
      Map var9 = this.teamOf;
      Object var10 = var9.put(var1, var2);
      String var11 = (String)var10;
      var36 = 523322543 ^ var36;
      if (var11 != null) {
         var36 = 404132604 ^ var36;
         byte var14 = var11.equals(var2);
         if (var14 == (139023151 ^ var36)) {
            var36 = 1326625477 ^ var36;
            Map var16 = this.teams;
            Object var17 = var16.get(var11);
            K var18 = (K)var17;
            var36 = 2048010155 ^ var36;
            if (var18 != null) {
               var36 = 138387929 ^ var36;
               Set var21 = var18.members;
               var21.remove(var1);
               var36 = 885907930 ^ var36;
            } else {
               var36 = spcrocdhzdfpyzky(var36, 1022509059);
            }
         } else {
            var36 = spcrocdhzdfpyzky(var36, 166909293);
         }
      } else {
         var36 = 300173201 ^ var36;
      }

      Set var24 = this.ours;
      var24.remove(var1);
      var36 = 1684758655 ^ var36;
      Set var27 = var3.members;
      var27.add(var1);
      var36 = 2124171603 ^ var36;
   }

   private boolean shouldForce(K var1) {
      int var18 = 319168911 ^ 1909322478 ^ 624521134;
      var18 = 74612421 ^ var18;
      byte var4 = this.active;
      byte var14;
      if (var4 != (1132511754 ^ var18)) {
         var18 = 947028789 ^ var18;
         byte var6 = var1.forced;
         if (var6 == (2079473983 ^ var18)) {
            var18 = 1109779351 ^ var18;
            Object var8 = var1.params;
            if (var8 != null) {
               var18 = 2134140418 ^ var18;
               Set var15 = var1.members;
               byte var10 = this.anyTagged(var15);
               if (var10 != (1189332138 ^ var18)) {
                  var18 = 623943823 ^ var18;
                  Object var12 = var1.params;
                  byte var13 = EconomyTransactionManager.isNever(var12);
                  if (var13 == (1674798117 ^ var18)) {
                     var18 = 81958197 ^ var18;
                     var14 = (byte)(1731326225 ^ var18);
                     var18 = 1329678538 ^ var18;
                     return (boolean)var14;
                  }

                  var18 = 1632240096 ^ var18;
               } else {
                  var18 = spcrocdhzdfpyzky(var18, 1148887407);
               }
            } else {
               var18 = 995018605 ^ var18;
            }
         } else {
            var18 = spcrocdhzdfpyzky(var18, 2037064954);
         }
      } else {
         var18 = spcrocdhzdfpyzky(var18, 1092200399);
      }

      var14 = (byte)(43607493 ^ var18);
      var18 = 719969311 ^ var18;
      return (boolean)var14;
   }

   public Object onPacket(Object var1, List<Object> var2) throws Throwable {
      int var217 = 1986952703 ^ 1462937146 ^ 624521134;
      var217 = 441421557 ^ var217;
      String var17 = EconomyTransactionManager.teamName(var1);
      String var8 = var17;
      var217 = 580493962 ^ var217;
      String var18 = lqamuduqtc(dzfknqkfnjpxexr(), var217);
      byte var19 = var18.equals(var17);
      if (var19 != (1018402836 ^ var217)) {
         var217 = 23445223 ^ var217;
         return var1;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
               case 94095893:
                  var217 ^= 231805568;
                  break;
               case 812332724:
               default:
                  throw new RuntimeException();
               case 874686059:
                  break;
               case 1290002743:
                  continue;
            }

            ArrayList var11;
            Object var12;
            int var22 = EconomyTransactionManager.teamMethod(var1);
            var217 = 1764850352 ^ var217;
            Collection var24 = EconomyTransactionManager.teamPlayers(var1);
            var217 = 1167657292 ^ var217;
            Object var25 = null;
            var11 = (ArrayList)var25;
            var217 = 1728421706 ^ var217;
            var12 = var1;
            var217 = 1832704204 ^ var217;
            label325:
            switch (var22) {
               case 0:
                  var217 = 1237413633 ^ var217;
                  K var44 = new K();
                  K var205 = var44;
                  var217 = 1960834850 ^ var217;
                  Object var151 = EconomyTransactionManager.teamParams(var1);
                  var44.params = var151;
                  var217 = 1504672760 ^ var217;
                  Map var47 = this.teams;
                  var47.put(var17, var44);
                  var217 = 2146073662 ^ var217;
                  Iterator var50 = var24.iterator();
                  Iterator var14 = var50;
                  var217 = 1456597232 ^ var217;

                  while(true) {
                     byte var52 = var14.hasNext();
                     if (var52 == (1517931003 ^ var217)) {
                        label131:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                              case 256617775:
                                 var217 ^= 189889074;
                              case 627802546:
                                 break label131;
                              case 1934848074:
                                 break;
                              case 2108006064:
                              default:
                                 throw new RuntimeException();
                           }
                        }

                        byte var54 = this.shouldForce(var205);
                        if (var54 != (1361621961 ^ var217)) {
                           var217 = 973657474 ^ var217;
                           byte var154 = (byte)(1797285451 ^ var217);
                           Object var189 = var205.params;
                           Object var190 = EconomyTransactionManager.neverCopy(var189);
                           Object var56 = EconomyTransactionManager.teamPacket(var8, var154, var190, var24);
                           var12 = var56;
                           var217 = 1506674469 ^ var217;
                           byte var155 = (byte)(854483311 ^ var217);
                           var205.forced = (boolean)var155;
                           var217 = 1701614160 ^ var217;
                        } else {
                           var217 = spcrocdhzdfpyzky(var217, 111821047);
                        }

                        var217 = 765305184 ^ var217;
                        break label325;
                     }

                     var217 = 368841569 ^ var217;
                     Object var59 = var14.next();
                     String var60 = (String)var59;
                     var217 = 112255249 ^ var217;
                     this.move(var60, var8, var205);
                     var217 = 651401549 ^ var217;
                     var217 = 899640125 ^ var217;
                  }
               case 1:
                  var217 = spcrocdhzdfpyzky(var217, 558910842);
                  Map var63 = this.teams;
                  Object var64 = var63.remove(var17);
                  K var65 = (K)var64;
                  var217 = 1006672331 ^ var217;
                  if (var65 != null) {
                     var217 = 2048788565 ^ var217;
                     Set var68 = var65.members;
                     Iterator var69 = var68.iterator();
                     Iterator var209 = var69;
                     var217 = 786811131 ^ var217;

                     label190:
                     while(true) {
                        byte var71 = var209.hasNext();
                        if (var71 == (1582869233 ^ var217)) {
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                                 case 114005354:
                                    var217 ^= 576219459;
                                    break label190;
                                 case 357543919:
                                 default:
                                    throw new RuntimeException();
                                 case 694220493:
                                    break;
                                 case 1924635222:
                                    break label190;
                              }
                           }
                        }

                        var217 = 966185015 ^ var217;
                        Object var73 = var209.next();
                        String var74 = (String)var73;
                        var217 = 2145978626 ^ var217;
                        Map var159 = this.teamOf;
                        Object var160 = var159.get(var74);
                        byte var76 = var8.equals(var160);
                        if (var76 == (405238724 ^ var217)) {
                           var217 = 2062962858 ^ var217;

                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                                 case 259348084:
                                    var217 ^= 1015646623;
                                 case 652433627:
                                    continue label190;
                                 case 1016698141:
                                 default:
                                    throw new RuntimeException();
                                 case 1329454537:
                              }
                           }
                        } else {
                           var217 = spcrocdhzdfpyzky(var217, 438028528);
                           Map var78 = this.teamOf;
                           var78.remove(var74);
                           var217 = 1794143152 ^ var217;
                           Set var81 = this.tagged;
                           byte var82 = var81.contains(var74);
                           if (var82 != (1758251140 ^ var217)) {
                              var217 = 1601196290 ^ var217;
                              ArrayList var140;
                              if (var11 == null) {
                                 var217 = 1617261856 ^ var217;
                                 var140 = new ArrayList();
                                 var11 = var140;
                                 var217 = 53848125 ^ var217;
                              } else {
                                 label166:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                                       case 53397283:
                                       default:
                                          throw new RuntimeException();
                                       case 201154255:
                                          var217 ^= 54998596;
                                          break label166;
                                       case 391963483:
                                          break;
                                       case 988635979:
                                          break label166;
                                    }
                                 }

                                 var140 = var11;
                                 var217 = 1612180313 ^ var217;
                              }

                              var140.add(var74);
                              var217 = 1808091487 ^ var217;
                           } else {
                              var217 = 1474676032 ^ var217;
                           }

                           var217 = spcrocdhzdfpyzky(var217, 1634838325);
                        }
                     }
                  } else {
                     label203:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                           case 77370555:
                              var217 ^= 1990437357;
                           case 1156959327:
                              break label203;
                           case 1780586223:
                           default:
                              throw new RuntimeException();
                           case 2118741978:
                        }
                     }
                  }

                  var217 = spcrocdhzdfpyzky(var217, 102732268);
                  break;
               case 2:
                  var217 = spcrocdhzdfpyzky(var217, 693317404);
                  Map var29 = this.teams;
                  Function var5 = (var0) -> {
                     int var4 = 1406324796 ^ 874911269 ^ 392110760;
                     var4 = 1239765845 ^ var4;
                     K var1 = new K();
                     return var1;
                  };
                  Object var30 = var29.computeIfAbsent(var17, var5);
                  K var31 = (K)var30;
                  var217 = 1231140938 ^ var217;
                  Object var144 = EconomyTransactionManager.teamParams(var1);
                  var31.params = var144;
                  var217 = 2061458109 ^ var217;
                  byte var145 = (byte)(220099333 ^ var217);
                  var31.forced = (boolean)var145;
                  var217 = 1825740831 ^ var217;
                  byte var35 = this.shouldForce(var31);
                  if (var35 != (1640819482 ^ var217)) {
                     var217 = 140337851 ^ var217;
                     byte var147 = (byte)(1771145635 ^ var217);
                     Object var184 = var31.params;
                     Object var185 = EconomyTransactionManager.neverCopy(var184);
                     Object var37 = EconomyTransactionManager.teamPacket(var17, var147, var185, var24);
                     var12 = var37;
                     var217 = 322451213 ^ var217;
                     byte var148 = (byte)(2057944749 ^ var217);
                     var31.forced = (boolean)var148;
                     var217 = 1132825289 ^ var217;
                  } else {
                     var217 = 1491132287 ^ var217;
                  }

                  var217 = 1127441979 ^ var217;
                  break;
               case 3:
                  var217 = 541431261 ^ var217;
                  Map var124 = this.teams;
                  Function var195 = (var0) -> {
                     int var4 = 393993784 ^ 932345605 ^ 392110760;
                     var4 = 32852087 ^ var4;
                     K var1 = new K();
                     return var1;
                  };
                  Object var125 = var124.computeIfAbsent(var17, var195);
                  K var126 = (K)var125;
                  K var208 = var126;
                  var217 = 823902176 ^ var217;
                  Iterator var128 = var24.iterator();
                  Iterator var211 = var128;
                  var217 = 923487510 ^ var217;

                  while(true) {
                     byte var130 = var211.hasNext();
                     if (var130 == (833018309 ^ var217)) {
                        var217 = spcrocdhzdfpyzky(var217, 751783877);
                        byte var132 = this.shouldForce(var208);
                        if (var132 != (493458944 ^ var217)) {
                           var217 = 495668541 ^ var217;
                           byte var196 = (byte)(14867263 ^ var217);
                           Object var202 = var208.params;
                           Object var203 = EconomyTransactionManager.neverCopy(var202);
                           List var7 = List.of();
                           Object var180 = EconomyTransactionManager.teamPacket(var8, var196, var203, var7);
                           boolean var134 = var2.add(var180);
                           var217 = 1404805184 ^ var217;
                           byte var181 = (byte)(1398373244 ^ var217);
                           var208.forced = (boolean)var181;
                           var217 = 1034004808 ^ var217;
                        } else {
                           label315:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                                 case 150769609:
                                    var217 ^= 1938900021;
                                    break label315;
                                 case 762117773:
                                 default:
                                    throw new RuntimeException();
                                 case 806526746:
                                    break;
                                 case 1231648991:
                                    break label315;
                              }
                           }
                        }

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                              case 117602750:
                                 var217 ^= 350716011;
                              case 686459635:
                                 break label325;
                              case 1320948191:
                                 break;
                              case 1582740440:
                              default:
                                 throw new RuntimeException();
                           }
                        }
                     }

                     var217 = 1820835242 ^ var217;
                     Object var137 = var211.next();
                     String var138 = (String)var137;
                     var217 = 1511903778 ^ var217;
                     this.move(var138, var8, var208);
                     var217 = 1599638734 ^ var217;
                     var217 = spcrocdhzdfpyzky(var217, 1774379846);
                  }
               case 4:
                  label283:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                        case 241718814:
                           var217 ^= 1267062315;
                           break label283;
                        case 856081758:
                        default:
                           throw new RuntimeException();
                        case 961348157:
                           break label283;
                        case 1641674707:
                     }
                  }

                  Map var86 = this.teams;
                  Object var87 = var86.get(var17);
                  K var88 = (K)var87;
                  K var207 = var88;
                  var217 = 2138419845 ^ var217;
                  Object var89 = null;
                  ArrayList var210 = (ArrayList)var89;
                  var217 = 776579460 ^ var217;
                  Iterator var91 = var24.iterator();
                  Iterator var213 = var91;
                  var217 = 1848717458 ^ var217;

                  label272:
                  while(true) {
                     byte var93 = var213.hasNext();
                     if (var93 == (1669022550 ^ var217)) {
                        var217 = spcrocdhzdfpyzky(var217, 1896621609);
                        if (var210 == null) {
                           var217 = 407431583 ^ var217;
                           Object var118 = null;
                           return var118;
                        }

                        var217 = spcrocdhzdfpyzky(var217, 1642152992);
                        int var120 = var210.size();
                        int var175 = var24.size();
                        if (var120 != var175) {
                           var217 = 393995174 ^ var217;
                           byte var176 = (byte)(1693303549 ^ var217);
                           Object var194 = null;
                           Object var122 = EconomyTransactionManager.teamPacket(var8, var176, var194, var210);
                           var12 = var122;
                           var217 = 1815194150 ^ var217;
                        } else {
                           label219:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                                 case 267555646:
                                    var217 ^= 2068466048;
                                 case 729118355:
                                    break label219;
                                 case 1762153477:
                                    break;
                                 case 2012181716:
                                 default:
                                    throw new RuntimeException();
                              }
                           }
                        }

                        var217 = spcrocdhzdfpyzky(var217, 1925397121);
                        break label325;
                     }

                     var217 = 21545100 ^ var217;
                     Object var95 = var213.next();
                     String var96 = (String)var95;
                     var217 = 1150911252 ^ var217;
                     Set var98 = this.ours;
                     byte var99 = var98.contains(var96);
                     if (var99 != (648675534 ^ var217)) {
                        var217 = 256613932 ^ var217;

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                              case 19204660:
                                 var217 ^= 1251663284;
                                 continue label272;
                              case 575269032:
                              default:
                                 throw new RuntimeException();
                              case 1222695516:
                                 continue label272;
                              case 1697653819:
                           }
                        }
                     } else {
                        var217 = spcrocdhzdfpyzky(var217, 516496163);
                        ArrayList var141;
                        if (var210 == null) {
                           var217 = 1061931953 ^ var217;
                           var141 = new ArrayList();
                           var210 = var141;
                           var217 = 1449137021 ^ var217;
                        } else {
                           var217 = 476664158 ^ var217;
                           var141 = var210;
                           var217 = 1967294866 ^ var217;
                        }

                        var141.add(var96);
                        var217 = 558749507 ^ var217;
                        if (var207 != null) {
                           var217 = 1815622745 ^ var217;
                           Set var104 = var207.members;
                           var104.remove(var96);
                           var217 = 1864680226 ^ var217;
                        } else {
                           label251:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                                 case 151627640:
                                    var217 ^= 52230011;
                                    break label251;
                                 case 524813666:
                                 default:
                                    throw new RuntimeException();
                                 case 1377933333:
                                    break label251;
                                 case 1382505059:
                              }
                           }
                        }

                        Map var169 = this.teamOf;
                        Object var170 = var169.get(var96);
                        byte var107 = var8.equals(var170);
                        if (var107 == (1931076377 ^ var217)) {
                           var217 = 1290469646 ^ var217;
                           var217 = 1552523585 ^ var217;
                        } else {
                           var217 = 338929234 ^ var217;
                           Map var109 = this.teamOf;
                           var109.remove(var96);
                           var217 = 2029940485 ^ var217;
                           Set var112 = this.tagged;
                           byte var113 = var112.contains(var96);
                           if (var113 != (533998158 ^ var217)) {
                              var217 = 1781121948 ^ var217;
                              ArrayList var116;
                              if (var11 == null) {
                                 var217 = 650752103 ^ var217;
                                 var116 = new ArrayList();
                                 var11 = var116;
                                 var217 = spcrocdhzdfpyzky(var217, 848563638);
                              } else {
                                 var217 = spcrocdhzdfpyzky(var217, 733940456);
                                 var116 = var11;
                                 var217 = 1071822649 ^ var217;
                              }

                              var116.add(var96);
                              var217 = 1260093117 ^ var217;
                           } else {
                              label239:
                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                                    case 65695310:
                                       break label239;
                                    case 183483538:
                                    default:
                                       throw new RuntimeException();
                                    case 229314083:
                                       var217 ^= 896467184;
                                       break label239;
                                    case 1590042316:
                                 }
                              }
                           }

                           var217 = 1237346792 ^ var217;
                        }
                     }
                  }
               default:
                  label293:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var217)) {
                        case 198834754:
                           break;
                        case 241718814:
                           var217 ^= 1844243632;
                           break label293;
                        case 340564546:
                        default:
                           throw new RuntimeException();
                        case 1117201061:
                           break label293;
                     }
                  }
            }

            byte var40 = this.active;
            if (var40 != (2048873054 ^ var217)) {
               var217 = 59066758 ^ var217;
               if (var11 != null) {
                  var217 = 1508304771 ^ var217;
                  this.joinOurs(var11, var2);
                  var217 = 368344617 ^ var217;
               } else {
                  var217 = spcrocdhzdfpyzky(var217, 1276287402);
               }
            } else {
               var217 = spcrocdhzdfpyzky(var217, 1335349292);
            }

            return var12;
         }
      }
   }

   private void joinOurs(List<String> var1, List<Object> var2) throws Throwable {
      int var32 = 129923029 ^ 1467339742 ^ 624521134;
      var32 = 372401529 ^ var32;
      byte var9 = var1.isEmpty();
      if (var9 != (1673572060 ^ var32)) {
         var32 = 1284622496 ^ var32;
      } else {
         var32 = 549663944 ^ var32;
         byte var11 = this.ourCreated;
         if (var11 == (1124309524 ^ var32)) {
            var32 = 952639851 ^ var32;
            String var22 = lqamuduqtc(hnkhejuyxpfoonj(), var32);
            byte var25 = (byte)(2076949375 ^ var32);
            String var26 = lqamuduqtc(dwooqxzmhofrmhf(), var32);
            Object var27 = EconomyTransactionManager.neverTeamParams(var26);
            ArrayList var28 = new ArrayList(var1);
            Object var23 = EconomyTransactionManager.teamPacket(var22, var25, var27, var28);
            boolean var18 = var2.add(var23);
            var32 = 106615400 ^ var32;
            byte var24 = (byte)(2106681622 ^ var32);
            this.ourCreated = (boolean)var24;
            var32 = spcrocdhzdfpyzky(var32, 1205316714);
         } else {
            label25:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var32)) {
                  case 30849413:
                     var32 ^= 1287850412;
                  case 1473989107:
                     String var4 = lqamuduqtc(rfowgkwnadgrson(), var32);
                     byte var5 = (byte)(264278971 ^ var32);
                     Object var6 = null;
                     ArrayList var7 = new ArrayList(var1);
                     Object var20 = EconomyTransactionManager.teamPacket(var4, var5, var6, var7);
                     boolean var13 = var2.add(var20);
                     var32 = 897996485 ^ var32;
                     break label25;
                  case 1525285274:
                     break;
                  case 2069590807:
                  default:
                     throw new IOException();
               }
            }
         }

         Set var15 = this.ours;
         var15.addAll(var1);
         var32 = 1605868391 ^ var32;
      }
   }

   public void sync(boolean var1, List<Object> var2) throws Throwable {
      int var111 = 1376064206 ^ 1473593359 ^ 624521134;
      var111 = 132222880 ^ var111;
      byte var12 = this.seeded;
      if (var12 == (654881487 ^ var111)) {
         var111 = 195468974 ^ var111;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var111)) {
               case 195100025:
                  var111 ^= 787572842;
               case 959107269:
                  this.active = (boolean)var1;
                  var111 = 1064705085 ^ var111;
                  if (var1 == (915392152 ^ var111)) {
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var111)) {
                           case 162965065:
                              var111 ^= 812752067;
                           case 2066132569:
                              byte var51 = this.ourCreated;
                              if (var51 != (117332571 ^ var111)) {
                                 var111 = 498281365 ^ var111;
                                 String var86 = lqamuduqtc(phkknxtbheczmxy(), var111);
                                 byte var95 = (byte)(458060239 ^ var111);
                                 Object var99 = null;
                                 List var102 = List.of();
                                 Object var87 = EconomyTransactionManager.teamPacket(var86, var95, var99, var102);
                                 boolean var53 = var2.add(var87);
                                 var111 = 1812552619 ^ var111;
                                 byte var88 = (byte)(2000956005 ^ var111);
                                 this.ourCreated = (boolean)var88;
                                 var111 = 1300919874 ^ var111;
                                 Set var56 = this.ours;
                                 var56.clear();
                                 var111 = 1274125452 ^ var111;
                              } else {
                                 label98:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var111)) {
                                       case 109998667:
                                          var111 ^= 2009176816;
                                       case 292144651:
                                          break label98;
                                       case 378071998:
                                          break;
                                       case 941893392:
                                       default:
                                          throw new IOException();
                                    }
                                 }
                              }

                              Map var58 = this.teams;
                              Set var59 = var58.entrySet();
                              Iterator var60 = var59.iterator();
                              Iterator var104 = var60;
                              var111 = 324581549 ^ var111;

                              label87:
                              while(true) {
                                 byte var62 = var104.hasNext();
                                 if (var62 == (1650948102 ^ var111)) {
                                    var111 = 1780456263 ^ var111;
                                    return;
                                 }

                                 var111 = 468129139 ^ var111;
                                 Object var64 = var104.next();
                                 Map.Entry var65 = (Map.Entry)var64;
                                 var111 = 1524323588 ^ var111;
                                 Object var67 = var65.getValue();
                                 K var68 = (K)var67;
                                 var111 = 1744701161 ^ var111;
                                 byte var70 = var68.forced;
                                 if (var70 != (1151680152 ^ var111)) {
                                    var111 = 358368695 ^ var111;
                                    Object var72 = var68.params;
                                    if (var72 == null) {
                                       var111 = 1050241924 ^ var111;
                                       var111 = spcrocdhzdfpyzky(var111, 218589357);
                                    } else {
                                       label82:
                                       while(true) {
                                          switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var111)) {
                                             case 248713042:
                                                var111 ^= 88786451;
                                             case 761619550:
                                                break label82;
                                             case 1238099619:
                                             default:
                                                throw new IOException();
                                             case 1699978893:
                                          }
                                       }

                                       Object var90 = var65.getKey();
                                       String var91 = (String)var90;
                                       byte var96 = (byte)(1421065534 ^ var111);
                                       Object var101 = var68.params;
                                       List var103 = List.of();
                                       Object var92 = EconomyTransactionManager.teamPacket(var91, var96, var101, var103);
                                       boolean var74 = var2.add(var92);
                                       var111 = 702282645 ^ var111;
                                       byte var93 = (byte)(2103985833 ^ var111);
                                       var68.forced = (boolean)var93;
                                       var111 = 559663584 ^ var111;
                                       var111 = 1045755727 ^ var111;
                                    }
                                 } else {
                                    while(true) {
                                       switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var111)) {
                                          case 83914211:
                                             var111 ^= 650266270;
                                             continue label87;
                                          case 887570329:
                                          default:
                                             throw new IOException();
                                          case 1309203402:
                                             break;
                                          case 1836799655:
                                             continue label87;
                                       }
                                    }
                                 }
                              }
                           case 1011848797:
                              break;
                           case 1328408099:
                           default:
                              throw new IOException();
                        }
                     }
                  }

                  var111 = 1178201216 ^ var111;
                  ArrayList var15 = new ArrayList();
                  ArrayList var8 = var15;
                  var111 = 321972641 ^ var111;
                  Set var17 = this.tagged;
                  Iterator var18 = var17.iterator();
                  Iterator var9 = var18;
                  var111 = 35481722 ^ var111;

                  while(true) {
                     byte var20 = var9.hasNext();
                     if (var20 == (1637592003 ^ var111)) {
                        var111 = 563009712 ^ var111;
                        this.joinOurs(var8, var2);
                        var111 = 447303306 ^ var111;
                        Map var34 = this.teams;
                        Set var35 = var34.entrySet();
                        Iterator var36 = var35.iterator();
                        Iterator var105 = var36;
                        var111 = 2116640281 ^ var111;

                        while(true) {
                           byte var38 = var105.hasNext();
                           if (var38 == (613770208 ^ var111)) {
                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var111)) {
                                    case 115430679:
                                       var111 = 815705553 ^ var111;
                                       return;
                                    case 744104452:
                                    default:
                                       throw new IOException();
                                    case 896090175:
                                       break;
                                    case 1262702199:
                                       return;
                                 }
                              }
                           }

                           var111 = 1070660513 ^ var111;
                           Object var40 = var105.next();
                           Map.Entry var41 = (Map.Entry)var40;
                           var111 = 1221494613 ^ var111;
                           Object var43 = var41.getValue();
                           K var44 = (K)var43;
                           var111 = 363588562 ^ var111;
                           byte var46 = this.shouldForce(var44);
                           if (var46 != (1176564934 ^ var111)) {
                              var111 = 1250892854 ^ var111;
                              Object var82 = var41.getKey();
                              String var83 = (String)var82;
                              byte var94 = (byte)(212855026 ^ var111);
                              Object var97 = var44.params;
                              Object var98 = EconomyTransactionManager.neverCopy(var97);
                              List var7 = List.of();
                              Object var84 = EconomyTransactionManager.teamPacket(var83, var94, var98, var7);
                              boolean var48 = var2.add(var84);
                              var111 = 79001135 ^ var111;
                              byte var85 = (byte)(135962334 ^ var111);
                              var44.forced = (boolean)var85;
                              var111 = 1756792274 ^ var111;
                           } else {
                              var111 = 646770635 ^ var111;
                           }

                           var111 = 1144617197 ^ var111;
                        }
                     }

                     var111 = 979901479 ^ var111;
                     Object var22 = var9.next();
                     String var23 = (String)var22;
                     var111 = 1344132094 ^ var111;
                     Map var25 = this.teamOf;
                     byte var26 = var25.containsKey(var23);
                     if (var26 == (200172570 ^ var111)) {
                        var111 = 89844911 ^ var111;
                        Set var28 = this.ours;
                        byte var29 = var28.contains(var23);
                        if (var29 == (246712501 ^ var111)) {
                           var111 = 1294233290 ^ var111;
                           var8.add(var23);
                           var111 = 293498634 ^ var111;
                        } else {
                           var111 = 1549402560 ^ var111;
                        }
                     } else {
                        var111 = 1493233007 ^ var111;
                     }

                     var111 = spcrocdhzdfpyzky(var111, 863314614);
                  }
               case 769229081:
               default:
                  throw new IOException();
               case 1767996747:
            }
         }
      }
   }

   public static String lqamuduqtc(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = htcrakieav;
         byte[] var34 = htcrakieav;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   static {
      htcrakieav = qvpskjsrhsplfnc();
   }

   private static byte[] qvpskjsrhsplfnc() {
      return new byte[]{84, 36, 57, 75, 102, 115, 68, 49, 67, 101, 70, 95, 124, 10, 50, 51, 46, 33, 115, 93, 10, 9, 93, 41, 35, 96, 8, 64, 86, 16, 27, 53, 23, 114, 21, 61, 8, 106, 100, 73, 125, 87, 115, 67, 90, 50, 57, 94, 98, 26, 31, 61, 102, 108, 46, 86, 97, 79, 104, 23, 4, 7, 32, 61, 30};
   }

   private static byte[] amuqmungwzfhzhj() {
      return new byte[]{-101, -22, 8, 82, 94, 32, 114, 105, 123, 38};
   }

   private static byte[] dzfknqkfnjpxexr() {
      return new byte[]{-101, -21, 8, 82, 82, 39, 118, 103, 112, 39};
   }

   private static byte[] hnkhejuyxpfoonj() {
      return new byte[]{-104, -21, 14, 92, 95, 35, 125, 108, 116, 36};
   }

   private static byte[] dwooqxzmhofrmhf() {
      return new byte[]{-104, -21, 14, 92, 95, 35, 125, 108, 116, 36};
   }

   private static byte[] rfowgkwnadgrson() {
      return new byte[]{-104, -19, 13, 88, 81, 47, 125, 105, 123, 35};
   }

   private static byte[] phkknxtbheczmxy() {
      return new byte[]{-98, -18, 1, 90, 80, 39, 118, 108, 123, 37};
   }

   private static int spcrocdhzdfpyzky(int var0, int var1) {
      return var0 ^ var1;
   }

   private static final class K {
      Object params;
      final Set<String> members;
      boolean forced;

      private K() {
         HashSet var2 = new HashSet();
         this.members = var2;
      }

      static {
      }
   }
}
