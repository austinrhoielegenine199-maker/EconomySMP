package org.mz.donutsmpcore.economy;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.mz.donutsmpcore.DonutSMPCore;

public class EconomyListener implements Listener {

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent var1) {
      int var34 = 871597992 ^ 389997046 ^ 438903376;
      var34 = 1246932099 ^ var34;
      DonutSMPCore var2 = DonutSMPCore.getInstance();
      Economy var7 = var2.getEconomy();
      var34 = 1535851463 ^ var34;
      if (var7 == null) {
         var34 = 558085445 ^ var34;
      } else {
         var34 = 1496674790 ^ var34;
         Player var21 = var1.getPlayer();
         byte var10 = var7.hasAccount(var21);
         if (var10 == (1980277420 ^ var34)) {
            var34 = 63369757 ^ var34;
            Player var23 = var1.getPlayer();
            var7.createPlayerAccount(var23);
            var34 = 1893828528 ^ var34;
         } else {
            label39:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var34)) {
                  case 78695717:
                     var34 ^= 1931965869;
                     break label39;
                  case 199804044:
                  default:
                     throw new IOException();
                  case 354360023:
                     break;
                  case 1125113088:
                     break label39;
               }
            }
         }

         Player var14 = var1.getPlayer();
         o0oOo0oOK.deliver(var14);
         var34 = 2061155296 ^ var34;
         byte var16 = var7 instanceof DonutEconomy;
         if (var16 != (2146790625 ^ var34)) {
            var34 = 1299188057 ^ var34;
            DonutEconomy var18 = (DonutEconomy)var7;
            var34 = 1192545050 ^ var34;
            Player var25 = var1.getPlayer();
            UUID var26 = var25.getUniqueId();
            var18.preloadBalance(var26);
            var34 = 1974988793 ^ var34;
            var34 = 1399919169 ^ var34;
            Player var28 = var1.getPlayer();
            UUID var29 = var28.getUniqueId();
            var34 = 1227806957 ^ var34;
            Player var30 = var1.getPlayer();
            String var31 = var30.getName();
            var34 = 184840902 ^ var34;
            var18.updatePlayerName(var29, var31);
            var34 = 744672788 ^ var34;
         } else {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var34)) {
                  case 132906246:
                     var34 = 1122655172 ^ var34;
                     return;
                  case 305686064:
                  default:
                     throw new IOException();
                  case 353467777:
                     break;
                  case 526755333:
                     return;
               }
            }
         }
      }
   }

   public static String hfzvgibiek(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] dgjzbxvxnyfauzh() {
      return new byte[]{99, 81, 69, 62, 83, 120, 99, 127, 21, 41, 44, 124, 22, 98, 17, 7, 59, 105, 78, 109, 11, 126, 49, 2, 37, 79, 84};
   }

   static {
   }
}
