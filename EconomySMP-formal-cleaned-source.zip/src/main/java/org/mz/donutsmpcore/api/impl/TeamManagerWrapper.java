package org.mz.donutsmpcore.api.impl;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mz.donutsmpcore.api.team.ITeam;
import org.mz.donutsmpcore.api.team.ITeamManager;
import org.mz.donutsmpcore.teams.TeamService;
import org.mz.donutsmpcore.teams.TeamService2;

public class TeamManagerWrapper implements ITeamManager {
   private final TeamService2 teamManager;

   public TeamManagerWrapper(@NotNull TeamService2 var1) {
      this.teamManager = var1;
   }

   public @Nullable ITeam getTeam(@NotNull String var1) {
      int var12 = 2021631913 ^ 2041756850 ^ 883535700;
      var12 = 1842851977 ^ var12;
      TeamService2 var6 = this.teamManager;
      TeamService var7 = var6.getTeam(var1);
      var12 = 1954901885 ^ var12;
      TeamWrapper var9;
      if (var7 != null) {
         var12 = 984032047 ^ var12;
         var9 = new TeamWrapper(var7);
         var12 = mouzefxcoctezdgm(var12, 1983992104);
         return var9;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
               case 94985356:
                  var12 ^= 1641343115;
               case 983826120:
                  var9 = null;
                  var12 = 758291084 ^ var12;
                  return var9;
               case 1547985843:
                  break;
               case 1672842888:
               default:
                  throw new RuntimeException();
            }
         }
      }
   }

   public @Nullable ITeam getTeamByPlayer(@NotNull UUID var1) {
      int var12 = 121901724 ^ 385262308 ^ 883535700;
      var12 = 386046676 ^ var12;
      TeamService2 var6 = this.teamManager;
      TeamService var7 = var6.getTeamByPlayer(var1);
      var12 = 1658569710 ^ var12;
      TeamWrapper var9;
      if (var7 == null) {
         var12 = mouzefxcoctezdgm(var12, 552453861);
         var9 = null;
         var12 = 613367812 ^ var12;
         return var9;
      } else {
         var12 = 2125918383 ^ var12;
         var9 = new TeamWrapper(var7);

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
               case 167906418:
                  var12 = 2060744270 ^ var12;
                  return var9;
               case 435020732:
                  break;
               case 1260058296:
                  return var9;
               case 2056107807:
               default:
                  throw new IllegalAccessException();
            }
         }
      }
   }

   public boolean isInTeam(@NotNull UUID var1) {
      int var8 = 576233595 ^ 1169656135 ^ 883535700;
      var8 = 2122265823 ^ var8;
      TeamService2 var4 = this.teamManager;
      boolean var5 = var4.isInTeam(var1);
      return var5;
   }

   public @NotNull Collection<ITeam> getAllTeams() {
      int var12 = 142912252 ^ 1380424349 ^ 883535700;
      var12 = 159604513 ^ var12;
      TeamService2 var3 = this.teamManager;
      Collection var4 = var3.getAllTeamsInternal();
      Stream var5 = var4.stream();
      Function var2 = TeamWrapper::new;
      var12 = 120055918 ^ var12;
      Stream var6 = var5.map(var2);
      var12 = 1013001977 ^ var12;
      Collector var9 = Collectors.toUnmodifiableList();
      Object var7 = var6.collect(var9);
      Collection var8 = (Collection)var7;
      var12 = 1588191210 ^ var12;
      return var8;
   }

   public int getTeamCount() {
      int var7 = 24571351 ^ 466455755 ^ 883535700;
      var7 = 1648996674 ^ var7;
      TeamService2 var2 = this.teamManager;
      Collection var3 = var2.getAllTeamsInternal();
      int var4 = var3.size();
      return var4;
   }

   public static String zngxbzxbco(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] cwkquzogpllftbv() {
      return new byte[]{93, 7, 31, 77, 90, 3, 5, 94, 49, 63, 120, 95, 44, 123, 116, 51, 23, 95, 39};
   }

   private static int mouzefxcoctezdgm(int var0, int var1) {
      return var0 ^ var1;
   }

   static {
   }
}
