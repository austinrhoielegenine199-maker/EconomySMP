package org.mz.donutsmpcore.api.impl;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mz.donutsmpcore.api.team.ITeam;
import org.mz.donutsmpcore.teams.TeamService;

public class TeamWrapper implements ITeam {
   private final TeamService team;
   private static byte[] nemrowcgpr;

   public TeamWrapper(@NotNull TeamService var1) {
      this.team = var1;
   }

   public @NotNull String getName() {
      int var6 = 993187541 ^ 275690436 ^ 1880205856;
      var6 = 1706153939 ^ var6;
      TeamService var2 = this.team;
      String var3 = var2.getName();
      return var3;
   }

   public @NotNull String getDisplayName() {
      int var6 = 1016421382 ^ 118417690 ^ 1880205856;
      var6 = 296819365 ^ var6;
      TeamService var2 = this.team;
      String var3 = var2.getDisplayName();
      return var3;
   }

   public @NotNull String getRawDisplayName() {
      int var6 = 342523020 ^ 2007378596 ^ 1880205856;
      var6 = 2110502627 ^ var6;
      TeamService var2 = this.team;
      String var3 = var2.getRawDisplayName();
      return var3;
   }

   public @NotNull UUID getLeader() {
      int var6 = 1995156812 ^ 221365788 ^ 1880205856;
      var6 = 298858707 ^ var6;
      TeamService var2 = this.team;
      UUID var3 = var2.getLeader();
      return var3;
   }

   public @NotNull Set<UUID> getMembers() {
      int var7 = 644324366 ^ 264210454 ^ 1880205856;
      var7 = 1661071329 ^ var7;
      TeamService var2 = this.team;
      Set var3 = var2.getMembers();
      Set var4 = Collections.unmodifiableSet(var3);
      return var4;
   }

   public long getCreatedAt() {
      int var6 = 282114643 ^ 1629928974 ^ 1880205856;
      var6 = 1038194201 ^ var6;
      TeamService var2 = this.team;
      long var3 = var2.getCreatedAt();
      return var3;
   }

   public boolean isLeader(@NotNull UUID var1) {
      int var8 = 286082733 ^ 2036332978 ^ 1880205856;
      var8 = 1944774133 ^ var8;
      TeamService var4 = this.team;
      boolean var5 = var4.isLeader(var1);
      return var5;
   }

   public boolean isMember(@NotNull UUID var1) {
      int var8 = 337456235 ^ 1809269728 ^ 1880205856;
      var8 = 2111786757 ^ var8;
      TeamService var4 = this.team;
      boolean var5 = var4.isMember(var1);
      return var5;
   }

   public int getMemberCount() {
      int var7 = 1984754007 ^ 583862045 ^ 1880205856;
      var7 = 152747429 ^ var7;
      TeamService var2 = this.team;
      Set var3 = var2.getMembers();
      int var4 = var3.size();
      return var4;
   }

   public boolean isPvpEnabled() {
      int var6 = 26573833 ^ 268876661 ^ 1880205856;
      var6 = 1601086782 ^ var6;
      TeamService var2 = this.team;
      boolean var3 = var2.isPvpEnabled();
      return var3;
   }

   public boolean hasTeamHome() {
      int var6 = 1518732162 ^ 731838409 ^ 1880205856;
      var6 = 1980682573 ^ var6;
      TeamService var2 = this.team;
      boolean var3 = var2.hasTeamHome();
      return var3;
   }

   public @Nullable Location getTeamHome() {
      int var6 = 1875921316 ^ 679042059 ^ 1880205856;
      var6 = 344120478 ^ var6;
      TeamService var2 = this.team;
      Location var3 = var2.getTeamHome();
      return var3;
   }

   public void setTeamHome(@NotNull Location var1) {
      int var7 = 671767669 ^ 9260444 ^ 1880205856;
      var7 = 851068899 ^ var7;
      TeamService var4 = this.team;
      var4.setTeamHome(var1);
      var7 = 798599500 ^ var7;
   }

   public void removeTeamHome() {
      int var6 = 1031071616 ^ 547910934 ^ 1880205856;
      var6 = 238594440 ^ var6;
      TeamService var3 = this.team;
      Object var2 = null;
      var3.setTeamHome((Location)var2);
      var6 = 1696030104 ^ var6;
   }

   public boolean canInvite(@NotNull UUID var1) {
      int var8 = 2095831017 ^ 1329273365 ^ 1880205856;
      var8 = 1344809523 ^ var8;
      TeamService var4 = this.team;
      boolean var5 = var4.canInvite(var1);
      return var5;
   }

   public boolean canKick(@NotNull UUID var1) {
      int var8 = 1637823984 ^ 1964497896 ^ 1880205856;
      var8 = 46678017 ^ var8;
      TeamService var4 = this.team;
      boolean var5 = var4.canKick(var1);
      return var5;
   }

   public boolean canTogglePvP(@NotNull UUID var1) {
      int var8 = 2036481418 ^ 1518896749 ^ 1880205856;
      var8 = 1219235024 ^ var8;
      TeamService var4 = this.team;
      boolean var5 = var4.canTogglePvP(var1);
      return var5;
   }

   public boolean canSetHome(@NotNull UUID var1) {
      int var8 = 1879950759 ^ 1025709087 ^ 1880205856;
      var8 = 312524850 ^ var8;
      TeamService var4 = this.team;
      boolean var5 = var4.canSetHome(var1);
      return var5;
   }

   public boolean canVisitHome(@NotNull UUID var1) {
      int var8 = 1561106968 ^ 276220143 ^ 1880205856;
      var8 = 1987386472 ^ var8;
      TeamService var4 = this.team;
      boolean var5 = var4.canVisitHome(var1);
      return var5;
   }

   public boolean isTeamChatEnabled(@NotNull UUID var1) {
      int var8 = 1372487557 ^ 657647427 ^ 1880205856;
      var8 = 113167844 ^ var8;
      TeamService var4 = this.team;
      boolean var5 = var4.isTeamChatEnabled(var1);
      return var5;
   }

   public static String tecuizpobj(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = nemrowcgpr;
         byte[] var34 = nemrowcgpr;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   static {
      nemrowcgpr = exrduggwxgnktpf();
   }

   private static byte[] exrduggwxgnktpf() {
      return new byte[]{75, 26, 65, 74, 111, 30, 106, 47, 87, 90, 25, 6, 14, 57, 127, 106, 78, 56, 96, 127, 57, 65, 12, 117, 63, 93, 74, 58, 1, 38, 29, 2, 81, 32, 74, 68, 15, 101, 22, 99, 10};
   }
}
