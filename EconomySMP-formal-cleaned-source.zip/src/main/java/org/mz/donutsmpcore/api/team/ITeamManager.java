package org.mz.donutsmpcore.api.team;

import java.util.Collection;
import java.util.UUID;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface ITeamManager {
   @Nullable ITeam getTeam(@NotNull String var1);

   @Nullable ITeam getTeamByPlayer(@NotNull UUID var1);

   boolean isInTeam(@NotNull UUID var1);

   @NotNull Collection<ITeam> getAllTeams();

   int getTeamCount();
}
