package org.mz.donutsmpcore.api;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mz.donutsmpcore.api.team.ITeamManager;

public final class DonutSMPCoreAPI {
   private static DonutSMPCoreAPI instance;
   private final ITeamManager teamManager;
   private static String tunaktcqqs;

   private DonutSMPCoreAPI(@NotNull ITeamManager var1) {
      this.teamManager = var1;
   }

   public static @Nullable DonutSMPCoreAPI get() {
      int var3 = 1426557853 ^ 208545876 ^ 1732967705;
      var3 = 1968292453 ^ var3;
      DonutSMPCoreAPI var0 = instance;
      return var0;
   }

   public @NotNull ITeamManager getTeamManager() {
      int var5 = 1173410124 ^ 177062484 ^ 925731349;
      var5 = 1632354770 ^ var5;
      ITeamManager var2 = this.teamManager;
      return var2;
   }

   public static @NotNull DonutSMPCoreAPI register(@NotNull ITeamManager var0) {
      int var6 = 1672310931 ^ 902998853 ^ 1732967705;
      var6 = 1696703944 ^ var6;
      DonutSMPCoreAPI var1 = new DonutSMPCoreAPI(var0);
      instance = var1;
      var6 = 861968666 ^ var6;
      DonutSMPCoreAPI var3 = instance;
      return var3;
   }

   public static void unregister() {
      int var3 = 1651549461 ^ 457403870 ^ 1732967705;
      var3 = 64777881 ^ var3;
      Object var0 = null;
      instance = (DonutSMPCoreAPI)var0;
      var3 = 433805030 ^ var3;
   }

   public static String lxnlnexqiw(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = tunaktcqqs;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   static {
      tunaktcqqs = ByteBuffer.wrap(nhdjkkrwcebfrnt()).asCharBuffer().toString();
   }

   private static byte[] nhdjkkrwcebfrnt() {
      return new byte[0];
   }
}
