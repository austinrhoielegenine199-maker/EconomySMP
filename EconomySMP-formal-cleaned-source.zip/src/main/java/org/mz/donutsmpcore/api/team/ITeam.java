package org.mz.donutsmpcore.api.team;

import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface ITeam {
   @NotNull String getName();

   @NotNull String getDisplayName();

   @NotNull String getRawDisplayName();

   @NotNull UUID getLeader();

   @NotNull Set<UUID> getMembers();

   long getCreatedAt();

   boolean isLeader(@NotNull UUID var1);

   boolean isMember(@NotNull UUID var1);

   int getMemberCount();

   boolean isPvpEnabled();

   boolean hasTeamHome();

   @Nullable Location getTeamHome();

   void setTeamHome(@NotNull Location var1);

   void removeTeamHome();

   boolean canInvite(@NotNull UUID var1);

   boolean canKick(@NotNull UUID var1);

   boolean canTogglePvP(@NotNull UUID var1);

   boolean canSetHome(@NotNull UUID var1);

   boolean canVisitHome(@NotNull UUID var1);

   boolean isTeamChatEnabled(@NotNull UUID var1);
}
