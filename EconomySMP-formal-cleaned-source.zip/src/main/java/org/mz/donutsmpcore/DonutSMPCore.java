package org.mz.donutsmpcore;

import org.bukkit.plugin.java.JavaPlugin;

/**
 * EconomySMP plugin bootstrap.
 *
 * The supplied decompiled main class referenced hundreds of obfuscated third-party package
 * classes whose source and original names were not present in the archive. Those
 * references cannot be safely reconstructed from the decompiled text alone.
 * This clean bootstrap intentionally avoids those broken imports and keeps the
 * project entry point readable while the feature classes are repaired.
 */
public final class DonutSMPCore extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getLogger().info("EconomySMP core bootstrap enabled.");
        getLogger().warning("Feature registration is not restored yet: the original main class depended on unavailable obfuscated classes.");
    }

    @Override
    public void onDisable() {
        getLogger().info("EconomySMP core disabled.");
    }
}
