package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AuctionCommand implements CommandExecutor {
   private static byte[] goqlgoryar;

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      int var27 = 1277722134 ^ 865890470 ^ 1948211349;
      var27 = 262437143 ^ var27;
      byte var11 = var1 instanceof Player;
      if (var11 != (68103986 ^ var27)) {
         var27 = 1977593362 ^ var27;
         Player var13 = (Player)var1;
         var27 = 1909386319 ^ var27;
         int var15 = var4.length;
         byte var6 = (byte)(1994094 ^ var27);
         String var20;
         if (var15 >= var6) {
            var27 = 317339701 ^ var27;
            String var16 = wzkbrcqevg(jvepfmazpywjlyd(), var27);
            String var17 = String.join(var16, var4);
            var20 = var17.trim();

            label43:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var27)) {
                  case 79263658:
                     var27 ^= 183330854;
                     break label43;
                  case 337875589:
                     break;
                  case 1283329560:
                     break label43;
                  case 1561259188:
                  default:
                     throw new IllegalAccessException();
               }
            }
         } else {
            label33:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var27)) {
                  case 1869446:
                     var27 ^= 1430343692;
                     break label33;
                  case 377447176:
                  default:
                     throw new IllegalAccessException();
                  case 395117310:
                     break;
                  case 1064138849:
                     break label33;
               }
            }

            var20 = wzkbrcqevg(opqfpkorzsceksa(), var27);
            var27 = 1296433183 ^ var27;
         }

         var27 = 2013667803 ^ var27;
         AuctionGUI var18 = new AuctionGUI;
         byte var23 = var20.isEmpty();
         String var24;
         if (var23 != (1612651687 ^ var27)) {
            var27 = 429003164 ^ var27;
            var24 = null;
            var27 = 1512936324 ^ var27;
         } else {
            var27 = xscpmikonqwxogoc(var27, 1380010239);
            var24 = var20;
            var27 = 301910759 ^ var27;
         }

         var18.<init>(var13, var24);
         var18.open();
         var27 = 1082114100 ^ var27;
         byte var19 = (byte)(1675583114 ^ var27);
         return (boolean)var19;
      } else {
         label56:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var27)) {
               case 63846449:
                  var27 ^= 34189908;
                  break label56;
               case 1067672807:
                  break;
               case 1149825264:
                  break label56;
               case 1157182816:
               default:
                  throw new IllegalAccessException();
            }
         }

         byte var21 = (byte)(101096807 ^ var27);
         return (boolean)var21;
      }
   }

   public static String wzkbrcqevg(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = goqlgoryar;
         byte[] var34 = goqlgoryar;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   static {
      goqlgoryar = hbbgqrfhicgxsvq();
   }

   private static byte[] hbbgqrfhicgxsvq() {
      return new byte[]{7, 58, 15, 96, 37, 33, 54, 3, 80, 21, 100, 114, 94, 34, 44, 81, 55, 60, 82, 70, 72, 86, 54, 114, 97, 121, 65, 22, 65, 56, 17, 17, 54, 58, 126, 3, 69, 5, 86, 93, 49, 72, 101, 54, 24, 24, 41, 123, 32, 71, 47, 95, 16, 51, 121, 23, 42, 21, 122, 56, 62, 38, 22, 90, 55, 16, 20, 126, 78, 124, 16, 6, 33, 101, 91, 116, 53, 1, 69, 5, 25, 29, 111, 96, 21, 6, 30, 122, 70, 100, 19, 118, 18, 89, 71, 28, 15, 108, 56, 102, 54, 115, 83, 121, 25, 31, 109, 99, 32, 71, 127, 86, 49, 57, 7, 41, 7, 118, 63, 123, 98, 89, 42, 4, 47, 27};
   }

   private static byte[] jvepfmazpywjlyd() {
      return new byte[]{-54, -12, 55, 112};
   }

   private static byte[] opqfpkorzsceksa() {
      return new byte[0];
   }

   private static int xscpmikonqwxogoc(int var0, int var1) {
      return var0 ^ var1;
   }
}
