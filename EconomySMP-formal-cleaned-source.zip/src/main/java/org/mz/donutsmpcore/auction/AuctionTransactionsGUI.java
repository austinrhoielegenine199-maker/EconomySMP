package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Stream;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemFactory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.mz.donutsmpcore.DonutSMPCore;
import org.mz.donutsmpcore.libs.signgui.SignGUI;
import org.mz.donutsmpcore.libs.signgui.SignGUIBuilder;
import org.mz.donutsmpcore.libs.signgui.SignGUIFinishHandler;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.KKoOoOo0oOK;
import skido.KoOKKo0K;
import skido.o0KoOo0KoOK;
import skido.o0o0oOKo0K;
import skido.o0oOoOo0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;

public class AuctionTransactionsGUI implements KKoOK {
   private final Player player;
   private Inventory inventory;
   private int page;
   private static final int ITEMS_PER_PAGE = 45;
   private String searchQuery;

   private static o0o0oOKo0K cfg() {
      int var4 = 15312204 ^ 992708861 ^ 552149470;
      var4 = 374958727 ^ var4;
      String var0 = kfixqwhemr(nwxwvscjhqnellk(), xlvmmareofevlcb(), var4);
      o0o0oOKo0K var1 = o0o0oOKo0K.of(var0);
      return var1;
   }

   public AuctionTransactionsGUI(Player var1) {
      String var3 = "";
      this.searchQuery = var3;
      this.player = var1;
   }

   public void open(int var1) {
      int var63 = 1625338477 ^ 2092749612 ^ 1585545255;
      var63 = 751639594 ^ var63;
      this.page = var1;
      var63 = 801999370 ^ var63;
      Inventory var11 = this.inventory;
      if (var11 != null) {
         var63 = 2121544058 ^ var63;
         Player var13 = this.player;
         var63 = 742248349 ^ var63;
         InventoryView var14 = var13.getOpenInventory();
         Inventory var15 = var14.getTopInventory();
         Inventory var31 = this.inventory;
         byte var16 = var15.equals(var31);
         if (var16 != (328501665 ^ var63)) {
            var63 = 16762195 ^ var63;
            this.decorate();
            var63 = 628186356 ^ var63;

            label56: {
               try {
                  Player var19 = this.player;
                  InventoryView var20 = var19.getOpenInventory();
                  var63 = 1715761140 ^ var63;
                  o0o0oOKo0K var32 = cfg();
                  String var4 = kfixqwhemr(yjwwpaojnrhmeke(), xlvmmareofevlcb(), var63);
                  String var5 = kfixqwhemr(tvxaiyhxkxogfmb(), xlvmmareofevlcb(), var63);
                  String var33 = var32.rawStr(var4, var5);
                  String var43 = kfixqwhemr(lyjomrqiyopfvgw(), xlvmmareofevlcb(), var63);
                  byte var6 = (byte)(1348370419 ^ var63);
                  int var48 = var1 + var6;
                  String var49 = String.valueOf(var48);
                  String var34 = var33.replace(var43, var49);
                  String var35 = oOo0KKoOoOK.color(var34);
                  var63 = 1384207284 ^ var63;
                  var20.setTitle(var35);
                  var63 = 1045201516 ^ var63;
               } catch (Throwable var64) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var63)) {
                     case -2097938542 -> var63 = tohvqcjkpmjgcblo(var63, 1156397827);
                     case -1328512975 -> var63 = tohvqcjkpmjgcblo(var63, 581522679);
                     case 385442352 -> var63 = 376203447 ^ var63;
                     default -> throw new IOException("Error in hash");
                  }

                  var63 = 613772041 ^ var63;
                  break label56;
               }

               label44:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var63)) {
                     case 90054114:
                        var63 ^= 213221842;
                     case 1613314160:
                        break label44;
                     case 1901456121:
                     default:
                        throw new IllegalAccessException();
                     case 1924253613:
                  }
               }
            }

            Player var22 = this.player;
            var22.updateInventory();
            var63 = 1272960018 ^ var63;
            return;
         }

         var63 = 268366929 ^ var63;
      } else {
         var63 = tohvqcjkpmjgcblo(var63, 1572276918);
      }

      Object var36 = null;
      InventoryHolder var37 = (InventoryHolder)var36;
      o0o0oOKo0K var44 = cfg();
      String var50 = kfixqwhemr(tbzadqigyrkejdr(), xlvmmareofevlcb(), var63);
      byte var55 = (byte)(476741062 ^ var63);
      int var45 = var44.intAt(var50, var55);
      o0o0oOKo0K var51 = cfg();
      String var56 = kfixqwhemr(zglyndslbnypzft(), xlvmmareofevlcb(), var63);
      String var7 = kfixqwhemr(ssltegorklkpiwo(), xlvmmareofevlcb(), var63);
      String var52 = var51.rawStr(var56, var7);
      String var57 = kfixqwhemr(elxnjlzpiovlxuq(), xlvmmareofevlcb(), var63);
      byte var8 = (byte)(476741105 ^ var63);
      int var59 = var1 + var8;
      String var60 = String.valueOf(var59);
      String var53 = var52.replace(var57, var60);
      String var54 = oOo0KKoOoOK.color(var53);
      Inventory var38 = Bukkit.createInventory(var37, var45, var54);
      this.inventory = var38;
      var63 = 9291361 ^ var63;
      oOoOKo0o0K var25 = oOoOKo0o0K.getInstance();
      Inventory var40 = this.inventory;
      var25.register(var40, this);
      var63 = 1438493589 ^ var63;
      this.decorate();
      var63 = 1127664909 ^ var63;
      Player var28 = this.player;
      Inventory var42 = this.inventory;
      var28.openInventory(var42);
      var63 = 162141950 ^ var63;
   }

   public void decorate() {
      int var421 = 1388107206 ^ 2114835085 ^ 1585545255;
      var421 = 169168317 ^ var421;
      byte var1 = (byte)(2015742695 ^ var421);
      ItemStack[] var27 = new ItemStack[var1];
      ItemStack[] var8 = var27;
      var421 = 445499661 ^ var421;
      Player var29 = this.player;
      UUID var30 = var29.getUniqueId();
      List var31 = TransactionHistory.getHistory(var30);
      List var9 = var31;
      var421 = 125242676 ^ var421;
      byte var32 = (byte)(1709117161 ^ var421);
      int var178 = var31.size();
      byte var3 = (byte)(1709117125 ^ var421);
      int var179 = var178 + var3;
      byte var270 = (byte)(1709117161 ^ var421);
      int var180 = var179 - var270;
      byte var271 = (byte)(1709117125 ^ var421);
      int var181 = var180 / var271;
      int var33 = Math.max(var32, var181);
      var421 = 1697111263 ^ var421;
      int var35 = this.page;
      if (var35 >= var33) {
         var421 = 572955195 ^ var421;
         byte var183 = (byte)(584992780 ^ var421);
         byte var4 = (byte)(584992781 ^ var421);
         int var273 = var33 - var4;
         int var184 = Math.max(var183, var273);
         this.page = var184;
         var421 = 1848203233 ^ var421;
      } else {
         label218:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var421)) {
               case 15287787:
                  var421 ^= 1276104154;
                  break label218;
               case 558872475:
               default:
                  throw new IOException();
               case 632723419:
                  break label218;
               case 722333191:
            }
         }
      }

      int var38 = this.page;
      byte var185 = (byte)(1291263936 ^ var421);
      int var39 = var38 * var185;
      var421 = 1777099718 ^ var421;
      byte var186 = (byte)(622558214 ^ var421);
      int var41 = var39 + var186;
      int var188 = var31.size();
      int var42 = Math.min(var41, var188);
      int var12 = var42;
      var421 = 1797266120 ^ var421;
      byte var43 = (byte)(1312515811 ^ var421);
      int var13 = var43;
      var421 = 2130495013 ^ var421;
      int var14 = var39;
      var421 = 1854212903 ^ var421;

      while(true) {
         if (var14 >= var12) {
            var421 = tohvqcjkpmjgcblo(var421, 1857990121);
            break;
         }

         var421 = 67268864 ^ var421;
         Object var47 = var9.get(var14);
         TransactionHistory.Transaction var48 = (TransactionHistory.Transaction)var47;
         var421 = 969020977 ^ var421;
         ItemStack var50 = var48.getItem();
         var421 = 178545947 ^ var421;
         if (var50 == null) {
            var421 = 1367240043 ^ var421;
            var421 = tohvqcjkpmjgcblo(var421, 793060204);
         } else {
            var421 = tohvqcjkpmjgcblo(var421, 626480815);
            Material var53 = var50.getType();
            String var54 = var53.name();
            String var55 = var54.toLowerCase();
            var421 = 1162216891 ^ var421;
            String var56 = kfixqwhemr(qhojavonvzwyrxx(), xlvmmareofevlcb(), var421);
            String var18 = var56;
            var421 = 103356406 ^ var421;
            byte var58 = var50.hasItemMeta();
            if (var58 != (253685033 ^ var421)) {
               var421 ^= 1594519174;
               ItemMeta var60 = var50.getItemMeta();
               byte var61 = var60.hasDisplayName();
               if (var61 != (1343521711 ^ var421)) {
                  var421 = 1626016105 ^ var421;
                  ItemMeta var63 = var50.getItemMeta();
                  String var64 = var63.getDisplayName();
                  var421 = 170380677 ^ var421;
                  String var66 = ChatColor.stripColor(var64);
                  String var67 = var66.toLowerCase();
                  var18 = var67;
                  var421 = 1138825575 ^ var421;
               } else {
                  label186:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var421)) {
                        case 187166519:
                           var421 ^= 690871691;
                           break label186;
                        case 197586697:
                           break;
                        case 237170980:
                        default:
                           throw new IOException();
                        case 2030707164:
                           break label186;
                     }
                  }
               }
            } else {
               label200:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var421)) {
                     case 67295620:
                        break;
                     case 223077473:
                        var421 ^= 1982313229;
                     case 520528861:
                        break label200;
                     case 1883659072:
                     default:
                        throw new IOException();
                  }
               }
            }

            byte var176;
            label227: {
               String var69 = this.searchQuery;
               byte var70 = var69.isEmpty();
               if (var70 == (2033802788 ^ var421)) {
                  var421 = 133763211 ^ var421;
                  String var192 = this.searchQuery;
                  byte var72 = var55.contains(var192);
                  if (var72 == (2126532271 ^ var421)) {
                     var421 = 1204664738 ^ var421;
                     String var194 = this.searchQuery;
                     byte var74 = var18.contains(var194);
                     if (var74 == (957216525 ^ var421)) {
                        var421 = tohvqcjkpmjgcblo(var421, 1248785312);
                        var176 = (byte)(1935869101 ^ var421);
                        var421 = 2040764543 ^ var421;
                        break label227;
                     }

                     var421 = 783576856 ^ var421;
                  } else {
                     var421 = 1769592506 ^ var421;
                  }
               } else {
                  var421 = tohvqcjkpmjgcblo(var421, 1853933105);
               }

               var176 = (byte)(398039060 ^ var421);

               label170:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var421)) {
                     case 164254046:
                        break;
                     case 234324241:
                        var421 ^= 494470343;
                        break label170;
                     case 368796468:
                     default:
                        throw new IOException();
                     case 872528844:
                        break label170;
                  }
               }
            }

            var421 = 3851492 ^ var421;
            if (var176 != (184178742 ^ var421)) {
               var421 = 2081198210 ^ var421;
               ItemStack var77 = var50.clone();
               var421 = 63021986 ^ var421;
               byte var79 = var77.hasItemMeta();
               ItemMeta var177;
               if (var79 == (1966566166 ^ var421)) {
                  var421 = 2017482691 ^ var421;
                  ItemFactory var175 = Bukkit.getItemFactory();
                  Material var269 = var77.getType();
                  var177 = var175.getItemMeta(var269);
                  var421 = 1485289910 ^ var421;
               } else {
                  var421 = 624752504 ^ var421;
                  var177 = var77.getItemMeta();

                  label149:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var421)) {
                        case 186003230:
                           var421 ^= 100342029;
                        case 533153599:
                           break label149;
                        case 842903896:
                           break;
                        case 903996489:
                        default:
                           throw new IOException();
                     }
                  }
               }

               var421 = 1116798701 ^ var421;
               Material var196 = var77.getType();
               String var197 = var196.name();
               String var82 = this.formatMaterialName(var197);
               var421 = 1016853890 ^ var421;
               long var199 = var48.timestamp;
               String var84 = this.formatTimeAgo(var199);
               var421 = 1698843559 ^ var421;
               UUID var86 = var48.otherPlayer;
               String var87 = Ko0KoOKoOK.getCachedName(var86);
               String var24 = var87;
               var421 = 530216408 ^ var421;
               String var201 = kfixqwhemr(ldomxhziutixeay(), xlvmmareofevlcb(), var421);
               byte var89 = var87.equals(var201);
               if (var89 == (1361293427 ^ var421)) {
                  var421 = tohvqcjkpmjgcblo(var421, 1076417143);
               } else {
                  var421 = 453699362 ^ var421;
                  UUID var91 = var48.otherPlayer;
                  Player var92 = Bukkit.getPlayer(var91);
                  var421 = 2064674988 ^ var421;
                  if (var92 != null) {
                     var421 = 962279299 ^ var421;
                     String var95 = var92.getName();
                     var24 = var95;
                     var421 = 188664114 ^ var421;
                     UUID var97 = var48.otherPlayer;
                     Ko0KoOKoOK.cachePlayerName(var97, var95);
                     var421 = 307739464 ^ var421;
                  } else {
                     label132:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var421)) {
                           case 11634974:
                              break label132;
                           case 83518105:
                              break;
                           case 176380441:
                           default:
                              throw new IOException();
                           case 257854531:
                              var421 ^= 540165625;
                              break label132;
                        }
                     }
                  }
               }

               TransactionHistory.Type var99 = var48.type;
               TransactionHistory.Type var203 = TransactionHistory.Type.BOUGHT;
               if (var99 == var203) {
                  var421 = 269349553 ^ var421;
                  o0o0oOKo0K var204 = cfg();
                  String var274 = kfixqwhemr(gtlrvgpgpzlcfxq(), xlvmmareofevlcb(), var421);
                  String var296 = kfixqwhemr(ycbghwztiflaiae(), xlvmmareofevlcb(), var421);
                  String var205 = var204.rawStr(var274, var296);
                  String var275 = kfixqwhemr(szzenikqnnzidja(), xlvmmareofevlcb(), var421);
                  String var206 = var205.replace(var275, var82);
                  String var207 = oOo0KKoOoOK.color(var206);
                  var177.setDisplayName(var207);
                  var421 = 1013827172 ^ var421;
                  byte var208 = (byte)(1030444755 ^ var421);
                  String[] var209 = new String[var208];
                  byte var298 = (byte)(1030444753 ^ var421);
                  o0o0oOKo0K var5 = cfg();
                  String var6 = kfixqwhemr(koilllbieokxrop(), xlvmmareofevlcb(), var421);
                  String var7 = kfixqwhemr(dtcgizbsafvvtau(), xlvmmareofevlcb(), var421);
                  String var315 = var5.rawStr(var6, var7);
                  String var354 = kfixqwhemr(kexpgfiuywhpgin(), xlvmmareofevlcb(), var421);
                  String var316 = var315.replace(var354, var24);
                  String var355 = kfixqwhemr(jhqsngwfnrflazz(), xlvmmareofevlcb(), var421);
                  String var317 = var316.replace(var355, var82);
                  String var356 = kfixqwhemr(znsbtkuqhqfiryr(), xlvmmareofevlcb(), var421);
                  double var376 = var48.amount;
                  String var378 = oOo0KKoOoOK.formatPrice(var376);
                  String var318 = var317.replace(var356, var378);
                  String var319 = oOo0KKoOoOK.color(var318);
                  var209[var298] = var319;
                  byte var299 = (byte)(1030444752 ^ var421);
                  o0o0oOKo0K var320 = cfg();
                  String var357 = kfixqwhemr(wpuvswxwvdyfkkz(), xlvmmareofevlcb(), var421);
                  String var379 = kfixqwhemr(axaywkktnyknixi(), xlvmmareofevlcb(), var421);
                  String var321 = var320.rawStr(var357, var379);
                  String var358 = kfixqwhemr(aprmdnggolxgrup(), xlvmmareofevlcb(), var421);
                  String var322 = var321.replace(var358, var84);
                  String var323 = oOo0KKoOoOK.color(var322);
                  var209[var299] = var323;
                  List var210 = Arrays.asList(var209);
                  var177.setLore(var210);
                  var421 = tohvqcjkpmjgcblo(var421, 1455666651);
               } else {
                  var421 = 884198075 ^ var421;
                  o0o0oOKo0K var261 = cfg();
                  String var294 = kfixqwhemr(zqihqplzerdmhcq(), xlvmmareofevlcb(), var421);
                  String var311 = kfixqwhemr(awrngpvbqjgvmal(), xlvmmareofevlcb(), var421);
                  String var262 = var261.rawStr(var294, var311);
                  String var295 = kfixqwhemr(vywnodqyidirhsx(), xlvmmareofevlcb(), var421);
                  String var263 = var262.replace(var295, var82);
                  String var264 = oOo0KKoOoOK.color(var263);
                  var177.setDisplayName(var264);
                  var421 = 2100112761 ^ var421;
                  byte var265 = (byte)(1486194116 ^ var421);
                  String[] var266 = new String[var265];
                  byte var313 = (byte)(1486194118 ^ var421);
                  o0o0oOKo0K var344 = cfg();
                  String var367 = kfixqwhemr(vgaremutosupilk(), xlvmmareofevlcb(), var421);
                  String var393 = kfixqwhemr(zkfsnueiesmetgy(), xlvmmareofevlcb(), var421);
                  String var345 = var344.rawStr(var367, var393);
                  String var368 = kfixqwhemr(vlwgpdesctyafkv(), xlvmmareofevlcb(), var421);
                  String var346 = var345.replace(var368, var24);
                  String var369 = kfixqwhemr(noteyxcoqonjgqb(), xlvmmareofevlcb(), var421);
                  String var347 = var346.replace(var369, var82);
                  String var370 = kfixqwhemr(lngeirhmznmliwm(), xlvmmareofevlcb(), var421);
                  double var397 = var48.amount;
                  String var399 = oOo0KKoOoOK.formatPrice(var397);
                  String var348 = var347.replace(var370, var399);
                  String var349 = oOo0KKoOoOK.color(var348);
                  var266[var313] = var349;
                  byte var314 = (byte)(1486194119 ^ var421);
                  o0o0oOKo0K var350 = cfg();
                  String var371 = kfixqwhemr(jwfkbzczuyegqlq(), xlvmmareofevlcb(), var421);
                  String var400 = kfixqwhemr(memkztlrjmttpxk(), xlvmmareofevlcb(), var421);
                  String var351 = var350.rawStr(var371, var400);
                  String var372 = kfixqwhemr(yhbimqogbptfggy(), xlvmmareofevlcb(), var421);
                  String var352 = var351.replace(var372, var84);
                  String var353 = oOo0KKoOoOK.color(var352);
                  var266[var314] = var353;
                  List var267 = Arrays.asList(var266);
                  var177.setLore(var267);
                  var421 = 859662028 ^ var421;
               }

               boolean var103 = var77.setItemMeta(var177);
               var421 = 1152662077 ^ var421;
               var8[var13] = var77;
               var421 = 328642401 ^ var421;
               var13 += 1015707223 ^ var421;
               byte var213 = (byte)(1015707259 ^ var421);
               if (var13 >= var213) {
                  var421 = 1804198697 ^ var421;
                  var421 = 1744802679 ^ var421;
                  break;
               }

               var421 = tohvqcjkpmjgcblo(var421, 731353498);
            } else {
               var421 = 501727226 ^ var421;
            }
         }

         var14 += 387835853 ^ var421;
         var421 = tohvqcjkpmjgcblo(var421, 1230982189);
      }

      label111: {
         Player var107 = this.player;
         UUID var108 = var107.getUniqueId();
         double var109 = TransactionHistory.getTotalSpent(var108);
         var421 = 1536526159 ^ var421;
         Player var112 = this.player;
         UUID var113 = var112.getUniqueId();
         double var114 = TransactionHistory.getTotalMade(var113);
         var421 = 116030788 ^ var421;
         Material var277 = Material.BOOK;
         ItemStack var116 = new ItemStack(var277);
         var421 = 197884420 ^ var421;
         ItemMeta var118 = var116.getItemMeta();
         var421 = 645327800 ^ var421;
         o0o0oOKo0K var214 = cfg();
         String var278 = kfixqwhemr(surtxdobbrsewhr(), xlvmmareofevlcb(), var421);
         String var300 = kfixqwhemr(uhlxyybrzrnukxf(), xlvmmareofevlcb(), var421);
         String var215 = var214.rawStr(var278, var300);
         String var216 = oOo0KKoOoOK.color(var215);
         var118.setDisplayName(var216);
         var421 = 1209439032 ^ var421;
         byte var217 = (byte)(136904325 ^ var421);
         String[] var218 = new String[var217];
         byte var301 = (byte)(136904327 ^ var421);
         o0o0oOKo0K var324 = cfg();
         String var359 = kfixqwhemr(sjmjwakscxhkufz(), xlvmmareofevlcb(), var421);
         String var381 = kfixqwhemr(lyxbguuwakraqiu(), xlvmmareofevlcb(), var421);
         String var325 = var324.rawStr(var359, var381);
         String var360 = kfixqwhemr(kscpqpvtaztttex(), xlvmmareofevlcb(), var421);
         String var384 = oOo0KKoOoOK.formatPrice(var109);
         String var326 = var325.replace(var360, var384);
         String var327 = oOo0KKoOoOK.color(var326);
         var218[var301] = var327;
         byte var302 = (byte)(136904326 ^ var421);
         o0o0oOKo0K var328 = cfg();
         String var361 = kfixqwhemr(mxhexwtkxbceyye(), xlvmmareofevlcb(), var421);
         String var385 = kfixqwhemr(vhnnyayswsspofg(), xlvmmareofevlcb(), var421);
         String var329 = var328.rawStr(var361, var385);
         String var362 = kfixqwhemr(pywvwxhhqsagmtd(), xlvmmareofevlcb(), var421);
         String var388 = oOo0KKoOoOK.formatPrice(var114);
         String var330 = var329.replace(var362, var388);
         String var331 = oOo0KKoOoOK.color(var330);
         var218[var302] = var331;
         List var219 = Arrays.asList(var218);
         var118.setLore(var219);
         var421 = 639752518 ^ var421;
         var116.setItemMeta(var118);
         var421 = 28714940 ^ var421;
         byte var221 = (byte)(801046605 ^ var421);
         var8[var221] = var116;
         var421 = 868772432 ^ var421;
         Material var280 = Material.WRITABLE_BOOK;
         ItemStack var124 = new ItemStack(var280);
         var421 = 821044306 ^ var421;
         ItemMeta var126 = var124.getItemMeta();
         var421 = 661505376 ^ var421;
         o0o0oOKo0K var222 = cfg();
         String var281 = kfixqwhemr(xzgidmtjtfqivpy(), xlvmmareofevlcb(), var421);
         String var303 = kfixqwhemr(mdogczeydibbxlx(), xlvmmareofevlcb(), var421);
         String var223 = var222.rawStr(var281, var303);
         String var224 = oOo0KKoOoOK.color(var223);
         var126.setDisplayName(var224);
         var421 = 573517034 ^ var421;
         byte var225 = (byte)(700819444 ^ var421);
         String[] var226 = new String[var225];
         byte var304 = (byte)(700819445 ^ var421);
         o0o0oOKo0K var332 = cfg();
         String var363 = kfixqwhemr(awoeyxylaektlsa(), xlvmmareofevlcb(), var421);
         String var389 = kfixqwhemr(voagjqelvrkuejr(), xlvmmareofevlcb(), var421);
         String var333 = var332.rawStr(var363, var389);
         String var334 = oOo0KKoOoOK.color(var333);
         var226[var304] = var334;
         List var227 = Arrays.asList(var226);
         var126.setLore(var227);
         var421 = 560720970 ^ var421;
         var124.setItemMeta(var126);
         var421 = 1645749893 ^ var421;
         byte var229 = (byte)(1790340363 ^ var421);
         var8[var229] = var124;
         var421 = 1364734774 ^ var421;
         Material var283 = Material.OAK_SIGN;
         ItemStack var132 = new ItemStack(var283);
         var421 = 1304718979 ^ var421;
         ItemMeta var134 = var132.getItemMeta();
         var421 = 214494500 ^ var421;
         o0o0oOKo0K var230 = cfg();
         String var284 = kfixqwhemr(nlegixixynantwg(), xlvmmareofevlcb(), var421);
         String var305 = kfixqwhemr(agztywnndzolpkd(), xlvmmareofevlcb(), var421);
         String var231 = var230.rawStr(var284, var305);
         String var232 = oOo0KKoOoOK.color(var231);
         var134.setDisplayName(var232);
         var421 = 2095169751 ^ var421;
         byte var233 = (byte)(100867453 ^ var421);
         String[] var234 = new String[var233];
         byte var306 = (byte)(100867452 ^ var421);
         o0o0oOKo0K var335 = cfg();
         String var364 = kfixqwhemr(ahkmtfptegasdwv(), xlvmmareofevlcb(), var421);
         String var390 = kfixqwhemr(joykvqnjjahfvkd(), xlvmmareofevlcb(), var421);
         String var336 = var335.rawStr(var364, var390);
         String var337 = oOo0KKoOoOK.color(var336);
         var234[var306] = var337;
         List var235 = Arrays.asList(var234);
         var134.setLore(var235);
         var421 = 237389072 ^ var421;
         var132.setItemMeta(var134);
         var421 = 1118848300 ^ var421;
         byte var237 = (byte)(1251286386 ^ var421);
         var8[var237] = var132;
         var421 = 763558580 ^ var421;
         int var141 = this.page;
         if (var141 <= (1729619956 ^ var421)) {
            var421 = 1141169040 ^ var421;
            byte var142 = o0KoOo0KoOK.always();
            if (var142 == (588463204 ^ var421)) {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var421)) {
                     case 66414098:
                        var421 ^= 1169528851;
                        break label111;
                     case 254396652:
                        break;
                     case 384746299:
                        break label111;
                     case 795039032:
                     default:
                        throw new IOException();
                  }
               }
            }

            var421 = 1884879921 ^ var421;
         } else {
            label109:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var421)) {
                  case 129906303:
                     var421 ^= 878454689;
                  case 294809020:
                     break label109;
                  case 584555302:
                     break;
                  case 938729989:
                  default:
                     throw new IOException();
               }
            }
         }

         Material var286 = Material.ARROW;
         ItemStack var143 = new ItemStack(var286);
         var421 = 857501458 ^ var421;
         ItemMeta var145 = var143.getItemMeta();
         var421 = 703758724 ^ var421;
         o0o0oOKo0K var238 = cfg();
         String var287 = kfixqwhemr(gmvpklsemhdpyou(), xlvmmareofevlcb(), var421);
         String var307 = kfixqwhemr(lmgrdlutyrkcjer(), xlvmmareofevlcb(), var421);
         String var239 = var238.rawStr(var287, var307);
         String var240 = oOo0KKoOoOK.color(var239);
         var145.setDisplayName(var240);
         var421 = 432819945 ^ var421;
         byte var241 = (byte)(1349083179 ^ var421);
         String[] var242 = new String[var241];
         byte var308 = (byte)(1349083178 ^ var421);
         o0o0oOKo0K var338 = cfg();
         String var365 = kfixqwhemr(ahrymyzjeqpfoeg(), xlvmmareofevlcb(), var421);
         String var391 = kfixqwhemr(rycbtsmcuyfycdi(), xlvmmareofevlcb(), var421);
         String var339 = var338.rawStr(var365, var391);
         String var340 = oOo0KKoOoOK.color(var339);
         var242[var308] = var340;
         List var243 = Arrays.asList(var242);
         var145.setLore(var243);
         var421 = 653643059 ^ var421;
         var143.setItemMeta(var145);
         var421 = 1204202032 ^ var421;
         byte var245 = (byte)(827983620 ^ var421);
         var8[var245] = var143;
         var421 = 1476174686 ^ var421;
      }

      label86: {
         int var152 = this.page;
         byte var289 = (byte)(1722197110 ^ var421);
         int var247 = var33 - var289;
         if (var152 >= var247) {
            var421 = 1249210725 ^ var421;
            byte var153 = o0KoOo0KoOK.always();
            if (var153 == (752080146 ^ var421)) {
               var421 = tohvqcjkpmjgcblo(var421, 1461197988);
               break label86;
            }

            var421 = 695554699 ^ var421;
         } else {
            var421 = tohvqcjkpmjgcblo(var421, 1660953582);
         }

         Material var290 = Material.ARROW;
         ItemStack var154 = new ItemStack(var290);
         var421 = 715969766 ^ var421;
         ItemMeta var156 = var154.getItemMeta();
         var421 = 939206028 ^ var421;
         o0o0oOKo0K var248 = cfg();
         String var291 = kfixqwhemr(kkeusfvybollvgs(), xlvmmareofevlcb(), var421);
         String var309 = kfixqwhemr(tqaxurcjqlupfcm(), xlvmmareofevlcb(), var421);
         String var249 = var248.rawStr(var291, var309);
         String var250 = oOo0KKoOoOK.color(var249);
         var156.setDisplayName(var250);
         var421 = 168662208 ^ var421;
         byte var251 = (byte)(318562866 ^ var421);
         String[] var252 = new String[var251];
         byte var310 = (byte)(318562867 ^ var421);
         o0o0oOKo0K var341 = cfg();
         String var366 = kfixqwhemr(ujhiaqvenzxialz(), xlvmmareofevlcb(), var421);
         String var392 = kfixqwhemr(gxnkpxgncmbmlrj(), xlvmmareofevlcb(), var421);
         String var342 = var341.rawStr(var366, var392);
         String var343 = oOo0KKoOoOK.color(var342);
         var252[var310] = var343;
         List var253 = Arrays.asList(var252);
         var156.setLore(var253);
         var421 = 202487847 ^ var421;
         var154.setItemMeta(var156);
         var421 = 1298389040 ^ var421;
         byte var255 = (byte)(1401848337 ^ var421);
         var8[var255] = var154;
         var421 = 675629970 ^ var421;
      }

      byte var162 = (byte)(2076953014 ^ var421);
      int var415 = var162;
      var421 = 787112434 ^ var421;

      while(true) {
         byte var256 = (byte)(1428269170 ^ var421);
         if (var415 >= var256) {
            var421 = tohvqcjkpmjgcblo(var421, 1024123743);
            return;
         }

         var421 = 141727239 ^ var421;
         Inventory var165 = this.inventory;
         ItemStack var166 = var165.getItem(var415);
         var421 = 1473910906 ^ var421;
         ItemStack var168 = var8[var415];
         var421 = 1778937256 ^ var421;
         byte var170 = stacksEqual(var166, var168);
         if (var170 == (1619086225 ^ var421)) {
            var421 = 695928737 ^ var421;
            Inventory var172 = this.inventory;
            var172.setItem(var415, var168);
            var421 = 1176262622 ^ var421;
         } else {
            var421 = 1869041791 ^ var421;
         }

         var415 += 266738671 ^ var421;
         var421 = tohvqcjkpmjgcblo(var421, 1523037098);
      }
   }

   private static boolean stacksEqual(ItemStack var0, ItemStack var1) {
      byte var9;
      int var30;
      label55: {
         var30 = 601206351 ^ 1492328908 ^ 552149470;
         var30 = 232754450 ^ var30;
         if (var0 != null) {
            var30 = 1913008674 ^ var30;
            Material var7 = var0.getType();
            byte var8 = var7.isAir();
            if (var8 == (605426029 ^ var30)) {
               var30 = 1020743467 ^ var30;
               var9 = (byte)(415325766 ^ var30);
               var30 = 880620587 ^ var30;
               break label55;
            }

            var30 = 859040891 ^ var30;
         } else {
            var30 = tohvqcjkpmjgcblo(var30, 1094049369);
         }

         var9 = (byte)(388365591 ^ var30);
         var30 = tohvqcjkpmjgcblo(var30, 999921531);
      }

      byte var22;
      label49: {
         var30 = 972669488 ^ var30;
         if (var1 != null) {
            var30 = 1945906782 ^ var30;
            Material var12 = var1.getType();
            byte var13 = var12.isAir();
            if (var13 == (1723434499 ^ var30)) {
               var30 = 632175898 ^ var30;
               var22 = (byte)(1125628697 ^ var30);
               var30 = 1606095122 ^ var30;
               break label49;
            }

            var30 = 1400554837 ^ var30;
         } else {
            var30 = 545712907 ^ var30;
         }

         var22 = (byte)(901989207 ^ var30);
         var30 = 695200093 ^ var30;
      }

      var30 = 357962952 ^ var30;
      if (var9 != (167427779 ^ var30)) {
         var30 = 1409033525 ^ var30;
         if (var22 != (1510382582 ^ var30)) {
            var30 = 1796685890 ^ var30;
            byte var16 = (byte)(823253941 ^ var30);
            return (boolean)var16;
         }

         var30 = 18895272 ^ var30;
      } else {
         var30 = tohvqcjkpmjgcblo(var30, 1390179485);
      }

      if (var9 == (1529268830 ^ var30)) {
         var30 = 967647588 ^ var30;
         if (var22 == (1653336890 ^ var30)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var30)) {
                  case 250574155:
                     var30 = 1040768196 ^ var30;
                  case 484899319:
                     boolean var20 = var0.equals(var1);
                     return var20;
                  case 988721198:
                     break;
                  case 1572039902:
                  default:
                     throw new RuntimeException();
               }
            }
         }

         var30 = 1262759664 ^ var30;
      } else {
         var30 = tohvqcjkpmjgcblo(var30, 1927876500);
      }

      byte var21 = (byte)(701482442 ^ var30);
      return (boolean)var21;
   }

   public void onClick(InventoryClickEvent var1) {
      int var87 = 903465845 ^ 1680036282 ^ 1585545255;
      var87 = 62384499 ^ var87;
      byte var3 = (byte)(214758298 ^ var87);
      var1.setCancelled((boolean)var3);
      var87 = 281793597 ^ var87;
      int var11 = var1.getRawSlot();
      var87 = 1474388468 ^ var87;
      if (var11 >= (1273382482 ^ var87)) {
         var87 = 1162348523 ^ var87;
         byte var52 = (byte)(246301071 ^ var87);
         if (var11 < var52) {
            var87 = tohvqcjkpmjgcblo(var87, 1680154729);
            byte var53 = (byte)(1787519457 ^ var87);
            if (var11 == var53) {
               var87 = 1793101977 ^ var87;
               Player var16 = this.player;
               String var54 = kfixqwhemr(dlfflnzxrpzsgmw(), xlvmmareofevlcb(), var87);
               Sound var4 = Sound.UI_TOAST_IN;
               float var5 = 1.0F;
               float var6 = 1.8F;
               KKo0KoOoOK.play(var16, var54, var4, var5, var6);
               var87 = 1209876838 ^ var87;
               this.decorate();
               var87 = 445548537 ^ var87;
               return;
            }

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var87)) {
                  case 242116360:
                     var87 ^= 1623213811;
                  case 583601482:
                     byte var55 = (byte)(172697358 ^ var87);
                     if (var11 == var55) {
                        var87 = 1296511933 ^ var87;
                        int var20 = this.page;
                        if (var20 > (1191974046 ^ var87)) {
                           var87 = 54263888 ^ var87;
                           int var56 = this.page;
                           byte var73 = (byte)(1144001743 ^ var87);
                           int var57 = var56 - var73;
                           this.page = var57;
                           var87 = 2006789797 ^ var87;
                           this.updateTitle();
                           var87 = 1692402093 ^ var87;
                           this.decorate();
                           var87 = 1132216001 ^ var87;
                           return;
                        }

                        var87 = 939186290 ^ var87;
                     } else {
                        var87 = tohvqcjkpmjgcblo(var87, 2059267023);
                     }

                     byte var58 = (byte)(1895222465 ^ var87);
                     if (var11 == var58) {
                        var87 = 1384101597 ^ var87;
                        byte var25 = o0KoOo0KoOK.always();
                        if (var25 != (579435057 ^ var87)) {
                           var87 = 1020000410 ^ var87;
                           Player var27 = this.player;
                           o0KoOo0KoOK.edge(var27);
                           var87 = 440072575 ^ var87;
                           return;
                        }

                        var87 = 1699288583 ^ var87;
                     } else {
                        var87 = tohvqcjkpmjgcblo(var87, 926327002);
                     }

                     byte var59 = (byte)(1203792902 ^ var87);
                     if (var11 == var59) {
                        var87 = 1652976563 ^ var87;
                        Player var51 = this.player;
                        String var72 = kfixqwhemr(vayzdegfybtwkae(), xlvmmareofevlcb(), var87);
                        Sound var80 = Sound.BLOCK_CHERRY_WOOD_BUTTON_CLICK_ON;
                        float var82 = 1.0F;
                        float var84 = 1.0F;
                        KKo0KoOoOK.play(var51, var72, var80, var82, var84);
                        var87 = 1413440744 ^ var87;
                        return;
                     }

                     label100:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var87)) {
                           case 184850024:
                              var87 ^= 894147055;
                              break label100;
                           case 344826153:
                              break;
                           case 813314286:
                              break label100;
                           case 1482563876:
                           default:
                              throw new IOException();
                        }
                     }

                     byte var60 = (byte)(1921775083 ^ var87);
                     if (var11 == var60) {
                        var87 = 177268788 ^ var87;
                        Player var46 = this.player;
                        String var71 = kfixqwhemr(zshcbvkmwaknief(), xlvmmareofevlcb(), var87);
                        Sound var79 = Sound.BLOCK_CHERRY_WOOD_BUTTON_CLICK_ON;
                        float var81 = 1.0F;
                        float var83 = 1.0F;
                        KKo0KoOoOK.play(var46, var71, var79, var81, var83);
                        var87 = 133496143 ^ var87;
                        Player var48 = this.player;
                        var48.closeInventory();
                        var87 = 1126756866 ^ var87;
                        this.openSearchSignGUI();
                        var87 = 1310051709 ^ var87;
                        return;
                     }

                     var87 = tohvqcjkpmjgcblo(var87, 587773596);
                     byte var61 = (byte)(1367556976 ^ var87);
                     if (var11 == var61) {
                        var87 = 140029595 ^ var87;
                        Player var32 = this.player;
                        UUID var33 = var32.getUniqueId();
                        List var34 = TransactionHistory.getHistory(var33);
                        var87 = 558744577 ^ var87;
                        byte var35 = (byte)(2023107038 ^ var87);
                        int var63 = var34.size();
                        byte var74 = (byte)(2023107058 ^ var87);
                        int var64 = var63 + var74;
                        byte var75 = (byte)(2023107038 ^ var87);
                        int var65 = var64 - var75;
                        byte var76 = (byte)(2023107058 ^ var87);
                        int var66 = var65 / var76;
                        int var36 = Math.max(var35, var66);
                        var87 = 1547936395 ^ var87;
                        int var38 = this.page;
                        byte var77 = (byte)(617974613 ^ var87);
                        int var68 = var36 - var77;
                        if (var38 >= var68) {
                           var87 = 1390696131 ^ var87;
                           byte var42 = o0KoOo0KoOK.always();
                           if (var42 != (1982979479 ^ var87)) {
                              var87 = 1806492175 ^ var87;
                              Player var44 = this.player;
                              o0KoOo0KoOK.edge(var44);
                              var87 = 237539363 ^ var87;
                           } else {
                              var87 = 1703178796 ^ var87;
                           }

                           return;
                        }

                        var87 = 1995186499 ^ var87;
                        int var69 = this.page;
                        byte var78 = (byte)(1379510806 ^ var87);
                        int var70 = var69 + var78;
                        this.page = var70;
                        var87 = 538132307 ^ var87;
                        this.updateTitle();
                        var87 = 925299649 ^ var87;
                        this.decorate();

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var87)) {
                              case 97010605:
                                 var87 = 1455016254 ^ var87;
                                 return;
                              case 547143525:
                              default:
                                 throw new IOException();
                              case 663008990:
                                 break;
                              case 1065003564:
                                 return;
                           }
                        }
                     }

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var87)) {
                           case 233702358:
                              var87 = 1110895870 ^ var87;
                              return;
                           case 598040460:
                              return;
                           case 1466715268:
                              break;
                           case 2068512200:
                           default:
                              throw new IOException();
                        }
                     }
                  case 387687632:
                     break;
                  case 1359295967:
                  default:
                     throw new IOException();
               }
            }
         }

         var87 = 672255341 ^ var87;
      } else {
         var87 = 1834601094 ^ var87;
      }

   }

   private void updateTitle() {
      int var20 = 118282955 ^ 18784774 ^ 1585545255;
      var20 = 1203673619 ^ var20;

      try {
         Player var7 = this.player;
         InventoryView var8 = var7.getOpenInventory();
         var20 = 1409254392 ^ var20;
         o0o0oOKo0K var2 = cfg();
         String var3 = kfixqwhemr(bmebiivpaclkxdz(), xlvmmareofevlcb(), var20);
         String var4 = kfixqwhemr(heudgkmubrxzech(), xlvmmareofevlcb(), var20);
         String var10 = var2.rawStr(var3, var4);
         String var13 = kfixqwhemr(lvkttdmucfobmcn(), xlvmmareofevlcb(), var20);
         int var15 = this.page;
         byte var5 = (byte)(1288888576 ^ var20);
         int var16 = var15 + var5;
         String var17 = String.valueOf(var16);
         String var11 = var10.replace(var13, var17);
         String var12 = oOo0KKoOoOK.color(var11);
         var20 = 1406794577 ^ var20;
         var8.setTitle(var12);
         var20 = 296783495 ^ var20;
      } catch (Throwable var21) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var20)) {
            case -128396672 -> var20 = tohvqcjkpmjgcblo(var20, 76828809);
            case -110422072 -> var20 = tohvqcjkpmjgcblo(var20, 78784544);
            case 1721174026 -> var20 = 1464708056 ^ var20;
            default -> throw new IOException("Error in hash");
         }

         var20 = 1687968858 ^ var20;
         return;
      }

      var20 = tohvqcjkpmjgcblo(var20, 1907917396);
   }

   private void openSearchSignGUI() {
      int var43 = 1510079300 ^ 2136242849 ^ 1585545255;
      var43 = 2062044542 ^ var43;
      Player var8 = this.player;
      KoOKKo0K.detach(var8);
      var43 = 852576726 ^ var43;

      try {
         SignGUIBuilder var9 = SignGUI.builder();
         byte var2 = (byte)(871171438 ^ var43);
         String[] var19 = new String[var2];
         byte var3 = (byte)(871171434 ^ var43);
         String var4 = kfixqwhemr(xxelklzzwbhsswi(), xlvmmareofevlcb(), var43);
         var19[var3] = var4;
         byte var30 = (byte)(871171435 ^ var43);
         var43 = 358697964 ^ var43;
         o0o0oOKo0K var34 = cfg();
         String var5 = kfixqwhemr(nuxlmbfkxkwrwdg(), xlvmmareofevlcb(), var43);
         String var6 = kfixqwhemr(goicjgsauwdpprz(), xlvmmareofevlcb(), var43);
         String var35 = var34.rawStr(var5, var6);
         var19[var30] = var35;
         byte var31 = (byte)(646729348 ^ var43);
         o0o0oOKo0K var36 = cfg();
         String var39 = kfixqwhemr(dtlbryaighvxlqp(), xlvmmareofevlcb(), var43);
         String var40 = kfixqwhemr(iewytuyvwzghyiv(), xlvmmareofevlcb(), var43);
         String var37 = var36.rawStr(var39, var40);
         var19[var31] = var37;
         byte var32 = (byte)(646729349 ^ var43);
         String var38 = kfixqwhemr(pbdvhalonmqbnpp(), xlvmmareofevlcb(), var43);
         var19[var32] = var38;
         SignGUIBuilder var10 = var9.setLines(var19);
         Material var20 = Material.OAK_SIGN;
         var43 = 1538031481 ^ var43;
         SignGUIBuilder var11 = var10.setType(var20);
         SignGUIFinishHandler var22 = (var1, var2x) -> {
            int var26 = 2147383821 ^ 1206176970 ^ 1585545255;
            var26 = 111853342 ^ var26;
            byte var4 = (byte)(1613859326 ^ var26);
            String var9 = var2x.getLineWithoutColor(var4);
            String var10 = var9.trim();
            var26 = 691113532 ^ var26;
            byte var17 = var10.isEmpty();
            String var22;
            if (var17 != (1224738754 ^ var26)) {
               var26 = 1997691839 ^ var26;
               var22 = kfixqwhemr(gosvzaleoxspchd(), xlvmmareofevlcb(), var26);
               var26 = tohvqcjkpmjgcblo(var26, 2114427482);
            } else {
               var26 = 1134679582 ^ var26;
               var22 = var10.toLowerCase();
               var26 = 1253316603 ^ var26;
            }

            this.searchQuery = var22;
            var26 = 815593883 ^ var26;
            byte var19 = (byte)(1888042940 ^ var26);
            this.page = var19;
            var26 = 1226259417 ^ var26;
            KKoOoOo0oOK var13 = KKoOoOo0oOK.getInstance();
            Player var21 = this.player;
            Runnable var23 = () -> {
               int var5 = 1560987536 ^ 257582854 ^ 1585545255;
               var5 = 2124753028 ^ var5;
               byte var2 = (byte)(1920206901 ^ var5);
               this.open(var2);
            };
            long var6 = 1L;
            var26 = 155969847 ^ var26;
            var13.runAtEntityLater(var21, var23, var6);
            var26 = 1209758582 ^ var26;
            List var15 = Collections.emptyList();
            return var15;
         };
         var43 = 1804475106 ^ var43;
         SignGUIBuilder var12 = var11.setHandler(var22);
         var43 = 1968805543 ^ var43;
         DonutSMPCore var23 = DonutSMPCore.getInstance();
         SignGUIBuilder var13 = var12.callHandlerSynchronously(var23);
         var43 = 818364233 ^ var43;
         SignGUI var14 = var13.build();
         Player var25 = this.player;
         var43 = 1732368339 ^ var43;
         var14.open(var25);
         var43 = 805406628 ^ var43;
      } catch (Exception var44) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var43)) {
            case -1719396454 -> var43 = 67001394 ^ var43;
            case -1620563119 -> var43 = tohvqcjkpmjgcblo(var43, 1663294379);
            case -1551193855 -> var43 = 1690274785 ^ var43;
            case -1250862872 -> var43 = 1180759516 ^ var43;
            case -385773573 -> var43 = 770633534 ^ var43;
            case 532540883 -> var43 = 859399035 ^ var43;
            case 878867505 -> var43 = tohvqcjkpmjgcblo(var43, 1984073799);
            default -> throw new IOException("Error in hash");
         }

         var43 = 1842884618 ^ var43;
         var44.printStackTrace();
         var43 = 624189151 ^ var43;
         Player var18 = this.player;
         o0o0oOKo0K var26 = cfg();
         String var29 = kfixqwhemr(mfrfjbxofzdiadp(), xlvmmareofevlcb(), var43);
         String var33 = kfixqwhemr(quzozxjdbqhblji(), xlvmmareofevlcb(), var43);
         String var27 = var26.rawStr(var29, var33);
         String var28 = oOo0KKoOoOK.color(var27);
         var18.sendMessage(var28);
         var43 = 696869124 ^ var43;
         return;
      }

      var43 = 903545748 ^ var43;
   }

   public Inventory createInventory() {
      int var4 = 126988359 ^ 308708192 ^ 1585545255;
      var4 = 1055076623 ^ var4;
      Object var1 = null;
      return (Inventory)var1;
   }

   private String formatMaterialName(String var1) {
      int var24 = 1285405396 ^ 453063372 ^ 1585545255;
      var24 = 1220452858 ^ var24;
      String var6 = o0oOoOo0oOK.material(var1);
      var24 = 439386334 ^ var24;
      if (var6 != null) {
         var24 = 2095587036 ^ var24;
         return var6;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var24)) {
               case 23938103:
                  var24 ^= 742669664;
               case 1302036536:
                  String var3 = kfixqwhemr(axazaiegjhgshgx(), xlvmmareofevlcb(), var24);
                  String var4 = kfixqwhemr(xtuakmkofxuhger(), xlvmmareofevlcb(), var24);
                  String var10 = var1.replace(var3, var4);
                  String var11 = var10.toLowerCase();
                  String var18 = kfixqwhemr(xbjgdozfcejinpu(), xlvmmareofevlcb(), var24);
                  String[] var12 = var11.split(var18);
                  Stream var13 = Arrays.stream(var12);
                  Function var19 = (var0) -> {
                     int var13 = 401379257 ^ 2052993345 ^ 552149470;
                     var13 = 1461970172 ^ var13;
                     byte var4 = var0.isEmpty();
                     String var8;
                     if (var4 != (444103642 ^ var13)) {
                        var13 = 46352417 ^ var13;
                        var8 = kfixqwhemr(fqdmbaqjnrwerwx(), xlvmmareofevlcb(), var13);
                        var13 = tohvqcjkpmjgcblo(var13, 489676803);
                        return var8;
                     } else {
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var13)) {
                              case 55145870:
                                 var13 ^= 1708691019;
                              case 1705053709:
                                 byte var2 = (byte)(2141255057 ^ var13);
                                 char var6 = var0.charAt(var2);
                                 char var7 = Character.toUpperCase(var6);
                                 byte var3 = (byte)(2141255056 ^ var13);
                                 String var10 = var0.substring(var3);
                                 var8 = var7 + var10;
                                 var13 = 2050238057 ^ var13;
                                 return var8;
                              case 321076937:
                              default:
                                 throw new IllegalAccessException();
                              case 592183361:
                           }
                        }
                     }
                  };
                  Stream var14 = var13.map(var19);
                  BinaryOperator var20 = (var0, var1x) -> {
                     int var7 = 1460356466 ^ 1175490339 ^ 552149470;
                     var7 = 778630046 ^ var7;
                     String var4 = var0 + " " + var1x;
                     return var4;
                  };
                  Optional var15 = var14.reduce(var20);
                  Object var16 = var15.orElse(var1);
                  String var17 = (String)var16;
                  return var17;
               case 289358088:
               default:
                  throw new IOException();
               case 1140845853:
            }
         }
      }
   }

   private String formatTimeAgo(long var1) {
   }

   public static String kfixqwhemr(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] xlvmmareofevlcb() {
      return new byte[]{6, 22, 71, 30, 29, 23, 47, 12, 93, 44, 118, 113, 20, 39, 102, 64, 110, 37, 54, 48, 8, 34, 104, 123, 48, 36, 81, 66, 17, 18, 26, 42, 32, 118, 23, 109, 16, 7, 41, 127, 107, 68, 19, 67, 54, 123};
   }

   private static byte[] nwxwvscjhqnellk() {
      return new byte[]{-54, -37, 114, 79, 45, 83, 29, 80, 107, 109, 68, 107, 34, 118, 87, 7, 91, 112, 4, 118, 61, 125, 88, 37, 2, 127, 103, 95, 35, 83, 44, 104, 17, 37, 34, 53, 34, 70, 28, 40, 91, 22, 33, 2, 0, 32, 52, 76, 113, 64, 44, 86, 26, 93, 111, 107, 67, 46};
   }

   private static byte[] fqdmbaqjnrwerwx() {
      return new byte[0];
   }

   private static byte[] gosvzaleoxspchd() {
      return new byte[0];
   }

   private static byte[] yjwwpaojnrhmeke() {
      return new byte[]{-55, -38, 115, 82, 46, 73, 31, 76, 108, 120, 71, 39};
   }

   private static byte[] tvxaiyhxkxogfmb() {
      return new byte[]{-55, -38, 110, 61, 44, -96, 2, 56, 110, 96, -32, 115, 61, 31, 72, 115, 67, 10, 5, 98, 36, 30, 94, 55, -92, 34, 97, 86, 32, 2, 43, 73, 20, 47, 36, 61, 32, 86, 24, 103, 90, 82, 39, 11, 5, 45, 54, 69, 118, 67, 44, 1};
   }

   private static byte[] lyjomrqiyopfvgw() {
      return new byte[]{-55, -38, 115, 3, 46, 80, 31, 89, 108, 115, 71, 39, 32, 58};
   }

   private static byte[] tbzadqigyrkejdr() {
      return new byte[]{-52, -34, 113, 90, 41, 79, 30, 70, 105, 125};
   }

   private static byte[] zglyndslbnypzft() {
      return new byte[]{-52, -34, 113, 93, 41, 79, 30, 72, 105, 116, 65, 34};
   }

   private static byte[] ssltegorklkpiwo() {
      return new byte[]{-52, -34, 108, 50, 43, -90, 3, 60, 107, 108, -26, 118, 62, 19, 74, 117, 67, 10, 0, 109, 35, 26, 94, 62, -90, 37, 101, 86, 38, 12, 45, 78, 17, 38, 39, 62, 36, 85, 31, 104, 95, 80, 34, 3, 2, 46, 49, 71, 112, 79, 44, 3};
   }

   private static byte[] elxnjlzpiovlxuq() {
      return new byte[]{-52, -34, 113, 12, 41, 86, 30, 93, 105, 127, 65, 34, 35, 54};
   }

   private static byte[] surtxdobbrsewhr() {
      return new byte[]{-55, -39, 112, 93, 37, 65, 28, 69, 104, 105, 71, 111, 35, 99, 94, 7, 93, 117, 3, 117, 57, 97};
   }

   private static byte[] uhlxyybrzrnukxf() {
      return new byte[]{-55, -39, 112, 10, 37, 21, 28, 123, 104, 91, 71, 5, 35, 41, 94, 75, -6, 37, 30, 26, 36, 18, 66, 87, -81, 38};
   }

   private static byte[] gmvpklsemhdpyou() {
      return new byte[]{-55, -37, 116, 95, 40, 68, 29, 69, 106, 97, 71, 109, 39, 112, 83, 23, 92, 119, 1, 98};
   }

   private static byte[] lmgrdlutyrkcjer() {
      return new byte[]{-55, -37, 116, 8, 40, 16, 29, 123, 106, 83, 71, 7, 39, 43, 83, 78, 94, -115, 28, 9, 36, 20, 70, 69};
   }

   private static byte[] ahkmtfptegasdwv() {
      return new byte[]{-55, -39, 119, 82, 43, 69, 27, 65, 111, 105, 70, 111, 44, 114, 81, 24, 91, 126, 7, 99, 56, 113, 94, 97, 4, 101, 99, 28, 33, 15, 34, 111, 23, 39, 34, 62, 33, 69, 25, 36, 93, 27};
   }

   private static byte[] joykvqnjjahfvkd() {
      return new byte[]{-55, -39, 119, 0, 43, 70, 27, 122, 111, 113, 70, 40, 44, 114, 81, 31, 91, 55, 7, 116, 56, 117, 94, 108, 4, 98, 99, 22, 33, 67, 34, 110, 23, 33, 34, 55};
   }

   private static byte[] qhojavonvzwyrxx() {
      return new byte[0];
   }

   private static byte[] nlegixixynantwg() {
      return new byte[]{-54, -39, 113, 91, 43, 74, 23, 70, 110, 109, 68, 111, 34, 101, 80, 29, 86, 118, 5, 119, 58, 113, 94, 34};
   }

   private static byte[] agztywnndzolpkd() {
      return new byte[]{-54, -39, 113, 12, 43, 30, 23, 120, 110, 95, 68, 5, 34, 47, 80, 64, -15, 38, 24, 2, 39, 18, 92, -54, 27, 24, 107, -20};
   }

   private static byte[] ldomxhziutixeay() {
      return new byte[]{-55, -38, 113, 122, 47, 64, 28, 83, 111, 117, 71, 45, 34, 97, 84, 23};
   }

   private static byte[] ujhiaqvenzxialz() {
      return new byte[]{-53, -40, 127, 95, 43, 64, 23, 66, 106, 107, 71, 103, 33, 114, 84, 20, 88, 123, 5, 98, 48, 124, 94, 100, 8, 102, 102, 30, 32, 7, 47, 123, 18, 33, 33, 119, 35, 66, 17, 37, 93, 91, 43, 1, 1, 32, 55, 75, 114, 5, 47, 65, 25, 94, 110, 101, 78, 48, 34, 56, 94, 6, 89, 119, 7, 111, 61, 113};
   }

   private static byte[] gxnkpxgncmbmlrj() {
      return new byte[]{-53, -40, 127, 13, 43, 67, 23, 121, 106, 115, 71, 32, 33, 114, 84, 19, 88, 50, 5, 117, 48, 120, 94, 105, 8, 117, 102, 30, 32, 10, 47, 104, 18, 33, 33, 122, 35, 66, 17, 34, 93, 19, 43, 85, 1, 38, 55, 75, 114, 80, 47, 91, 25, 27, 110, 109, 78, 37, 34, 114, 94, 19};
   }

   private static byte[] xzgidmtjtfqivpy() {
      return new byte[]{-55, -48, 126, 83, 47, 66, 27, 69, 104, 105, 79, 102, 45, 97, 86, 6, 95, 113, 7, 103, 49, 104, 90, 42, 4, 118, 100, 7, 40, 66, 35, 119, 16, 44, 38, 43};
   }

   private static byte[] mdogczeydibbxlx() {
      return new byte[]{-55, -48, 126, 4, 47, 22, 27, 123, 104, 91, 79, 12, 45, 44, 86, 76, 66, 11, 5, -119, 44, 27, 88, 63, -93, 36, 121, 115, 53, 47, 62, 3, 18, 40, 59, 87, 35, 74, -73, 119};
   }

   private static byte[] awoeyxylaektlsa() {
      return new byte[]{-49, -39, 119, 82, 44, 75, 27, 64, 104, 111, 70, 111, 44, 117, 95, 24, 90, 121, 1, 99, 56, 113, 89, 111, 4, 100, 100, 26, 33, 15, 34, 105, 25, 39, 35, 62, 39, 69, 25, 34, 90, 14, 39, 31};
   }

   private static byte[] voagjqelvrkuejr() {
      return new byte[]{-49, -39, 119, 0, 44, 72, 27, 123, 104, 119, 70, 40, 44, 117, 95, 31, 90, 48, 1, 116, 56, 117, 89, 98, 4, 98, 100, 16, 33, 68, 34, 105, 25, 39, 35, 43, 39, 95};
   }

   private static byte[] zqihqplzerdmhcq() {
      return new byte[]{-50, -38, 117, 82, 40, 74, 23, 69, 104, 110, 69, 109, 44, 123, 94, 12, 95, 117, 0, 110, 58, 55, 93, 45, 8, 116, 100, 25, 34, 69};
   }

   private static byte[] awrngpvbqjgvmal() {
      return new byte[]{-50, -38, 117, 0, 40, 73, 23, 24, 104, 115, 69, 55, 44, 119, 94, 21, 95, 53};
   }

   private static byte[] vywnodqyidirhsx() {
      return new byte[]{-50, -38, 117, 3, 40, 70, 23, 73, 104, 127, 69, 46, 44, 55};
   }

   private static byte[] gtlrvgpgpzlcfxq() {
      return new byte[]{-55, -34, 117, 90, 42, 70, 24, 67, 108, 111, 68, 111, 35, 122, 81, 3, 95, 119, 4, 109, 63, 59, 95, 34, 1, 114, 99, 31, 38, 67};
   }

   private static byte[] ycbghwztiflaiae() {
      return new byte[]{-55, -34, 117, 8, 42, 69, 24, 30, 108, 114, 68, 53, 35, 118, 81, 26, 95, 55};
   }

   private static byte[] szzenikqnnzidja() {
      return new byte[]{-55, -34, 117, 11, 42, 74, 24, 79, 108, 126, 68, 44, 35, 54};
   }

   private static byte[] vgaremutosupilk() {
      return new byte[]{-55, -35, 127, 92, 44, 75, 27, 69, 108, 96, 71, 107, 44, 98, 87, 22, 90, 120, 7, 108, 57, 59, 80, 33, 1, 116, 101, 29, 32, 79};
   }

   private static byte[] zkfsnueiesmetgy() {
      return new byte[]{-55, -35, 127, 11, 44, 31, 27, 123, 108, 82, 71, 1, 44, 40, 87, 65, 90, 49, 7, 120, 57, 122, 80, 44, 1, 100, 101, 22, 32, 88, 43, 59, 24, 96, 38, 114, 36, 80, 24, 37, 90, 31, 43, 0, 7, 37, 50, 79, 118, 82, 44, 3, 23, 67, 108, 122, 66, 53, 37, 109, 87, 84, 86, 53, 7, 111, 60, 54, 89, 42, 1, 100, 105, 17, 32, 70, 46, 62, 17, 110, 38, 127, 40, 87, 24, 32, 95, 26, 34, 9, 7, 111, 62, 3, 118, 22, 41, 96, 30, 114, 108, 92, 78, 126, 37, 38, 82, 84, 95, 109, 7, 118, 48, 125, 89, 33, 4, 112, 96, 95};
   }

   private static byte[] vlwgpdesctyafkv() {
      return new byte[]{-55, -35, 127, 13, 44, 94, 27, 81, 108, 117, 71, 60, 44, 116, 87, 11, 90, 49};
   }

   private static byte[] noteyxcoqonjgqb() {
      return new byte[]{-55, -35, 127, 13, 44, 71, 27, 73, 108, 113, 71, 40, 44, 52};
   }

   private static byte[] lngeirhmznmliwm() {
      return new byte[]{-55, -35, 127, 13, 44, 94, 27, 79, 108, 125, 71, 38, 44, 116, 87, 92};
   }

   private static byte[] jwfkbzczuyegqlq() {
      return new byte[]{-55, -35, 127, 92, 44, 75, 27, 69, 108, 96, 71, 107, 44, 101, 87, 16, 90, 121, 7, 109, 57, 59, 80, 44, 1, 122, 101, 28};
   }

   private static byte[] memkztlrjmttpxk() {
      return new byte[]{-55, -35, 127, 11, 44, 31, 27, 123, 108, 82, 71, 1, 44, 40, 87, 65, 90, 49, 7, 124, 57, 127, 80, 32, 1, 120, 101, 86};
   }

   private static byte[] yhbimqogbptfggy() {
      return new byte[]{-55, -35, 127, 13, 44, 90, 27, 84, 108, 121, 71, 32, 44, 52};
   }

   private static byte[] koilllbieokxrop() {
      return new byte[]{-55, -39, 116, 90, 41, 70, 27, 67, 104, 107, 71, 111, 39, 117, 82, 27, 90, 103, 3, 100, 57, 122, 91, 63, 4, 61, 101, 25, 36, 72, 43, 116, 19, 35};
   }

   private static byte[] dtcgizbsafvvtau() {
      return new byte[]{-55, -39, 116, 8, 41, 69, 27, 98, 104, 112, 71, 52, 39, 55, 82, 22, 90, 125, 3, 118, 57, 117, 91, 35, 4, 100, 101, 85, 36, 2, 43, 43, 19, 0, 35, 31, 36, 116, 28, 117, 90, 76, 32, 86, 2, 63, 50, 77, 114, 76, 44, 94, 28, 89, 105, 106, 66, 99, 33, 50, 87, 22, 93, 50, 2, 119, 60, 53, 93, 110, 1, 114, 98, 87, 37, 79, 46, 105, 21, 32, 38, 48, 35, 18, 29, 107, 95, 85, 38, 22, 7, 45, 53, 73, 115, 88, 41, 0, 26, 28, 108, 45, 69, 7, 32, 85, 82, 51, 91, 47, 7, 56, 59, 55, 92, 63, 4, 97, 100, 24, 32, 65, 41, 127, 20, 103};
   }

   private static byte[] kexpgfiuywhpgin() {
      return new byte[]{-55, -39, 116, 11, 41, 83, 27, 87, 104, 126, 71, 56, 39, 114, 82, 6, 90, 55};
   }

   private static byte[] jhqsngwfnrflazz() {
      return new byte[]{-55, -39, 116, 11, 41, 74, 27, 79, 104, 122, 71, 44, 39, 50};
   }

   private static byte[] znsbtkuqhqfiryr() {
      return new byte[]{-55, -39, 116, 11, 41, 83, 27, 73, 104, 118, 71, 34, 39, 114, 82, 81};
   }

   private static byte[] wpuvswxwvdyfkkz() {
      return new byte[]{-55, -39, 116, 90, 41, 70, 27, 67, 104, 107, 71, 111, 39, 99, 82, 29, 90, 127, 3, 102, 57, 63, 91, 42, 4, 119, 101, 26};
   }

   private static byte[] axaywkktnyknixi() {
      return new byte[]{-55, -39, 116, 13, 41, 18, 27, 125, 104, 89, 71, 5, 39, 46, 82, 76, 90, 55, 3, 119, 57, 123, 91, 38, 4, 117, 101, 80};
   }

   private static byte[] aprmdnggolxgrup() {
      return new byte[]{-55, -39, 116, 11, 41, 87, 27, 82, 104, 114, 71, 36, 39, 50};
   }

   private static byte[] sjmjwakscxhkufz() {
      return new byte[]{-55, -38, 113, 83, 45, 70, 28, 70, 106, 105, 69, 105, 45, 99, 82, 28, 92, 102, 7, 98, 62, 119, 88, 98, 3, 101, 102, 3, 34, 65, 35, 116, 20, 49};
   }

   private static byte[] lyxbguuwakraqiu() {
      return new byte[]{-55, -38, 113, 1, 45, 69, 28, 106, 106, 114, 69, 51, 45, 118, 82, 31, 92, 50, 7, 80, 62, 107, 88, 42, 3, 120, 102, 7, 34, 30, 35, 58, 20, 102, 37, 107, 33, 114, 31, 0, 91, 52, 32, 72, 1, 114, 53, 5, 126, 79, 41, 73, 29, 84, 108, 106, 64, 38, 36, 103, 85, 87};
   }

   private static byte[] kscpqpvtaztttex() {
      return new byte[]{-55, -38, 113, 2, 45, 66, 28, 83, 106, 114, 69, 50, 45, 121, 82, 7, 92, 55};
   }

   private static byte[] mxhexwtkxbceyye() {
      return new byte[]{-55, -38, 113, 83, 45, 70, 28, 70, 106, 105, 69, 105, 45, 99, 82, 28, 92, 102, 7, 98, 62, 119, 88, 98, 3, 123, 102, 18, 34, 64, 35, 127};
   }

   private static byte[] vhnnyayswsspofg() {
      return new byte[]{-55, -38, 113, 1, 45, 69, 28, 106, 106, 114, 69, 51, 45, 118, 82, 31, 92, 50, 7, 78, 62, 122, 88, 43, 3, 115, 102, 73, 34, 4, 35, 57, 20, 116, 37, 28, 33, 114, 31, 2, 91, 73, 32, 73, 1, 111, 53, 65, 126, 67, 41, 75, 29, 78, 108, 113, 64, 60, 36, 54};
   }

   private static byte[] pywvwxhhqsagmtd() {
      return new byte[]{-55, -38, 113, 2, 45, 66, 28, 83, 106, 114, 69, 50, 45, 121, 82, 7, 92, 55};
   }

   private static byte[] ahrymyzjeqpfoeg() {
      return new byte[]{-55, -38, 115, 83, 45, 74, 28, 69, 106, 96, 71, 108, 32, 125, 86, 20, 93, 125, 1, 107, 57, 122, 92, 111, 0, 104, 98, 28, 38, 7, 43, 126, 20, 32, 39, 120, 35, 66, 30, 40, 90, 90, 39, 14, 6, 43, 53, 66, 112, 11, 44, 84, 27, 71, 109, 113, 69, 54, 35, 118, 87, 28, 90, 105, 6, 123, 59, 62, 95, 51, 1, 118, 101, 28, 33, 79};
   }

   private static byte[] rycbtsmcuyfycdi() {
      return new byte[]{-55, -38, 115, 1, 45, 73, 28, 126, 106, 120, 71, 43, 32, 125, 86, 19, 93, 52, 1, 124, 57, 126, 92, 98, 0, 123, 98, 28, 38, 10, 43, 109, 20, 32, 39, 117, 35, 66, 30, 47, 90, 18, 39, 90, 6, 51, 53, 85, 112, 67, 44, 82, 27, 92, 109, 123, 69, 53, 35, 108, 87, 83, 90, 108, 6, 105, 59, 116, 95, 38};
   }

   private static byte[] kkeusfvybollvgs() {
      return new byte[]{-52, -40, 127, 94, 42, 69, 23, 69, 108, 108, 71, 103, 32, 126, 81, 29, 95, 108, 2, 117};
   }

   private static byte[] tqaxurcjqlupfcm() {
      return new byte[]{-52, -40, 127, 9, 42, 17, 23, 123, 108, 94, 71, 13, 32, 41, 81, 64, 93, 96, 31, 6, 48, 110, 66, 87};
   }

   private static byte[] zshcbvkmwaknief() {
      return new byte[]{-54, -39, 118, 74, 45, 86, 28, 95, 104, 107, 68, 40, 37, 125, 86, 26, 93, 59, 3, 119, 58, 96, 89, 47, 0, 126, 98, 1, 36, 64, 40, 121, 17, 55, 39, 48, 35, 88, 28, 34, 89, 7, 34, 17, 6, 58, 53, 79, 114, 3, 47, 68, 30, 85, 109, 113, 69, 34, 33, 127, 84, 66};
   }

   private static byte[] dlfflnzxrpzsgmw() {
      return new byte[]{-49, -39, 112, 75, 44, 80, 30, 88, 109, 111, 66, 41, 38, 121, 81, 30, 89, 63, 7, 118, 57, 103, 88, 45, 4, 123, 99, 0, 38, 67, 45, 125, 17, 48, 38, 51, 32, 95, 29, 32, 89, 6, 36, 20, 1, 58, 55, 77, 118, 7, 45, 82, 27, 88, 111, 123, 65, 51, 35, 118, 87, 1, 95, 122};
   }

   private static byte[] vayzdegfybtwkae() {
      return new byte[]{-50, -37, 114, 76, 41, 84, 27, 92, 106, 110, 68, 45, 39, 124, 80, 26, 93, 60, 0, 118, 61, 99, 92, 44, 4, 121, 102, 7, 35, 70, 41, 125, 22, 54, 36, 51, 38, 90, 28, 34, 95, 1, 39, 23, 1, 56, 52, 74, 116, 4, 43, 64, 28, 87, 107, 119, 67, 33, 32, 122};
   }

   private static byte[] bmebiivpaclkxdz() {
      return new byte[]{-55, -37, 127, 82, 37, 70, 23, 77, 106, 119, 71, 38};
   }

   private static byte[] heudgkmubrxzech() {
      return new byte[]{-55, -37, 98, 61, 39, -81, 10, 57, 104, 111, -32, 114, 49, 31, 67, 124, 75, 11, 3, 109, 36, 31, 82, 55, -81, 45, 105, 87, 38, 13, 43, 72, 24, 47, 47, 50, 40, 87, 30, 104, 90, 83, 43, 11, 14, 34, 62, 68, 112, 76, 44, 0};
   }

   private static byte[] lvkttdmucfobmcn() {
      return new byte[]{-55, -37, 127, 3, 37, 95, 23, 88, 106, 124, 71, 38, 44, 58};
   }

   private static byte[] xxelklzzwbhsswi() {
      return new byte[0];
   }

   private static byte[] nuxlmbfkxkwrwdg() {
      return new byte[]{-50, -35, 113, 93, 47, 75, 28, 65, 109, 110, 66, 105, 35, 102, 95, 22, 91, 116, 0, 118, 62, 118, 90, 42, 3, 60, 97, 7, 37, 77, 45, 127, 25, 43, 34, 112, 38, 82, 31, 58, 89, 15, 32, 25, 6, 58, 50, 83};
   }

   private static byte[] goicjgsauwdpprz() {
      return new byte[]{-50, -35, 80, -72, 14, -65, 61, -88, 76, -117, 99, -42, 2, -124, 126, -30, 122, -124, 33, -107, 31, -124, 123, -45, 34, -128};
   }

   private static byte[] dtlbryaighvxlqp() {
      return new byte[]{-50, -35, 113, 93, 47, 75, 28, 65, 109, 110, 66, 105, 35, 102, 95, 22, 91, 116, 0, 118, 62, 118, 90, 42, 3, 60, 97, 7, 37, 77, 45, 127, 25, 43, 34, 112, 38, 95, 31, 41, 89, 31, 32, 19, 6, 33};
   }

   private static byte[] iewytuyvwzghyiv() {
      return new byte[]{-50, -35, 113, 122, 47, 75, 28, 88, 109, 104, 66, 36, 35, 125};
   }

   private static byte[] pbdvhalonmqbnpp() {
      return new byte[0];
   }

   private static byte[] mfrfjbxofzdiadp() {
      return new byte[]{-52, -39, 115, 83, 47, 68, 27, 76, 105, 108, 70, 107, 45, 102, 80, 17, 86, 112, 2, 114, 60, 120, 90, 37, 4, 49, 101, 16, 33, 71, 35, 113, 22, 46, 47, 60, 36, 83, 29, 107, 89, 6, 39, 9, 2, 54, 54, 15, 126, 77, 43, 68, 23, 89, 105, 117, 66, 38, 38, 60, 82, 20, 90, 112, 6, 112, 49, 117, 94, 61};
   }

   private static byte[] quzozxjdbqhblji() {
      return new byte[]{-52, -39, 115, 1, 47, 66, 27, 103, 105, 125, 70, 36, 45, 103, 80, 23, 86, 121, 2, 32, 60, 125, 90, 44, 4, 117, 101, 26, 33, 67, 35, 124, 22, 108, 47, 121, 36, 99, 29, 52, 89, 11, 39, 91, 2, 46, 54, 69, 126, 77, 43, 74, 23, 86, 105, 60, 66, 36, 38, 112, 82, 12, 90, 116, 6, 118, 49, 62};
   }

   private static byte[] axazaiegjhgshgx() {
      return new byte[]{-54, -39, 118, 113};
   }

   private static byte[] xtuakmkofxuhger() {
      return new byte[]{-54, -39, 118, 14};
   }

   private static byte[] xbjgdozfcejinpu() {
      return new byte[]{-54, -39, 118, 14};
   }

   private static byte[] qjqmhnxbdkgxzih() {
      return new byte[0];
   }

   private static byte[] juxkqqlvcmyewak() {
      return new byte[]{-55, -36, 117, 90};
   }

   private static byte[] otywwbaonkbjojr() {
      return new byte[0];
   }

   private static byte[] cmdmirjtutrzhrh() {
      return new byte[0];
   }

   private static byte[] hhbjjfsorfwkjnx() {
      return new byte[]{-54, -38, 117, 91};
   }

   private static int tohvqcjkpmjgcblo(int var0, int var1) {
      return var0 ^ var1;
   }

   static {
   }
}
