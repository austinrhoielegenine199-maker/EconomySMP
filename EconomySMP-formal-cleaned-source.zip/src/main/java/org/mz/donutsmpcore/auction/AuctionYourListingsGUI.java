package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemFactory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.KKoOoOo0oOK;
import skido.KoOo0oOo0oOK;
import skido.o0o0oOKo0K;
import skido.o0oOoOo0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;
import skido.oOoOo0oOK;

public class AuctionYourListingsGUI implements KKoOK {
   private final Player player;
   private final AuctionGUI returnGui;
   private Inventory inventory;
   private final Map<Integer, AuctionListingRecord> expiredSlotMap;
   private final Map<Integer, AuctionItem> activeSlotMap;
   private int sellButtonSlot;

   private static o0o0oOKo0K cfg() {
      int var4 = 1000980545 ^ 1184407161 ^ 80073499;
      var4 = 682610510 ^ var4;
      String var0 = qicikzelvv(gzysrrtgptupxar(), oayxxlrvxarpesv(), var4);
      o0o0oOKo0K var1 = o0o0oOKo0K.of(var0);
      return var1;
   }

   public static String TITLE_PREFIX() {
      int var6 = 1065107366 ^ 639112143 ^ 80073499;
      var6 = 1210751978 ^ var6;
      o0o0oOKo0K var0 = cfg();
      String var1 = qicikzelvv(cbzndwzrzgbpvmy(), oayxxlrvxarpesv(), var6);
      String var2 = qicikzelvv(bqlsvguscjfvtfq(), oayxxlrvxarpesv(), var6);
      String var3 = var0.rawStr(var1, var2);
      return var3;
   }

   public AuctionYourListingsGUI(Player var1, AuctionGUI var2) {
      HashMap var4 = new HashMap();
      this.expiredSlotMap = var4;
      HashMap var10 = new HashMap();
      this.activeSlotMap = var10;
      byte var11 = -1;
      this.sellButtonSlot = var11;
      this.player = var1;
      this.returnGui = var2;
   }

   public void open() {
      int var62 = 1020540388 ^ 715272867 ^ 1937058277;
      var62 = 1625137134 ^ var62;
      Ko0KoOKoOK var1 = Ko0KoOKoOK.getInstance();
      Player var24 = this.player;
      UUID var25 = var24.getUniqueId();
      int var10 = var1.getPlayerListingCount(var25);
      var62 = 1145050910 ^ var62;
      Ko0KoOKoOK var11 = Ko0KoOKoOK.getInstance();
      Player var27 = this.player;
      int var12 = var11.getPlayerListingLimit(var27);
      var62 = 896950686 ^ var62;
      int var28 = 186071091 ^ var62;
      String var23;
      if (var12 == var28) {
         var62 = 1342340723 ^ var62;
         var23 = qicikzelvv(dtsaxetpapgioyq(), oayxxlrvxarpesv(), var62);
         var62 = yuklzeqklkbasblj(var62, 344641840);
      } else {
         var62 = yuklzeqklkbasblj(var62, 937227043);
         var23 = String.valueOf(var12);
         var62 = 1934908512 ^ var62;
      }

      var62 = 1707925107 ^ var62;
      Object var29 = null;
      InventoryHolder var30 = (InventoryHolder)var29;
      o0o0oOKo0K var3 = cfg();
      String var4 = qicikzelvv(hueohdjqynqrgom(), oayxxlrvxarpesv(), var62);
      byte var5 = (byte)(1437382375 ^ var62);
      int var41 = var3.intAt(var4, var5);
      o0o0oOKo0K var45 = cfg();
      String var51 = qicikzelvv(mlvqfbxhxetctaj(), oayxxlrvxarpesv(), var62);
      String var6 = qicikzelvv(rmsylkilsviwona(), oayxxlrvxarpesv(), var62);
      String var46 = var45.rawStr(var51, var6);
      String var52 = qicikzelvv(kmdnvthbfvmhojk(), oayxxlrvxarpesv(), var62);
      String var55 = TITLE_PREFIX();
      String var47 = var46.replace(var52, var55);
      String var53 = qicikzelvv(kmiqenqryknugjf(), oayxxlrvxarpesv(), var62);
      String var57 = String.valueOf(var10);
      String var48 = var47.replace(var53, var57);
      String var54 = qicikzelvv(hlmkrgszrlzoajz(), oayxxlrvxarpesv(), var62);
      String var59 = String.valueOf(var23);
      String var49 = var48.replace(var54, var59);
      String var50 = oOo0KKoOoOK.color(var49);
      Inventory var31 = Bukkit.createInventory(var30, var41, var50);
      this.inventory = var31;
      var62 = 2059690546 ^ var62;
      oOoOKo0o0K var15 = oOoOKo0o0K.getInstance();
      Inventory var33 = this.inventory;
      var15.register(var33, this);
      var62 = 1125825317 ^ var62;
      Ko0KoOKoOK var16 = Ko0KoOKoOK.getInstance();
      Player var35 = this.player;
      UUID var36 = var35.getUniqueId();
      var16.addYourItemsViewer(var36);
      var62 = 126058698 ^ var62;
      oOoOKo0o0K var17 = oOoOKo0o0K.getInstance();
      Inventory var38 = this.inventory;
      Runnable var44 = () -> {
         int var7 = 99722428 ^ 378785628 ^ 1937058277;
         var7 = 1350914617 ^ var7;
         Ko0KoOKoOK var1 = Ko0KoOKoOK.getInstance();
         Player var3 = this.player;
         UUID var4 = var3.getUniqueId();
         var1.removeYourItemsViewer(var4);
         var7 = 2088453249 ^ var7;
      };
      var17.setCloseAction(var38, var44);
      var62 = 508463701 ^ var62;
      this.decorate();
      var62 = 1088894122 ^ var62;
      Player var20 = this.player;
      Inventory var40 = this.inventory;
      var20.openInventory(var40);
      var62 = 77694446 ^ var62;
   }

   public void updateDisplayItems() {
      int var24 = 2000177139 ^ 696040508 ^ 1937058277;
      var24 = 1970842858 ^ var24;
      Player var5 = this.player;
      byte var6 = var5.isOnline();
      if (var6 == (1481211584 ^ var24)) {
         var24 = 1856547310 ^ var24;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var24)) {
               case 185482717:
                  var24 ^= 78674856;
               case 122158103:
                  Player var8 = this.player;
                  InventoryView var9 = var8.getOpenInventory();
                  var24 = 1628844933 ^ var24;
                  String var11 = var9.getTitle();
                  if (var11 != null) {
                     var24 = 1429416331 ^ var24;
                     String var13 = var9.getTitle();
                     String var2 = TITLE_PREFIX();
                     byte var14 = var13.contains(var2);
                     if (var14 != (1759256422 ^ var24)) {
                        var24 = yuklzeqklkbasblj(var24, 1861555932);
                        Inventory var18 = var9.getTopInventory();
                        this.inventory = var18;
                        var24 = 2007934908 ^ var24;
                        KKoOoOo0oOK var16 = KKoOoOo0oOK.getInstance();
                        Player var20 = this.player;
                        Runnable var21 = this::decorate;
                        var16.runAtEntity(var20, var21);
                        var24 = 2134006335 ^ var24;
                        return;
                     }

                     var24 = 340124670 ^ var24;
                  } else {
                     var24 = yuklzeqklkbasblj(var24, 1098304117);
                  }

                  return;
               case 1239354248:
               default:
                  throw new IOException();
               case 1512808625:
            }
         }
      }
   }

   public void decorate() {
      int var338 = 290319391 ^ 1408858959 ^ 1937058277;
      var338 = 1763257982 ^ var338;
      Inventory var25 = this.inventory;
      var25.clear();
      var338 = 1748613772 ^ var338;
      Map var27 = this.expiredSlotMap;
      var27.clear();
      var338 = 1458076419 ^ var338;
      Map var29 = this.activeSlotMap;
      var29.clear();
      var338 = 1460042629 ^ var338;
      Ko0KoOKoOK var30 = Ko0KoOKoOK.getInstance();
      Player var136 = this.player;
      UUID var137 = var136.getUniqueId();
      List var31 = var30.getExpiredItems(var137);
      List var9 = var31;
      var338 = 2038128346 ^ var338;
      Ko0KoOKoOK var32 = Ko0KoOKoOK.getInstance();
      List var33 = var32.getActiveItems();
      Stream var34 = var33.stream();
      Predicate var139 = (var1) -> {
         int var10 = 1305300633 ^ 456322138 ^ 1937058277;
         var10 = 792681918 ^ var10;
         UUID var4 = var1.getSeller();
         Player var6 = this.player;
         UUID var7 = var6.getUniqueId();
         boolean var5 = var4.equals(var7);
         return var5;
      };
      Stream var35 = var34.filter(var139);
      List var36 = var35.toList();
      List var10 = var36;
      var338 = 1797488606 ^ var338;
      int var38 = var31.size();
      int var141 = var36.size();
      int var39 = var38 + var141;
      var338 = 335460724 ^ var338;
      if (var39 == (816427697 ^ var338)) {
         var338 = 1124994032 ^ var338;
         byte var142 = (byte)(1940371777 ^ var338);
         this.sellButtonSlot = var142;
         var338 = yuklzeqklkbasblj(var338, 1100192248);
      } else {
         var338 = yuklzeqklkbasblj(var338, 1032322227);
         byte var234 = (byte)(221138459 ^ var338);
         int var217 = Math.min(var39, var234);
         this.sellButtonSlot = var217;
         var338 = 1058696891 ^ var338;
      }

      Ko0KoOKoOK var42 = Ko0KoOKoOK.getInstance();
      Player var144 = this.player;
      int var43 = var42.getPlayerListingLimit(var144);
      var338 = 493343637 ^ var338;
      int var145 = 1353452755 ^ var338;
      String var132;
      if (var43 == var145) {
         var338 = 749375365 ^ var338;
         var132 = qicikzelvv(tcvowadmwjicdpu(), oayxxlrvxarpesv(), var338);
         var338 = 1048559810 ^ var338;
      } else {
         var338 = 1554953014 ^ var338;
         var132 = String.valueOf(var43);
         var338 = 1316748401 ^ var338;
      }

      var338 = 1638761846 ^ var338;
      Ko0KoOKoOK var46 = Ko0KoOKoOK.getInstance();
      Player var147 = this.player;
      byte var47 = var46.canPlayerList(var147);
      var338 = 1317788013 ^ var338;
      ItemStack var48 = new ItemStack;
      Material var235;
      if (var47 != (312533104 ^ var338)) {
         var338 = 1239836762 ^ var338;
         var235 = Material.PAPER;

         label175:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var338)) {
               case 14220439:
                  var338 ^= 1196197634;
               case 495481172:
                  break label175;
               case 675969870:
                  break;
               case 1369879149:
               default:
                  throw new IOException();
            }
         }
      } else {
         var338 = yuklzeqklkbasblj(var338, 819195427);
         var235 = Material.BARRIER;
         var338 = 1048117627 ^ var338;
      }

      var48.<init>(var235);
      var338 = 39856182 ^ var338;
      ItemMeta var50 = var48.getItemMeta();
      var338 = 800398946 ^ var338;
      String var218;
      if (var47 != (836712828 ^ var338)) {
         var338 = 729599351 ^ var338;
         o0o0oOKo0K var215 = cfg();
         String var233 = qicikzelvv(wmlbhhjtzlmamjc(), oayxxlrvxarpesv(), var338);
         String var255 = qicikzelvv(ynugspdokruhyud(), oayxxlrvxarpesv(), var338);
         var218 = var215.rawStr(var233, var255);
         var338 = yuklzeqklkbasblj(var338, 65297774);
      } else {
         var338 = yuklzeqklkbasblj(var338, 420569202);
         o0o0oOKo0K var149 = cfg();
         String var219 = qicikzelvv(qehximicnxlyutc(), oayxxlrvxarpesv(), var338);
         String var4 = qicikzelvv(nlmadxbblhdjgks(), oayxxlrvxarpesv(), var338);
         var218 = var149.rawStr(var219, var4);
         var338 = 831123563 ^ var338;
      }

      String var150 = oOo0KKoOoOK.color(var218);
      var50.setDisplayName(var150);
      var338 = 793155163 ^ var338;
      if (var47 != (906051390 ^ var338)) {
         var338 = 1417964766 ^ var338;
         byte var212 = (byte)(1652904933 ^ var338);
         String[] var213 = new String[var212];
         byte var250 = (byte)(1652904928 ^ var338);
         var338 = 692401286 ^ var338;
         o0o0oOKo0K var282 = cfg();
         String var305 = qicikzelvv(bevhsqiokblyomy(), oayxxlrvxarpesv(), var338);
         String var326 = qicikzelvv(bjgtverczpowzgz(), oayxxlrvxarpesv(), var338);
         String var283 = var282.rawStr(var305, var326);
         String var284 = oOo0KKoOoOK.color(var283);
         var213[var250] = var284;
         byte var251 = (byte)(1270900583 ^ var338);
         String var285 = qicikzelvv(zekbdltixtmmpsn(), oayxxlrvxarpesv(), var338);
         var213[var251] = var285;
         byte var252 = (byte)(1270900580 ^ var338);
         var338 = 972521856 ^ var338;
         o0o0oOKo0K var286 = cfg();
         String var306 = qicikzelvv(jiswpbkurnbsupt(), oayxxlrvxarpesv(), var338);
         String var327 = qicikzelvv(rifkhjdttddzbzx(), oayxxlrvxarpesv(), var338);
         String var287 = var286.rawStr(var306, var327);
         String var288 = oOo0KKoOoOK.color(var287);
         var213[var252] = var288;
         byte var253 = (byte)(1916266213 ^ var338);
         var338 = 691206248 ^ var338;
         o0o0oOKo0K var289 = cfg();
         String var307 = qicikzelvv(gomfzigpukpcesq(), oayxxlrvxarpesv(), var338);
         String var328 = qicikzelvv(szkkxwsbrbatsxc(), oayxxlrvxarpesv(), var338);
         String var290 = var289.rawStr(var307, var328);
         String var291 = oOo0KKoOoOK.color(var290);
         var213[var253] = var291;
         byte var254 = (byte)(1527062154 ^ var338);
         var338 = 2087978305 ^ var338;
         o0o0oOKo0K var292 = cfg();
         String var308 = qicikzelvv(zzbexdpofvdfjob(), oayxxlrvxarpesv(), var338);
         String var329 = qicikzelvv(lsfdvvvkizuwevu(), oayxxlrvxarpesv(), var338);
         String var293 = var292.rawStr(var308, var329);
         String var294 = oOo0KKoOoOK.color(var293);
         var213[var254] = var294;
         var338 = 1943815205 ^ var338;
         List var214 = Arrays.asList(var213);
         var50.setLore(var214);
         var338 = 931939877 ^ var338;
      } else {
         label162:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var338)) {
               case 144858249:
                  var338 ^= 1007164753;
                  break label162;
               case 555563222:
                  break;
               case 800592327:
               default:
                  throw new IOException();
               case 1348685037:
                  break label162;
            }
         }

         byte var151 = (byte)(168370794 ^ var338);
         String[] var152 = new String[var151];
         byte var236 = (byte)(168370799 ^ var338);
         var338 = 1897617864 ^ var338;
         o0o0oOKo0K var5 = cfg();
         String var6 = qicikzelvv(nmpdbxlnncutopg(), oayxxlrvxarpesv(), var338);
         String var7 = qicikzelvv(effloemlrnlkzlg(), oayxxlrvxarpesv(), var338);
         String var256 = var5.rawStr(var6, var7);
         String var257 = oOo0KKoOoOK.color(var256);
         var152[var236] = var257;
         byte var237 = (byte)(2064808870 ^ var338);
         String var258 = qicikzelvv(otqeacycejusdme(), oayxxlrvxarpesv(), var338);
         var152[var237] = var258;
         byte var238 = (byte)(2064808869 ^ var338);
         var338 = 588841252 ^ var338;
         o0o0oOKo0K var259 = cfg();
         String var295 = qicikzelvv(twdhoprdycpywmo(), oayxxlrvxarpesv(), var338);
         String var309 = qicikzelvv(osfbfeieeazzvcz(), oayxxlrvxarpesv(), var338);
         String var260 = var259.rawStr(var295, var309);
         String var296 = qicikzelvv(gurnecwajxtgqll(), oayxxlrvxarpesv(), var338);
         int var311 = var36.size();
         String var312 = String.valueOf(var311);
         String var261 = var260.replace(var296, var312);
         String var297 = qicikzelvv(pwfghpsqqypeqmi(), oayxxlrvxarpesv(), var338);
         String var314 = String.valueOf(var132);
         String var262 = var261.replace(var297, var314);
         String var263 = oOo0KKoOoOK.color(var262);
         var152[var238] = var263;
         byte var239 = (byte)(1477147264 ^ var338);
         String var264 = qicikzelvv(kdkzkraitapwbxc(), oayxxlrvxarpesv(), var338);
         var152[var239] = var264;
         byte var240 = (byte)(1477147271 ^ var338);
         var338 = 909836532 ^ var338;
         o0o0oOKo0K var265 = cfg();
         String var298 = qicikzelvv(vynweijaxzvkduf(), oayxxlrvxarpesv(), var338);
         String var315 = qicikzelvv(trjohyivwuytlid(), oayxxlrvxarpesv(), var338);
         String var266 = var265.rawStr(var298, var315);
         String var267 = oOo0KKoOoOK.color(var266);
         var152[var240] = var267;
         var338 = 429416219 ^ var338;
         List var153 = Arrays.asList(var152);
         var50.setLore(var153);
         var338 = 344538275 ^ var338;
      }

      boolean var55 = var48.setItemMeta(var50);
      var338 = 528791678 ^ var338;
      Inventory var57 = this.inventory;
      int var156 = this.sellButtonSlot;
      var57.setItem(var156, var48);
      var338 = 186042530 ^ var338;
      Material var221 = Material.WRITABLE_BOOK;
      ItemStack var58 = new ItemStack(var221);
      var338 = 1349325108 ^ var338;
      ItemMeta var60 = var58.getItemMeta();
      var338 = 1641371732 ^ var338;
      o0o0oOKo0K var157 = cfg();
      String var222 = qicikzelvv(lebhcblmkymgrga(), oayxxlrvxarpesv(), var338);
      String var241 = qicikzelvv(bvvbejunwgumcve(), oayxxlrvxarpesv(), var338);
      String var158 = var157.rawStr(var222, var241);
      String var159 = oOo0KKoOoOK.color(var158);
      var60.setDisplayName(var159);
      var338 = 1314676866 ^ var338;
      byte var160 = (byte)(139935984 ^ var338);
      String[] var161 = new String[var160];
      byte var242 = (byte)(139935985 ^ var338);
      o0o0oOKo0K var268 = cfg();
      String var299 = qicikzelvv(qybkflleaykllvd(), oayxxlrvxarpesv(), var338);
      String var316 = qicikzelvv(hqroynuighxrvzu(), oayxxlrvxarpesv(), var338);
      String var269 = var268.rawStr(var299, var316);
      String var270 = oOo0KKoOoOK.color(var269);
      var161[var242] = var270;
      List var162 = Arrays.asList(var161);
      var60.setLore(var162);
      var338 = 1288410433 ^ var338;
      var58.setItemMeta(var60);
      var338 = 262348274 ^ var338;
      Inventory var66 = this.inventory;
      byte var164 = (byte)(1262471256 ^ var338);
      var66.setItem(var164, var58);
      var338 = 680119531 ^ var338;
      byte var67 = (byte)(1672873129 ^ var338);
      int var19 = var67;
      var338 = 1924368055 ^ var338;
      byte var68 = (byte)(285573662 ^ var338);
      int var20 = var68;
      var338 = 1434236493 ^ var338;

      label151:
      while(true) {
         int var166 = var9.size();
         if (var20 >= var166) {
            var338 = yuklzeqklkbasblj(var338, 1196107539);
            break;
         }

         var338 = 384281589 ^ var338;
         byte var167 = (byte)(1386127292 ^ var338);
         if (var19 >= var167) {
            var338 = 1370262758 ^ var338;
            break;
         }

         var338 = 1415674354 ^ var338;
         int var169 = this.sellButtonSlot;
         if (var19 == var169) {
            var338 = 2101926265 ^ var338;
            var19 += 2075606828 ^ var338;
            var338 = 1135488221 ^ var338;
         } else {
            label145:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var338)) {
                  case 110092561:
                     var338 ^= 1055323556;
                  case 198533928:
                     break label145;
                  case 806044050:
                  default:
                     throw new IOException();
                  case 1482140851:
               }
            }
         }

         byte var170 = (byte)(941167594 ^ var338);
         if (var19 >= var170) {
            var338 = 95932427 ^ var338;
            var338 = 1050464443 ^ var338;
            break;
         }

         label134:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var338)) {
               case 173456021:
               default:
                  throw new IOException();
               case 212905656:
                  var338 ^= 633519907;
               case 532680894:
                  break label134;
               case 1156628312:
            }
         }

         Object var74 = var9.get(var20);
         AuctionListingRecord var75 = (AuctionListingRecord)var74;
         var338 = 998844249 ^ var338;
         ItemStack var77 = var75.getItemStack();
         var338 = 1699427832 ^ var338;
         byte var79 = var77.hasItemMeta();
         ItemMeta var135;
         if (var79 != (1125760626 ^ var338)) {
            var338 = 1873144483 ^ var338;
            var135 = var77.getItemMeta();
            var338 = yuklzeqklkbasblj(var338, 909274421);
         } else {
            var338 = 757087640 ^ var338;
            ItemFactory var80 = Bukkit.getItemFactory();
            Material var173 = var77.getType();
            var135 = var80.getItemMeta(var173);
            var338 = 1958197774 ^ var338;
         }

         int var392 = 1925069294 ^ var338;
         o0o0oOKo0K var174 = cfg();
         String var224 = qicikzelvv(jvcdjkwhuxtmxuu(), oayxxlrvxarpesv(), var392);
         String var243 = qicikzelvv(zpvjuvnzaqifwzc(), oayxxlrvxarpesv(), var392);
         String var175 = var174.rawStr(var224, var243);
         String var176 = oOo0KKoOoOK.color(var175);
         var135.setDisplayName(var176);
         int var393 = 1876213757 ^ var392;
         ArrayList var82 = new ArrayList();
         int var394 = 1231650450 ^ var393;
         o0o0oOKo0K var177 = cfg();
         String var225 = qicikzelvv(nysmfpxlxoebytf(), oayxxlrvxarpesv(), var394);
         String var244 = qicikzelvv(rpeoxigrcupfool(), oayxxlrvxarpesv(), var394);
         String var178 = var177.rawStr(var225, var244);
         String var179 = oOo0KKoOoOK.color(var178);
         var82.add(var179);
         int var395 = 1986279530 ^ var394;
         String var181 = var75.getTimeUntilDeletion();
         var82.add(var181);
         int var396 = 638749712 ^ var395;
         var135.setLore(var82);
         int var397 = 1658024822 ^ var396;
         var77.setItemMeta(var135);
         int var398 = 1570965150 ^ var397;
         Inventory var91 = this.inventory;
         var91.setItem(var19, var77);
         int var399 = 124961050 ^ var398;
         Map var93 = this.expiredSlotMap;
         Integer var186 = var19;
         var93.put(var186, var75);
         int var400 = 332139507 ^ var399;
         var19 += 892717599 ^ var400;
         var338 = 780901986 ^ var400;
         var20 += 465458301 ^ var338;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var338)) {
               case 96524302:
                  var338 ^= 1606901807;
                  continue label151;
               case 171312632:
                  break;
               case 568657692:
                  continue label151;
               case 759674300:
               default:
                  throw new IOException();
            }
         }
      }

      byte var96 = (byte)(53613376 ^ var338);
      int var330 = var96;
      var338 = 2023464507 ^ var338;

      while(true) {
         int var188 = var10.size();
         if (var330 >= var188) {
            var338 = 1317891298 ^ var338;
            return;
         }

         var338 = 1529241165 ^ var338;
         byte var189 = (byte)(546296620 ^ var338);
         if (var19 >= var189) {
            var338 = yuklzeqklkbasblj(var338, 363541167);
            return;
         }

         var338 = 1771970184 ^ var338;
         int var191 = this.sellButtonSlot;
         if (var19 == var191) {
            var338 = 1735289287 ^ var338;
            var19 += 780117112 ^ var338;
            var338 = 192242982 ^ var338;
         } else {
            label102:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var338)) {
                  case 227686321:
                     var338 ^= 1813712097;
                  case 943998896:
                     break label102;
                  case 2067507230:
                     break;
                  case 2103195369:
                  default:
                     throw new IOException();
               }
            }
         }

         byte var192 = (byte)(621461829 ^ var338);
         if (var19 >= var192) {
            var338 = 1056424974 ^ var338;
            var338 = yuklzeqklkbasblj(var338, 786031816);
            return;
         }

         label91:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var338)) {
               case 93179066:
                  break label91;
               case 130347938:
                  var338 ^= 1688325993;
                  break label91;
               case 282409914:
                  break;
               case 1718358024:
               default:
                  throw new IOException();
            }
         }

         Object var102 = var10.get(var330);
         AuctionItem var103 = (AuctionItem)var102;
         var338 = 651697384 ^ var338;
         ItemStack var105 = var103.getItemStack();
         var338 = 1344409135 ^ var338;
         byte var107 = var105.hasItemMeta();
         ItemMeta var134;
         if (var107 != (928062705 ^ var338)) {
            var338 = 124008359 ^ var338;
            var134 = var105.getItemMeta();
            var338 = 943708096 ^ var338;
         } else {
            var338 = yuklzeqklkbasblj(var338, 1702439193);
            ItemFactory var108 = Bukkit.getItemFactory();
            Material var195 = var105.getType();
            var134 = var108.getItemMeta(var195);
            var338 = 1512229246 ^ var338;
         }

         var338 = 1859547499 ^ var338;
         Material var110 = var105.getType();
         String var111 = var110.name();
         String var196 = qicikzelvv(wcfsebwbzunwigo(), oayxxlrvxarpesv(), var338);
         String var228 = qicikzelvv(hqkoxkkeyaqoftt(), oayxxlrvxarpesv(), var338);
         String var112 = var111.replace(var196, var228);
         String var113 = var112.toLowerCase();
         var338 = 414437967 ^ var338;
         String var197 = qicikzelvv(dzurwakjopugdus(), oayxxlrvxarpesv(), var338);
         String[] var115 = var113.split(var197);
         Stream var116 = Arrays.stream(var115);
         Function var198 = (var0) -> {
            int var13 = 963218437 ^ 279777616 ^ 80073499;
            var13 = 868411697 ^ var13;
            byte var4 = var0.isEmpty();
            String var8;
            if (var4 != (516138879 ^ var13)) {
               var13 = 1902834325 ^ var13;
               var8 = qicikzelvv(flxhywebmuvoktw(), oayxxlrvxarpesv(), var13);
               var13 = 13779136 ^ var13;
            } else {
               var13 = 1391578883 ^ var13;
               byte var2 = (byte)(1278371964 ^ var13);
               char var6 = var0.charAt(var2);
               char var7 = Character.toUpperCase(var6);
               byte var3 = (byte)(1278371965 ^ var13);
               String var10 = var0.substring(var3);
               var8 = var7 + var10;
               var13 = 592018774 ^ var13;
            }

            return var8;
         };
         Stream var117 = var116.map(var198);
         BinaryOperator var199 = (var0, var1) -> {
            int var7 = 1536077743 ^ 9358645 ^ 80073499;
            var7 = 790987775 ^ var7;
            String var4 = var0 + " " + var1;
            return var4;
         };
         Optional var118 = var117.reduce(var199);
         Object var119 = var118.orElse(var113);
         String var120 = (String)var119;
         var338 = 1788081378 ^ var338;
         o0o0oOKo0K var201 = cfg();
         String var229 = qicikzelvv(uyhirayvxqtlewv(), oayxxlrvxarpesv(), var338);
         String var245 = qicikzelvv(adhxuslbpdwfgch(), oayxxlrvxarpesv(), var338);
         String var202 = var201.rawStr(var229, var245);
         String var230 = qicikzelvv(uewithfmvoffwwc(), oayxxlrvxarpesv(), var338);
         String var203 = var202.replace(var230, var120);
         String var204 = oOo0KKoOoOK.color(var203);
         var134.setDisplayName(var204);
         var338 = 307231841 ^ var338;
         byte var205 = (byte)(112416562 ^ var338);
         String[] var206 = new String[var205];
         byte var247 = (byte)(112416561 ^ var338);
         var338 = 1855994475 ^ var338;
         o0o0oOKo0K var271 = cfg();
         String var300 = qicikzelvv(aacdvrlrhhilhen(), oayxxlrvxarpesv(), var338);
         String var317 = qicikzelvv(lqsmsuvyxgdcmbe(), oayxxlrvxarpesv(), var338);
         String var272 = var271.rawStr(var300, var317);
         String var301 = qicikzelvv(ymjubsrzwcmwlrg(), oayxxlrvxarpesv(), var338);
         double var319 = var103.getPrice();
         String var321 = oOo0KKoOoOK.formatPrice(var319);
         String var273 = var272.replace(var301, var321);
         String var274 = oOo0KKoOoOK.color(var273);
         var206[var247] = var274;
         byte var248 = (byte)(1746103643 ^ var338);
         var338 = 1542736419 ^ var338;
         o0o0oOKo0K var275 = cfg();
         String var302 = qicikzelvv(fqilglzkpntwflh(), oayxxlrvxarpesv(), var338);
         String var322 = qicikzelvv(quohsjgpqwequxk(), oayxxlrvxarpesv(), var338);
         String var276 = var275.rawStr(var302, var322);
         String var277 = oOo0KKoOoOK.color(var276);
         var206[var248] = var277;
         byte var249 = (byte)(870786939 ^ var338);
         var338 = 1725254882 ^ var338;
         o0o0oOKo0K var278 = cfg();
         String var303 = qicikzelvv(jiyfsqszpqvofcv(), oayxxlrvxarpesv(), var338);
         String var323 = qicikzelvv(cgaplbrsfdfcwjq(), oayxxlrvxarpesv(), var338);
         String var279 = var278.rawStr(var303, var323);
         String var304 = qicikzelvv(mmcomrmmqkpkxpg(), oayxxlrvxarpesv(), var338);
         String var325 = this.formatTimeLeftHM(var103);
         String var280 = var279.replace(var304, var325);
         String var281 = oOo0KKoOoOK.color(var280);
         var206[var249] = var281;
         var338 = 147222194 ^ var338;
         List var207 = Arrays.asList(var206);
         var134.setLore(var207);
         var338 = 1715837131 ^ var338;
         var105.setItemMeta(var134);
         var338 = 733938528 ^ var338;
         Inventory var126 = this.inventory;
         var126.setItem(var19, var105);
         var338 = 1603308172 ^ var338;
         Map var128 = this.activeSlotMap;
         Integer var211 = var19;
         var128.put(var211, var103);
         var338 = 101053782 ^ var338;
         var19 += 1234952537 ^ var338;
         var338 = 1058005842 ^ var338;
         var330 += 1989411339 ^ var338;
         var338 = yuklzeqklkbasblj(var338, 222138225);
      }
   }

   public void onClick(InventoryClickEvent var1) {
      int var239 = 2102733139 ^ 1238890616 ^ 1937058277;
      var239 = 897972114 ^ var239;
      byte var3 = (byte)(1920077661 ^ var239);
      var1.setCancelled((boolean)var3);
      var239 = 112531311 ^ var239;
      int var15 = var1.getRawSlot();
      var239 = 701349106 ^ var239;
      if (var15 >= (1560978625 ^ var239)) {
         var239 = 2090105395 ^ var239;
         byte var115 = (byte)(564059881 ^ var239);
         if (var15 < var115) {
            var239 = yuklzeqklkbasblj(var239, 995973571);
            ItemStack var19 = var1.getCurrentItem();
            var239 = 1179549220 ^ var239;
            if (var19 != null) {
               label159: {
                  var239 = 269910048 ^ var239;
                  Material var22 = var19.getType();
                  byte var23 = var22.isAir();
                  if (var23 != (1285257525 ^ var239)) {
                     var239 = 470433581 ^ var239;
                     return;
                  }

                  label160: {
                     var239 = 431139534 ^ var239;
                     int var117 = this.sellButtonSlot;
                     if (var15 == var117) {
                        var239 = 1551727689 ^ var239;
                        Material var26 = var19.getType();
                        Material var118 = Material.PAPER;
                        if (var26 == var118) {
                           var239 = 131724088 ^ var239;
                           break label160;
                        }

                        var239 = 1354405976 ^ var239;
                        Material var28 = var19.getType();
                        Material var119 = Material.BARRIER;
                        if (var28 == var119) {
                           var239 = 1466133344 ^ var239;
                           break label160;
                        }

                        var239 = yuklzeqklkbasblj(var239, 1108253832);
                     } else {
                        label125:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var239)) {
                              case 83976095:
                                 var239 ^= 1321826457;
                              case 193293902:
                                 break label125;
                              case 423360357:
                                 break;
                              case 1807756571:
                              default:
                                 throw new IOException();
                           }
                        }
                     }

                     byte var120 = (byte)(467708792 ^ var239);
                     if (var15 == var120) {
                        var239 = 901453009 ^ var239;
                        Material var31 = var19.getType();
                        Material var121 = Material.WRITABLE_BOOK;
                        if (var31 == var121) {
                           var239 = 1673352953 ^ var239;
                           Player var33 = this.player;
                           String var122 = qicikzelvv(svuctbcqljbuper(), oayxxlrvxarpesv(), var239);
                           Sound var4 = Sound.BLOCK_CHERRY_WOOD_BUTTON_CLICK_ON;
                           float var5 = 1.0F;
                           float var6 = 1.0F;
                           KKo0KoOoOK.play(var33, var122, var4, var5, var6);
                           var239 = 220338074 ^ var239;
                           Player var180 = this.player;
                           AuctionTransactionsGUI var34 = new AuctionTransactionsGUI(var180);
                           byte var123 = (byte)(1086652112 ^ var239);
                           var34.open(var123);
                           var239 = 1477568522 ^ var239;
                           return;
                        }

                        var239 = 1823851964 ^ var239;
                     } else {
                        label114:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var239)) {
                              case 100882413:
                                 var239 ^= 1494143341;
                                 break label114;
                              case 530832593:
                                 break;
                              case 927497460:
                              default:
                                 throw new IOException();
                              case 1959526511:
                                 break label114;
                           }
                        }
                     }

                     Map var36 = this.expiredSlotMap;
                     Integer var125 = var15;
                     byte var37 = var36.containsKey(var125);
                     if (var37 != (1122925071 ^ var239)) {
                        var239 = 358418876 ^ var239;
                        Map var39 = this.expiredSlotMap;
                        Integer var127 = var15;
                        Object var40 = var39.get(var127);
                        AuctionListingRecord var41 = (AuctionListingRecord)var40;
                        var239 = 1988269110 ^ var239;
                        Ko0KoOKoOK var42 = Ko0KoOKoOK.getInstance();
                        byte var43 = var42.collectExpiredItem(var41);
                        if (var43 == (556918661 ^ var239)) {
                           var239 = 2004744932 ^ var239;
                           Player var63 = this.player;
                           o0o0oOKo0K var140 = cfg();
                           String var184 = qicikzelvv(ybadtxfsfpkadwt(), oayxxlrvxarpesv(), var239);
                           String var201 = qicikzelvv(ynmhqqelcofisxz(), oayxxlrvxarpesv(), var239);
                           String var141 = var140.rawStr(var184, var201);
                           String var142 = oOo0KKoOoOK.color(var141);
                           var63.sendMessage(var142);
                           var239 = 2132707945 ^ var239;
                           Player var65 = this.player;
                           String var143 = qicikzelvv(kyhagebzrqcfobq(), oayxxlrvxarpesv(), var239);
                           Sound var185 = Sound.ENTITY_VILLAGER_NO;
                           float var202 = 1.0F;
                           float var218 = 1.0F;
                           KKo0KoOoOK.play(var65, var143, var185, var202, var218);
                           var239 = 1270959354 ^ var239;
                           this.decorate();
                           var239 = 391903863 ^ var239;
                           return;
                        }

                        label88:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var239)) {
                              case 5280160:
                                 var239 ^= 772766878;
                                 break label88;
                              case 1696297946:
                                 break;
                              case 1994566802:
                              default:
                                 throw new IOException();
                              case 2022363498:
                                 break label88;
                           }
                        }

                        ItemStack var45 = var41.getItemStack();
                        ItemStack var46 = KoOo0oOo0oOK.thaw(var45);
                        var239 = 264893887 ^ var239;
                        Player var48 = this.player;
                        PlayerInventory var49 = var48.getInventory();
                        byte var129 = (byte)(16215717 ^ var239);
                        ItemStack[] var130 = new ItemStack[var129];
                        byte var197 = (byte)(16215716 ^ var239);
                        var130[var197] = var46;
                        HashMap var50 = var49.addItem(var130);
                        var239 = 695650884 ^ var239;
                        byte var52 = var50.isEmpty();
                        if (var52 == (696362208 ^ var239)) {
                           var239 = 563308353 ^ var239;
                           Collection var54 = var50.values();
                           Consumer var132 = (var1x) -> {
                              int var12 = 1240367028 ^ 1614062320 ^ 1937058277;
                              var12 = 1825869416 ^ var12;
                              Player var5 = this.player;
                              World var6 = var5.getWorld();
                              Player var8 = this.player;
                              Location var9 = var8.getLocation();
                              var6.dropItem(var9, var1x);
                           };
                           var54.forEach(var132);
                           var239 = 1844847615 ^ var239;
                           break label159;
                        }

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var239)) {
                              case 7014131:
                                 var239 ^= 1281705150;
                              case 762444252:
                                 break label159;
                              case 1250509771:
                              default:
                                 throw new IOException();
                              case 1982062784:
                           }
                        }
                     }

                     var239 = yuklzeqklkbasblj(var239, 1018963139);
                     Map var68 = this.activeSlotMap;
                     Integer var145 = var15;
                     byte var69 = var68.containsKey(var145);
                     if (var69 != (2119327436 ^ var239)) {
                        var239 = 1657037765 ^ var239;
                        Map var71 = this.activeSlotMap;
                        Integer var147 = var15;
                        Object var72 = var71.get(var147);
                        AuctionItem var73 = (AuctionItem)var72;
                        var239 = 659341708 ^ var239;
                        Ko0KoOKoOK var74 = Ko0KoOKoOK.getInstance();
                        byte var75 = var74.removeItem(var73);
                        if (var75 == (1004207237 ^ var239)) {
                           var239 = 111042179 ^ var239;
                           Player var77 = this.player;
                           o0o0oOKo0K var149 = cfg();
                           String var186 = qicikzelvv(uavetxpcwrjttup(), oayxxlrvxarpesv(), var239);
                           String var203 = qicikzelvv(qfvzdmzxjctshbm(), oayxxlrvxarpesv(), var239);
                           String var150 = var149.rawStr(var186, var203);
                           String var151 = oOo0KKoOoOK.color(var150);
                           var77.sendMessage(var151);
                           var239 = 1539979596 ^ var239;
                           Player var79 = this.player;
                           String var152 = qicikzelvv(lkifobcpaekprpb(), oayxxlrvxarpesv(), var239);
                           Sound var187 = Sound.ENTITY_VILLAGER_NO;
                           float var204 = 1.0F;
                           float var219 = 1.0F;
                           KKo0KoOoOK.play(var79, var152, var187, var204, var219);
                           var239 = 1147481670 ^ var239;
                           this.decorate();
                           var239 = 1018695738 ^ var239;
                           return;
                        }

                        var239 = 758835545 ^ var239;
                        ItemStack var82 = var73.getItemStack();
                        ItemStack var83 = KoOo0oOo0oOK.thaw(var82);
                        var239 = 152902243 ^ var239;
                        Player var85 = this.player;
                        PlayerInventory var86 = var85.getInventory();
                        byte var153 = (byte)(536678334 ^ var239);
                        ItemStack[] var154 = new ItemStack[var153];
                        byte var205 = (byte)(536678335 ^ var239);
                        var154[var205] = var83;
                        HashMap var87 = var86.addItem(var154);
                        var239 = 320764786 ^ var239;
                        byte var89 = var87.isEmpty();
                        if (var89 == (216233165 ^ var239)) {
                           var239 = 1467886945 ^ var239;
                           Collection var91 = var87.values();
                           Consumer var156 = (var1x) -> {
                              int var12 = 534535739 ^ 1291504140 ^ 1937058277;
                              var12 = 734458260 ^ var12;
                              Player var5 = this.player;
                              World var6 = var5.getWorld();
                              Player var8 = this.player;
                              Location var9 = var8.getLocation();
                              var6.dropItem(var9, var1x);
                           };
                           var91.forEach(var156);
                           var239 = 1408910701 ^ var239;
                        } else {
                           var239 = 75786252 ^ var239;
                        }

                        Player var93 = this.player;
                        o0o0oOKo0K var157 = cfg();
                        String var188 = qicikzelvv(saakmfliqygkwja(), oayxxlrvxarpesv(), var239);
                        String var206 = qicikzelvv(stkwnuoiaoczizz(), oayxxlrvxarpesv(), var239);
                        String var158 = var157.rawStr(var188, var206);
                        String var159 = oOo0KKoOoOK.color(var158);
                        var93.sendMessage(var159);
                        var239 = 1735573902 ^ var239;
                        Player var95 = this.player;
                        o0o0oOKo0K var160 = cfg();
                        String var189 = qicikzelvv(ejfcjdqqpawrsxp(), oayxxlrvxarpesv(), var239);
                        String var207 = qicikzelvv(lklpuflxpwuxbpu(), oayxxlrvxarpesv(), var239);
                        String var161 = var160.rawStr(var189, var207);
                        String var162 = oOo0KKoOoOK.color(var161);
                        var95.sendActionBar(var162);
                        var239 = 1249655515 ^ var239;
                        Player var97 = this.player;
                        String var163 = qicikzelvv(glguuodqshotqoq(), oayxxlrvxarpesv(), var239);
                        Sound var190 = Sound.ENTITY_ITEM_PICKUP;
                        float var208 = 1.0F;
                        float var221 = 1.0F;
                        KKo0KoOoOK.play(var97, var163, var190, var208, var221);
                        var239 = 1889708025 ^ var239;
                        this.decorate();
                        var239 = 1892208149 ^ var239;
                        return;
                     }

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var239)) {
                           case 79686137:
                              var239 = 169126262 ^ var239;
                              return;
                           case 448288982:
                              break;
                           case 1261639830:
                           default:
                              throw new IOException();
                           case 1474822059:
                              return;
                        }
                     }
                  }

                  Ko0KoOKoOK var99 = Ko0KoOKoOK.getInstance();
                  Player var165 = this.player;
                  byte var100 = var99.canPlayerList(var165);
                  if (var100 == (244145290 ^ var239)) {
                     var239 = 1489786859 ^ var239;
                     Ko0KoOKoOK var101 = Ko0KoOKoOK.getInstance();
                     Player var167 = this.player;
                     int var102 = var101.getPlayerListingLimit(var167);
                     var239 = 1393433398 ^ var239;
                     Ko0KoOKoOK var103 = Ko0KoOKoOK.getInstance();
                     Player var169 = this.player;
                     UUID var170 = var169.getUniqueId();
                     int var104 = var103.getPlayerListingCount(var170);
                     var239 = 1905923575 ^ var239;
                     Player var106 = this.player;
                     String var171 = qicikzelvv(wozcnpxfwsuqnxb(), oayxxlrvxarpesv(), var239);
                     String var191 = qicikzelvv(mgtpqgponpsobpc(), oayxxlrvxarpesv(), var239);
                     byte var209 = (byte)(1960117668 ^ var239);
                     Object[] var210 = new Object[var209];
                     byte var7 = (byte)(1960117664 ^ var239);
                     String var8 = qicikzelvv(jmsxeprtuivmfii(), oayxxlrvxarpesv(), var239);
                     var210[var7] = var8;
                     byte var224 = (byte)(1960117665 ^ var239);
                     Integer var228 = var104;
                     var210[var224] = var228;
                     byte var225 = (byte)(1960117666 ^ var239);
                     String var229 = qicikzelvv(mqbbyrbdmfwvjzp(), oayxxlrvxarpesv(), var239);
                     var210[var225] = var229;
                     byte var226 = (byte)(1960117667 ^ var239);
                     Integer var231 = var102;
                     var210[var226] = var231;
                     oOoOo0oOK.send(var106, var171, var191, var210);
                     var239 = 1088299628 ^ var239;
                     Player var108 = this.player;
                     o0o0oOKo0K var172 = cfg();
                     String var192 = qicikzelvv(hmgdntnkbqfdswl(), oayxxlrvxarpesv(), var239);
                     String var211 = qicikzelvv(fnureugadbonmdi(), oayxxlrvxarpesv(), var239);
                     String var173 = var172.rawStr(var192, var211);
                     String var174 = oOo0KKoOoOK.color(var173);
                     var108.sendActionBar(var174);
                     var239 = 1265117790 ^ var239;
                     Player var110 = this.player;
                     String var175 = qicikzelvv(xpuijnfyrnmivem(), oayxxlrvxarpesv(), var239);
                     Sound var193 = Sound.ENTITY_VILLAGER_NO;
                     float var212 = 1.0F;
                     float var222 = 1.0F;
                     KKo0KoOoOK.play(var110, var175, var193, var212, var222);
                     var239 = 962810637 ^ var239;
                     return;
                  }

                  var239 = yuklzeqklkbasblj(var239, 1908912277);
                  Player var112 = this.player;
                  String var176 = qicikzelvv(dainbjeobdhiehd(), oayxxlrvxarpesv(), var239);
                  Sound var194 = Sound.BLOCK_CHERRY_WOOD_BUTTON_CLICK_ON;
                  float var213 = 1.0F;
                  float var223 = 1.0F;
                  KKo0KoOoOK.play(var112, var176, var194, var213, var223);
                  var239 = 1717834157 ^ var239;
                  Player var196 = this.player;
                  AuctionGUI var215 = this.returnGui;
                  oOKo0oOKoOK var113 = new oOKo0oOKoOK(var196, var215);
                  Runnable var178 = () -> {
                     int var8 = 1003340221 ^ 43716191 ^ 1937058277;
                     var8 = 1578914143 ^ var8;
                     Player var4 = this.player;
                     AuctionGUI var5 = this.returnGui;
                     AuctionYourListingsGUI var1 = new AuctionYourListingsGUI(var4, var5);
                     var1.open();
                  };
                  var239 = 1308703696 ^ var239;
                  oOKo0oOKoOK var114 = var113.backTo(var178);
                  var239 = 879207939 ^ var239;
                  var114.open();
                  var239 = 407852246 ^ var239;
                  return;
               }
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var239)) {
                     case 55791125:
                        var239 = 203210509 ^ var239;
                        return;
                     case 1163660633:
                     default:
                        throw new IOException();
                     case 1699377648:
                        break;
                     case 2041761569:
                        return;
                  }
               }
            }

            Player var56 = this.player;
            o0o0oOKo0K var133 = cfg();
            String var181 = qicikzelvv(tztgecpfhdlhaxc(), oayxxlrvxarpesv(), var239);
            String var198 = qicikzelvv(ujbkkbqqaqjjfed(), oayxxlrvxarpesv(), var239);
            String var134 = var133.rawStr(var181, var198);
            String var135 = oOo0KKoOoOK.color(var134);
            var56.sendMessage(var135);
            var239 = 2004945231 ^ var239;
            Player var58 = this.player;
            o0o0oOKo0K var136 = cfg();
            String var182 = qicikzelvv(tvvbavgodeuxmvf(), oayxxlrvxarpesv(), var239);
            String var199 = qicikzelvv(crjwnnsqyezkizr(), oayxxlrvxarpesv(), var239);
            String var137 = var136.rawStr(var182, var199);
            String var138 = oOo0KKoOoOK.color(var137);
            var58.sendActionBar(var138);
            var239 = 1663417353 ^ var239;
            Player var60 = this.player;
            String var139 = qicikzelvv(wxowbmxxvicfxzm(), oayxxlrvxarpesv(), var239);
            Sound var183 = Sound.ENTITY_ITEM_PICKUP;
            float var200 = 1.0F;
            float var217 = 1.0F;
            KKo0KoOoOK.play(var60, var139, var183, var200, var217);
            var239 = 27290572 ^ var239;
            this.decorate();
            var239 = 1855258769 ^ var239;
            return;
         }

         var239 = 382097009 ^ var239;
      } else {
         var239 = 1783770178 ^ var239;
      }

   }

   public Inventory createInventory() {
      int var4 = 1061170051 ^ 1066543778 ^ 1937058277;
      var4 = 1738466993 ^ var4;
      Object var1 = null;
      return (Inventory)var1;
   }

   private String formatMaterialName(String var1) {
      int var24 = 1989521545 ^ 1693420203 ^ 1937058277;
      var24 = 938501432 ^ var24;
      String var6 = o0oOoOo0oOK.material(var1);
      var24 = 1040087596 ^ var24;
      if (var6 != null) {
         var24 = 559083583 ^ var24;
         return var6;
      } else {
         var24 = 2104409339 ^ var24;
         String var3 = qicikzelvv(vifpsfulpuybnbj(), oayxxlrvxarpesv(), var24);
         String var4 = qicikzelvv(niohakqrpyvoapb(), oayxxlrvxarpesv(), var24);
         String var9 = var1.replace(var3, var4);
         String var10 = var9.toLowerCase();
         String var18 = qicikzelvv(qcaxyzyltfuopvz(), oayxxlrvxarpesv(), var24);
         String[] var11 = var10.split(var18);
         Stream var12 = Arrays.stream(var11);
         Function var19 = (var0) -> {
            int var13 = 1947807776 ^ 2077810158 ^ 80073499;
            var13 = 2056272808 ^ var13;
            byte var4 = var0.isEmpty();
            String var8;
            if (var4 != (1905526141 ^ var13)) {
               var13 = 590123832 ^ var13;
               var8 = qicikzelvv(dbpvsewzwujxuci(), oayxxlrvxarpesv(), var13);
               var13 = yuklzeqklkbasblj(var13, 656314397);
            } else {
               var13 = yuklzeqklkbasblj(var13, 1793600317);
               byte var2 = (byte)(461123136 ^ var13);
               char var6 = var0.charAt(var2);
               char var7 = Character.toUpperCase(var6);
               byte var3 = (byte)(461123137 ^ var13);
               String var10 = var0.substring(var3);
               var8 = var7 + var10;
               var13 = 1859790872 ^ var13;
            }

            return var8;
         };
         Stream var13 = var12.map(var19);
         BinaryOperator var20 = (var0, var1x) -> {
            int var7 = 768469179 ^ 428051171 ^ 80073499;
            var7 = 1446284612 ^ var7;
            String var4 = var0 + " " + var1x;
            return var4;
         };
         Optional var14 = var13.reduce(var20);
         Object var15 = var14.orElse(var1);
         String var16 = (String)var15;
         return var16;
      }
   }

   private String formatTimeLeftHM(AuctionItem var1) {
   }

   public static String qicikzelvv(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] oayxxlrvxarpesv() {
      return new byte[]{94, 58, 76, 2, 87, 61, 11, 123, 69, 10, 45, 102, 75, 16, 47, 87, 26, 92, 34, 115, 86, 45, 123, 41, 80, 27, 43, 37, 96, 81, 65, 52, 111, 16, 62, 28, 32, 89, 40, 5, 37, 108, 113, 40, 113, 36, 65, 89, 86, 80, 80, 15, 44, 15, 64, 92, 29, 24, 65, 59, 54, 65, 29, 47, 55, 30, 108, 46, 110, 12, 27, 87, 5, 42, 104, 51, 39, 1, 23, 48, 86, 96, 63, 31, 52, 14, 38, 90, 59, 43, 81, 38, 75, 73, 23, 117, 65, 12};
   }

   private static byte[] gzysrrtgptupxar() {
      return new byte[]{-111, -10, 122, 81, 110, 123, 62, 32, 114, 78, 28, 122, 125, 69, 22, 17, 47, 13, 21, 48, 103, 119, 77, 114, 105, 70, 30, 56, 87, 31, 112, 104, 89, 81, 7, 93, 21, 2, 31, 70, 20, 58, 71, 113, 72, 100, 116, 12, 97, 18, 97, 85};
   }

   private static byte[] cbzndwzrzgbpvmy() {
      return new byte[]{-111, -15, 127, 67, 102, 109, 51, 57, 116, 80, 28, 55};
   }

   private static byte[] bqlsvguscjfvtfq() {
      return new byte[]{-111, -15, 98, 55, 123, 24, 46, 73, 105, 39, 30, 56, 101, 42, 28, 26, 34, 74, 19, 104, 103, 39, 72, 60, 99, -83, 14, 28, 76, 123, 114, -128, 92, 5, 13, 79, 5, 116, 4, 52, 9, 85, 70, 72};
   }

   private static byte[] dbpvsewzwujxuci() {
      return new byte[0];
   }

   private static byte[] flxhywebmuvoktw() {
      return new byte[0];
   }

   private static byte[] dtsaxetpapgioyq() {
      return new byte[]{-106, -12, 87, 47};
   }

   private static byte[] hueohdjqynqrgom() {
      return new byte[]{-111, -15, 127, 70, 100, 108, 57, 50, 124, 89};
   }

   private static byte[] mlvqfbxhxetctaj() {
      return new byte[]{-111, -15, 127, 65, 100, 108, 57, 60, 124, 80, 28, 55, 120, 10, 28, 9, 40, 0, 27, 55, 103, 116, 72, 127, 99, 87};
   }

   private static byte[] rmsylkilsviwona() {
      return new byte[]{-111, -15, 127, 16, 100, 113, 57, 33, 124, 72, 28, 62, 120, 66, 28, 74, 40, 79, 27, 99, 103, 46, 72, 54, 99, 6, 25, 117, 89, 18, 112, 114, 92, 85, 13, 65, 18, 4, 17, 71, 20, 125, 66, 48, 66, 57, 115, 6, 111, 15, 97, 86, 31, 81, 115, 16, 47, 14, 120, 36};
   }

   private static byte[] kmdnvthbfvmhojk() {
      return new byte[]{-111, -15, 127, 16, 100, 113, 57, 33, 124, 72, 28, 62, 120, 66, 28, 74};
   }

   private static byte[] kmiqenqryknugjf() {
      return new byte[]{-111, -15, 127, 16, 100, 102, 57, 61, 124, 78, 28, 32, 120, 66, 28, 1, 40, 27, 27, 96};
   }

   private static byte[] hlmkrgszrlzoajz() {
      return new byte[]{-111, -15, 127, 16, 100, 105, 57, 33, 124, 81, 28, 59, 120, 83, 28, 74};
   }

   private static byte[] gomfzigpukpcesq() {
      return new byte[]{-111, -16, 126, 65, 103, 110, 57, 50, 112, 70, 28, 125, 121, 79, 31, 14, 40, 1, 23, 47, 103, 53, 73, 127, 96, 67, 25, 57, 85, 0, 112, 117, 93, 66, 14, 71, 18, 69, 29, 92, 20, 55, 67, 123, 65, 63, 115, 28, 99, 17, 97, 74, 30, 93};
   }

   private static byte[] szkkxwsbrbatsxc() {
      return new byte[]{-111, -16, 126, 22, 103, 62, 57, 127, 112, 7, 28, 102, 121, 18, 31, 84, 40, 37, 23, 36, 103, 116, 73, 122, 96, 13, 25, 117, 85, 7, 112, 33, 93, 78, 14, 94, 18, 13, 29, 80, 20, 121, 67, 126, 65, 124, 115, 12, 99, 72, 97, 78, 30, 65, 112, 26, 47, 76};
   }

   private static byte[] wcfsebwbzunwigo() {
      return new byte[]{-111, -14, 126, 104};
   }

   private static byte[] hqkoxkkeyaqoftt() {
      return new byte[]{-111, -14, 126, 23};
   }

   private static byte[] jvcdjkwhuxtmxuu() {
      return new byte[]{-111, -14, 120, 65, 110, 111, 61, 49, 117, 76, 28, 127, 127, 94, 22, 15, 44, 27, 18, 51, 103, 55, 79, 119, 105, 88, 29, 114, 80, 14, 112, 46, 91, 80, 7, 74, 22, 24, 24, 26, 20, 53, 69, 112, 72, 103, 119, 70, 102, 17, 97, 87, 24, 84, 121, 15};
   }

   private static byte[] zpvjuvnzaqifwzc() {
      return new byte[]{-111, -14, 120, 22, 110, 76, 61, 15, 117, 13, 28, 100, 127, 18, 22, 85, 44, 55, 18, 46, 103, 111, 79, 108, 105, 12, 29, 126, 80, 23, 112, 102, 91, 74, 7, 11, 22, 28, 24, 86, 20, 40, 69, 63, 72, 125, 119, 4, 102, 22, 97, 24, 24, 75, 121, 4, 43, 70, 113, 109};
   }

   private static byte[] wmlbhhjtzlmamjc() {
      return new byte[]{-108, -15, 122, 79, 98, 106, 63, 54, 124, 74, 25, 126, 114, 86, 29, 6, 47, 9, 22, 43, 96, 57, 78, 114, 100, 90, 18, 116, 84, 10};
   }

   private static byte[] ynugspdokruhyud() {
      return new byte[]{-108, -15, 122, 24, 98, 63, 63, 126, 124, 120, 25, 19, 114, 29, 29, 91, 47, 54, 22, 34, 96, 120, 78, 119, 100, 14, 18, 88, 84, 19, 120, 100, 93, 73};
   }

   private static byte[] twdhoprdycpywmo() {
      return new byte[]{-111, -15, 123, 65, 102, 108, 60, 49, 115, 73, 28, 124, 124, 75, 30, 10, 45, 29, 20, 48, 103, 112, 76, 112, 97, 72, 28, 100, 86, 75, 112, 108, 88, 78, 15, 70, 23, 14};
   }

   private static byte[] osfbfeieeazzvcz() {
      return new byte[]{-111, -15, 123, 19, 102, 62, 60, 5, 115, 84, 28, 33, 124, 83, 30, 10, 45, 0, 20, 35, 103, 106, 76, 36, 97, 15, 28, 49, 86, 5, 112, 37, 88, 68, 15, 93, 23, 25, 30, 64, 20, 61, 70, 113, 64, 100, 118, 78, 96, 65, 97, 12, 27, 23, 113, 78, 42, 73, 119, 41, 7, 25, 42, 113, 6, 71, 91, 117, 88, 79, 42, 70};
   }

   private static byte[] gurnecwajxtgqll() {
      return new byte[]{-111, -15, 123, 16, 102, 106, 60, 60, 115, 79, 28, 32, 124, 66, 30, 13, 45, 26, 20, 97};
   }

   private static byte[] pwfghpsqqypeqmi() {
      return new byte[]{-111, -15, 123, 16, 102, 101, 60, 32, 115, 80, 28, 59, 124, 83, 30, 70};
   }

   private static byte[] kdkzkraitapwbxc() {
      return new byte[0];
   }

   private static byte[] uyhirayvxqtlewv() {
      return new byte[]{-109, -16, 126, 71, 103, 107, 57, 55, 125, 77, 24, 122, 122, 76, 28, 12, 46, 23, 17, 50, 100, 117, 75, 116, 98, 72, 19, 59, 85, 13, 112, 101, 92, 79, 10, 65};
   }

   private static byte[] adhxuslbpdwfgch() {
      return new byte[]{-109, -16, 126, 21, 103, 104, 57, 106, 125, 80, 24, 32, 122, 69, 28, 8, 46, 65};
   }

   private static byte[] uewithfmvoffwwc() {
      return new byte[]{-109, -16, 126, 22, 103, 103, 57, 59, 125, 92, 24, 57, 122, 5};
   }

   private static byte[] nmpdbxlnncutopg() {
      return new byte[]{-110, -11, 122, 66, 111, 104, 51, 59, 114, 79, 31, 120, 125, 93, 23, 8, 34, 17, 21, 111, 100, 107, 77, 120, 104, 6, 19, 111, 87, 5, 115, 101, 89, 71, 6, 68, 24, 4, 31, 80, 23, 113, 71, 101, 73, 123, 121, 20, 97, 19, 98, 18, 26, 87, 120, 5, 37, 83, 118, 126, 4, 24, 43, 117, 15, 73, 84, 59, 89, 81, 41, 14, 51, 115, 80, 106, 31, 77};
   }

   private static byte[] effloemlrnlkzlg() {
      return new byte[]{-110, -11, 122, 16, 111, 110, 51, 26, 114, 84, 31, 35, 125, 3, 23, 17, 34, 1, 21, 98, 100, 111, 77, 120, 104, 74, 19, 126, 87, 8, 115, 97, 89, 64, 6, 12, 24, 24, 31, 91, 23, 41, 71, 110, 73, 52, 121, 13, 97, 8, 98, 76, 26, 79, 120, 5, 37, 78, 118, 109, 4, 81, 43, 119, 15, 71, 84, 123, 89, 84, 41, 19, 51, 63};
   }

   private static byte[] otqeacycejusdme() {
      return new byte[0];
   }

   private static byte[] qehximicnxlyutc() {
      return new byte[]{-106, -3, 120, 64, 102, 105, 51, 54, 113, 72, 21, 124, 125, 82, 30, 10, 47, 4, 20, 39, 98, 54, 74, 113, 104, 90, 31, 118, 88, 8, 119, 40, 94, 68, 11, 65, 22, 12, 28, 90, 20, 41, 73, 48, 69, 96, 121, 8, 96, 0, 97, 84, 25, 83, 118, 1, 41, 74};
   }

   private static byte[] nlmadxbblhdjgks() {
      return new byte[]{-106, -3, 120, 23, 102, 74, 51, 8, 113, 13, 21, 22, 125, 16, 30, 43, 47, 59, 20, 46, 98, 119, 74, 116, 104, 14, 31, 90, 88, 17, 119, 96, 94, 69, 11, 8, 22, 71, 28, 4, 20, 117, 73, 81, 69, 123, 121, 0, 96, 8, 97, 67, 25, 27, 118, 54, 41, 75, 112, 107, 14, 23, 41, 113, 15, 79, 90, 123, 95, 29};
   }

   private static byte[] vynweijaxzvkduf() {
      return new byte[]{-111, -3, 120, 78, 97, 111, 59, 59, 118, 71, 28, 112, 127, 90, 25, 5, 42, 9, 17, 37, 103, 99, 79, 116, 102, 1, 27, 124, 83, 69, 112, 96, 91, 65, 8, 88, 16, 21, 27, 85, 20, 58, 69, 119, 71, 62, 113, 21, 101, 6, 97, 26, 24, 68, 118, 14, 45, 76, 114, 110, 7, 84, 41, 122, 1, 70, 92, 100, 93, 80, 42, 66, 49, 123, 94, 112, 23, 92, 36, 100, 103, 43};
   }

   private static byte[] trjohyivwuytlid() {
      return new byte[]{-111, -3, 120, 28, 97, 61, 59, 17, 118, 86, 28, 51, 127, 71, 25, 22, 42, 1, 17, 106, 103, 116, 79, 49, 102, 64, 27, 116, 83, 27, 112, 120, 91, 65, 8, 69, 16, 6, 27, 28, 20, 32, 69, 127, 71, 51, 113, 18, 101, 12, 97, 91, 24, 91, 118, 75, 45, 77, 114, 109, 7, 11, 41, 114, 1, 9, 92, 127, 93, 65, 42, 10, 49, 127, 94, 119};
   }

   private static byte[] dzurwakjopugdus() {
      return new byte[]{-110, -12, 126, 19};
   }

   private static byte[] aacdvrlrhhilhen() {
      return new byte[]{-111, -14, 120, 64, 102, 104, 56, 53, 113, 76, 28, 127, 127, 74, 30, 14, 41, 25, 22, 53, 103, 115, 79, 113, 97, 76, 24, 62, 84, 19, 112, 113, 91, 79, 15, 79, 19, 10};
   }

   private static byte[] lqsmsuvyxgdcmbe() {
      return new byte[]{-111, -14, 120, 23, 102, 61, 56, 125, 113, 126, 28, 23, 127, 22, 30, 87, 41, 79, 22, 49, 103, 104, 79, 118, 97, 72, 24, 118, 84, 70};
   }

   private static byte[] ymjubsrzwcmwlrg() {
      return new byte[]{-111, -14, 120, 17, 102, 125, 56, 63, 113, 81, 28, 50, 127, 67, 30, 66};
   }

   private static byte[] tcvowadmwjicdpu() {
      return new byte[]{-106, -13, 88, 36};
   }

   private static byte[] fqilglzkpntwflh() {
      return new byte[]{-104, -14, 124, 65, 111, 110, 50, 48, 114, 70, 26, 120, 124, 92, 25, 7, 41, 6, 26, 33, 102, 55, 67, 115, 105, 77, 28, 123, 87, 21};
   }

   private static byte[] quohsjgpqwequxk() {
      return new byte[]{-104, -14, 124, 22, 111, 62, 50, 125, 114, 7, 26, 99, 124, 29, 25, 91, 41, 63, 26, 45, 102, 119, 67, 122, 105, 8, 28, 81, 87, 4, 118, 106, 89, 93, 13, 17};
   }

   private static byte[] qybkflleaykllvd() {
      return new byte[]{-111, -10, 117, 79, 100, 109, 50, 59, 112, 79, 30, 113, 114, 64, 26, 2, 34, 0, 19, 35, 111, 127, 72, 49, 105, 87, 30, 123, 83, 69, 120, 116, 90, 76, 6, 76, 17, 71, 17, 69, 22, 54, 72, 101, 68, 103, 114, 77, 111, 19, 101, 67, 20, 72, 113, 12, 36, 73, 114, 111, 15, 10, 40, 123, 4, 84, 85, 48, 91, 84, 35, 12, 52, 125, 81, 39, 20, 71, 46, 105, 99, 61, 12, 67, 13, 78};
   }

   private static byte[] hqroynuighxrvzu() {
      return new byte[]{-111, -10, 117, 29, 100, 110, 50, 0, 112, 87, 30, 54, 114, 64, 26, 5, 34, 73, 19, 52, 111, 123, 72, 60, 105, 80, 30, 113, 83, 13, 120, 39, 90, 80, 6, 70, 17, 31, 17, 78, 22, 121, 72, 96, 68, 96, 114, 18, 111, 0, 101, 94, 20, 91, 113, 28, 36, 68, 114, 125, 15, 89, 40, 127, 4, 73, 85, 121, 91, 21, 35, 17, 52, 120, 81, 102, 20, 81, 46, 123};
   }

   private static byte[] jiswpbkurnbsupt() {
      return new byte[]{-111, -4, 125, 64, 101, 110, 61, 49, 116, 74, 28, 113, 122, 73, 29, 19};
   }

   private static byte[] rifkhjdttddzbzx() {
      return new byte[]{-111, -4, 125, 23, 101, 62, 61, 124, 116, 11, 28, 106, 122, 19, 29, 84, 44, 33, 19, 53, 103, 58, 74, 49, 98, 3};
   }

   private static byte[] zzbexdpofvdfjob() {
      return new byte[]{-106, -13, 125, 65, 101, 108, 58, 50, 116, 72, 27, 121, 124, 67, 27, 14, 43, 64, 20, 54, 103, 127, 73, 113, 97, 70, 26, 62, 86, 16, 118, 116, 91, 72, 15, 78, 22, 10};
   }

   private static byte[] lsfdvvvkizuwevu() {
      return new byte[]{-106, -13, 125, 22, 101, 60, 58, 127, 116, 9, 27, 98, 124, 23, 27, 83, 43, 66, 20, 36, 103, 114, 73, 61, 97, 89, 26, 118, 86, 12, 118, 106, 91, 1, 15, 5, 22, 31, 25, 64, 23, 49, 64, 122, 64, 119, 119, 65};
   }

   private static byte[] jiyfsqszpqvofcv() {
      return new byte[]{-111, -15, 126, 79, 100, 110, 60, 52, 117, 73, 28, 124, 121, 69, 28, 8, 45, 24, 18, 48, 103, 112, 73, 126, 99, 74, 28, 63, 80, 18, 112, 105, 93, 68, 13, 79};
   }

   private static byte[] cgaplbrsfdfcwjq() {
      return new byte[]{-111, -15, 126, 24, 100, 62, 60, 121, 117, 8, 28, 103, 121, 28, 28, 84, 45, 78, 18, 48, 103, 112, 73, 125, 99, 72, 28, 55};
   }

   private static byte[] mmcomrmmqkpkxpg() {
      return new byte[]{-111, -15, 126, 30, 100, 127, 60, 37, 117, 80, 28, 55, 121, 12};
   }

   private static byte[] nysmfpxlxoebytf() {
      return new byte[]{-111, -10, 125, 65, 110, 105, 57, 58, 118, 77, 28, 123, 122, 68, 22, 10, 40, 12, 17, 35, 103, 117, 74, 51, 105, 94, 25, 115, 83, 79, 112, 100, 94, 72, 7, 65, 18, 12, 27, 83, 20, 60, 64, 107};
   }

   private static byte[] rpeoxigrcupfool() {
      return new byte[]{-111, -10, 125, 19, 110, 106, 57, 1, 118, 85, 28, 60, 122, 68, 22, 13, 40, 69, 17, 52, 103, 113, 74, 62, 105, 73, 25, 115, 83, 14, 112, 107, 94, 66, 7, 78, 18, 20};
   }

   private static byte[] bevhsqiokblyomy() {
      return new byte[]{-111, -9, 123, 70, 110, 104, 59, 54, 125, 76, 28, 122, 124, 67, 22, 11, 42, 0, 26, 34, 103, 116, 76, 52, 105, 95, 27, 127, 88, 78, 112, 106, 88, 73, 7, 95, 16, 24, 16, 26, 20, 63, 70, 118, 72, 57, 113, 5, 110, 22, 97, 88, 27, 82};
   }

   private static byte[] bjgtverczpowzgz() {
      return new byte[]{-111, -9, 123, 17, 110, 75, 59, 8, 125, 126, 28, 18, 124, 102, 22, 33, 42, 42, 26, 45, 103, 118, 76, 122, 105, 64, 27, 48, 88, 23, 112, 105, 88, 0, 7, 64, 16, 5, 16, 68, 20, 42, 70, 56, 72, 117, 113, 2, 110, 66, 97, 84, 27, 75, 121, 9, 45, 64};
   }

   private static byte[] zekbdltixtmmpsn() {
      return new byte[0];
   }

   private static byte[] lebhcblmkymgrga() {
      return new byte[]{-111, -12, 123, 67, 102, 107, 63, 48, 119, 77, 28, 121, 124, 81, 30, 22, 46, 14, 16, 46, 103, 111, 76, 125, 97, 75, 31, 98, 82, 11, 112, 106, 88, 75, 15, 92};
   }

   private static byte[] bvvbejunwgumcve() {
      return new byte[]{-111, -12, 123, 20, 102, 63, 63, 14, 119, 127, 28, 19, 124, 28, 30, 92, 51, 116, 18, -64, 122, 28, 78, 104, 97, 91, 2, 22, 79, 102, 109, 30, 90, 79, 18, 32, 22, 30, 26, 69};
   }

   private static byte[] glguuodqshotqoq() {
      return new byte[]{-106, -9, 123, 85, 110, 127, 62, 45, 115, 72, 31, 56, 125, 70, 24, 12, 47, 68, 20, 56, 97, 116, 66, 107, 101, 92, 29, 122, 82, 18, 119, 104, 88, 72, 11, 89, 22, 12, 31, 70, 28, 50, 68, 51, 71, 98, 115, 7, 96, 10, 103, 81, 25, 76, 118, 30, 42, 28};
   }

   private static byte[] wxowbmxxvicfxzm() {
      return new byte[]{-111, -4, 124, 83, 103, 124, 58, 44, 124, 72, 28, 54, 123, 79, 31, 13, 43, 70, 27, 60, 103, 123, 75, 108, 96, 93, 26, 120, 89, 19, 112, 104, 95, 77, 14, 91, 17, 10, 17, 70, 20, 60, 65, 54, 65, 96, 112, 4, 111, 5, 97, 93, 28, 74, 112, 24};
   }

   private static byte[] ybadtxfsfpkadwt() {
      return new byte[]{-111, -15, 120, 65, 111, 106, 51, 59, 118, 77, 28, 124, 127, 83, 23, 13, 34, 13, 17, 51, 103, 52, 79, 119, 104, 93, 19, 120, 83, 15, 112, 45, 91, 78, 6, 93, 24, 76, 27, 88, 20, 55, 69, 50, 73, 122, 121, 14, 101, 13, 97, 92, 24, 93, 120, 28, 37, 13, 114, 105, 7, 3, 41, 121, 15, 69, 84, 122, 93, 94, 42, 1, 49, 113, 80, 100};
   }

   private static byte[] ynmhqqelcofisxz() {
      return new byte[]{-111, -15, 120, 19, 111, 108, 51, 23, 118, 81, 28, 59, 127, 84, 23, 69, 34, 13, 17, 52, 103, 124, 79, 115, 104, 9, 19, 116, 83, 17, 112, 32, 91, 73, 6, 65, 24, 65, 27, 90, 20, 55, 69, 113, 73, 113, 121, 4, 101, 17, 97, 27, 24, 89, 120, 24, 37, 65, 114, 97, 7, 25, 41, 121, 15, 78, 84, 122, 93, 90, 42, 77};
   }

   private static byte[] kyhagebzrqcfobq() {
      return new byte[]{-106, -4, 127, 81, 96, 112, 63, 47, 119, 72, 20, 60, 121, 72, 23, 13, 45, 64, 20, 51, 101, 112, 76, 100, 100, 94, 25, 122, 89, 22, 115, 102, 87, 73, 9, 93, 22, 7, 27, 66, 18, 61, 69, 49, 67, 118, 120, 15, 100, 9, 104, 66, 27, 15};
   }

   private static byte[] saakmfliqygkwja() {
      return new byte[]{-111, -15, 124, 79, 96, 109, 57, 58, 114, 79, 25, 120, 114, 94, 26, 10, 35, 30, 19, 106, 102, 119, 76, 115, 98, 78, 28, 120, 84, 4, 120, 96, 90, 86, 7, 78, 17, 9, 24, 17, 18, 32, 67, 126, 70, 96, 117, 27, 111, 74, 101, 84, 21, 76, 113, 13, 45, 76};
   }

   private static byte[] stkwnuoiaoczizz() {
      return new byte[]{-111, -15, 124, 29, 96, 63, 57, 27, 114, 84, 25, 35, 114, 7, 26, 6, 35, 4, 19, 43, 102, 120, 76, 121, 98, 65, 28, 96, 84, 4, 120, 103, 90, 2, 7, 82, 17, 2, 24, 73, 18, 43, 67, 49, 70, 124, 117, 29, 111, 2, 101, 80, 21, 22};
   }

   private static byte[] uavetxpcwrjttup() {
      return new byte[]{-111, -11, 126, 65, 110, 104, 51, 50, 117, 76, 28, 120, 121, 83, 22, 15, 34, 4, 18, 50, 103, 48, 73, 119, 105, 95, 19, 113, 80, 14, 112, 41, 93, 80, 7, 77, 24, 27, 24, 26, 20, 61, 67, 115, 72, 102, 121, 13, 102, 3, 97, 91, 30, 65, 121, 65, 37, 75, 113, 102, 7, 4, 47, 127, 14, 70, 84, 107, 94, 19, 42, 8, 55, 111, 81, 46, 31, 89, 39, 113, 103, 125, 13, 70, 13, 81, 30, 70, 11, 117, 96, 121, 121, 16, 46, 34, 121, 88, 110, 122, 125, 31, 101, 107, 50, 61, 125, 90, 29, 61, 122, 76, 29, 1, 35, 14, 26, 46, 102, 122};
   }

   private static byte[] qfvzdmzxjctshbm() {
      return new byte[]{-111, -11, 126, 19, 110, 110, 51, 30, 117, 80, 28, 63, 121, 84, 22, 71, 34, 4, 18, 53, 103, 120, 73, 115, 105, 11, 19, 99, 80, 2, 112, 119, 93, 7, 7, 77, 24, 4, 24, 69, 20, 57, 67, 126, 72, 112, 121, 17, 102, 66, 97, 93, 30, 87, 121, 25, 37, 78, 113, 97, 7, 5, 47, 56, 14, 65, 84, 109, 94, 30, 42, 14, 55, 110, 81, 35, 31, 94, 39, 109, 103, 112, 13, 68, 13, 81, 30, 5, 11, 126, 96, 115, 121, 12, 46, 101, 121, 92, 110, 126, 125, 83, 101, 99, 50, 39, 125, 90, 29, 54, 122, 76, 29, 5, 35, 77};
   }

   private static byte[] svuctbcqljbuper() {
      return new byte[]{-111, -10, 124, 85, 110, 127, 51, 46, 118, 74, 28, 60, 123, 73, 22, 14, 34, 68, 17, 62, 103, 113, 75, 106, 105, 94, 19, 122, 83, 17, 112, 98, 95, 75, 7, 88, 24, 8, 27, 68, 20, 54, 65, 48, 72, 112, 121, 3, 101, 13, 97, 95, 28, 82, 121, 89};
   }

   private static byte[] tvvbavgodeuxmvf() {
      return new byte[]{-109, -11, 116, 64, 97, 96, 61, 59, 124, 77, 29, 112, 125, 95, 23, 14, 34, 16, 17, 110, 110, 120, 77, 126, 102, 79, 18, 122, 80, 12, 119, 97, 87, 82, 6, 64, 19, 13, 16, 30, 19, 45, 71, 127, 72, 98, 113, 19, 96, 75, 104, 76, 20, 88, 115, 31, 37, 65, 119, 111, 0, 29, 36, 49, 7, 79, 90, 108, 86, 95, 35, 3};
   }

   private static byte[] crjwnnsqyezkizr() {
      return new byte[]{-109, -11, 116, 18, 97, 50, 61, 26, 124, 86, 29, 43, 125, 6, 23, 2, 34, 10, 17, 47, 110, 119, 77, 116, 102, 64, 18, 98, 80, 12, 119, 102, 87, 6, 6, 92, 19, 6, 16, 70, 19, 38, 71, 48, 72, 98, 113, 15, 96, 21, 104, 86, 20, 90, 115, 8, 37, 14, 119, 106, 0, 13, 36, 121, 7, 75, 90, 54};
   }

   private static byte[] lkifobcpaekprpb() {
      return new byte[]{-111, -14, 126, 83, 97, 122, 58, 32, 124, 70, 28, 56, 121, 79, 25, 11, 43, 74, 27, 50, 103, 117, 73, 108, 102, 91, 26, 116, 89, 29, 112, 102, 93, 77, 8, 93, 17, 6, 17, 72, 20, 50, 67, 54, 71, 114, 112, 4, 111, 6, 97, 65, 30, 12};
   }

   private static byte[] dainbjeobdhiehd() {
      return new byte[]{-110, -12, 127, 86, 97, 121, 61, 45, 113, 77, 31, 62, 120, 74, 25, 8, 44, 71, 22, 57, 100, 115, 72, 105, 102, 88, 29, 121, 84, 22, 115, 96, 92, 72, 8, 94, 22, 11, 28, 67, 23, 52, 66, 51, 71, 118, 119, 0, 98, 10, 98, 93, 31, 81};
   }

   private static byte[] wozcnpxfwsuqnxb() {
      return new byte[]{-111, -4, 122, 83, 102, 121, 60, 46, 115, 74, 28, 54, 125, 79, 30, 8, 45, 68, 20, 43, 103, 125, 77, 106, 97, 94, 28, 122, 86, 11, 112, 106, 89, 13, 15, 65, 23, 6, 30, 92, 20, 60, 71, 108};
   }

   private static byte[] mgtpqgponpsobpc() {
      return new byte[]{-111, -4, 122, 20, 102, 111, 60, 20, 115, 81, 28, 42, 125, 0, 30, 14, 45, 11, 20, 49, 103, 113, 77, 57, 97, 88, 28, 118, 86, 4, 112, 110, 89, 72, 15, 72, 23, 11, 30, 17, 20, 44, 71, 119, 64, 96, 118, 29, 96, 68, 97, 90, 26, 86, 113, 30, 42, 90, 119, 102, 7, 22, 43, 120, 6, 15, 91, 116, 88, 81, 42, 3, 51, 115, 89, 118, 16, 22, 33, 36, 103, 113, 9, 10, 5, 92, 17, 25, 13, 109, 96, 109, 125, 28, 38, 42, 118, 78, 104, 43, 125, 20, 97, 40, 58, 38, 114, 85, 27, 63, 122, 64, 25, 19, 43, 72, 21, 108};
   }

   private static byte[] jmsxeprtuivmfii() {
      return new byte[]{-111, -4, 122, 23, 102, 111, 60, 56, 115, 76, 28, 45, 125, 69, 30, 8, 45, 30, 20, 98};
   }

   private static byte[] mqbbyrbdmfwvjzp() {
      return new byte[]{-111, -4, 122, 23, 102, 96, 60, 36, 115, 83, 28, 54, 125, 84, 30, 67};
   }

   private static byte[] ejfcjdqqpawrsxp() {
      return new byte[]{-111, -3, 122, 69, 96, 104, 56, 59, 125, 73, 28, 112, 125, 90, 24, 8, 41, 17, 26, 105, 103, 118, 77, 117, 103, 71, 24, 113, 88, 3, 112, 111, 89, 87, 9, 73, 19, 5, 16, 31, 20, 45, 71, 116, 70, 97, 114, 19, 110, 74, 97, 94, 26, 72, 119, 9, 46, 77};
   }

   private static byte[] lklpuflxpwuxbpu() {
      return new byte[]{-111, -3, 122, 23, 96, 58, 56, 26, 125, 82, 28, 43, 125, 3, 24, 4, 41, 11, 26, 40, 103, 121, 77, 127, 103, 72, 24, 105, 88, 3, 112, 104, 89, 3, 9, 85, 19, 14, 16, 71, 20, 38, 71, 59, 70, 125, 114, 21, 110, 2, 97, 90, 26, 18};
   }

   private static byte[] xpuijnfyrnmivem() {
      return new byte[]{-110, -12, 127, 84, 102, 113, 60, 33, 114, 78, 31, 62, 120, 72, 30, 0, 45, 75, 21, 58, 100, 115, 72, 107, 97, 80, 28, 117, 87, 21, 115, 96, 92, 74, 15, 86, 23, 7, 31, 64, 23, 52, 66, 49, 64, 121, 118, 5, 97, 14, 98, 71};
   }

   private static byte[] hmgdntnkbqfdswl() {
      return new byte[]{-104, -14, 127, 71, 99, 110, 56, 50, 115, 70, 26, 123, 122, 72, 25, 13, 43, 25, 26, 48, 101, 117, 79, 113, 99, 77, 29, 48, 87, 14, 112, 105, 89, 78, 15, 67, 24, 26, 27, 25, 17, 40, 66, 124, 71, 125, 118, 9, 103, 12, 102, 89, 29, 93};
   }

   private static byte[] fnureugadbonmdi() {
      return new byte[]{-104, -14, 127, 21, 99, 104, 56, 6, 115, 91, 26, 38, 122, 80, 25, 13, 43, 4, 26, 35, 101, 60, 79, 115, 99, 67, 29, 112, 87, 11, 112, 116, 89, 3, 15, 88, 24, 11, 27, 85, 17, 57, 66, 113, 71, 121, 118, 14, 103, 69};
   }

   private static byte[] tztgecpfhdlhaxc() {
      return new byte[]{-111, -14, 124, 79, 99, 97, 51, 55, 115, 76, 28, 127, 123, 80, 27, 1, 34, 29, 20, 108, 103, 121, 75, 127, 100, 78, 19, 125, 86, 6, 112, 96, 95, 93, 10, 64, 24, 9, 30, 26, 20, 34, 65, 126, 69, 104, 121, 31, 96, 79, 97, 77, 28, 88, 116, 22, 37, 67, 119, 101, 7, 18, 45, 59, 3, 78, 84, 110, 88, 91, 42, 13};
   }

   private static byte[] ujbkkbqqaqjjfed() {
      return new byte[]{-111, -14, 124, 29, 99, 51, 51, 22, 115, 87, 28, 36, 123, 9, 27, 13, 34, 7, 20, 45, 103, 118, 75, 117, 100, 65, 19, 101, 86, 6, 112, 103, 95, 9, 10, 92, 24, 2, 30, 66, 20, 41, 65, 49, 69, 104, 121, 3, 96, 17, 97, 87, 28, 90, 116, 1, 37, 12, 119, 96, 7, 2, 45, 115, 3, 74, 84, 52};
   }

   private static byte[] vifpsfulpuybnbj() {
      return new byte[]{-109, -14, 122, 105};
   }

   private static byte[] niohakqrpyvoapb() {
      return new byte[]{-109, -14, 122, 22};
   }

   private static byte[] qcaxyzyltfuopvz() {
      return new byte[]{-109, -14, 122, 22};
   }

   private static byte[] tggnryotsqmbfiu() {
      return new byte[]{-111, -14, 117, 8, 102, 57, 58, 47};
   }

   private static byte[] mgwpbhrxqyfbvfa() {
      return new byte[]{-111, -13, 122, 66, 111, 104, 59, 58, 125, 79, 27, 126, 127, 77, 31, 31, 35, 20, 19, 44, 96, 107, 67, 124, 96, 70};
   }

   private static byte[] mpadiscexllisia() {
      return new byte[]{-111, -13, 122, 115, 111, 117, 59, 50, 125, 82, 27, 34, 127, 77, 31, 3};
   }

   private static byte[] lamsazdsikatlff() {
      return new byte[]{-111, -15, 117, 66, 102, 97, 56, 49, 113, 78, 28, 124, 114, 65, 30, 22, 41, 30, 22, 42, 103, 107, 66, 120, 97, 70};
   }

   private static byte[] jrihrygjdkkqykc() {
      return new byte[]{-111, -15, 117, 115, 102, 124, 56, 57, 113, 83, 28, 32, 114, 65, 30, 10};
   }

   private static int yuklzeqklkbasblj(int var0, int var1) {
      return var0 ^ var1;
   }

   static {
   }
}
