package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFactory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.KoOo0oOo0oOK;
import skido.o0o0oOKo0K;
import skido.o0oOoOo0oOK;
import skido.oOo0KKoOoOK;
import skido.oOo0KoOo0oOK;
import skido.oOoOKo0o0K;

public class AuctionItemEditorGUI implements KKoOK {
   private final Player player;
   private final AuctionItem auctionItem;
   private Inventory inventory;
   private final boolean isShulker;
   private static byte[] zgfjtlyvfe;

   private static o0o0oOKo0K cfg() {
      int var4 = 29451672 ^ 346569322 ^ 349960680;
      var4 = 1346517904 ^ var4;
      String var0 = nnacygklgn(slswwjlislypsjx(), var4);
      o0o0oOKo0K var1 = o0o0oOKo0K.of(var0);
      return var1;
   }

   public AuctionItemEditorGUI(Player var1, AuctionItem var2) {
      this.player = var1;
      this.auctionItem = var2;
      ItemStack var11 = var2.getItemStackDirect();
      Material var12 = var11.getType();
      String var13 = var12.name();
      String var5 = "SHULKER_BOX";
      boolean var14 = var13.contains(var5);
      this.isShulker = var14;
   }

   public void open() {
      int var116;
      label91: {
         var116 = 1749907401 ^ 991362761 ^ 1576271025;
         var116 = 1741673184 ^ var116;
         byte var17 = this.isShulker;
         if (var17 != (1768400721 ^ var116)) {
            var116 = 1804759525 ^ var116;
            String var18 = nnacygklgn(echgorfhdetabwv(), var116);
            o0o0oOKo0K var19 = o0o0oOKo0K.of(var18);
            String var2 = nnacygklgn(urvbmlbjcybvnvt(), var116);
            byte var3 = (byte)(49665717 ^ var116);
            byte var20 = var19.bool(var2, (boolean)var3);
            if (var20 != (49665716 ^ var116)) {
               var116 = 323597612 ^ var116;
               break label91;
            }

            var116 = 1314559440 ^ var116;
         } else {
            var116 = 633922613 ^ var116;
         }

         Player var22 = this.player;
         String var55 = nnacygklgn(ltzsawqakcxqzzo(), var116);
         var116 = 911707713 ^ var116;
         byte var23 = oOo0KoOo0oOK.usable(var22, var55);
         if (var23 != (2063125797 ^ var116)) {
            var116 = 1228988271 ^ var116;
            AuctionItem var25 = this.auctionItem;
            double var26 = var25.getPrice();
            String var28 = oOo0KKoOoOK.formatPrice(var26);
            var116 = 1892412953 ^ var116;
            Player var30 = this.player;
            var30.closeInventory();
            var116 = 1773832635 ^ var116;
            Player var32 = this.player;
            String var56 = nnacygklgn(hivcqsabhqjzdwh(), var116);
            String var70 = nnacygklgn(nxuhouvyhodskot(), var116);
            AuctionItem var79 = this.auctionItem;
            var116 = 524765400 ^ var116;
            ItemStack var80 = var79.getItemStack();
            String var5 = nnacygklgn(frkuavuqoxkpvgx(), var116);
            String var6 = nnacygklgn(zpprkdvrkuwnukv(), var116);
            String var7 = nnacygklgn(zwrvcgdxmallqgb(), var116);
            byte var8 = (byte)(898514225 ^ var116);
            Runnable var83 = this::purchase;
            Runnable var84 = () -> {
               int var6 = 1314442360 ^ 1630425363 ^ 1576271025;
               var6 = 986458312 ^ var6;
               Player var3 = this.player;
               AuctionGUI var1 = new AuctionGUI(var3);
               var1.open();
            };
            byte var11 = (byte)(898514230 ^ var116);
            Object[] var85 = new Object[var11];
            byte var12 = (byte)(898514224 ^ var116);
            String var13 = nnacygklgn(zmgvbexvgpbltxg(), var116);
            var85[var12] = var13;
            byte var86 = (byte)(898514225 ^ var116);
            var116 = 1300234255 ^ var116;
            String var14 = nnacygklgn(xcdshextzgiudnk(), var116);
            byte var92 = var28.startsWith(var14);
            String var102;
            if (var92 != (2014199103 ^ var116)) {
               var116 = 1039656715 ^ var116;
               byte var108 = (byte)(1174002229 ^ var116);
               var102 = var28.substring(var108);
               var116 = acfcjefbfustriqm(var116, 1298779379);
            } else {
               var116 = 511324118 ^ var116;
               var102 = var28;
               var116 = 1860437038 ^ var116;
            }

            var85[var86] = var102;
            byte var87 = (byte)(143660741 ^ var116);
            String var93 = nnacygklgn(wylbclthjjmofro(), var116);
            var85[var87] = var93;
            byte var88 = (byte)(143660740 ^ var116);
            AuctionItem var95 = this.auctionItem;
            var116 = 101606647 ^ var116;
            String var96 = var95.getSellerName();
            String var97 = String.valueOf(var96);
            var85[var88] = var97;
            byte var89 = (byte)(245264948 ^ var116);
            String var98 = nnacygklgn(qpnvryiypskyyzj(), var116);
            var85[var89] = var98;
            byte var90 = (byte)(245264949 ^ var116);
            AuctionItem var104 = this.auctionItem;
            var116 = 943926996 ^ var116;
            ItemStack var105 = var104.getItemStackDirect();
            Material var106 = var105.getType();
            String var107 = var106.name();
            String var100 = this.formatName(var107);
            var85[var90] = var100;
            var116 = 620298064 ^ var116;
            byte var33 = oOo0KoOo0oOK.confirm(var32, var56, var70, var80, var5, var6, var7, (boolean)var8, var83, var84, var85);
            if (var33 != (304456628 ^ var116)) {
               var116 = 60015751 ^ var116;
               return;
            }

            var116 = 60407852 ^ var116;
         } else {
            var116 = acfcjefbfustriqm(var116, 1799663293);
         }
      }

      byte var35 = this.isShulker;
      int var53;
      if (var35 != (297558936 ^ var116)) {
         var116 = 816850180 ^ var116;
         o0o0oOKo0K var52 = cfg();
         String var69 = nnacygklgn(wpeizduewhcclxu(), var116);
         byte var78 = (byte)(554452650 ^ var116);
         var53 = var52.intAt(var69, var78);
         var116 = 403499766 ^ var116;
      } else {
         var116 = 803747879 ^ var116;
         o0o0oOKo0K var36 = cfg();
         String var57 = nnacygklgn(epeeihhpsurualk(), var116);
         byte var71 = (byte)(1045715876 ^ var116);
         var53 = var36.intAt(var57, var71);
         var116 = 123008981 ^ var116;
      }

      var116 = 567486456 ^ var116;
      byte var37 = AuctionGUI.isNewLore();
      String var54;
      if (var37 != (416517010 ^ var116)) {
         var116 = 864142361 ^ var116;
         byte var49 = this.isShulker;
         if (var49 != (726814603 ^ var116)) {
            var116 = 1116865682 ^ var116;
            o0o0oOKo0K var50 = cfg();
            String var67 = nnacygklgn(ymlfbhavccnkohk(), var116);
            String var76 = nnacygklgn(tbpycnrygbsmyng(), var116);
            var54 = var50.rawStr(var67, var76);
            var116 = acfcjefbfustriqm(var116, 1309067718);
         } else {
            label69:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var116)) {
                  case 66015567:
                     var116 ^= 912624924;
                     break label69;
                  case 154553135:
                  default:
                     throw new IOException();
                  case 390527491:
                     break label69;
                  case 674890686:
               }
            }

            o0o0oOKo0K var51 = cfg();
            String var68 = nnacygklgn(iysifwgmjsxpiui(), var116);
            String var77 = nnacygklgn(udjocudtpvcansf(), var116);
            var54 = var51.rawStr(var68, var77);

            label59:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var116)) {
                  case 144446515:
                     var116 ^= 988889160;
                     break label59;
                  case 806942521:
                  default:
                     throw new IOException();
                  case 1812892276:
                     break;
                  case 2081775021:
                     break label59;
               }
            }
         }
      } else {
         label81:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var116)) {
               case 1689273:
                  var116 ^= 396581563;
               case 454499127:
                  break label81;
               case 1869893662:
                  break;
               case 2013242011:
               default:
                  throw new IOException();
            }
         }

         byte var39 = this.isShulker;
         if (var39 != (259051817 ^ var116)) {
            var116 = 747918519 ^ var116;
            o0o0oOKo0K var47 = cfg();
            String var66 = nnacygklgn(irmqofpvasudghn(), var116);
            String var75 = nnacygklgn(nrpmfofjryxfkvc(), var116);
            var54 = var47.rawStr(var66, var75);
            var116 = 69338945 ^ var116;
         } else {
            var116 = acfcjefbfustriqm(var116, 1924377186);
            o0o0oOKo0K var40 = cfg();
            String var58 = nnacygklgn(gsigzrlrpmpmqkt(), var116);
            String var72 = nnacygklgn(vpajnnntrdqfjcy(), var116);
            var54 = var40.rawStr(var58, var72);
            var116 = 1510341012 ^ var116;
         }
      }

      var116 = 357695766 ^ var116;
      Object var59 = null;
      InventoryHolder var60 = (InventoryHolder)var59;
      String var82 = oOo0KKoOoOK.color(var54);
      Inventory var61 = Bukkit.createInventory(var60, var53, var82);
      this.inventory = var61;
      var116 = 817273524 ^ var116;
      oOoOKo0o0K var42 = oOoOKo0o0K.getInstance();
      Inventory var63 = this.inventory;
      var42.register(var63, this);
      var116 = 1523085764 ^ var116;
      this.decorate();
      var116 = 2099399332 ^ var116;
      Player var45 = this.player;
      Inventory var65 = this.inventory;
      var45.openInventory(var65);
      var116 = 628181300 ^ var116;
   }

   public void decorate() {
      int var176 = 714841052 ^ 2105519643 ^ 1576271025;
      var176 = 675882088 ^ var176;
      Inventory var23 = this.inventory;
      var23.clear();
      var176 = 1184179748 ^ var176;
      byte var24 = AuctionGUI.isNewLore();
      var176 = 715068745 ^ var176;
      AuctionItem var26 = this.auctionItem;
      ItemStack var27 = var26.getItemStack();
      var176 = 1139389414 ^ var176;
      ItemStack var29 = var27.clone();
      var176 = 1526546270 ^ var176;
      byte var31 = var29.hasItemMeta();
      ItemMeta var97;
      if (var31 != (1463833291 ^ var176)) {
         var176 = 929325118 ^ var176;
         var97 = var29.getItemMeta();
         var176 = 111881944 ^ var176;
      } else {
         var176 = 1623756382 ^ var176;
         ItemFactory var96 = Bukkit.getItemFactory();
         Material var132 = var29.getType();
         var97 = var96.getItemMeta(var132);
         var176 = 1359462584 ^ var176;
      }

      var176 = 1751036076 ^ var176;
      Material var98 = var27.getType();
      String var99 = var98.name();
      String var34 = this.formatName(var99);
      var176 = 242617932 ^ var176;
      String var101 = "&f" + var34;
      String var102 = oOo0KKoOoOK.color(var101);
      var97.setDisplayName(var102);
      var176 = 1821829839 ^ var176;
      if (var24 != (1815169026 ^ var176)) {
         var176 = 974648629 ^ var176;
         AuctionItem var91 = this.auctionItem;
         double var92 = var91.getPrice();
         String var94 = oOo0KKoOoOK.formatPrice(var92);
         var176 = 1946286464 ^ var176;
         byte var128 = (byte)(572998838 ^ var176);
         String[] var129 = new String[var128];
         byte var145 = (byte)(572998839 ^ var176);
         String var170 = nnacygklgn(ywkumaewffzyuzz(), var176);
         byte var164 = var94.startsWith(var170);
         String var165;
         if (var164 == (572998839 ^ var176)) {
            var176 = 717594439 ^ var176;
            var165 = var94;
            var176 = 1221814358 ^ var176;
         } else {
            var176 = 382865235 ^ var176;
            byte var171 = (byte)(888490981 ^ var176);
            var165 = var94.substring(var171);

            label167:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var176)) {
                  case 15731460:
                     break label167;
                  case 110852092:
                     var176 ^= 1959065666;
                     break label167;
                  case 731692777:
                  default:
                     throw new IOException();
                  case 1846182477:
               }
            }
         }

         String var166 = "#FFFFFFPrice: #00FF00" + var165;
         String var167 = oOo0KKoOoOK.color(var166);
         var129[var145] = var167;
         List var130 = Arrays.asList(var129);
         var97.setLore(var130);
         var176 = 1983482498 ^ var176;
         var176 = acfcjefbfustriqm(var176, 1065467063);
      } else {
         var176 = 899672493 ^ var176;
         byte var103 = (byte)(1504616877 ^ var176);
         String[] var104 = new String[var103];
         byte var3 = (byte)(1504616879 ^ var176);
         AuctionItem var146 = this.auctionItem;
         double var147 = var146.getPrice();
         String var149 = oOo0KKoOoOK.formatPrice(var147);
         String var150 = "&fPrice: #1FFD98" + var149;
         String var151 = oOo0KKoOoOK.color(var150);
         var104[var3] = var151;
         byte var142 = (byte)(1504616878 ^ var176);
         AuctionItem var153 = this.auctionItem;
         String var154 = var153.getSellerName();
         String var155 = "&fSeller: #1FFD98" + var154;
         String var156 = oOo0KKoOoOK.color(var155);
         var104[var142] = var156;
         List var105 = Arrays.asList(var104);
         var97.setLore(var105);
         var176 = 1344742460 ^ var176;
      }

      boolean var39 = var29.setItemMeta(var97);
      var176 = 1904414705 ^ var176;
      Inventory var41 = this.inventory;
      byte var107 = (byte)(2013956719 ^ var176);
      var41.setItem(var107, var29);
      var176 = 363636779 ^ var176;
      Material var136 = Material.RED_STAINED_GLASS_PANE;
      ItemStack var42 = new ItemStack(var136);
      var176 = 1331775120 ^ var176;
      ItemMeta var44 = var42.getItemMeta();
      var176 = 1583995914 ^ var176;
      String var134;
      if (var24 != (2091825363 ^ var176)) {
         var176 = 2038049912 ^ var176;
         var134 = nnacygklgn(dkfbbimenwzpwry(), var176);
         var176 = acfcjefbfustriqm(var176, 169024195);
      } else {
         var176 = 2014669444 ^ var176;
         var134 = nnacygklgn(yzkmgnryhrafdme(), var176);
         var176 = 192699455 ^ var176;
      }

      String var109 = oOo0KKoOoOK.color(var134);
      var44.setDisplayName(var109);
      var176 = 1691064184 ^ var176;
      if (var24 != (1795954960 ^ var176)) {
         var176 = 1659390699 ^ var176;
         byte var110 = (byte)(165958650 ^ var176);
         String[] var111 = new String[var110];
         byte var143 = (byte)(165958651 ^ var176);
         o0o0oOKo0K var157 = cfg();
         String var5 = nnacygklgn(rqqxxifafvvnoco(), var176);
         String var6 = nnacygklgn(byicilimoykedro(), var176);
         String var158 = var157.rawStr(var5, var6);
         String var159 = oOo0KKoOoOK.color(var158);
         var111[var143] = var159;
         List var112 = Arrays.asList(var111);
         var44.setLore(var112);
         var176 = 1253653948 ^ var176;
      } else {
         label150:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var176)) {
               case 258415491:
                  var176 ^= 676427607;
                  break label150;
               case 404657242:
                  break;
               case 535387205:
               default:
                  throw new IOException();
               case 946344330:
                  break label150;
            }
         }
      }

      boolean var49 = var42.setItemMeta(var44);
      var176 = 571051442 ^ var176;
      Inventory var51 = this.inventory;
      byte var114 = (byte)(1632953342 ^ var176);
      var51.setItem(var114, var42);
      var176 = 1187114548 ^ var176;
      Material var138 = Material.LIME_STAINED_GLASS_PANE;
      ItemStack var52 = new ItemStack(var138);
      var176 = 1069936787 ^ var176;
      ItemMeta var54 = var52.getItemMeta();
      var176 = 1543675822 ^ var176;
      String var133;
      if (var24 != (1146249980 ^ var176)) {
         var176 = 904959103 ^ var176;
         var133 = nnacygklgn(pxunjinmuejtmhj(), var176);
         var176 = 1444452140 ^ var176;
      } else {
         var176 = acfcjefbfustriqm(var176, 857279056);
         var133 = nnacygklgn(pbyztzagizudtbg(), var176);
         var176 = 1357973763 ^ var176;
      }

      String var116 = oOo0KKoOoOK.color(var133);
      var54.setDisplayName(var116);
      var176 = 1882724402 ^ var176;
      if (var24 != (1468168605 ^ var176)) {
         var176 = 363014706 ^ var176;
         byte var117 = (byte)(1109480366 ^ var176);
         String[] var118 = new String[var117];
         byte var144 = (byte)(1109480367 ^ var176);
         o0o0oOKo0K var160 = cfg();
         String var169 = nnacygklgn(qwkbbpjbfxkrlex(), var176);
         String var172 = nnacygklgn(thmlqkufugxjaww(), var176);
         String var161 = var160.rawStr(var169, var172);
         String var162 = oOo0KKoOoOK.color(var161);
         var118[var144] = var162;
         List var119 = Arrays.asList(var118);
         var54.setLore(var119);
         var176 = 17044349 ^ var176;
      } else {
         var176 = acfcjefbfustriqm(var176, 346503503);
      }

      boolean var59 = var52.setItemMeta(var54);
      var176 = 336799728 ^ var176;
      Inventory var61 = this.inventory;
      byte var121 = (byte)(1463183149 ^ var176);
      var61.setItem(var121, var52);
      var176 = 357009156 ^ var176;
      byte var63 = this.isShulker;
      if (var63 == (1114759206 ^ var176)) {
         var176 = acfcjefbfustriqm(var176, 994150349);
      } else {
         var176 = 507641638 ^ var176;
         ItemMeta var65 = var27.getItemMeta();
         var176 = 1089171588 ^ var176;
         byte var67 = var65 instanceof BlockStateMeta;
         if (var67 != (484142980 ^ var176)) {
            var176 = 1189396231 ^ var176;
            BlockStateMeta var69 = (BlockStateMeta)var65;
            var176 = 146781735 ^ var176;
            BlockState var71 = var69.getBlockState();
            var176 = 818463038 ^ var176;
            byte var73 = var71 instanceof ShulkerBox;
            if (var73 != (1648928666 ^ var176)) {
               var176 = 1341843505 ^ var176;
               ShulkerBox var75 = (ShulkerBox)var71;
               ShulkerBox var19 = var75;
               var176 = 582821248 ^ var176;
               byte var76 = (byte)(252668459 ^ var176);
               int var20 = var76;
               var176 = 893503616 ^ var176;

               label111:
               while(true) {
                  byte var122 = (byte)(978231984 ^ var176);
                  if (var20 >= var122) {
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var176)) {
                           case 16277861:
                              var176 = 1132381504 ^ var176;
                              return;
                           case 280971385:
                              break;
                           case 742947207:
                              return;
                           case 1555470663:
                           default:
                              throw new IOException();
                        }
                     }
                  }

                  var176 = 748416671 ^ var176;
                  Inventory var79 = var19.getInventory();
                  ItemStack var80 = var79.getItem(var20);
                  var176 = 206974957 ^ var176;
                  if (var80 == null) {
                     var176 = acfcjefbfustriqm(var176, 1292617514);
                  } else {
                     var176 = 1990213428 ^ var176;
                     Material var83 = var80.getType();
                     byte var84 = var83.isAir();
                     if (var84 == (1814256877 ^ var176)) {
                        var176 = 626453269 ^ var176;
                        ItemStack var86 = var80.clone();
                        var176 = 2098758228 ^ var176;
                        Object var124 = null;
                        List var125 = (List)var124;
                        var86.setLore(var125);
                        var176 = 801676025 ^ var176;
                        Inventory var89 = this.inventory;
                        byte var126 = (byte)(463843150 ^ var176);
                        int var127 = var126 + var20;
                        var89.setItem(var127, var86);
                        var176 = 1278020518 ^ var176;
                     } else {
                        label92:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var176)) {
                              case 25487400:
                                 var176 ^= 1001125918;
                                 break label92;
                              case 1359685534:
                              default:
                                 throw new IOException();
                              case 1633408642:
                                 break;
                              case 2002422347:
                                 break label92;
                           }
                        }
                     }
                  }

                  var20 += 1468572914 ^ var176;

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var176)) {
                        case 161015838:
                           var176 ^= 1841694296;
                           continue label111;
                        case 1386571103:
                           break;
                        case 1440867720:
                        default:
                           throw new IOException();
                        case 1819469347:
                           continue label111;
                     }
                  }
               }
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var176)) {
                     case 9722287:
                        return;
                     case 242001650:
                        var176 = 460898417 ^ var176;
                        return;
                     case 442590180:
                        break;
                     case 942032909:
                     default:
                        throw new IOException();
                  }
               }
            }
         } else {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var176)) {
                  case 132723924:
                     var176 = 1709901935 ^ var176;
                     return;
                  case 175861000:
                  default:
                     throw new IOException();
                  case 1286530849:
                     break;
                  case 1478091072:
                     return;
               }
            }
         }
      }
   }

   public void onClick(InventoryClickEvent var1) {
      int var21 = 500387496 ^ 1733373228 ^ 1576271025;
      var21 = 1797018196 ^ var21;
      byte var3 = (byte)(1282264416 ^ var21);
      var1.setCancelled((boolean)var3);
      var21 = 1372344484 ^ var21;
      int var6 = var1.getRawSlot();
      byte var14 = (byte)(497130958 ^ var21);
      if (var6 == var14) {
         var21 = 311985973 ^ var21;
         Player var17 = this.player;
         AuctionGUI var7 = new AuctionGUI(var17);
         var7.open();
         var21 = 1338334280 ^ var21;
      } else {
         var21 = acfcjefbfustriqm(var21, 819143891);
         int var9 = var1.getRawSlot();
         byte var15 = (byte)(762493209 ^ var21);
         if (var9 == var15) {
            var21 = 522896388 ^ var21;
            byte var10 = AuctionGUI.isNewLore();
            if (var10 != (844659986 ^ var21)) {
               var21 = 1721944120 ^ var21;
               Player var12 = this.player;
               String var16 = nnacygklgn(sjwsbfzyewsqysm(), var21);
               String var18 = nnacygklgn(cynxtnypnvazjrx(), var21);
               AuctionComponent.play(var12, var16, var18);
               var21 = 1437795291 ^ var21;
            } else {
               var21 = 856804323 ^ var21;
            }

            this.purchase();
            var21 = 885268851 ^ var21;
         } else {
            var21 = acfcjefbfustriqm(var21, 419376788);
         }

      }
   }

   private void purchase() {
      int var153 = 569226563 ^ 130074410 ^ 1576271025;
      var153 = 786141374 ^ var153;
      DonutSMPCore var1 = DonutSMPCore.getInstance();
      Economy var11 = var1.getEconomy();
      var153 = 100183054 ^ var153;
      if (var11 != null) {
         var153 = 1939443354 ^ var153;
         Player var63 = this.player;
         AuctionItem var97 = this.auctionItem;
         double var98 = var97.getPrice();
         byte var14 = var11.has(var63, var98);
         if (var14 != (593771762 ^ var153)) {
            var153 = acfcjefbfustriqm(var153, 384267966);
            Ko0KoOKoOK var15 = Ko0KoOKoOK.getInstance();
            List var16 = var15.getActiveItems();
            AuctionItem var65 = this.auctionItem;
            byte var17 = var16.contains(var65);
            if (var17 == (897796684 ^ var153)) {
               var153 = 1194899055 ^ var153;
               Player var19 = this.player;
               o0o0oOKo0K var66 = cfg();
               String var100 = nnacygklgn(elqfgxpirjvvjha(), var153);
               String var4 = nnacygklgn(ekesdpigbdiauqo(), var153);
               String var67 = var66.rawStr(var100, var4);
               String var68 = oOo0KKoOoOK.color(var67);
               var19.sendMessage(var68);
               var153 = 274807600 ^ var153;
               Player var102 = this.player;
               AuctionGUI var20 = new AuctionGUI(var102);
               var20.open();
               var153 = 1798853534 ^ var153;
               return;
            }

            var153 = acfcjefbfustriqm(var153, 487532623);
            AuctionItem var22 = this.auctionItem;
            double var23 = var22.getPrice();
            var153 = 1285031406 ^ var153;
            Ko0KoOKoOK var25 = Ko0KoOKoOK.getInstance();
            AuctionItem var70 = this.auctionItem;
            byte var26 = var25.removeItem(var70);
            if (var26 == (1679058925 ^ var153)) {
               var153 = 976246446 ^ var153;
               Player var28 = this.player;
               o0o0oOKo0K var71 = cfg();
               String var103 = nnacygklgn(xfztmkollwjyjvb(), var153);
               String var125 = nnacygklgn(jditywlrwimqgvn(), var153);
               String var72 = var71.rawStr(var103, var125);
               String var73 = oOo0KKoOoOK.color(var72);
               var28.sendMessage(var73);
               var153 = 1460980479 ^ var153;
               Player var30 = this.player;
               String var74 = nnacygklgn(eqbkuwfkyfpwyem(), var153);
               Sound var104 = Sound.ENTITY_VILLAGER_NO;
               float var126 = 1.0F;
               float var5 = 1.0F;
               KKo0KoOoOK.play(var30, var74, var104, var126, var5);
               var153 = 330299455 ^ var153;
               Player var106 = this.player;
               AuctionGUI var31 = new AuctionGUI(var106);
               var31.open();
               var153 = 771725811 ^ var153;
               return;
            }

            var153 = acfcjefbfustriqm(var153, 99009768);
            Player var76 = this.player;
            var11.withdrawPlayer(var76, var23);
            var153 = 382887327 ^ var153;
            AuctionItem var35 = this.auctionItem;
            UUID var36 = var35.getSeller();
            OfflinePlayer var37 = Bukkit.getOfflinePlayer(var36);
            var153 = 1753588026 ^ var153;
            var11.depositPlayer(var37, var23);
            var153 = 2024075823 ^ var153;
            Player var41 = this.player;
            String var78 = nnacygklgn(iovntoysveilnow(), var153);
            String var111 = nnacygklgn(nslkfzuqfikigwm(), var153);
            var153 = 44222983 ^ var153;
            String var79 = AuctionComponent.msg(var78, var111);
            String var112 = nnacygklgn(eriwhaebziraglm(), var153);
            AuctionItem var140 = this.auctionItem;
            var153 = 1796193010 ^ var153;
            ItemStack var141 = var140.getItemStackDirect();
            Material var142 = var141.getType();
            String var143 = var142.name();
            String var128 = this.formatName(var143);
            String var80 = var79.replace(var112, var128);
            String var113 = nnacygklgn(pivfvavwxmghyst(), var153);
            var153 = 1185792439 ^ var153;
            String var131 = oOo0KKoOoOK.formatPrice(var23);
            String var81 = var80.replace(var113, var131);
            var153 = 6840774 ^ var153;
            String var82 = oOo0KKoOoOK.color(var81);
            var41.sendMessage(var82);
            var153 = 1638883087 ^ var153;
            Player var43 = this.player;
            String var83 = nnacygklgn(srhbjvotqjnzvxn(), var153);
            String var114 = nnacygklgn(lisyoviddtwessk(), var153);
            float var132 = 1.0F;
            float var144 = 1.2F;
            AuctionComponent.play(var43, var83, var114, var132, var144);
            var153 = 1485681994 ^ var153;
            Player var45 = this.player;
            UUID var46 = var45.getUniqueId();
            AuctionItem var85 = this.auctionItem;
            UUID var86 = var85.getSeller();
            AuctionItem var116 = this.auctionItem;
            ItemStack var117 = var116.getItemStack();
            TransactionHistory.logPurchase(var46, var86, var117, var23);
            var153 = 211818540 ^ var153;
            Player var48 = this.player;
            PlayerInventory var49 = var48.getInventory();
            byte var87 = (byte)(2112599907 ^ var153);
            ItemStack[] var88 = new ItemStack[var87];
            byte var135 = (byte)(2112599906 ^ var153);
            AuctionItem var146 = this.auctionItem;
            ItemStack var147 = var146.getItemStack();
            ItemStack var148 = KoOo0oOo0oOK.thaw(var147);
            var88[var135] = var148;
            HashMap var50 = var49.addItem(var88);
            var153 = 1292462525 ^ var153;
            Collection var52 = var50.values();
            Consumer var90 = (var1x) -> {
               int var12 = 841154721 ^ 1104367683 ^ 1576271025;
               var12 = 1062249470 ^ var12;
               Player var5 = this.player;
               World var6 = var5.getWorld();
               Player var8 = this.player;
               Location var9 = var8.getLocation();
               var6.dropItem(var9, var1x);
            };
            var52.forEach(var90);
            var153 = 1585129121 ^ var153;
            Ko0KoOKoOK var53 = Ko0KoOKoOK.getInstance();
            AuctionItem var92 = this.auctionItem;
            Player var119 = this.player;
            var53.notifySellerOfPurchase(var92, var119, var23);
            var153 = 728658001 ^ var153;
            Player var121 = this.player;
            AuctionGUI var54 = new AuctionGUI(var121);
            var54.open();
            var153 = 1533497329 ^ var153;
            return;
         }

         var153 = 902827122 ^ var153;
      } else {
         label30:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var153)) {
               case 110239133:
                  break label30;
               case 216783188:
                  var153 ^= 1179222760;
                  break label30;
               case 610027330:
                  break;
               case 1745843713:
               default:
                  throw new IOException();
            }
         }
      }

      String var55 = nnacygklgn(rnnzpnwhpnhtdup(), var153);
      var153 = 1421864360 ^ var153;
      Player var57 = this.player;
      String var93 = nnacygklgn(uzkjjzuzuakcvpe(), var153);
      String var94 = oOo0KKoOoOK.color(var93);
      var57.sendMessage(var94);
      var153 = 1019238539 ^ var153;
      Player var59 = this.player;
      String var95 = nnacygklgn(fdxywjgcrtytjgv(), var153);
      oOo0KKoOoOK.sendActionBar(var59, var95);
      var153 = 1452236293 ^ var153;
      Player var61 = this.player;
      String var96 = nnacygklgn(mdbfjhxixiggrnd(), var153);
      Sound var122 = Sound.ENTITY_VILLAGER_NO;
      float var138 = 1.0F;
      float var149 = 1.0F;
      KKo0KoOoOK.play(var61, var96, var122, var138, var149);
      var153 = 1924474515 ^ var153;
      Player var124 = this.player;
      AuctionGUI var62 = new AuctionGUI(var124);
      var62.open();
      var153 = 1815738840 ^ var153;
   }

   private String formatName(String var1) {
      int var24 = 1507796009 ^ 977153662 ^ 1576271025;
      var24 = 3869816 ^ var24;
      String var6 = o0oOoOo0oOK.material(var1);
      var24 = 1982822737 ^ var24;
      if (var6 != null) {
         var24 = 736168487 ^ var24;
         return var6;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var24)) {
               case 193779559:
                  var24 ^= 814679931;
               case 1522393748:
                  String var3 = nnacygklgn(zcttqxgplvhsqle(), var24);
                  String var4 = nnacygklgn(bnujsvaprfnjvig(), var24);
                  String var10 = var1.replace(var3, var4);
                  String var11 = var10.toLowerCase();
                  String var18 = nnacygklgn(qqppsymdeakhhot(), var24);
                  String[] var12 = var11.split(var18);
                  Stream var13 = Arrays.stream(var12);
                  Function var19 = (var0) -> {
                     int var13 = 255379651 ^ 1516277630 ^ 349960680;
                     var13 = 900025088 ^ var13;
                     byte var4 = var0.isEmpty();
                     String var8;
                     if (var4 == (1948710229 ^ var13)) {
                        var13 = acfcjefbfustriqm(var13, 913831148);
                        byte var2 = (byte)(1112605113 ^ var13);
                        char var6 = var0.charAt(var2);
                        char var7 = Character.toUpperCase(var6);
                        byte var3 = (byte)(1112605112 ^ var13);
                        String var10 = var0.substring(var3);
                        var8 = var7 + var10;
                        var13 = 764460614 ^ var13;
                        return var8;
                     } else {
                        var13 = 1498286711 ^ var13;
                        var8 = nnacygklgn(ezcrfgalgffvvoc(), var13);

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var13)) {
                              case 29353853:
                                 break;
                              case 133907257:
                                 var13 = 1118388445 ^ var13;
                                 return var8;
                              case 1735420890:
                              default:
                                 throw new RuntimeException();
                              case 1838844023:
                                 return var8;
                           }
                        }
                     }
                  };
                  Stream var14 = var13.map(var19);
                  BinaryOperator var20 = (var0, var1x) -> {
                     int var7 = 1267895138 ^ 2076223112 ^ 349960680;
                     var7 = 1648720532 ^ var7;
                     String var4 = var0 + " " + var1x;
                     return var4;
                  };
                  Optional var15 = var14.reduce(var20);
                  Object var16 = var15.orElse(var1);
                  String var17 = (String)var16;
                  return var17;
               case 1670655567:
                  break;
               case 1793045767:
               default:
                  throw new RuntimeException();
            }
         }
      }
   }

   public Inventory createInventory() {
      int var4 = 584943355 ^ 286588918 ^ 1576271025;
      var4 = 1069720858 ^ var4;
      Object var1 = null;
      return (Inventory)var1;
   }

   public static String nnacygklgn(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = zgfjtlyvfe;
         byte[] var34 = zgfjtlyvfe;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   static {
      zgfjtlyvfe = pfchkbhgimuoflo();
   }

   private static byte[] pfchkbhgimuoflo() {
      return new byte[]{45, 93, 88, 100, 25, 56, 117, 89, 95, 30, 12, 40, 122, 123, 91, 5, 29, 42, 29, 100, 22, 19, 72, 121, 70, 9, 72, 121, 100, 5, 61, 46, 40, 87, 88, 21, 126, 2, 7, 93, 78, 94, 14, 11, 43, 125, 122, 114, 78, 67, 47, 119, 31, 9, 40, 122, 100, 21, 111, 16, 125, 27, 88, 5, 113, 62, 21, 31, 105, 9, 122, 41, 36, 33, 47, 4, 127};
   }

   private static byte[] slswwjlislypsjx() {
      return new byte[]{-30, -111, 111, 55, 46, 127, 70, 4, 105, 91, 61, 52, 77, 46, 108, 66, 46, 125, 43, 38, 39, 73, 127, 34, 113, 85, 123, 98, 82, 80, 12, 114, 31, 13, 111, 65, 77, 95, 49, 25, 127, 0, 57, 79, 28, 58, 73, 52, 120, 22, 30, 44, 40, 92, 31, 59, 87, 68, 89, 65, 76, 93, 111, 88};
   }

   private static byte[] ezcrfgalgffvvoc() {
      return new byte[0];
   }

   private static byte[] iysifwgmjsxpiui() {
      return new byte[]{-25, -101, 104, 33, 32, 98, 64, 24, 102, 70, 53, 125, 75, 111, 104, 94, 40, 118, 41, 42};
   }

   private static byte[] udjocudtpvcansf() {
      return new byte[]{-25, -101, 104, 22, 32, 100, 64, 2, 102, 76, 53, 113, 75, 48, 104, 93, 40, 51, 41, 13, 38, 87, 113, 56, 115, 95, 113, 37, 93, 84, 12, 100, 27, 7};
   }

   private static byte[] ymlfbhavccnkohk() {
      return new byte[]{-30, -107, 111, 36, 43, 97, 76, 21, 110, 69, 61, 122, 77, 98, 105, 91, 36, 119, 44, 36, 39, 9, 127, 62, 116, 81, 113, 52, 85, 94, 12, 114, 31, 6, 106, 87};
   }

   private static byte[] tbpycnrygbsmyng() {
      return new byte[]{-30, -107, 111, 19, 43, 103, 76, 15, 110, 79, 61, 118, 77, 61, 105, 88, 36, 50, 44, 3, 39, 81, 127, 63, 116, 90, 113, 41, 85, 83, 12, 106, 31, 6, 106, 5, 71, 91, 54, 4, 127, 13, 57, 31, 25, 29, 67, 56, 127, 17, 30, 54, 40, 84, 26, 47, 93, 90};
   }

   private static byte[] xcdshextzgiudnk() {
      return new byte[]{-31, -110, 105, 116};
   }

   private static byte[] irmqofpvasudghn() {
      return new byte[]{-27, -110, 106, 33, 46, 105, 76, 26, 107, 68, 60, 127, 75, 97, 99, 79, 42, 118, 43, 33, 36, 78, 127, 42, 127, 91, 124, 61};
   }

   private static byte[] nrpmfofjryxfkvc() {
      return new byte[]{-27, -110, 119, 81, 51, 15, 78, 26, 111, -69, 62, 112, 73, -52, 126, 49, 42, 62, 54, 76, 57, 62, 125, -63, 98, 58, 126, -45, 73, 55, 12, 106, 13, 105, 111, 1, 85, 50, 55, 24, 100, 99, 55, 28, 2, 83, 72, -64, 98, 115, 10, 110, 42, 87, 3, 77, 75, 5};
   }

   private static byte[] frkuavuqoxkpvgx() {
      return new byte[]{-21, -101, 96, 114, 40, 60, 71, 91, 107, 96, 53, 86, 79, 122, 111, 7, 47, 58, 37, 125, 46, 5, 121, 11, 116, 125, 124, 7, 93, 123, 8, 89, 28, 35, 106, 4, 70, 75, 63, 26, 127, 3, 60, 90, 31, 32, 67, 111};
   }

   private static byte[] zpprkdvrkuwnukv() {
      return new byte[]{-21, -101, 96, 114, 40, 74, 71, 45, 107, 19, 53, 37, 79, 127, 111, 2, 47, 80, 37, 50};
   }

   private static byte[] zwrvcgdxmallqgb() {
      return new byte[]{-21, -101, 96, 114, 40, 57, 71, 94, 107, 96, 53, 86, 79, 127, 111, 2, 47, 71, 37, 56, 46, 85};
   }

   private static byte[] zmgvbexvgpbltxg() {
      return new byte[]{-21, -101, 96, 116, 40, 124, 71, 25, 107, 79, 53, 115, 79, 47, 111, 18};
   }

   private static byte[] epeeihhpsurualk() {
      return new byte[]{-30, -110, 108, 34, 46, 96, 64, 26, 111, 72};
   }

   private static byte[] qpnvryiypskyyzj() {
      return new byte[]{-31, -106, 109, 115, 47, 101, 76, 25, 107, 73, 56, 112, 72, 104};
   }

   private static byte[] wylbclthjjmofro() {
      return new byte[]{-30, -106, 107, 119, 47, 123, 66, 8, 108, 67, 56, 119, 76, 40, 107, 64, 41, 60};
   }

   private static byte[] wpeizduewhcclxu() {
      return new byte[]{-26, -105, 108, 35, 44, 99, 67, 16, 105, 78, 57, 49, 78, 61, 105, 91, 46, 105, 40, 61, 34, 76, 125, 46, 112, 72};
   }

   private static byte[] hivcqsabhqjzdwh() {
      return new byte[]{-28, -109, 111, 61, 45, 120, 76, 3, 109, 93, 61, 118, 66, 32, 110, 82, 36, 53, 42, 55, 33, 94, 124, 53};
   }

   private static byte[] nxuhouvyhodskot() {
      return new byte[]{-28, -109, 111, 127, 45, 75, 76, 38, 109, 111, 61, 89, 66, 9, 110, 122, 36, 89, 42, 39, 33, 78, 124, 108, 127, 73, 122, 33, 85, 71, 5, 58, 29, 29, 97, 82, 73, 65, 48, 0, 122, 75, 55, 75, 25, 37, 75, 48, 118, 87, 26, 57, 38, 90, 31, 37, 83, 89, 91, 5, 68, 86, 106, 93, 64, 41, 45, 73, 92, 69, 67, 98, 19, 48, 24, 72, 75, 112, 100, 8, 86, 93, 9, 125};
   }

   private static byte[] ltzsawqakcxqzzo() {
      return new byte[]{-30, -112, 96, 51, 44, 120, 65, 14, 105, 82, 61, 115, 66, 34, 110, 94, 41, 51, 43, 62, 39, 84, 112, 54};
   }

   private static byte[] echgorfhdetabwv() {
      return new byte[]{-25, -101, 110, 49, 44, 96, 68, 1, 107, 65, 58, 119, 79, 62, 106, 94, 41, 119, 43, 59, 35, 69, 121, 35, 114, 95, 126, 40};
   }

   private static byte[] urvbmlbjcybvnvt() {
      return new byte[]{-25, -101, 110, 51, 44, 122, 68, 12, 107, 83, 58, 119, 79, 35, 106, 93, 41, 62, 43, 48, 35, 81, 121, 54, 114, 30, 126, 60, 81, 90, 12, 109, 28, 2, 110, 72, 75, 80, 54, 25, 122, 74, 56, 72, 30, 57, 75, 33, 122, 9, 25, 108, 42, 83, 25, 41, 80, 66, 89, 83};
   }

   private static byte[] gsigzrlrpmpmqkt() {
      return new byte[]{-31, -109, 104, 41, 32, 103, 70, 29, 103, 65, 62, 124};
   }

   private static byte[] vpajnnntrdqfjcy() {
      return new byte[]{-31, -109, 117, 89, 61, 1, 68, 29, 99, -66, 60, 115, 72, -62, 127, 62, 46, 58, 56, 79, 57, 62, 122, -64, 98, 59, 121, -43, 65, 54, 15, 108, 5, 105};
   }

   private static byte[] pbyztzagizudtbg() {
      return new byte[]{-31, -110, 104, 118, 45, 56, 69, 47, 111, 104, 62, 94, 74, 122, 111, 6, 48, 25, 48, 91, 38, 87, 124, -37, 112, 80, 122, -50, 73, 56};
   }

   private static byte[] rqqxxifafvvnoco() {
      return new byte[]{-30, -108, 109, 41, 44, 101, 67, 20, 110, 91, 58, 51, 67, 45, 99, 95, 40, 114, 44, 49, 35, 65, 125, 108, 112, 72, 121, 39, 82, 29, 4, 120, 16, 0, 109, 74, 79, 87, 50, 1, 123, 10};
   }

   private static byte[] byicilimoykedro() {
      return new byte[]{-30, -108, 109, 126, 44, 65, 67, 45, 110, 110, 58, 92, 67, 15, 99, 114, 40, 88, 44, 62, 35, 67, 125, 34, 112, 87, 121, 104, 82, 68, 4, 116, 16, 65, 109, 71, 79, 85, 50, 10, 123, 5, 56, 91, 26, 32};
   }

   private static byte[] yzkmgnryhrafdme() {
      return new byte[]{-28, -101, 108, 118, 46, 71, 65, 44, 104, 22, 56, 93, 77, 115, 111, 114, 55, 23, 52, 85, 35, 94, 97, 78, 108, 55, 126, -41};
   }

   private static byte[] ywkumaewffzyuzz() {
      return new byte[]{-26, -107, 106, 121};
   }

   private static byte[] dkfbbimenwzpwry() {
      return new byte[]{-22, -107, 96, 118, 46, 73, 66, 46, 102, 111, 52, 95, 77, 10, 108, 114, 36, 94, 37, 52, 33, 74, 127, 43, 127, 91, 112, 36};
   }

   private static byte[] pxunjinmuejtmhj() {
      return new byte[]{-30, -101, 104, 113, 44, 78, 64, 44, 107, 111, 61, 87, 74, 11, 110, 115, 40, 90, 41, 60, 39, 68, 120, 41, 115, 80, 125, 56, 80, 95};
   }

   private static byte[] qwkbbpjbfxkrlex() {
      return new byte[]{-30, -109, 104, 41, 45, 101, 69, 18, 105, 93, 61, 55, 74, 33, 111, 81, 45, 112, 43, 48, 39, 73, 120, 109, 114, 69, 120, 37, 82, 31, 12, 125, 24, 27, 108, 84};
   }

   private static byte[] thmlqkufugxjaww() {
      return new byte[]{-30, -109, 104, 126, 45, 65, 69, 43, 105, 104, 61, 88, 74, 3, 111, 124, 45, 90, 43, 63, 39, 75, 120, 35, 114, 90, 120, 106, 82, 70, 12, 112, 24, 78, 108, 79, 78, 68, 49, 19};
   }

   private static byte[] sjwsbfzyewsqysm() {
      return new byte[]{-30, -106, 106, 50, 46, 101, 67, 5, 109, 79, 61, 119};
   }

   private static byte[] cynxtnypnvazjrx() {
      return new byte[]{-30, -106, 106, 19, 46, 69, 67, 35, 109, 111, 61, 87, 72, 17, 108, 119, 43, 87, 47, 19, 39, 117, 122, 30, 113, 97, 126, 19, 86, 96, 12, 85, 26, 45, 111, 96, 72, 104, 53, 45, 127, 63, 60, 106, 28, 24, 76, 8, 124, 63, 30, 28, 45, 127, 31, 7, 82, 105, 93, 97, 76, 100, 106, 111, 70, 64, 35, 100};
   }

   private static byte[] eqbkuwfkyfpwyem() {
      return new byte[]{-30, -105, 108, 55, 41, 120, 68, 11, 105, 91, 57, 117, 72, 36, 110, 90, 44, 50, 44, 50, 34, 78, 120, 34, 119, 94, 126, 33, 81, 67, 15, 115, 29, 22, 105, 86, 79, 69, 51, 12, 126, 3, 63, 91, 29, 63, 79, 35, 124, 20, 26, 51, 46, 86, 25, 97, 80, 67, 95, 64, 76, 68, 110, 77, 68, 56};
   }

   private static byte[] pivfvavwxmghyst() {
      return new byte[]{-31, -106, 110, 115, 40, 121, 76, 29, 109, 69, 56, 125, 72, 47, 106, 25};
   }

   private static byte[] eriwhaebziraglm() {
      return new byte[]{-30, -107, 104, 116, 43, 97, 64, 27, 107, 75, 61, 114, 74, 107};
   }

   private static byte[] fdxywjgcrtytjgv() {
      return new byte[]{-31, -109, 106, 112, 43, 72, 66, 45, 108, 30, 62, 44, 72, 121, 105, 6, 42, 65, 46, 62, 36, 87, 122, 110, 116, 91, 127, 36, 87, 94, 15, 56, 26, 20, 106, 3, 73, 88, 52, 9, 124, 25, 60, 89, 25, 107, 77, 37, 125, 24, 29, 41, 45, 75, 26, 43, 83, 79, 92, 5, 79, 71, 106, 93, 67, 102, 34, 72, 90, 69, 72, 56, 22, 112, 29, 93, 72, 109, 110, 77, 86, 92, 10, 42, 107, 0, 41, 77, 27, 97};
   }

   private static byte[] mdbfjhxixiggrnd() {
      return new byte[]{-27, -107, 109, 51, 41, 124, 70, 11, 103, 92, 59, 116, 76, 36, 106, 88, 44, 60, 43, 48, 35, 74, 120, 38, 117, 94, 112, 38, 83, 66, 11, 115, 25, 20, 105, 88, 72, 71, 50, 8, 126, 7, 61, 91, 19, 56, 77, 34, 120, 20, 30, 49, 46, 88, 30, 99, 81, 71, 95, 68, 78, 68, 96, 74};
   }

   private static byte[] iovntoysveilnow() {
      return new byte[]{-30, -107, 106, 44, 40, 120, 66, 27, 104, 76, 61, 119, 72, 34, 106, 67, 42, 127, 42, 49};
   }

   private static byte[] nslkfzuqfikigwm() {
      return new byte[]{-30, -107, 106, 122, 40, 108, 66, 48, 104, 64, 61, 106, 72, 99, 106, 64, 42, 111, 42, 39, 39, 71, 122, 41, 119, 93, 127, 58, 83, 81, 12, 125, 26, 79, 105, 6, 73, 84, 48, 73, 127, 0, 60, 71, 26, 45, 77, 47, 121, 87, 30, 96, 45, 23, 25, 46, 83, 67, 88, 78, 76, 94, 106, 29, 64, 40, 34, 30, 94, 126, 75, 88, 22, 93, 30, 8, 72, 37, 106, 76, 85, 94, 10, 63, 104, 3, 41, 95, 31, 46, 74, 73};
   }

   private static byte[] elqfgxpirjvvjha() {
      return new byte[]{-30, -101, 106, 36, 32, 111, 71, 21, 111, 89, 61, 63, 72, 59, 98, 95, 47, 119, 45, 36, 39, 7, 122, 36, 127, 79, 122, 40, 84, 91, 12, 58, 26, 10, 97, 84, 76, 27, 55, 0, 127, 8, 60, 18, 18, 35, 72, 41, 126, 30, 30, 41, 45, 88, 17, 58, 86, 12, 95, 66, 76, 84, 106, 80, 72, 101, 39, 71, 89, 91, 75, 114, 22, 121, 22, 83, 77, 52, 109, 10, 85, 76, 10, 51, 96, 8, 44, 89, 24, 45, 74, 27, 55, 4, 19, 77, 86, 77, 35, 14, 72, 24, 59, 20, 64, 34, 55, 36, 30, 116, 102, 19, 39, 103, 59, 80, 111, 2, 110, 77, 58, 123, 79, 60, 75, 25, 113, 127};
   }

   private static byte[] ekesdpigbdiauqo() {
      return new byte[]{-30, -101, 106, 118, 32, 105, 71, 57, 111, 69, 61, 120, 72, 60, 98, 23, 47, 119, 45, 35, 39, 79, 122, 32, 127, 27, 122, 36, 84, 69, 12, 55, 26, 13, 97, 72, 76, 22, 55, 2, 127, 8, 60, 81, 18, 40, 72, 35, 126, 2, 30, 110, 45, 92, 17, 62, 86, 64, 95, 74, 76, 78, 106, 80, 72, 110, 39, 71, 89, 95, 75, 48, 22, 61, 22, 87, 77, 117, 109, 25, 85, 69, 10, 32, 96, 9, 44, 65, 24, 105, 74, 0, 55, 70, 19, 90, 86, 69, 35, 19, 72, 11, 59, 92, 64, 57, 55, 123, 30, 59, 102, 4, 39, 50, 59, 69, 111, 19, 110, 79, 58, 119, 79, 42, 75, 85, 113, 53};
   }

   private static byte[] srhbjvotqjnzvxn() {
      return new byte[]{-28, -110, 104, 44, 45, 117, 67, 31, 107, 74, 60, 112, 66, 46, 99, 64, 41, 123, 42, 121, 38, 88, 124, 52, 112, 94, 124, 45, 84, 80, 5, 105, 16, 18};
   }

   private static byte[] lisyoviddtwessk() {
      return new byte[]{-28, -110, 104, 25, 45, 78, 67, 57, 107, 96, 60, 76, 66, 22, 99, 108, 41, 78, 42, 24, 38, 106, 124, 24, 112, 120, 124, 28, 84, 106, 5, 86, 16, 36, 108, 119, 73, 119, 55, 41, 122, 51, 56, 111};
   }

   private static byte[] rnnzpnwhpnhtdup() {
      return new byte[]{-32, -102, 104, 126, 41, 73, 67, 43, 103, 24, 52, 45, 67, 126, 108, 6, 41, 75, 46, 51, 38, 95, 120, 110, 112, 89, 112, 37, 92, 91, 4, 57, 31, 21, 108, 13, 77, 82, 55, 5, 126, 31, 56, 90, 19, 110, 66, 39, 119, 29, 24, 46, 43, 68, 27, 37, 84, 68, 95, 7, 75, 66, 96, 89, 73, 96, 44, 74, 94, 70, 78, 49, 23, 127, 31, 82, 79, 104, 107, 76, 92, 94, 0, 45, 96, 6, 41, 73, 28, 108};
   }

   private static byte[] uzkjjzuzuakcvpe() {
      return new byte[]{-30, -109, 104, 127, 41, 73, 70, 40, 105, 19, 61, 44, 74, 118, 107, 7, 46, 68, 43, 51, 39, 87, 120, 97, 118, 90, 123, 33, 82, 83, 12, 56, 24, 27, 104, 2, 77, 93, 49, 4, 127, 25, 62, 86, 27, 106, 73, 32, 120, 21, 30, 41, 47, 68, 24, 42, 87, 74, 89, 8, 76, 71, 104, 82, 65, 103, 38, 77, 95, 72, 75, 56, 20, 127, 31, 92, 76, 104, 107, 64, 85, 92, 8, 37, 105, 1, 45, 72, 30, 108};
   }

   private static byte[] xfztmkollwjyjvb() {
      return new byte[]{-30, -105, 111, 41, 45, 110, 69, 19, 110, 91, 61, 51, 77, 54, 111, 94, 45, 113, 44, 38, 39, 11, 127, 41, 114, 78, 120, 46, 85, 89, 12, 54, 31, 7, 108, 85, 78, 29, 54, 2, 127, 4, 57, 31, 31, 34, 74, 47, 127, 28, 30, 37, 40, 85, 28, 59, 84, 10, 94, 64, 76, 88, 111, 93, 69, 100, 37, 65, 88, 89, 75, 126, 19, 116, 27, 82, 79, 50, 108, 8, 85, 64, 15, 62, 109, 9, 46, 95, 25, 47, 74, 23, 50, 9, 30, 76, 84, 75, 34, 12, 72, 20, 62, 25, 77, 35, 53, 34, 31, 118, 102, 31, 34, 106, 54, 81, 109, 4, 111, 79, 58, 119, 74, 49, 70, 24, 115, 121};
   }

   private static byte[] jditywlrwimqgvn() {
      return new byte[]{-30, -105, 111, 123, 45, 104, 69, 63, 110, 71, 61, 116, 77, 49, 111, 22, 45, 113, 44, 33, 39, 67, 127, 45, 114, 26, 120, 34, 85, 71, 12, 59, 31, 0, 108, 73, 78, 16, 54, 0, 127, 4, 57, 92, 31, 41, 74, 37, 127, 0, 30, 98, 40, 81, 28, 63, 84, 70, 94, 72, 76, 66, 111, 93, 69, 111, 37, 65, 88, 93, 75, 60, 19, 48, 27, 86, 79, 115, 108, 27, 85, 73, 15, 45, 109, 8, 46, 71, 25, 107, 74, 12, 50, 75, 30, 91, 84, 67, 34, 17, 72, 7, 62, 81, 77, 56, 53, 125, 31, 57, 102, 8, 34, 63, 54, 68, 109, 21, 111, 77, 58, 123, 74, 39, 70, 84, 115, 51};
   }

   private static byte[] zcttqxgplvhsqle() {
      return new byte[]{-31, -110, 106, 9};
   }

   private static byte[] bnujsvaprfnjvig() {
      return new byte[]{-31, -110, 106, 118};
   }

   private static byte[] qqppsymdeakhhot() {
      return new byte[]{-31, -110, 106, 118};
   }

   private static int acfcjefbfustriqm(int var0, int var1) {
      return var1 ^ var0;
   }
}
