package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import skido.o0o0oOKo0K;
import skido.o0o0oOKoOK;
import skido.oOo0KKoOoOK;

public final class AuctionComponent {

   private AuctionComponent() {
   }

   private static o0o0oOKo0K cfg() {
      int var4 = 1092692466 ^ 1197005789 ^ 846444547;
      var4 = 952577132 ^ var4;
      String var0 = jzohglacwl(yqwziwthfmwjtka(), ypdcqwvbpyztqcq(), var4);
      o0o0oOKo0K var1 = o0o0oOKo0K.of(var0);
      return var1;
   }

   public static String msg(String var0, String var1) {
      int var12 = 553884701 ^ 659129299 ^ 846444547;
      var12 = 1255796457 ^ var12;
      o0o0oOKo0K var2 = cfg();
      String var9 = "messages." + var0;
      String var6 = var2.rawStr(var9, var1);
      var12 = 1527014574 ^ var12;
      String var8;
      if (var6 == null) {
         var12 = 177032050 ^ var12;
         var8 = var1;
         var12 = kknkwrtskuihgumw(var12, 2019980163);
      } else {
         var12 = kknkwrtskuihgumw(var12, 1689791598);
         var8 = var6;
         var12 = 374543519 ^ var12;
      }

      return var8;
   }

   public static void send(Player var0, String var1, String var2) {
      int var15 = 1846246739 ^ 582288689 ^ 846444547;
      var15 = 706156485 ^ var15;
      String var6 = msg(var1, var2);
      var15 = 211198504 ^ var15;
      String var8 = var6.trim();
      byte var9 = var8.isEmpty();
      if (var9 != (1481405836 ^ var15)) {
         var15 = 543357180 ^ var15;
      } else {
         var15 = kknkwrtskuihgumw(var15, 55768581);
         String var12 = oOo0KKoOoOK.color(var6);
         var0.sendMessage(var12);
         var15 = 1451545196 ^ var15;
      }
   }

   public static void send(Player var0, String var1, String var2, String var3, String var4) {
      int var20 = 383762423 ^ 662551734 ^ 846444547;
      var20 = 1222397236 ^ var20;
      String var10 = msg(var1, var2);
      var20 = 153169621 ^ var20;
      String var12 = var10.trim();
      byte var13 = var12.isEmpty();
      if (var13 != (1110235299 ^ var20)) {
         var20 = 1475760897 ^ var20;
      } else {
         var20 = 251848010 ^ var20;
         String var16 = var10.replace(var3, var4);
         String var17 = oOo0KKoOoOK.color(var16);
         var0.sendMessage(var17);
         var20 = 2049556348 ^ var20;
      }
   }

   public static void play(Player var0, String var1, String var2) {
      int var10 = 592922749 ^ 1217146370 ^ 846444547;
      var10 = 1946174688 ^ var10;
      float var6 = 1.0F;
      float var7 = 1.0F;
      play(var0, var1, var2, var6, var7);
      var10 = 1415057835 ^ var10;
   }

   public static void play(Player var0, String var1, String var2, float var3, float var4) {
      int var33 = 333571790 ^ 964804450 ^ 846444547;
      var33 = 2005775902 ^ var33;
      if (var0 != null) {
         var33 = 524304558 ^ var33;
         byte var13 = var0.isOnline();
         if (var13 != (1893603103 ^ var33)) {
            var33 = 2126127693 ^ var33;
            o0o0oOKo0K var14 = cfg();
            String var26 = "sounds." + var1;
            String var15 = var14.rawStr(var26, var2);
            String var10 = var15;
            var33 = 1793600560 ^ var33;
            if (var15 != null) {
               var33 = 1188875120 ^ var33;
               String var18 = var15.trim();
               byte var19 = var18.isEmpty();
               if (var19 != (575722002 ^ var33)) {
                  var33 = 302913288 ^ var33;
                  return;
               }

               label64:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var33)) {
                     case 41727314:
                        var33 ^= 387384293;
                        break label64;
                     case 1098438084:
                     default:
                        throw new IOException();
                     case 1252812997:
                        break label64;
                     case 1745505407:
                  }
               }

               try {
                  String var21 = var10.trim();
                  String var22 = var21.toUpperCase();
                  Sound var23 = o0o0oOKoOK.valueOf(var22);
                  var33 = 1784526279 ^ var33;
                  Location var28 = var0.getLocation();
                  var0.playSound(var28, var23, var3, var4);
                  var33 = 546119351 ^ var33;
               } catch (Throwable var34) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var33)) {
                     case -1438740551 -> var33 = 1651067402 ^ var33;
                     case -120381054 -> var33 = kknkwrtskuihgumw(var33, 137691085);
                     default -> throw new RuntimeException("Error in hash");
                  }

                  var33 = 271303997 ^ var33;
                  return;
               }

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var33)) {
                     case 120914674:
                        var33 = 949101639 ^ var33;
                        return;
                     case 895851212:
                        return;
                     case 1171068419:
                        break;
                     case 2083689619:
                     default:
                        throw new IOException();
                  }
               }
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var33)) {
                     case 47125921:
                        var33 = 1423105144 ^ var33;
                        return;
                     case 614062301:
                        break;
                     case 878323576:
                        return;
                     case 930454793:
                     default:
                        throw new IOException();
                  }
               }
            }
         }

         var33 = 1087399110 ^ var33;
      } else {
         var33 = kknkwrtskuihgumw(var33, 1603282024);
      }

   }

   public static String jzohglacwl(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] ypdcqwvbpyztqcq() {
      return new byte[]{90, 11, 70, 14, 11, 104, 65};
   }

   private static byte[] yqwziwthfmwjtka() {
      return new byte[]{-106, -59, 114, 87, 51, 58, 119, 25, 51, 89, 63, 94, 95, 12, 109, 94, 114, 66, 57, 48, 117, 2, 51, 31, 56, 88, 80, 6, 107, 86};
   }

   private static int kknkwrtskuihgumw(int var0, int var1) {
      return var0 ^ var1;
   }

   static {
   }
}
