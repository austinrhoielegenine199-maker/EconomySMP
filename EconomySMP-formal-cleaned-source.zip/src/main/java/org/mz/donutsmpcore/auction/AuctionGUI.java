package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemFactory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.mz.donutsmpcore.DonutSMPCore;
import org.mz.donutsmpcore.libs.signgui.SignGUI;
import org.mz.donutsmpcore.libs.signgui.SignGUIBuilder;
import org.mz.donutsmpcore.libs.signgui.SignGUIFinishHandler;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.KKoOoOo0oOK;
import skido.KoOKKo0K;
import skido.KoOo0oOo0oOK;
import skido.o0KoOo0KoOK;
import skido.o0o0oOKo0K;
import skido.o0o0oOKoOK;
import skido.o0oOo0Ko0K;
import skido.o0oOo0KoOoOK;
import skido.o0oOoOo0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;
import skido.oOoOo0oOK;

public class AuctionGUI implements KKoOK {
   private final Player player;
   private Inventory inventory;
   private int page;
   private AuctionSortOrder currentSort;
   private AuctionCategory currentFilter;
   private static final int ITEMS_PER_PAGE = 45;
   private List<AuctionItem> currentItems;
   private int totalPages;
   private String searchQuery;
   private static volatile List<String> COLORED_ADMIN_LORE;
   private static volatile long configVersion;
   private ItemStack cachedSortItem;
   private AuctionSortOrder cachedSortType;
   private ItemStack cachedFilterItem;
   private AuctionCategory cachedFilterType;
   private static final Map<Material, String> MATERIAL_NAME_CACHE;
   private static final Map<UUID, K> playerPreferences;
   private static volatile ItemStack cachedRefreshItem;
   private static volatile ItemStack cachedYourItemsItem;
   private static final boolean NEW_AUCTION_LORE;
   private static volatile long navConfigVersion;

   public static boolean isNewLore() {
      int var3 = 243933619 ^ 850992514 ^ 1243011330;
      var3 = 1976851582 ^ var3;
      boolean var0 = NEW_AUCTION_LORE;
      return var0;
   }

   private static o0o0oOKo0K acfg() {
      int var4 = 509248568 ^ 1487182893 ^ 1243011330;
      var4 = 1576979876 ^ var4;
      String var0 = wjiertwehi(iecjwjftisijkcn(), xreaynobfrqbnip(), var4);
      o0o0oOKo0K var1 = o0o0oOKo0K.of(var0);
      return var1;
   }

   private static Sound sound(String var0, String var1) {
      int var15 = 777855716 ^ 177101477 ^ 1243011330;
      var15 = 587614547 ^ var15;

      try {
         o0o0oOKo0K var2 = acfg();
         String var6 = var2.rawStr(var0, var1);
         String var7 = var6.trim();
         String var8 = var7.toUpperCase();
         var15 = 1356842967 ^ var15;
         Sound var9 = o0o0oOKoOK.valueOf(var8);
         var15 = 1802871246 ^ var15;
         return var9;
      } catch (Throwable var16) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var15)) {
            case -387875272 -> var15 = 1892858355 ^ var15;
            case 1847541890 -> var15 = 537755172 ^ var15;
            default -> throw new IOException("Error in hash");
         }

         var15 = 2438957 ^ var15;
         Sound var12 = o0o0oOKoOK.valueOf(var1);
         return var12;
      }
   }

   public AuctionGUI(Player var1) {
      Object var4 = null;
      this(var1, (String)var4);
   }

   public AuctionGUI(Player var1, String var2) {
      byte var4 = 0;
      this.page = var4;
      AuctionSortOrder var26 = AuctionSortOrder.RECENTLY_LISTED;
      this.currentSort = var26;
      AuctionCategory var27 = AuctionCategory.ALL;
      this.currentFilter = var27;
      ArrayList var28 = new ArrayList();
      this.currentItems = var28;
      byte var29 = 1;
      this.totalPages = var29;
      String var30 = "";
      this.searchQuery = var30;
      this.player = var1;
      String var43;
      if (var2 == null) {
         var43 = "";
      } else {
         var43 = var2.trim();
      }

      this.searchQuery = var43;
      ensureConfigColored();
      boolean var14 = o0oOo0KoOoOK.rememberSortFilter;
      if (var14) {
         Map var15 = playerPreferences;
         UUID var35 = var1.getUniqueId();
         Object var16 = var15.get(var35);
         K var17 = (K)var16;
         if (var17 != null) {
            AuctionSortOrder var37 = var17.sort;
            this.currentSort = var37;
            AuctionCategory var39 = var17.filter;
            this.currentFilter = var39;
            int var41 = var17.page;
            this.page = var41;
         }
      }

      String var23 = this.searchQuery;
      boolean var24 = var23.isEmpty();
      if (!var24) {
         byte var42 = 0;
         this.page = var42;
      }

   }

   private static boolean matchesSearch(AuctionItem var0, String var1) {
      int var44 = 1580192856 ^ 1480549776 ^ 1243011330;
      var44 = 1360315357 ^ var44;
      String var7 = var0.getSellerName();
      if (var7 != null) {
         var44 = 371229315 ^ var44;
         String var9 = var0.getSellerName();
         String var10 = var9.toLowerCase();
         byte var11 = var10.contains(var1);
         if (var11 != (187836820 ^ var44)) {
            var44 = 1945242080 ^ var44;
            byte var37 = (byte)(2025857141 ^ var44);
            return (boolean)var37;
         }

         var44 = gvqzrkmahtxotvmd(var44, 1125758627);
      } else {
         label85:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var44)) {
               case 139736686:
                  var44 ^= 1429812256;
                  break label85;
               case 438519529:
               default:
                  throw new IllegalAccessException();
               case 810508296:
                  break;
               case 1898652286:
                  break label85;
            }
         }
      }

      ItemStack var13 = var0.getItemStackDirect();
      var44 = 2011471700 ^ var44;
      if (var13 == null) {
         var44 = 122407788 ^ var44;
         byte var36 = (byte)(948226831 ^ var44);
         return (boolean)var36;
      } else {
         label74:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var44)) {
               case 30576021:
                  break;
               case 195112816:
                  var44 ^= 1046419545;
                  break label74;
               case 260771048:
               default:
                  throw new IllegalAccessException();
               case 1169604718:
                  break label74;
            }
         }

         byte var16 = var13.hasItemMeta();
         if (var16 != (26220602 ^ var44)) {
            var44 = 81299584 ^ var44;
            ItemMeta var18 = var13.getItemMeta();
            byte var19 = var18.hasDisplayName();
            if (var19 != (88641722 ^ var44)) {
               var44 = 969599977 ^ var44;
               var44 = 1923848015 ^ var44;
               ItemMeta var21 = var13.getItemMeta();
               String var22 = var21.getDisplayName();
               String var23 = var22.toLowerCase();
               byte var24 = var23.contains(var1);
               if (var24 != (1311370268 ^ var44)) {
                  var44 = 1964324502 ^ var44;
                  byte var25 = (byte)(993843851 ^ var44);
                  return (boolean)var25;
               }

               var44 = 1562494166 ^ var44;
            } else {
               var44 = 373340272 ^ var44;
            }
         } else {
            label63:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var44)) {
                  case 24581926:
                     var44 ^= 311963888;
                     break label63;
                  case 347327813:
                     break;
                  case 893886997:
                  default:
                     throw new IllegalAccessException();
                  case 2113812178:
                     break label63;
               }
            }
         }

         Material var27 = var13.getType();
         String var28 = var27.name();
         String var29 = var28.toLowerCase();
         var44 = 991785692 ^ var44;
         byte var31 = var29.contains(var1);
         byte var35;
         if (var31 == (672487958 ^ var44)) {
            var44 = 2015729288 ^ var44;
            byte var40 = (byte)(1345375425 ^ var44);
            byte var4 = (byte)(1345375422 ^ var44);
            String var33 = var29.replace((char)var40, (char)var4);
            byte var34 = var33.contains(var1);
            if (var34 == (1345375390 ^ var44)) {
               var44 = gvqzrkmahtxotvmd(var44, 1510993338);
               var35 = (byte)(171909412 ^ var44);
               var44 = 1344703130 ^ var44;
               return (boolean)var35;
            }

            var44 = 1775857635 ^ var44;
         } else {
            label51:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var44)) {
                  case 197475015:
                  default:
                     throw new IllegalAccessException();
                  case 229209759:
                     var44 ^= 301791595;
                  case 934859559:
                     break label51;
                  case 2023958552:
               }
            }
         }

         var35 = (byte)(971613052 ^ var44);
         var44 = 1676675267 ^ var44;
         return (boolean)var35;
      }
   }

   private void savePreferences() {
      int var16 = 25874657 ^ 483091119 ^ 378349300;
      var16 = 1422041219 ^ var16;
      byte var1 = o0oOo0KoOoOK.rememberSortFilter;
      if (var1 != (1594766393 ^ var16)) {
         var16 = 1812364266 ^ var16;
         Map var7 = playerPreferences;
         Player var9 = this.player;
         UUID var10 = var9.getUniqueId();
         AuctionSortOrder var11 = this.currentSort;
         AuctionCategory var12 = this.currentFilter;
         int var13 = this.page;
         K var3 = new K(var11, var12, var13);
         var7.put(var10, var3);
         var16 = 1034038038 ^ var16;
      } else {
         var16 = gvqzrkmahtxotvmd(var16, 1369723132);
      }

   }

   public static void clearPreferences(UUID var0) {
      int var6 = 1671878754 ^ 204842948 ^ 1243011330;
      var6 = 240236736 ^ var6;
      Map var1 = playerPreferences;
      var1.remove(var0);
      var6 = 1633168039 ^ var6;
   }

   private static void ensureConfigColored() {
   }

   private static ItemStack buildStaticGuiItem(Material var0, String var1, List<String> var2) {
      int var23 = 332705263 ^ 487864984 ^ 1243011330;
      var23 = 1451529619 ^ var23;
      ItemStack var3 = new ItemStack(var0);
      var23 = 1582903622 ^ var23;
      ItemMeta var8 = var3.getItemMeta();
      var23 = 1435901229 ^ var23;
      String var18 = oOo0KKoOoOK.color(var1);
      var8.setDisplayName(var18);
      var23 = 737595913 ^ var23;
      if (var2 == null) {
         var23 = gvqzrkmahtxotvmd(var23, 472196463);
      } else {
         var23 = 1543379909 ^ var23;
         byte var12 = var2.isEmpty();
         if (var12 == (1771388481 ^ var23)) {
            var23 = 888922936 ^ var23;
            var8.setLore(var2);
            var23 = 1931533714 ^ var23;
         } else {
            label22:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var23)) {
                  case 110666935:
                     break;
                  case 210845960:
                     var23 ^= 1205550762;
                     break label22;
                  case 1234084142:
                  default:
                     throw new RuntimeException();
                  case 2016590123:
                     break label22;
               }
            }
         }
      }

      boolean var15 = var3.setItemMeta(var8);
      var23 = 66777567 ^ var23;
      return var3;
   }

   public void open() {
      int var25 = 2111317631 ^ 1083563553 ^ 378349300;
      var25 = 97021596 ^ var25;
      Inventory var11 = this.createInventory();
      this.inventory = var11;
      var25 = 712987306 ^ var25;
      oOoOKo0o0K var4 = oOoOKo0o0K.getInstance();
      Inventory var13 = this.inventory;
      var4.register(var13, this);
      var25 = 1588443179 ^ var25;
      Ko0KoOKoOK var5 = Ko0KoOKoOK.getInstance();
      Player var15 = this.player;
      UUID var16 = var15.getUniqueId();
      var5.addViewer(var16);
      var25 = 365121174 ^ var25;
      oOoOKo0o0K var6 = oOoOKo0o0K.getInstance();
      Inventory var18 = this.inventory;
      Runnable var22 = () -> {
         int var7 = 1418161882 ^ 623360780 ^ 378349300;
         var7 = 1860737819 ^ var7;
         Ko0KoOKoOK var1 = Ko0KoOKoOK.getInstance();
         Player var3 = this.player;
         UUID var4 = var3.getUniqueId();
         var1.removeViewer(var4);
         var7 = 82397818 ^ var7;
      };
      var6.setCloseAction(var18, var22);
      var25 = 1498489734 ^ var25;
      this.decorate();
      var25 = 1438237176 ^ var25;
      Player var9 = this.player;
      Inventory var20 = this.inventory;
      var9.openInventory(var20);
      var25 = 598543974 ^ var25;
   }

   public Inventory createInventory() {
      int var11 = 1059542088 ^ 1516905907 ^ 378349300;
      var11 = 928501469 ^ var11;
      Object var1 = null;
      int var2 = o0oOo0KoOoOK.auctionSize;
      int var6 = this.page;
      byte var4 = (byte)(1150786003 ^ var11);
      int var7 = var6 + var4;
      String var8 = o0oOo0KoOoOK.getTitle(var7);
      Inventory var5 = Bukkit.createInventory((InventoryHolder)var1, var2, var8);
      return var5;
   }

   public void decorate() {
      int var365 = 1543320328 ^ 906064990 ^ 378349300;
      var365 = 966252018 ^ var365;
      Inventory var28 = this.inventory;
      Inventory var8 = var28;
      var365 = 985338371 ^ var365;
      if (var28 == null) {
         var365 = 931300055 ^ var365;
         Player var31 = this.player;
         InventoryView var32 = var31.getOpenInventory();
         Inventory var33 = var32.getTopInventory();
         var8 = var33;
         var365 = 1558953633 ^ var365;
      } else {
         var365 = 1802058870 ^ var365;
      }

      var8.clear();
      var365 = 2035713849 ^ var365;
      Ko0KoOKoOK var35 = Ko0KoOKoOK.getInstance();
      AuctionSortOrder var181 = this.currentSort;
      List var36 = var35.getSortedItems(var181);
      Stream var37 = var36.stream();
      Predicate var183 = (var1) -> {
         int var10 = 1898460524 ^ 370584843 ^ 378349300;
         var10 = 1031577356 ^ var10;
         AuctionCategory var4 = this.currentFilter;
         ItemStack var6 = var1.getItemStackDirect();
         Material var7 = var6.getType();
         boolean var5 = var4.matches(var7);
         return var5;
      };
      var365 = 1334550807 ^ var365;
      Stream var38 = var37.filter(var183);
      Predicate var185 = (var1) -> {
         int var15 = 2038117278 ^ 1412506587 ^ 378349300;
         var15 = 990518074 ^ var15;
         String var4 = this.searchQuery;
         byte var10;
         if (var4 != null) {
            var15 = 835655433 ^ var15;
            String var6 = this.searchQuery;
            byte var7 = var6.isEmpty();
            if (var7 == (822229634 ^ var15)) {
               var15 = 1578811879 ^ var15;
               String var11 = this.searchQuery;
               var15 = 2081824964 ^ var15;
               String var12 = var11.toLowerCase();
               byte var9 = matchesSearch(var1, var12);
               if (var9 == (319740833 ^ var15)) {
                  var15 = 1584558835 ^ var15;
                  var10 = (byte)(1300015442 ^ var15);
                  var15 = 1990554616 ^ var15;
                  return (boolean)var10;
               }

               var15 = 1576422361 ^ var15;
            } else {
               var15 = gvqzrkmahtxotvmd(var15, 2147134202);
            }
         } else {
            var15 = gvqzrkmahtxotvmd(var15, 1312144883);
         }

         var10 = (byte)(1324912761 ^ var15);
         var15 = gvqzrkmahtxotvmd(var15, 1965116114);
         return (boolean)var10;
      };
      var365 = 644935404 ^ var365;
      Stream var39 = var38.filter(var185);
      var365 = 1550555399 ^ var365;
      List var40 = var39.toList();
      List var9 = var40;
      var365 = 502984562 ^ var365;
      byte var41 = (byte)(1107829907 ^ var365);
      int var187 = var40.size();
      byte var3 = (byte)(1107829951 ^ var365);
      int var188 = var187 + var3;
      byte var263 = (byte)(1107829907 ^ var365);
      int var189 = var188 - var263;
      byte var264 = (byte)(1107829951 ^ var365);
      int var190 = var189 / var264;
      int var42 = Math.max(var41, var190);
      var365 = 2102490571 ^ var365;
      int var44 = this.page;
      if (var44 >= var42) {
         var365 = 1558636897 ^ var365;
         byte var192 = (byte)(1673508920 ^ var365);
         byte var4 = (byte)(1673508921 ^ var365);
         int var266 = var42 - var4;
         int var193 = Math.max(var192, var266);
         this.page = var193;
         var365 = 80969957 ^ var365;
      } else {
         var365 = 1479895428 ^ var365;
      }

      this.currentItems = var40;
      var365 = 1951201624 ^ var365;
      this.totalPages = var42;
      var365 = 794458943 ^ var365;
      Player var49 = this.player;
      String var196 = wjiertwehi(ekthnwqhaislcyk(), xreaynobfrqbnip(), var365);
      byte var50 = var49.hasPermission(var196);
      byte var11 = var50;
      var365 = 369864248 ^ var365;
      int var52 = this.page;
      byte var197 = (byte)(712053935 ^ var365);
      int var53 = var52 * var197;
      int var12 = var53;
      var365 = 1148506730 ^ var365;
      byte var198 = (byte)(1845872325 ^ var365);
      int var55 = var53 + var198;
      int var200 = var40.size();
      int var56 = Math.min(var55, var200);
      int var13 = var56;
      var365 = 620901249 ^ var365;
      int var14 = var53;
      var365 = 106553670 ^ var365;

      while(true) {
         int var104;
         ItemStack var107;
         ItemMeta var179;
         ArrayList var360;
         if (var14 < var13) {
            var365 = 946879218 ^ var365;
            Object var101 = var9.get(var14);
            AuctionItem var102 = (AuctionItem)var101;
            var365 = 472892634 ^ var365;
            var104 = var14 - var12;
            var365 = 496710328 ^ var365;
            ItemStack var106 = var102.getItemStackDirect();
            var107 = var106.clone();
            var365 = 1054630892 ^ var365;
            byte var109 = var107.hasItemMeta();
            if (var109 != (1246149459 ^ var365)) {
               var365 = 2134630561 ^ var365;
               var179 = var107.getItemMeta();
               var365 = gvqzrkmahtxotvmd(var365, 285219492);
            } else {
               var365 = gvqzrkmahtxotvmd(var365, 926799907);
               ItemFactory var178 = Bukkit.getItemFactory();
               Material var261 = var107.getType();
               var179 = var178.getItemMeta(var261);
               var365 = 1493574182 ^ var365;
            }

            var365 = 1518287663 ^ var365;
            Material var112 = var107.getType();
            String var113 = getMaterialName(var112);
            String var19 = var113;
            var365 = 894233414 ^ var365;
            String var115 = var102.getSellerName();
            String var20 = var115;
            var365 = 414801280 ^ var365;
            byte var117 = var179.hasDisplayName();
            if (var117 == (1408748735 ^ var365)) {
               var365 = 205308914 ^ var365;
               String var118 = o0oOo0KoOoOK.itemDisplayName;
               String var229 = wjiertwehi(jjfmxpqfkwtsvkk(), xreaynobfrqbnip(), var365);
               String var119 = var118.replace(var229, var113);
               var365 = 377007005 ^ var365;
               String var231 = oOo0KKoOoOK.color(var119);
               var179.setDisplayName(var231);
               var365 = 751628281 ^ var365;
            } else {
               label234:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                     case 45109061:
                        var365 ^= 914917270;
                        break label234;
                     case 161723718:
                        break;
                     case 2028314420:
                     default:
                        throw new IOException();
                     case 2076948132:
                        break label234;
                  }
               }
            }

            ArrayList var121 = new ArrayList();
            var360 = var121;
            var365 = 1621314870 ^ var365;
            byte var123 = var179.hasLore();
            if (var123 != (98305567 ^ var365)) {
               var365 = 1633019621 ^ var365;
               List var125 = var179.getLore();
               if (var125 != null) {
                  var365 = 1971015004 ^ var365;
                  List var233 = var179.getLore();
                  var121.addAll(var233);
                  var365 = 1767399323 ^ var365;
               } else {
                  label222:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                        case 46876525:
                           var365 ^= 472060615;
                        case 1354395949:
                           break label222;
                        case 1643991902:
                           break;
                        case 1992072202:
                        default:
                           throw new IOException();
                     }
                  }
               }
            } else {
               var365 = 2104947746 ^ var365;
            }

            double var129 = var102.getPrice();
            String var131 = oOo0KKoOoOK.formatPrice(var129);
            String var22 = var131;
            var365 = 1664314246 ^ var365;
            String var133 = var102.getTimeLeft();
            String var23 = var133;
            var365 = 1246584731 ^ var365;
            byte var134 = NEW_AUCTION_LORE;
            if (var134 != (1372898848 ^ var365)) {
               var365 = 722156234 ^ var365;
               String var234 = wjiertwehi(enfjlusqokhrasb(), xreaynobfrqbnip(), var365);
               byte var136 = var131.startsWith(var234);
               String var180;
               if (var136 != (2061499626 ^ var365)) {
                  var365 = 71074648 ^ var365;
                  byte var235 = (byte)(2128838579 ^ var365);
                  var180 = var131.substring(var235);
                  var365 = gvqzrkmahtxotvmd(var365, 1982632378);
               } else {
                  var365 = 687144095 ^ var365;
                  var180 = var131;
                  var365 = 1524952701 ^ var365;
               }

               String var24 = var180;
               var365 = 1823717117 ^ var365;
               var121.clear();
               var365 = 1514828087 ^ var365;
               o0o0oOKo0K var139 = acfg();
               var365 = 1397668663 ^ var365;
               String var236 = wjiertwehi(otdqtxqbtffcbkv(), xreaynobfrqbnip(), var365);
               byte var298 = (byte)(1836618485 ^ var365);
               byte var141 = var139.bool(var236, (boolean)var298);
               if (var141 != (1836618485 ^ var365)) {
                  var365 = 1535718663 ^ var365;
                  byte var143 = var179.hasLore();
                  if (var143 != (921806834 ^ var365)) {
                     var365 = 246288007 ^ var365;
                     List var145 = var179.getLore();
                     if (var145 != null) {
                        var365 = 555688547 ^ var365;
                        List var238 = var179.getLore();
                        var121.addAll(var238);
                        var365 = 65427558 ^ var365;
                     } else {
                        label181:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                              case 221863949:
                                 var365 ^= 586775045;
                                 break label181;
                              case 381943168:
                              default:
                                 throw new IOException();
                              case 892347727:
                                 break;
                              case 1150226924:
                                 break label181;
                           }
                        }
                     }
                  } else {
                     var365 = gvqzrkmahtxotvmd(var365, 743928962);
                  }
               } else {
                  label192:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                        case 68809154:
                           var365 ^= 2011054469;
                        case 342354205:
                           break label192;
                        case 360549504:
                        default:
                           throw new IOException();
                        case 1493049126:
                     }
                  }
               }

               String var239 = wjiertwehi(ugrziknmrgcyyet(), xreaynobfrqbnip(), var365);
               String var299 = wjiertwehi(gbulrpagvvvxbai(), xreaynobfrqbnip(), var365);
               var365 = 951375997 ^ var365;
               List var300 = List.of(var299);
               var365 = 703856486 ^ var365;
               List var149 = var139.rawListAt(var239, var300);
               Iterator var150 = var149.iterator();
               Iterator var26 = var150;
               var365 = 1343817511 ^ var365;

               label171:
               while(true) {
                  byte var152 = var26.hasNext();
                  if (var152 == (1543041868 ^ var365)) {
                     label152:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                           case 36834459:
                              var365 ^= 699288846;
                              break label152;
                           case 60158430:
                              break;
                           case 1292594383:
                              break label152;
                           case 1720517243:
                           default:
                              throw new IOException();
                        }
                     }

                     String var247 = wjiertwehi(ehtrqrgjhurpohq(), xreaynobfrqbnip(), var365);
                     byte var306 = (byte)(1918287427 ^ var365);
                     byte var159 = var139.bool(var247, (boolean)var306);
                     if (var159 != (1918287426 ^ var365)) {
                        var365 = 922483841 ^ var365;
                        String var307 = wjiertwehi(unewwgpbaqtinnl(), xreaynobfrqbnip(), var365);
                        String var331 = wjiertwehi(olqwhmdwjcsbyhd(), xreaynobfrqbnip(), var365);
                        String var249 = var139.rawStr(var307, var331);
                        String var308 = wjiertwehi(wcbeeqvwsthawib(), xreaynobfrqbnip(), var365);
                        var365 = 195766325 ^ var365;
                        String var250 = var249.replace(var308, var23);
                        var365 = 749684332 ^ var365;
                        String var251 = oOo0KKoOoOK.color(var250);
                        boolean var161 = var360.add(var251);
                        var365 = 1087055242 ^ var365;
                     } else {
                        label140:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                              case 112184811:
                              default:
                                 throw new IOException();
                              case 227041993:
                                 var365 ^= 1362409298;
                                 break label140;
                              case 544631161:
                                 break;
                              case 1617610180:
                                 break label140;
                           }
                        }
                     }

                     var365 = 1991726237 ^ var365;
                     break;
                  }

                  var365 = 980399796 ^ var365;
                  Object var154 = var26.next();
                  String var155 = (String)var154;
                  var365 = 1930300400 ^ var365;
                  String var301 = wjiertwehi(qkugvqnujtxpauh(), xreaynobfrqbnip(), var365);
                  var365 = 1789998862 ^ var365;
                  String var241 = var155.replace(var301, var24);
                  String var302 = wjiertwehi(nfbjabznjbjxzbb(), xreaynobfrqbnip(), var365);
                  var365 = 784726781 ^ var365;
                  String var242 = var241.replace(var302, var22);
                  String var303 = wjiertwehi(aohgqthpqbwxkpg(), xreaynobfrqbnip(), var365);
                  var365 = 182770780 ^ var365;
                  String var243 = var242.replace(var303, var20);
                  String var304 = wjiertwehi(wztxikhiwfyehvq(), xreaynobfrqbnip(), var365);
                  var365 = 972363136 ^ var365;
                  String var244 = var243.replace(var304, var19);
                  String var305 = wjiertwehi(qtxkzyhpgwebkok(), xreaynobfrqbnip(), var365);
                  var365 = 333620307 ^ var365;
                  String var245 = var244.replace(var305, var23);
                  var365 = 1428191094 ^ var365;
                  String var246 = oOo0KKoOoOK.color(var245);
                  boolean var157 = var360.add(var246);
                  var365 = 1796059111 ^ var365;

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                        case 196402000:
                           continue label171;
                        case 199455336:
                           var365 ^= 332121513;
                           continue label171;
                        case 532582901:
                        default:
                           throw new IOException();
                        case 728167648:
                     }
                  }
               }
            } else {
               var365 = 1022977463 ^ var365;
               List var166 = o0oOo0KoOoOK.itemDisplayLoreColored;
               Iterator var167 = var166.iterator();
               Iterator var361 = var167;
               var365 = 62763345 ^ var365;

               while(true) {
                  byte var169 = var361.hasNext();
                  if (var169 == (1854935750 ^ var365)) {
                     label206:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                           case 104286927:
                              var365 ^= 1657592727;
                           case 112459884:
                              break label206;
                           case 841663062:
                           default:
                              throw new IOException();
                           case 1609680205:
                        }
                     }

                     if (var11 != (207407441 ^ var365)) {
                        var365 = 1461126145 ^ var365;
                        List var259 = COLORED_ADMIN_LORE;
                        var360.addAll(var259);
                        var365 = 245272797 ^ var365;
                     } else {
                        var365 = gvqzrkmahtxotvmd(var365, 1502188764);
                     }
                     break;
                  }

                  var365 = 1325298670 ^ var365;
                  Object var171 = var361.next();
                  String var172 = (String)var171;
                  var365 = 1809484713 ^ var365;
                  String var310 = wjiertwehi(cfftgezedxmgcvl(), xreaynobfrqbnip(), var365);
                  var365 = 1475992789 ^ var365;
                  String var256 = var172.replace(var310, var22);
                  String var311 = wjiertwehi(alqwstgordfddcf(), xreaynobfrqbnip(), var365);
                  var365 = 996501527 ^ var365;
                  String var257 = var256.replace(var311, var20);
                  String var312 = wjiertwehi(fqtezvbohxiryvw(), xreaynobfrqbnip(), var365);
                  var365 = 1678975694 ^ var365;
                  String var258 = var257.replace(var312, var23);
                  var365 = 472023266 ^ var365;
                  boolean var174 = var360.add(var258);
                  var365 = 1114475635 ^ var365;
                  var365 = gvqzrkmahtxotvmd(var365, 1944347354);
               }
            }
         } else {
            label345: {
               var365 = gvqzrkmahtxotvmd(var365, 814349634);
               int var60 = this.page;
               if (var60 <= (2111301997 ^ var365)) {
                  var365 = 1913909118 ^ var365;
                  byte var61 = o0KoOo0KoOK.always();
                  if (var61 == (264504851 ^ var365)) {
                     label315:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                           case 116543042:
                           default:
                              throw new IOException();
                           case 244040704:
                              var365 ^= 637915722;
                              break label315;
                           case 770842357:
                              break;
                           case 1372990317:
                              break label315;
                        }
                     }

                     int var202 = o0oOo0KoOoOK.prevPageSlot;
                     Object var267 = null;
                     ItemStack var268 = (ItemStack)var267;
                     var8.setItem(var202, var268);
                     var365 = 1503629083 ^ var365;
                     break label345;
                  }

                  var365 = 939039266 ^ var365;
               } else {
                  var365 = 1173058908 ^ var365;
               }

               ItemStack var91 = new ItemStack;
               byte var291 = NEW_AUCTION_LORE;
               Material var293;
               if (var291 == (943496241 ^ var365)) {
                  var365 = gvqzrkmahtxotvmd(var365, 140090385);
                  var293 = o0oOo0KoOoOK.prevPageMaterial;
                  var365 = 673130725 ^ var365;
               } else {
                  var365 = 954286521 ^ var365;
                  o0o0oOKo0K var292 = acfg();
                  String var323 = wjiertwehi(vwgdabulhxxqnfa(), xreaynobfrqbnip(), var365);
                  Material var339 = o0oOo0KoOoOK.prevPageMaterial;
                  var293 = var292.material(var323, var339);

                  label303:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                        case 13631346:
                           var365 ^= 413660493;
                           break label303;
                        case 1569978436:
                           break;
                        case 1570765393:
                        default:
                           throw new IOException();
                        case 1981420204:
                           break label303;
                     }
                  }
               }

               var91.<init>(var293);
               var365 = 716343927 ^ var365;
               ItemMeta var93 = var91.getItemMeta();
               var365 = 1349816927 ^ var365;
               byte var94 = NEW_AUCTION_LORE;
               if (var94 != (1656500461 ^ var365)) {
                  var365 = 1977600688 ^ var365;
                  o0o0oOKo0K var220 = acfg();
                  String var294 = wjiertwehi(uulshntvmufqwkm(), xreaynobfrqbnip(), var365);
                  String var324 = o0oOo0KoOoOK.prevPageNameEnabled;
                  String var221 = var220.name(var294, var324);
                  var93.setDisplayName(var221);
                  var365 = 1887811632 ^ var365;
                  o0o0oOKo0K var222 = acfg();
                  String var295 = wjiertwehi(qcohwxskqkgjulx(), xreaynobfrqbnip(), var365);
                  List var325 = o0oOo0KoOoOK.prevPageLore;
                  List var223 = var222.lore(var295, var325);
                  var93.setLore(var223);
                  var365 = 1601924162 ^ var365;
               } else {
                  var365 = gvqzrkmahtxotvmd(var365, 1279339655);
                  String var225 = o0oOo0KoOoOK.prevPageNameEnabled;
                  var93.setDisplayName(var225);
                  var365 = 679420223 ^ var365;
                  List var226 = o0oOo0KoOoOK.prevPageLore;
                  var93.setLore(var226);
                  var365 = 1042223994 ^ var365;
               }

               int var224 = o0oOo0KoOoOK.prevPageSlot;
               var8.setItem(var224, var91);
               var365 = 1306273447 ^ var365;
               var365 = 85939146 ^ var365;
            }

            ItemStack var63 = new ItemStack;
            byte var269 = NEW_AUCTION_LORE;
            Material var270;
            if (var269 != (1885231938 ^ var365)) {
               var365 = 2093746280 ^ var365;
               o0o0oOKo0K var290 = acfg();
               String var322 = wjiertwehi(gvakeliajafubwp(), xreaynobfrqbnip(), var365);
               Material var338 = o0oOo0KoOoOK.nextPageMaterial;
               var270 = var290.material(var322, var338);
               var365 = gvqzrkmahtxotvmd(var365, 32308740);
            } else {
               var365 = gvqzrkmahtxotvmd(var365, 1334808208);
               var270 = o0oOo0KoOoOK.nextPageMaterial;
               var365 = 850360572 ^ var365;
            }

            var63.<init>(var270);
            var365 = 740370447 ^ var365;
            ItemMeta var65 = var63.getItemMeta();
            var365 = 1734973820 ^ var365;
            byte var66 = NEW_AUCTION_LORE;
            if (var66 != (1177951325 ^ var365)) {
               var365 = 956279691 ^ var365;
               o0o0oOKo0K var216 = acfg();
               String var288 = wjiertwehi(eoxwfsudettfnjh(), xreaynobfrqbnip(), var365);
               String var317 = wjiertwehi(leqqmlxmysnocru(), xreaynobfrqbnip(), var365);
               String var318 = oOo0KKoOoOK.color(var317);
               String var217 = var216.name(var288, var318);
               var65.setDisplayName(var217);
               var365 = 805379600 ^ var365;
               o0o0oOKo0K var218 = acfg();
               String var289 = wjiertwehi(vbwkrlfodukwryv(), xreaynobfrqbnip(), var365);
               String var319 = wjiertwehi(zvquqmwlkdkklgo(), xreaynobfrqbnip(), var365);
               var365 = 790575841 ^ var365;
               String var320 = oOo0KKoOoOK.color(var319);
               List var321 = List.of(var320);
               var365 = 753631143 ^ var365;
               List var219 = var218.lore(var289, var321);
               var65.setLore(var219);
               var365 = 794371435 ^ var365;
            } else {
               var365 = gvqzrkmahtxotvmd(var365, 1550370107);
               int var204 = this.page;
               byte var313 = (byte)(442423655 ^ var365);
               int var272 = var42 - var313;
               String var262;
               if (var204 < var272) {
                  var365 = 434300667 ^ var365;
                  var262 = o0oOo0KoOoOK.nextPageNameEnabled;
                  var365 = gvqzrkmahtxotvmd(var365, 2017008426);
               } else {
                  label283:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                        case 51896171:
                           var365 ^= 442081651;
                        case 1119014387:
                           break label283;
                        case 1139761302:
                           break;
                        case 1357895337:
                        default:
                           throw new IOException();
                     }
                  }

                  var262 = o0oOo0KoOoOK.nextPageNameDisabled;
                  var365 = 2072140962 ^ var365;
               }

               var65.setDisplayName(var262);
               var365 = 1698875183 ^ var365;
               List var205 = o0oOo0KoOoOK.nextPageLore;
               var65.setLore(var205);
               var365 = 2091002483 ^ var365;
            }

            boolean var70 = var63.setItemMeta(var65);
            var365 = 1640612252 ^ var365;
            int var207 = o0oOo0KoOoOK.nextPageSlot;
            var8.setItem(var207, var63);
            var365 = 847905057 ^ var365;
            byte var72 = NEW_AUCTION_LORE;
            if (var72 != (824576342 ^ var365)) {
               var365 = 778461541 ^ var365;
               String var73 = wjiertwehi(vflpvrbevdmtkqt(), xreaynobfrqbnip(), var365);
               o0o0oOKo0K var74 = o0o0oOKo0K.of(var73);
               var365 = 618179799 ^ var365;
               int var208 = o0oOo0KoOoOK.refreshSlot;
               String var314 = wjiertwehi(dqfeilfgilziwfi(), xreaynobfrqbnip(), var365);
               Material var5 = Material.ANVIL;
               String var6 = wjiertwehi(vcudlckloskhxtb(), xreaynobfrqbnip(), var365);
               var365 = 2068408863 ^ var365;
               String var340 = oOo0KKoOoOK.color(var6);
               String var7 = wjiertwehi(asdnsybgfpoowgk(), xreaynobfrqbnip(), var365);
               var365 = 1630179985 ^ var365;
               String var345 = oOo0KKoOoOK.color(var7);
               List var346 = List.of(var345);
               var365 = 1353947163 ^ var365;
               ItemStack var275 = var74.button(var314, var5, var340, var346);
               var365 = 141204748 ^ var365;
               var8.setItem(var208, var275);
               var365 = 1647588744 ^ var365;

               label269:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                     case 14279812:
                     default:
                        throw new IOException();
                     case 75145740:
                        var365 ^= 554762129;
                        break label269;
                     case 978187789:
                        break;
                     case 1670172552:
                        break label269;
                  }
               }
            } else {
               label259:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                     case 255427376:
                        var365 ^= 1961077639;
                        break label259;
                     case 1625531346:
                        break;
                     case 1933736857:
                     default:
                        throw new IOException();
                     case 2038100435:
                        break label259;
                  }
               }

               int var215 = o0oOo0KoOoOK.refreshSlot;
               ItemStack var287 = cachedRefreshItem;
               var8.setItem(var215, var287);
               var365 = 2143506869 ^ var365;
            }

            int var209 = o0oOo0KoOoOK.searchSlot;
            ItemStack var277 = this.createSearchItem();
            var8.setItem(var209, var277);
            var365 = 1218662497 ^ var365;
            byte var77 = NEW_AUCTION_LORE;
            if (var77 != (1923457797 ^ var365)) {
               var365 = 2005964080 ^ var365;
               String var78 = wjiertwehi(okhuvqvwxbeswtb(), xreaynobfrqbnip(), var365);
               o0o0oOKo0K var79 = o0o0oOKo0K.of(var78);
               var365 = 1168680202 ^ var365;
               int var210 = o0oOo0KoOoOK.yourItemsSlot;
               String var315 = wjiertwehi(iytchyvslgiqqlk(), xreaynobfrqbnip(), var365);
               Material var336 = Material.CHEST;
               String var341 = wjiertwehi(anhqyhplqmuauyp(), xreaynobfrqbnip(), var365);
               var365 = 1626282365 ^ var365;
               String var342 = oOo0KKoOoOK.color(var341);
               String var347 = wjiertwehi(wkkpfdmlihgpqwo(), xreaynobfrqbnip(), var365);
               var365 = 955529555 ^ var365;
               String var348 = oOo0KKoOoOK.color(var347);
               List var349 = List.of(var348);
               var365 = 1594973157 ^ var365;
               ItemStack var279 = var79.button(var315, var336, var342, var349);
               var365 = 843350957 ^ var365;
               var8.setItem(var210, var279);
               var365 = 1131981933 ^ var365;
               var365 = gvqzrkmahtxotvmd(var365, 1700648285);
            } else {
               label247:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var365)) {
                     case 103113253:
                        break;
                     case 237017468:
                        var365 ^= 1194468083;
                     case 1720422022:
                        break label247;
                     case 1828330768:
                     default:
                        throw new IOException();
                  }
               }

               int var214 = o0oOo0KoOoOK.yourItemsSlot;
               ItemStack var286 = cachedYourItemsItem;
               var8.setItem(var214, var286);
               var365 = 1717670815 ^ var365;
            }

            int var211 = o0oOo0KoOoOK.sortSlot;
            ItemStack var281 = this.getCachedSortItem();
            var8.setItem(var211, var281);
            var365 = 321443629 ^ var365;
            byte var82 = NEW_AUCTION_LORE;
            if (var82 != (1088341316 ^ var365)) {
               var365 = 1062259718 ^ var365;
               String var83 = wjiertwehi(toqtqdjdcitovvg(), xreaynobfrqbnip(), var365);
               o0o0oOKo0K var84 = o0o0oOKo0K.of(var83);
               var365 = 350473997 ^ var365;
               int var212 = o0oOo0KoOoOK.filterSlot;
               String var316 = wjiertwehi(hmgyaxlqtmpkeip(), xreaynobfrqbnip(), var365);
               Material var337 = Material.ENDER_CHEST;
               String var343 = wjiertwehi(uzqplpcwrcebjdr(), xreaynobfrqbnip(), var365);
               var365 = 666165135 ^ var365;
               String var344 = oOo0KKoOoOK.color(var343);
               String var350 = wjiertwehi(fqhtnjjkbsvincr(), xreaynobfrqbnip(), var365);
               var365 = 255980564 ^ var365;
               String var351 = oOo0KKoOoOK.color(var350);
               List var352 = List.of(var351);
               var365 = 1978203016 ^ var365;
               ItemStack var283 = var84.button(var316, var337, var344, var352);
               var365 = 492907359 ^ var365;
               var8.setItem(var212, var283);
               var365 = 468173135 ^ var365;
               var365 = 875943811 ^ var365;
            } else {
               var365 = gvqzrkmahtxotvmd(var365, 1482433014);
               int var213 = o0oOo0KoOoOK.filterSlot;
               ItemStack var285 = this.getCachedFilterItem();
               var8.setItem(var213, var285);
               var365 = 474075005 ^ var365;
            }

            return;
         }

         var179.setLore(var360);
         var365 = 1675450729 ^ var365;
         var107.setItemMeta(var179);
         var365 = 1489888855 ^ var365;
         var8.setItem(var104, var107);
         var365 = 1037730480 ^ var365;
         var14 += 1394565122 ^ var365;
         var365 = 507606060 ^ var365;
      }
   }

   private static String getMaterialName(Material var0) {
      int var8 = 869210254 ^ 1261582023 ^ 1243011330;
      var8 = 1598933782 ^ var8;
      Map var1 = MATERIAL_NAME_CACHE;
      Function var3 = (var0x) -> {
         int var39 = 1550412370 ^ 1972348299 ^ 1243011330;
         var39 = 37384420 ^ var39;
         String var7 = var0x.name();
         var39 = 55400107 ^ var39;
         StringBuilder var8 = new StringBuilder();
         StringBuilder var4 = var8;
         var39 = 1385668993 ^ var39;
         String var22 = wjiertwehi(wlgemropadwhqtl(), xreaynobfrqbnip(), var39);
         String[] var10 = var7.split(var22);
         String[] var5 = var10;
         var39 = 350682780 ^ var39;
         byte var11 = (byte)(620130185 ^ var39);
         int var6 = var11;
         var39 = 430609206 ^ var39;

         while(true) {
            int var24 = var5.length;
            if (var6 >= var24) {
               var39 = gvqzrkmahtxotvmd(var39, 902802251);
               String var14 = var4.toString();
               return var14;
            }

            var39 = 992618444 ^ var39;
            if (var6 > (108452723 ^ var39)) {
               var39 = 701912718 ^ var39;
               byte var25 = (byte)(799051229 ^ var39);
               StringBuilder var17 = var4.append((char)var25);
               var39 = 936355015 ^ var39;
            } else {
               label23:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var39)) {
                     case 57777806:
                        break label23;
                     case 101673933:
                        var39 ^= 505016905;
                        break label23;
                     case 567845014:
                     default:
                        throw new RuntimeException();
                     case 1669427922:
                  }
               }
            }

            String var27 = var5[var6];
            byte var34 = (byte)(409938234 ^ var39);
            char var28 = var27.charAt(var34);
            char var29 = Character.toUpperCase(var28);
            StringBuilder var19 = var4.append(var29);
            var39 = 1193735467 ^ var39;
            String var31 = var5[var6];
            byte var36 = (byte)(1598675984 ^ var39);
            String var32 = var31.substring(var36);
            String var33 = var32.toLowerCase();
            StringBuilder var21 = var4.append(var33);
            var39 = 1813132918 ^ var39;
            var6 += 861661798 ^ var39;
            var39 = 235345624 ^ var39;
         }
      };
      Object var4 = var1.computeIfAbsent(var0, var3);
      String var5 = (String)var4;
      return var5;
   }

   private ItemStack createSearchItem() {
      int var77 = 781464498 ^ 846299551 ^ 378349300;
      var77 = 897130884 ^ var77;
      ItemStack var1 = new ItemStack;
      byte var2 = NEW_AUCTION_LORE;
      Material var62;
      if (var2 != (1058125149 ^ var77)) {
         var77 = 1190488574 ^ var77;
         o0o0oOKo0K var61 = acfg();
         String var70 = wjiertwehi(uebflnnflyjwzfv(), xreaynobfrqbnip(), var77);
         Material var73 = o0oOo0KoOoOK.searchMaterial;
         var62 = var61.material(var70, var73);
         var77 = gvqzrkmahtxotvmd(var77, 1305497696);
      } else {
         label58:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var77)) {
               case 171077749:
                  var77 ^= 617647924;
               case 410726420:
                  break label58;
               case 1160085275:
               default:
                  throw new RuntimeException();
               case 1426122820:
            }
         }

         var62 = o0oOo0KoOoOK.searchMaterial;
         var77 = 804632234 ^ var77;
      }

      var1.<init>(var62);
      var77 = 471171441 ^ var77;
      ItemMeta var10 = var1.getItemMeta();
      var77 = 732971240 ^ var77;
      byte var11 = NEW_AUCTION_LORE;
      if (var11 != (59854170 ^ var77)) {
         var77 = 1454569916 ^ var77;
         o0o0oOKo0K var26 = acfg();
         var77 = 1932480599 ^ var77;
         String var56 = wjiertwehi(ogolyrfqjuxsvgn(), xreaynobfrqbnip(), var77);
         String var64 = wjiertwehi(izyfhhpukxgblqs(), xreaynobfrqbnip(), var77);
         String var65 = oOo0KKoOoOK.color(var64);
         String var47 = var26.name(var56, var65);
         var10.setDisplayName(var47);
         var77 = 1186607917 ^ var77;
         String var66 = wjiertwehi(mrerclwnhjilepf(), xreaynobfrqbnip(), var77);
         String var4 = wjiertwehi(otocfnimuzmptpk(), xreaynobfrqbnip(), var77);
         var77 = 1863759343 ^ var77;
         String var71 = oOo0KKoOoOK.color(var4);
         List var72 = List.of(var71);
         List var58 = var26.lore(var66, var72);
         ArrayList var28 = new ArrayList(var58);
         var77 = 53327156 ^ var77;
         String var30 = this.searchQuery;
         if (var30 != null) {
            var77 = 93120462 ^ var77;
            String var32 = this.searchQuery;
            byte var33 = var32.isEmpty();
            if (var33 == (151072905 ^ var77)) {
               var77 = 67980948 ^ var77;
               String var59 = wjiertwehi(dtimtpspfnnaynh(), xreaynobfrqbnip(), var77);
               String var67 = wjiertwehi(vtneqwuolomomgl(), xreaynobfrqbnip(), var77);
               String var49 = var26.rawStr(var59, var67);
               String var60 = wjiertwehi(pgzmigzkejnjvfx(), xreaynobfrqbnip(), var77);
               String var69 = this.searchQuery;
               var77 = 2070057513 ^ var77;
               String var50 = var49.replace(var60, var69);
               var77 = 1198553684 ^ var77;
               String var51 = oOo0KKoOoOK.color(var50);
               var28.add(var51);
               var77 = 1930383218 ^ var77;
            } else {
               var77 = 1259399579 ^ var77;
            }
         } else {
            var77 = gvqzrkmahtxotvmd(var77, 1318850133);
         }

         var10.setLore(var28);
         var77 = 1654066426 ^ var77;
         var1.setItemMeta(var10);
         var77 = 42671145 ^ var77;
         return var1;
      } else {
         label47: {
            var77 = gvqzrkmahtxotvmd(var77, 1966950239);
            String var40 = o0oOo0KoOoOK.searchName;
            var10.setDisplayName(var40);
            var77 = 526947914 ^ var77;
            String var14 = this.searchQuery;
            if (var14 != null) {
               var77 = 2073339204 ^ var77;
               String var16 = this.searchQuery;
               byte var17 = var16.isEmpty();
               if (var17 == (307247371 ^ var77)) {
                  label41:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var77)) {
                        case 58424533:
                           var77 ^= 1534004266;
                           break label41;
                        case 1216136714:
                        default:
                           throw new RuntimeException();
                        case 1634503031:
                           break label41;
                        case 1993867442:
                     }
                  }

                  List var54 = o0oOo0KoOoOK.searchLore;
                  ArrayList var18 = new ArrayList(var54);
                  var77 = 462728945 ^ var77;
                  String var41 = o0oOo0KoOoOK.searchLoreQuery;
                  String var55 = wjiertwehi(yobyfbaeskdgbjq(), xreaynobfrqbnip(), var77);
                  String var63 = this.searchQuery;
                  String var42 = var41.replace(var55, var63);
                  var18.add(var42);
                  var77 = 1939571056 ^ var77;
                  var10.setLore(var18);
                  var77 = 953027418 ^ var77;
                  break label47;
               }

               var77 = 1713092518 ^ var77;
            } else {
               var77 = gvqzrkmahtxotvmd(var77, 495915746);
            }

            List var45 = o0oOo0KoOoOK.searchLore;
            var10.setLore(var45);
            var77 = gvqzrkmahtxotvmd(var77, 1840619351);
         }

         boolean var23 = var1.setItemMeta(var10);
         var77 = 731617786 ^ var77;
         return var1;
      }
   }

   private ItemStack createGuiItem(Material var1, String var2, List<String> var3) {
      int var24 = 1037546327 ^ 1601238664 ^ 378349300;
      var24 = 1982681182 ^ var24;
      ItemStack var4 = new ItemStack(var1);
      var24 = 1519396565 ^ var24;
      ItemMeta var9 = var4.getItemMeta();
      var24 = 1195876379 ^ var24;
      String var19 = oOo0KKoOoOK.color(var2);
      var9.setDisplayName(var19);
      var24 = 1940843141 ^ var24;
      if (var3 != null) {
         var24 ^= 1274292601;
         byte var13 = var3.isEmpty();
         if (var13 == (663385671 ^ var24)) {
            var24 = 992717519 ^ var24;
            var9.setLore(var3);
            var24 = 1878011586 ^ var24;
         } else {
            label24:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var24)) {
                  case 211575459:
                     var24 ^= 1423672333;
                  case 591211174:
                     break label24;
                  case 1181060145:
                  default:
                     throw new IOException();
                  case 1661549186:
               }
            }
         }
      } else {
         label37:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var24)) {
               case 37008630:
                  var24 ^= 523218292;
                  break label37;
               case 1198479837:
               default:
                  throw new IOException();
               case 2011385936:
                  break label37;
               case 2094052218:
            }
         }
      }

      boolean var16 = var4.setItemMeta(var9);
      var24 = 2080463524 ^ var24;
      return var4;
   }

   private ItemStack getCachedSortItem() {
      label27: {
         int var17 = 1939753519 ^ 238678921 ^ 378349300;
         var17 = 1476689114 ^ var17;
         ItemStack var3 = this.cachedSortItem;
         if (var3 != null) {
            var17 = 1132087687 ^ var17;
            AuctionSortOrder var5 = this.cachedSortType;
            AuctionSortOrder var10 = this.currentSort;
            if (var5 == var10) {
               var17 = gvqzrkmahtxotvmd(var17, 1322793883);
               break label27;
            }

            var17 = 1561688274 ^ var17;
         } else {
            label25:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var17)) {
                  case 53144569:
                     var17 ^= 510603605;
                     break label25;
                  case 468351598:
                  default:
                     throw new RuntimeException();
                  case 879988181:
                     break label25;
                  case 1172367349:
               }
            }
         }

         ItemStack var12 = this.buildSortItem();
         this.cachedSortItem = var12;
         var17 = 924371222 ^ var17;
         AuctionSortOrder var14 = this.currentSort;
         this.cachedSortType = var14;
         var17 = 617974367 ^ var17;
      }

      ItemStack var9 = this.cachedSortItem;
      return var9;
   }

   private static List<AuctionSortOrder> sortCycle() {
      int var40 = 133918965 ^ 1899634291 ^ 1243011330;
      var40 = 1041779755 ^ var40;
      ArrayList var0 = new ArrayList();
      ArrayList var4 = var0;
      var40 = 796515779 ^ var40;
      o0o0oOKo0K var8 = acfg();
      String var29 = wjiertwehi(xlkuymxozvqlknt(), xreaynobfrqbnip(), var40);
      String var1 = wjiertwehi(ddzmwrbajhzkyun(), xreaynobfrqbnip(), var40);
      String var2 = wjiertwehi(vxekjlmjfqxgrgv(), xreaynobfrqbnip(), var40);
      String var3 = wjiertwehi(qtbmbxwdtcenxuo(), xreaynobfrqbnip(), var40);
      var40 = 410386121 ^ var40;
      List var37 = List.of(var1, var2, var3);
      var40 = 1245604585 ^ var40;
      List var9 = var8.rawListAt(var29, var37);
      Iterator var10 = var9.iterator();
      Iterator var5 = var10;
      var40 = 1930097075 ^ var40;

      while(true) {
         byte var12 = var5.hasNext();
         if (var12 == (217531391 ^ var40)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var40)) {
                  case 153034569:
                     var40 ^= 216938677;
                  case 1088156470:
                     byte var21 = var4.isEmpty();
                     if (var21 != (1669962 ^ var40)) {
                        var40 = 1166622512 ^ var40;
                        AuctionSortOrder var34 = AuctionSortOrder.LOWEST_PRICE;
                        var4.add(var34);
                        var40 = 2089333978 ^ var40;
                        AuctionSortOrder var35 = AuctionSortOrder.HIGHEST_PRICE;
                        var4.add(var35);
                        var40 = 2120187780 ^ var40;
                        AuctionSortOrder var36 = AuctionSortOrder.RECENTLY_LISTED;
                        var4.add(var36);
                        var40 = 722237561 ^ var40;
                     } else {
                        var40 = gvqzrkmahtxotvmd(var40, 1817349143);
                     }

                     return var4;
                  case 671417481:
                  default:
                     throw new IOException();
                  case 1228109686:
               }
            }
         }

         var40 = 1411747005 ^ var40;
         Object var14 = var5.next();
         String var15 = (String)var14;
         String var6 = var15;
         var40 = 449429938 ^ var40;
         if (var15 == null) {
            var40 = 13409346 ^ var40;
            var40 = 1310773581 ^ var40;
         } else {
            var40 = gvqzrkmahtxotvmd(var40, 1306040095);

            label41: {
               try {
                  String var31 = var6.trim();
                  String var32 = var31.toUpperCase();
                  AuctionSortOrder var33 = AuctionSortOrder.valueOf(var32);
                  boolean var18 = var4.add(var33);
                  var40 = 816159987 ^ var40;
               } catch (IllegalArgumentException var41) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var40)) {
                     case 2115817336:
                        var40 = gvqzrkmahtxotvmd(var40, 1792488524);
                        var40 = 292231782 ^ var40;
                        break label41;
                     default:
                        throw new RuntimeException("Error in hash");
                  }
               }

               var40 = 1259975385 ^ var40;
            }

            var40 = 2022241338 ^ var40;
         }
      }
   }

   private static String sortLabel(o0o0oOKo0K var0, AuctionSortOrder var1) {
      int var11 = 1986982816 ^ 1921673101 ^ 1243011330;
      var11 = 1559927690 ^ var11;
      String var6 = var1.name();
      String var7 = "sort.labels." + var6;
      String var8 = defaultSortLabel(var1);
      String var5 = var0.rawStr(var7, var8);
      return var5;
   }

   private static String defaultSortLabel(AuctionSortOrder var0) {
      int var13 = 1115660741 ^ 1730793950 ^ 1243011330;
      var13 = 939316357 ^ var13;
      int[] var1 = null.$SwitchMap$org$mz$donutsmpcore$auction$SortType;
      int var10 = var0.ordinal();
      int var3 = var1[var10];
      switch (var3) {
         case 1:
            var13 = 1663085156 ^ var13;
            String var9 = wjiertwehi(oiqlwirpbgwdyqa(), xreaynobfrqbnip(), var13);
            return var9;
         case 2:
            var13 = gvqzrkmahtxotvmd(var13, 232673632);
            String var8 = wjiertwehi(kiiokhnsxpwjszz(), xreaynobfrqbnip(), var13);
            return var8;
         case 3:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var13)) {
                  case 200109026:
                     var13 ^= 367347228;
                  case 1683375734:
                     String var4 = wjiertwehi(bgoedvfrxhcnwvs(), xreaynobfrqbnip(), var13);
                     return var4;
                  case 1364587215:
                  default:
                     throw new RuntimeException();
                  case 1394668011:
               }
            }
         default:
            var13 = gvqzrkmahtxotvmd(var13, 1798462449);
            String var6 = var0.name();
            String var7 = prettify(var6);
            return var7;
      }
   }

   private static String prettify(String var0) {
      int var45 = 1579274291 ^ 854397405 ^ 1243011330;
      var45 = 350709981 ^ var45;
      String var8 = o0oOoOo0oOK.material(var0);
      var45 = 1491977110 ^ var45;
      if (var8 != null) {
         var45 = 1204689085 ^ var45;
         return var8;
      } else {
         var45 = gvqzrkmahtxotvmd(var45, 1585098611);
         StringBuilder var10 = new StringBuilder();
         StringBuilder var42 = var10;
         var45 = 1661260789 ^ var45;
         String var31 = wjiertwehi(wcpblmvlkrrbhqt(), xreaynobfrqbnip(), var45);
         String[] var12 = var0.split(var31);
         String[] var4 = var12;
         int var14 = var12.length;
         int var5 = var14;
         byte var15 = (byte)(1471074081 ^ var45);
         int var6 = var15;

         for(var45 = 1895385213 ^ var45; var6 < var5; var45 = gvqzrkmahtxotvmd(var45, 465525521)) {
            var45 = 1180719769 ^ var45;
            String var20 = var4[var6];
            var45 = 1368290631 ^ var45;
            byte var22 = var20.isEmpty();
            if (var22 != (817473666 ^ var45)) {
               var45 = 2087209388 ^ var45;
               var45 = gvqzrkmahtxotvmd(var45, 1882799459);
            } else {
               label34:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var45)) {
                     case 145502988:
                        break;
                     case 241665730:
                        var45 ^= 739632753;
                     case 417828746:
                        break label34;
                     case 1144830326:
                     default:
                        throw new IllegalAccessException();
                  }
               }

               int var24 = var42.length();
               if (var24 > (481054451 ^ var45)) {
                  var45 = 739741922 ^ var45;
                  byte var34 = (byte)(817618481 ^ var45);
                  StringBuilder var26 = var42.append((char)var34);
                  var45 = 1643146566 ^ var45;
               } else {
                  var45 = 1307049380 ^ var45;
               }

               byte var2 = (byte)(1363915607 ^ var45);
               char var36 = var20.charAt(var2);
               char var37 = Character.toUpperCase(var36);
               StringBuilder var28 = var42.append(var37);
               byte var41 = (byte)(1363915606 ^ var45);
               String var39 = var20.substring(var41);
               String var40 = var39.toLowerCase();
               var28.append(var40);
               var45 = 1839427354 ^ var45;
            }

            var6 += 1021893708 ^ var45;
         }

         var45 = 1249316938 ^ var45;
         String var18 = var42.toString();
         return var18;
      }
   }

   private ItemStack buildSortItem() {
      int var161 = 1447150252 ^ 704832495 ^ 378349300;
      var161 = 951463895 ^ var161;
      byte var1 = NEW_AUCTION_LORE;
      ItemStack var52;
      ItemMeta var54;
      o0o0oOKo0K var57;
      String[] var85;
      byte var112;
      String var132;
      if (var1 != (1383606368 ^ var161)) {
         var161 = 1442252553 ^ var161;
         o0o0oOKo0K var17 = acfg();
         o0o0oOKo0K var8 = var17;
         var161 = 844668004 ^ var161;
         String var3 = wjiertwehi(otlcrodyvsxxwjz(), xreaynobfrqbnip(), var161);
         Material var4 = Material.HOPPER;
         Material var89 = var17.material(var3, var4);
         ItemStack var18 = new ItemStack(var89);
         var161 = 1918121311 ^ var161;
         ItemMeta var20 = var18.getItemMeta();
         var161 = 571976316 ^ var161;
         String var90 = wjiertwehi(ewarbjuukhxmjlt(), xreaynobfrqbnip(), var161);
         String var101 = wjiertwehi(wwfsjrovunwouct(), xreaynobfrqbnip(), var161);
         String var102 = oOo0KKoOoOK.color(var101);
         String var67 = var17.name(var90, var102);
         var20.setDisplayName(var67);
         var161 = 577816417 ^ var161;
         String var68 = wjiertwehi(zjgajjqcyymzbvh(), xreaynobfrqbnip(), var161);
         String var91 = wjiertwehi(mtxcdydadkwhtsa(), xreaynobfrqbnip(), var161);
         String var23 = var17.rawStr(var68, var91);
         String var11 = var23;
         var161 = 308217275 ^ var161;
         String var69 = wjiertwehi(csmfsynfhdzmqlr(), xreaynobfrqbnip(), var161);
         String var92 = wjiertwehi(pdwusuxdeplgnux(), xreaynobfrqbnip(), var161);
         String var25 = var17.rawStr(var69, var92);
         String var12 = var25;
         var161 = 770581945 ^ var161;
         String var70 = wjiertwehi(myuynzcikpmaodj(), xreaynobfrqbnip(), var161);
         String var93 = wjiertwehi(mswtkclbuqpqgma(), xreaynobfrqbnip(), var161);
         String var27 = var17.rawStr(var70, var93);
         String var13 = var27;
         var161 = 1174459592 ^ var161;
         ArrayList var28 = new ArrayList();
         ArrayList var14 = var28;
         var161 = 1473641741 ^ var161;
         String var71 = wjiertwehi(unqvtewbnsjconf(), xreaynobfrqbnip(), var161);
         String var94 = wjiertwehi(iejsyyxvaervcgl(), xreaynobfrqbnip(), var161);
         String var103 = wjiertwehi(wrjvbyxcacwqcrq(), xreaynobfrqbnip(), var161);
         var161 = 389548292 ^ var161;
         List var95 = List.of(var94, var103);
         var161 = 1813497278 ^ var161;
         List var30 = var17.rawListAt(var71, var95);
         Iterator var31 = var30.iterator();
         Iterator var15 = var31;
         var161 = 725428145 ^ var161;

         while(true) {
            byte var33 = var15.hasNext();
            if (var33 == (965872003 ^ var161)) {
               var161 = 533581807 ^ var161;
               List var39 = sortCycle();
               Iterator var40 = var39.iterator();
               Iterator var157 = var40;
               var161 = 658702386 ^ var161;

               label68:
               while(true) {
                  byte var42 = var157.hasNext();
                  if (var42 == (18663006 ^ var161)) {
                     var161 = 1133546162 ^ var161;
                     var20.setLore(var14);
                     var161 = 2092210746 ^ var161;
                     var18.setItemMeta(var20);
                     var161 = 1725909305 ^ var161;
                     return var18;
                  }

                  var161 = 1734113807 ^ var161;
                  Object var44 = var157.next();
                  AuctionSortOrder var45 = (AuctionSortOrder)var44;
                  var161 = 301779331 ^ var161;
                  String var96 = wjiertwehi(fmaubuzjuisqiys(), xreaynobfrqbnip(), var161);
                  var161 = 1302465568 ^ var161;
                  AuctionSortOrder var105 = this.currentSort;
                  String var106;
                  if (var105 == var45) {
                     var161 = 69232482 ^ var161;
                     var106 = var11;
                     var161 = 185949522 ^ var161;
                  } else {
                     var161 = gvqzrkmahtxotvmd(var161, 657764744);
                     var106 = var12;
                     var161 = 671189944 ^ var161;
                  }

                  String var76 = var13.replace(var96, var106);
                  String var97 = wjiertwehi(tucofigodjpwyyv(), xreaynobfrqbnip(), var161);
                  var161 = 1221014423 ^ var161;
                  String var108 = sortLabel(var8, var45);
                  String var77 = var76.replace(var97, var108);
                  var161 = 2060842335 ^ var161;
                  String var78 = oOo0KKoOoOK.color(var77);
                  boolean var47 = var14.add(var78);
                  var161 = 1550732028 ^ var161;

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var161)) {
                        case 16415163:
                           var161 ^= 1514867112;
                           continue label68;
                        case 44657102:
                        default:
                           throw new RuntimeException();
                        case 927150576:
                           continue label68;
                        case 1774546821:
                     }
                  }
               }
            }

            var161 = 138873196 ^ var161;
            Object var35 = var15.next();
            String var36 = (String)var35;
            var161 = 1834040730 ^ var161;
            byte var73 = var36.isEmpty();
            String var88;
            if (var73 == (1552170357 ^ var161)) {
               var161 = 1750163033 ^ var161;
               var88 = oOo0KKoOoOK.color(var36);
               var161 = 1592859335 ^ var161;
            } else {
               var161 = 1274348855 ^ var161;
               var88 = wjiertwehi(wjlggtijjskgrzb(), xreaynobfrqbnip(), var161);

               label86:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var161)) {
                     case 199361909:
                        break;
                     case 225135502:
                        var161 ^= 2102739369;
                        break label86;
                     case 1317652437:
                     default:
                        throw new RuntimeException();
                     case 1710383526:
                        break label86;
                  }
               }
            }

            var14.add(var88);
            var161 = 2043976775 ^ var161;
            var161 = 711126063 ^ var161;
         }
      } else {
         var161 = 1236212687 ^ var161;
         Material var98 = o0oOo0KoOoOK.sortMaterial;
         var52 = new ItemStack(var98);
         var161 = 65168867 ^ var161;
         var54 = var52.getItemMeta();
         var161 = 1519839856 ^ var161;
         String var81 = o0oOo0KoOoOK.sortName;
         var54.setDisplayName(var81);
         var161 = 1009508292 ^ var161;
         String var56 = wjiertwehi(guhebklrsesefyn(), xreaynobfrqbnip(), var161);
         var161 = 105463929 ^ var161;
         var57 = o0o0oOKo0K.of(var56);
         var161 = 1153130687 ^ var161;
         String var82 = wjiertwehi(rfjywpotbftqstw(), xreaynobfrqbnip(), var161);
         String var99 = wjiertwehi(lshhldmmvjsvlsn(), xreaynobfrqbnip(), var161);
         String var59 = var57.rawStr(var82, var99);
         var161 = 498807154 ^ var161;
         String var83 = wjiertwehi(icdzokctyoevunq(), xreaynobfrqbnip(), var161);
         String var100 = wjiertwehi(pyifofgpkzoyorj(), xreaynobfrqbnip(), var161);
         String var61 = var57.rawStr(var83, var100);
         var161 = 297341377 ^ var161;
         byte var84 = (byte)(813196169 ^ var161);
         var85 = new String[var84];
         byte var109 = (byte)(813196173 ^ var161);
         var161 = 1584396095 ^ var161;
         AuctionSortOrder var116 = this.currentSort;
         AuctionSortOrder var5 = AuctionSortOrder.HIGHEST_PRICE;
         String var117;
         if (var116 == var5) {
            var161 = 481217435 ^ var161;
            var117 = var59;

            label139:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var161)) {
                  case 239557350:
                     var161 ^= 1540527781;
                  case 356861988:
                     break label139;
                  case 576310380:
                  default:
                     throw new RuntimeException();
                  case 775007380:
               }
            }
         } else {
            var161 = gvqzrkmahtxotvmd(var161, 526805574);
            var117 = var61;
            var161 = 1478113144 ^ var161;
         }

         String var6 = wjiertwehi(rfkhxqcjmztnrul(), xreaynobfrqbnip(), var161);
         String var7 = wjiertwehi(ekrjvczkeweladr(), xreaynobfrqbnip(), var161);
         String var136 = var57.rawStr(var6, var7);
         String var118 = var117 + var136;
         String var119 = oOo0KKoOoOK.color(var118);
         var85[var109] = var119;
         byte var110 = (byte)(694929805 ^ var161);
         var161 = 294309724 ^ var161;
         AuctionSortOrder var121 = this.currentSort;
         AuctionSortOrder var137 = AuctionSortOrder.LOWEST_PRICE;
         String var133;
         if (var121 == var137) {
            var161 = 48632816 ^ var161;
            var133 = var59;

            label127:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var161)) {
                  case 7176937:
                     var161 ^= 263944818;
                     break label127;
                  case 961474526:
                  default:
                     throw new RuntimeException();
                  case 1486835335:
                     break label127;
                  case 2090904071:
               }
            }
         } else {
            var161 = 162365192 ^ var161;
            var133 = var61;
            var161 = 82843274 ^ var161;
         }

         String var146 = wjiertwehi(lfbsextdubtbcuu(), xreaynobfrqbnip(), var161);
         String var149 = wjiertwehi(hueleleunnxguel(), xreaynobfrqbnip(), var161);
         String var139 = var57.rawStr(var146, var149);
         String var122 = var133 + var139;
         String var123 = oOo0KKoOoOK.color(var122);
         var85[var110] = var123;
         byte var111 = (byte)(901541712 ^ var161);
         var161 = 1653887149 ^ var161;
         AuctionSortOrder var125 = this.currentSort;
         AuctionSortOrder var140 = AuctionSortOrder.LAST_LISTED;
         String var134;
         if (var125 == var140) {
            var161 = 522890780 ^ var161;
            var134 = var59;

            label115:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var161)) {
                  case 116763758:
                  default:
                     throw new RuntimeException();
                  case 193245861:
                     var161 ^= 1696537407;
                     break label115;
                  case 1193949917:
                     break;
                  case 1363637044:
                     break label115;
               }
            }
         } else {
            var161 = gvqzrkmahtxotvmd(var161, 599243920);
            var134 = var61;
            var161 = 1501694387 ^ var161;
         }

         String var147 = wjiertwehi(avdfahnzahfawyz(), xreaynobfrqbnip(), var161);
         String var150 = wjiertwehi(dzwfmmubmlxvont(), xreaynobfrqbnip(), var161);
         String var142 = var57.rawStr(var147, var150);
         String var126 = var134 + var142;
         String var127 = oOo0KKoOoOK.color(var126);
         var85[var111] = var127;
         var112 = (byte)(756910815 ^ var161);
         var161 = 77848162 ^ var161;
         AuctionSortOrder var129 = this.currentSort;
         AuctionSortOrder var143 = AuctionSortOrder.RECENTLY_LISTED;
         if (var129 == var143) {
            var161 = 1993580607 ^ var161;
            var132 = var59;
            var161 = 1126825844 ^ var161;
         } else {
            label104:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var161)) {
                  case 14740878:
                     var161 ^= 34660396;
                  case 635715628:
                     break label104;
                  case 1004776636:
                     break;
                  case 2073528305:
                  default:
                     throw new RuntimeException();
               }
            }

            var132 = var61;
            var161 = 938131303 ^ var161;
         }
      }

      String var148 = wjiertwehi(zmglitzbiolggtc(), xreaynobfrqbnip(), var161);
      String var151 = wjiertwehi(lekpzouboqremvl(), xreaynobfrqbnip(), var161);
      String var145 = var57.rawStr(var148, var151);
      String var130 = var132 + var145;
      String var131 = oOo0KKoOoOK.color(var130);
      var85[var112] = var131;
      var161 = 1695380681 ^ var161;
      List var86 = Arrays.asList(var85);
      var54.setLore(var86);
      var161 = 613030497 ^ var161;
      var52.setItemMeta(var54);
      var161 = 1721138605 ^ var161;
      return var52;
   }

   private ItemStack getCachedFilterItem() {
      label15: {
         int var17 = 879096251 ^ 960388635 ^ 378349300;
         var17 = 81189435 ^ var17;
         ItemStack var3 = this.cachedFilterItem;
         if (var3 != null) {
            var17 = 1776605951 ^ var17;
            AuctionCategory var5 = this.cachedFilterType;
            AuctionCategory var10 = this.currentFilter;
            if (var5 == var10) {
               var17 = gvqzrkmahtxotvmd(var17, 1532849469);
               break label15;
            }

            var17 = 1404728011 ^ var17;
         } else {
            var17 = 979281972 ^ var17;
         }

         ItemStack var12 = this.buildFilterItem();
         this.cachedFilterItem = var12;
         var17 = 10293009 ^ var17;
         AuctionCategory var14 = this.currentFilter;
         this.cachedFilterType = var14;
         var17 = 142217447 ^ var17;
      }

      ItemStack var9 = this.cachedFilterItem;
      return var9;
   }

   private ItemStack buildFilterItem() {
      int var64 = 1291533390 ^ 1059206388 ^ 378349300;
      var64 = 1665375772 ^ var64;
      Material var2 = o0oOo0KoOoOK.filterMaterial;
      ItemStack var1 = new ItemStack(var2);
      var64 = 819748942 ^ var64;
      ItemMeta var17 = var1.getItemMeta();
      var64 = 972445897 ^ var64;
      String var41 = o0oOo0KoOoOK.filterName;
      var17.setDisplayName(var41);
      var64 = 431838948 ^ var64;
      String var19 = wjiertwehi(bfrlujaspoinema(), xreaynobfrqbnip(), var64);
      var64 = 899243790 ^ var64;
      o0o0oOKo0K var20 = o0o0oOKo0K.of(var19);
      var64 = 701630297 ^ var64;
      String var42 = wjiertwehi(gcyvinpoejbvdni(), xreaynobfrqbnip(), var64);
      String var53 = wjiertwehi(ucaijdulmytpjue(), xreaynobfrqbnip(), var64);
      String var22 = var20.rawStr(var42, var53);
      String var8 = var22;
      var64 = 109455791 ^ var64;
      String var43 = wjiertwehi(vhvrbmtpjezjzua(), xreaynobfrqbnip(), var64);
      String var54 = wjiertwehi(hlyxisalagyphjv(), xreaynobfrqbnip(), var64);
      String var24 = var20.rawStr(var43, var54);
      String var9 = var24;
      var64 = 197444673 ^ var64;
      String var44 = wjiertwehi(mzdvzwhgqjftcxb(), xreaynobfrqbnip(), var64);
      String var55 = wjiertwehi(xccodpftzjvossk(), xreaynobfrqbnip(), var64);
      String var26 = var20.rawStr(var44, var55);
      String var10 = var26;
      var64 = 1417624913 ^ var64;
      ArrayList var27 = new ArrayList();
      ArrayList var11 = var27;
      var64 = 2053779345 ^ var64;
      AuctionCategory[] var28 = AuctionCategory.values();
      AuctionCategory[] var12 = var28;
      int var30 = var28.length;
      int var13 = var30;
      byte var31 = (byte)(698120520 ^ var64);
      int var14 = var31;

      for(var64 = 19959979 ^ var64; var14 < var13; var64 = 1437206761 ^ var64) {
         var64 = 2066053237 ^ var64;
         AuctionCategory var38 = var12[var14];
         var64 = 201749944 ^ var64;
         String var56 = wjiertwehi(slldubkratskieg(), xreaynobfrqbnip(), var64);
         var64 = 849075628 ^ var64;
         AuctionCategory var58 = this.currentFilter;
         String var59;
         if (var58 == var38) {
            var64 = 95369854 ^ var64;
            var59 = var8;
            var64 = gvqzrkmahtxotvmd(var64, 1799856824);
         } else {
            var64 = 1860873149 ^ var64;
            var59 = var9;
            var64 = 144251 ^ var64;
         }

         String var50 = var10.replace(var56, var59);
         String var57 = wjiertwehi(ssdxgspnmstmqva(), xreaynobfrqbnip(), var64);
         int var82 = 1364423038 ^ var64;
         String var61 = var38.getDisplay();
         String var51 = var50.replace(var57, var61);
         int var83 = 1110317747 ^ var82;
         String var52 = oOo0KKoOoOK.color(var51);
         boolean var40 = var11.add(var52);
         var64 = 1837575043 ^ var83;
         var14 += 2097602827 ^ var64;
      }

      var64 = gvqzrkmahtxotvmd(var64, 693395215);
      var17.setLore(var11);
      var64 = 456950731 ^ var64;
      var1.setItemMeta(var17);
      var64 = 1221648055 ^ var64;
      return var1;
   }

   public void updateDisplayItems() {
      int var32 = 1286417762 ^ 1159150026 ^ 378349300;
      var32 = 2061163502 ^ var32;
      Player var5 = this.player;
      byte var6 = var5.isOnline();
      if (var6 == (1710090674 ^ var32)) {
         var32 = 1984701179 ^ var32;
      } else {
         var32 = gvqzrkmahtxotvmd(var32, 242312580);
         Player var8 = this.player;
         InventoryView var9 = var8.getOpenInventory();
         var32 = 535686349 ^ var32;
         Inventory var11 = var9.getTopInventory();
         Inventory var19 = this.inventory;
         if (var11 == var19) {
            var32 = gvqzrkmahtxotvmd(var32, 1233642331);
         } else {
            var32 = 1863188945 ^ var32;
            var32 = 1790383078 ^ var32;
            String var13 = var9.getTitle();
            if (var13 == null) {
               var32 = 323295260 ^ var32;
               return;
            }

            var32 = 931682658 ^ var32;
            String var15 = var9.getTitle();
            int var21 = this.page;
            byte var3 = (byte)(1178610607 ^ var32);
            int var22 = var21 + var3;
            String var23 = o0oOo0KoOoOK.getTitle(var22);
            byte var16 = var15.equals(var23);
            if (var16 == (1178610606 ^ var32)) {
               var32 = 617431422 ^ var32;
               return;
            }

            label35:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var32)) {
                  case 136057569:
                     var32 ^= 2075568142;
                     break label35;
                  case 444343653:
                  default:
                     throw new IOException();
                  case 1508513223:
                     break label35;
                  case 1701817651:
               }
            }
         }

         Inventory var25 = var9.getTopInventory();
         this.inventory = var25;
         var32 = 2006588370 ^ var32;
         KKoOoOo0oOK var18 = KKoOoOo0oOK.getInstance();
         Player var27 = this.player;
         Runnable var29 = this::decorate;
         var18.runAtEntity(var27, var29);
         var32 = 542834802 ^ var32;
      }
   }

   public void onClick(InventoryClickEvent var1) {
      int var24;
      int var25;
      int var26;
      int var27;
      int var28;
      int var29;
      int var30;
      int var31;
      byte var185;
      int var370;
      label394: {
         var370 = 1569329843 ^ 741341033 ^ 378349300;
         var370 = 845139266 ^ var370;
         byte var3 = (byte)(1433865837 ^ var370);
         var1.setCancelled((boolean)var3);
         var370 = 1098646197 ^ var370;
         var24 = var1.getRawSlot();
         var370 = 747018032 ^ var370;
         var25 = o0oOo0KoOoOK.refreshSlot;
         var370 = 1456342806 ^ var370;
         var26 = o0oOo0KoOoOK.sortSlot;
         var370 = 1410411353 ^ var370;
         var27 = o0oOo0KoOoOK.filterSlot;
         var370 = 549945054 ^ var370;
         var28 = o0oOo0KoOoOK.searchSlot;
         var370 = 1852893567 ^ var370;
         var29 = o0oOo0KoOoOK.yourItemsSlot;
         var370 = 62493876 ^ var370;
         var30 = o0oOo0KoOoOK.prevPageSlot;
         var370 = 316262668 ^ var370;
         var31 = o0oOo0KoOoOK.nextPageSlot;
         var370 = 1714753896 ^ var370;
         if (var24 != var26) {
            label369: {
               var370 = 2083932315 ^ var370;
               if (var24 == var27) {
                  var370 = 1519177183 ^ var370;
                  byte var34 = NEW_AUCTION_LORE;
                  if (var34 == (621472147 ^ var370)) {
                     var370 = 455916006 ^ var370;
                     break label369;
                  }

                  label364:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                        case 130351494:
                           var370 ^= 1128191131;
                           break label364;
                        case 765468322:
                           break;
                        case 1731548646:
                        default:
                           throw new RuntimeException();
                        case 2125743462:
                           break label364;
                     }
                  }
               } else {
                  var370 = gvqzrkmahtxotvmd(var370, 431102276);
               }

               var185 = (byte)(1714699528 ^ var370);
               var370 = 571992030 ^ var370;
               break label394;
            }
         } else {
            var370 = gvqzrkmahtxotvmd(var370, 1033256098);
         }

         var185 = (byte)(1042698356 ^ var370);
         var370 = 2047183523 ^ var370;
      }

      var370 = 1555909357 ^ var370;
      if (var185 != (413044795 ^ var370)) {
         var370 = 1787005065 ^ var370;
         Player var37 = this.player;
         String var189;
         if (var24 == var26) {
            var370 = 1526015185 ^ var370;
            var189 = wjiertwehi(ubflfpzxmbnehwl(), xreaynobfrqbnip(), var370);

            label337:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                  case 255974423:
                     var370 ^= 1076013659;
                     break label337;
                  case 708829435:
                     break;
                  case 911006315:
                     break label337;
                  case 939906131:
                  default:
                     throw new RuntimeException();
               }
            }
         } else {
            label349:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                  case 219688389:
                     var370 ^= 1228219638;
                  case 790432464:
                     break label349;
                  case 916388029:
                  default:
                     throw new RuntimeException();
                  case 1383502151:
               }
            }

            var189 = wjiertwehi(laypqmuiqffemuh(), xreaynobfrqbnip(), var370);
            var370 = 1407363708 ^ var370;
         }

         KKo0KoOoOK.filter(var37, var189);
         var370 = 1332142004 ^ var370;
      } else {
         var370 = gvqzrkmahtxotvmd(var370, 1060297143);
      }

      if (var185 == (665602444 ^ var370)) {
         var370 = 1861799916 ^ var370;
         if (var24 >= (1230276192 ^ var370)) {
            var370 = 198700179 ^ var370;
            Inventory var191 = this.inventory;
            int var192 = var191.getSize();
            if (var24 < var192) {
               var370 = 92553505 ^ var370;
               if (var24 != var25) {
                  var370 = 1597027252 ^ var370;
                  Player var43 = this.player;
                  Player var195 = this.player;
                  Location var196 = var195.getLocation();
                  String var264 = wjiertwehi(kgounbtjfkatupt(), xreaynobfrqbnip(), var370);
                  String var5 = wjiertwehi(mbtdhqfwznybrro(), xreaynobfrqbnip(), var370);
                  var370 = 1218164530 ^ var370;
                  Sound var265 = sound(var264, var5);
                  var370 = 774544322 ^ var370;
                  o0o0oOKo0K var307 = acfg();
                  String var6 = wjiertwehi(ncfwiwxkjiaplii(), xreaynobfrqbnip(), var370);
                  byte var7 = (byte)(2122757271 ^ var370);
                  int var308 = var307.intAt(var6, var7);
                  float var309 = (float)var308;
                  var370 = 1568063454 ^ var370;
                  o0o0oOKo0K var335 = acfg();
                  String var347 = wjiertwehi(tmahtxpdsokriib(), xreaynobfrqbnip(), var370);
                  byte var8 = (byte)(602934089 ^ var370);
                  int var336 = var335.intAt(var347, var8);
                  float var337 = (float)var336;
                  var370 = 539879233 ^ var370;
                  var43.playSound(var196, var265, var309, var337);
                  var370 = 134025996 ^ var370;
               } else {
                  var370 = 1126683863 ^ var370;
               }
            } else {
               label321:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                     case 14605749:
                        var370 ^= 1185125878;
                        break label321;
                     case 715884435:
                        break;
                     case 1726659843:
                     default:
                        throw new RuntimeException();
                     case 1892450418:
                        break label321;
                  }
               }
            }
         } else {
            var370 = 1299478885 ^ var370;
         }
      } else {
         var370 = gvqzrkmahtxotvmd(var370, 596424329);
      }

      if (var24 == var25) {
         var370 = 2100960065 ^ var370;
         Player var46 = this.player;
         Player var199 = this.player;
         Location var200 = var199.getLocation();
         String var266 = wjiertwehi(wkqvoniuvrsrerp(), xreaynobfrqbnip(), var370);
         String var310 = wjiertwehi(zmdhfhlmszfhjkg(), xreaynobfrqbnip(), var370);
         Sound var267 = sound(var266, var310);
         float var311 = 1.0F;
         float var338 = 1.5F;
         var46.playSound(var200, var267, var311, var338);
         var370 = 552457521 ^ var370;
         byte var47 = o0oOo0KoOoOK.rememberSortFilter;
         if (var47 == (1509372277 ^ var370)) {
            var370 = 685054648 ^ var370;
            byte var201 = (byte)(1898064845 ^ var370);
            this.page = var201;
            var370 = 1438395417 ^ var370;
            AuctionSortOrder var202 = AuctionSortOrder.RECENTLY_LISTED;
            this.currentSort = var202;
            var370 = 657411546 ^ var370;
            AuctionCategory var203 = AuctionCategory.ALL;
            this.currentFilter = var203;
            var370 = 469272685 ^ var370;
            String var204 = wjiertwehi(iwotpslhcflekce(), xreaynobfrqbnip(), var370);
            this.searchQuery = var204;
            var370 = 1786811616 ^ var370;
         } else {
            label181:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                  case 133892017:
                     break label181;
                  case 240039461:
                     var370 ^= 725510134;
                     break label181;
                  case 603005054:
                     break;
                  case 1620131661:
                  default:
                     throw new RuntimeException();
               }
            }
         }

         this.savePreferences();
         var370 = 1307035049 ^ var370;
         this.decorate();
         var370 = 752616103 ^ var370;
      } else {
         var370 = 1457199241 ^ var370;
         if (var24 == var26) {
            var370 = 1422925164 ^ var370;
            byte var55 = NEW_AUCTION_LORE;
            if (var55 != (103545568 ^ var370)) {
               var370 = 472491884 ^ var370;
               List var56 = sortCycle();
               var370 = 997200508 ^ var370;
               AuctionSortOrder var207 = this.currentSort;
               int var58 = var56.indexOf(var207);
               var370 = 1123276862 ^ var370;
               byte var312 = (byte)(1669437391 ^ var370);
               int var269 = var58 + var312;
               int var314 = var56.size();
               int var270 = var269 % var314;
               Object var209 = var56.get(var270);
               AuctionSortOrder var210 = (AuctionSortOrder)var209;
               this.currentSort = var210;
               var370 = 479568848 ^ var370;
               var370 = 750561864 ^ var370;
            } else {
               label207:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                     case 97074457:
                        var370 ^= 865906277;
                     case 277157390:
                        break label207;
                     case 981028880:
                        break;
                     case 1001026242:
                     default:
                        throw new RuntimeException();
                  }
               }

               AuctionSortOrder[] var213 = AuctionSortOrder.values();
               AuctionSortOrder var272 = this.currentSort;
               int var273 = var272.ordinal();
               byte var315 = (byte)(901207172 ^ var370);
               int var274 = var273 + var315;
               AuctionSortOrder[] var316 = AuctionSortOrder.values();
               int var317 = var316.length;
               int var275 = var274 % var317;
               AuctionSortOrder var214 = var213[var275];
               this.currentSort = var214;
               var370 = 1713359571 ^ var370;
            }

            byte var211 = (byte)(1403559510 ^ var370);
            this.page = var211;
            var370 = 1428433779 ^ var370;
            Object var212 = null;
            this.cachedSortItem = (ItemStack)var212;
            var370 = 2003595266 ^ var370;
            this.savePreferences();
            var370 = 2061341135 ^ var370;
            this.decorate();

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                  case 96919484:
                     var370 = 416269669 ^ var370;
                     return;
                  case 1070872585:
                  default:
                     throw new RuntimeException();
                  case 1215025678:
                     return;
                  case 1426348073:
               }
            }
         } else {
            var370 = 65248275 ^ var370;
            if (var24 == var27) {
               var370 = 1279725073 ^ var370;
               byte var178 = NEW_AUCTION_LORE;
               if (var178 != (492795278 ^ var370)) {
                  var370 = 591208003 ^ var370;
                  Player var301 = this.player;
                  AuctionItemSearchGUI var179 = new AuctionItemSearchGUI(var301);
                  var179.open();
                  var370 = 1687125608 ^ var370;
               } else {
                  var370 = gvqzrkmahtxotvmd(var370, 257142081);
                  AuctionCategory[] var260 = AuctionCategory.values();
                  AuctionCategory var303 = this.currentFilter;
                  int var304 = var303.ordinal();
                  byte var332 = (byte)(302831822 ^ var370);
                  int var305 = var304 + var332;
                  AuctionCategory[] var333 = AuctionCategory.values();
                  int var334 = var333.length;
                  int var306 = var305 % var334;
                  AuctionCategory var261 = var260[var306];
                  this.currentFilter = var261;
                  var370 = 2039226996 ^ var370;
                  byte var262 = (byte)(1803614907 ^ var370);
                  this.page = var262;
                  var370 = 811038453 ^ var370;
                  Object var263 = null;
                  this.cachedFilterItem = (ItemStack)var263;
                  var370 = 1478050487 ^ var370;
                  this.savePreferences();
                  var370 = 1067426991 ^ var370;
                  this.decorate();
                  var370 = 799275995 ^ var370;
               }
            } else {
               label310:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                     case 52485837:
                     default:
                        throw new RuntimeException();
                     case 220151452:
                        var370 ^= 896457176;
                        break label310;
                     case 292455395:
                        break;
                     case 1066199066:
                        break label310;
                  }
               }

               if (var24 == var28) {
                  var370 = 648230934 ^ var370;
                  this.savePreferences();
                  var370 = 925545467 ^ var370;
                  Player var173 = this.player;
                  String var259 = wjiertwehi(poxdmjkkmfjkvlz(), xreaynobfrqbnip(), var370);
                  o0o0oOKo0K var298 = acfg();
                  String var329 = wjiertwehi(txhgamyimwdwtfp(), xreaynobfrqbnip(), var370);
                  String var344 = wjiertwehi(twobhiraglbkkhx(), xreaynobfrqbnip(), var370);
                  String var299 = var298.rawStr(var329, var344);
                  String var331 = this.searchQuery;
                  BiConsumer var346 = (var1x, var2) -> {
                     int var11 = 1072450443 ^ 975751740 ^ 378349300;
                     var11 = 1253677639 ^ var11;
                     this.searchQuery = var2;
                     var11 = 2056089271 ^ var11;
                     byte var8 = (byte)(595415987 ^ var11);
                     this.page = var8;
                     var11 = 314891380 ^ var11;
                     this.savePreferences();
                     var11 = 866703149 ^ var11;
                     this.open();
                     var11 = 1316492010 ^ var11;
                  };
                  Consumer var349 = (var1x) -> {
                     int var5 = 678817490 ^ 1906331569 ^ 378349300;
                     var5 = 931350529 ^ var5;
                     this.open();
                  };
                  byte var174 = o0oOo0Ko0K.open(var173, var259, var299, var331, var346, var349);
                  if (var174 != (1979656618 ^ var370)) {
                     var370 = 860763178 ^ var370;
                  } else {
                     var370 = gvqzrkmahtxotvmd(var370, 295632430);
                     Player var176 = this.player;
                     var176.closeInventory();
                     var370 = 332117753 ^ var370;
                     this.openSearchSignGUI();
                     var370 = gvqzrkmahtxotvmd(var370, 1683550448);
                  }
               } else {
                  var370 = 2058307011 ^ var370;
                  if (var24 == var29) {
                     var370 = 251259831 ^ var370;
                     this.savePreferences();
                     var370 = 546308743 ^ var370;
                     byte var168 = NEW_AUCTION_LORE;
                     if (var168 != (816844468 ^ var370)) {
                        var370 = 211329810 ^ var370;
                        Player var295 = this.player;
                        AuctionListingEditorGUI var169 = new AuctionListingEditorGUI(var295, this);
                        var169.open();

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                              case 76475481:
                                 var370 = 802831403 ^ var370;
                                 return;
                              case 263475937:
                              default:
                                 throw new RuntimeException();
                              case 406876810:
                                 return;
                              case 1720174148:
                           }
                        }
                     } else {
                        var370 = gvqzrkmahtxotvmd(var370, 967015338);
                        Player var297 = this.player;
                        AuctionYourListingsGUI var170 = new AuctionYourListingsGUI(var297, this);
                        var170.open();

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                              case 26590201:
                                 var370 = 451011731 ^ var370;
                                 return;
                              case 420175947:
                                 break;
                              case 1131036371:
                                 return;
                              case 1199772039:
                              default:
                                 throw new RuntimeException();
                           }
                        }
                     }
                  } else {
                     label299:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                           case 197537366:
                              var370 ^= 2319820;
                           case 605937033:
                              break label299;
                           case 1416708089:
                           default:
                              throw new RuntimeException();
                           case 2111356239:
                        }
                     }

                     if (var24 == var30) {
                        var370 = 639891238 ^ var370;
                        int var70 = this.page;
                        if (var70 > (953775470 ^ var370)) {
                           var370 = 638215338 ^ var370;
                           int var219 = this.page;
                           byte var276 = (byte)(517149125 ^ var370);
                           int var220 = var219 - var276;
                           this.page = var220;
                           var370 = 287000489 ^ var370;
                           this.savePreferences();
                           var370 = 1379368956 ^ var370;
                           this.decorate();
                           var370 = gvqzrkmahtxotvmd(var370, 1309521948);
                           return;
                        }

                        var370 = gvqzrkmahtxotvmd(var370, 2112078821);
                     } else {
                        label288:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                              case 78300473:
                                 break;
                              case 201671313:
                                 var370 ^= 1539323075;
                                 break label288;
                              case 692507522:
                              default:
                                 throw new RuntimeException();
                              case 2011330950:
                                 break label288;
                           }
                        }
                     }

                     if (var24 == var31) {
                        var370 = 2126087897 ^ var370;
                        int var76 = this.page;
                        int var223 = this.totalPages;
                        byte var277 = (byte)(998453331 ^ var370);
                        int var224 = var223 - var277;
                        if (var76 < var224) {
                           var370 = 1960101768 ^ var370;
                           int var225 = this.page;
                           byte var278 = (byte)(1331165147 ^ var370);
                           int var226 = var225 + var278;
                           this.page = var226;
                           var370 = 241914873 ^ var370;
                           this.savePreferences();
                           var370 = 518038582 ^ var370;
                           this.decorate();

                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                                 case 16590452:
                                    break;
                                 case 163192820:
                                    var370 = 1278120344 ^ var370;
                                    return;
                                 case 348633883:
                                    return;
                                 case 2016315895:
                                 default:
                                    throw new RuntimeException();
                              }
                           }
                        }

                        var370 = gvqzrkmahtxotvmd(var370, 1684163143);
                     } else {
                        var370 = gvqzrkmahtxotvmd(var370, 450612382);
                     }

                     label385: {
                        if (var24 != var30) {
                           var370 = 1558043164 ^ var370;
                           if (var24 != var31) {
                              var370 = 1814582504 ^ var370;
                              break label385;
                           }

                           var370 = 739150134 ^ var370;
                        } else {
                           var370 = gvqzrkmahtxotvmd(var370, 1892897578);
                        }

                        byte var82 = o0KoOo0KoOK.always();
                        if (var82 != (791816511 ^ var370)) {
                           var370 = 1542337977 ^ var370;
                           Player var84 = this.player;
                           o0KoOo0KoOK.edge(var84);
                           var370 = 1731104011 ^ var370;
                           return;
                        }

                        var370 = gvqzrkmahtxotvmd(var370, 1076288990);
                     }

                     if (var24 < (1863644385 ^ var370)) {
                        var370 = gvqzrkmahtxotvmd(var370, 2095474028);
                     } else {
                        var370 = 498976976 ^ var370;
                        byte var229 = (byte)(1923693596 ^ var370);
                        if (var24 >= var229) {
                           var370 = 1633398204 ^ var370;
                        } else {
                           var370 = 801084767 ^ var370;
                           ItemStack var88 = var1.getCurrentItem();
                           var370 = 115677186 ^ var370;
                           if (var88 != null) {
                              var370 = 1323218423 ^ var370;
                              Material var91 = var88.getType();
                              byte var92 = var91.isAir();
                              if (var92 != (355271835 ^ var370)) {
                                 var370 = 1868717229 ^ var370;
                              } else {
                                 var370 = 342116712 ^ var370;
                                 int var231 = this.page;
                                 byte var279 = (byte)(21581278 ^ var370);
                                 int var232 = var231 * var279;
                                 int var94 = var24 + var232;
                                 var370 = 312977888 ^ var370;
                                 List var234 = this.currentItems;
                                 int var235 = var234.size();
                                 if (var94 >= var235) {
                                    var370 = 611514136 ^ var370;
                                    Player var97 = this.player;
                                    String var236 = wjiertwehi(sbalkhyfrufvpmc(), xreaynobfrqbnip(), var370);
                                    String var280 = wjiertwehi(wpvnrnlixeuaakj(), xreaynobfrqbnip(), var370);
                                    AuctionComponent.send(var97, var236, var280);
                                    var370 = 1575017404 ^ var370;
                                    this.decorate();
                                    var370 = 865842718 ^ var370;
                                 } else {
                                    var370 = gvqzrkmahtxotvmd(var370, 938825099);
                                    List var100 = this.currentItems;
                                    Object var101 = var100.get(var94);
                                    AuctionItem var102 = (AuctionItem)var101;
                                    var370 = 1514216723 ^ var370;
                                    ClickType var104 = var1.getClick();
                                    byte var105 = var104.isShiftClick();
                                    if (var105 != (2119871627 ^ var370)) {
                                       var370 = 644829330 ^ var370;
                                       Player var107 = this.player;
                                       String var238 = wjiertwehi(njnlrxkltoaxjsv(), xreaynobfrqbnip(), var370);
                                       byte var108 = var107.hasPermission(var238);
                                       if (var108 != (1479932953 ^ var370)) {
                                          var370 = 1085099670 ^ var370;
                                          Ko0KoOKoOK var155 = Ko0KoOKoOK.getInstance();
                                          byte var156 = var155.removeItem(var102);
                                          if (var156 == (412660367 ^ var370)) {
                                             var370 = 28780802 ^ var370;
                                             Player var158 = this.player;
                                             String var255 = wjiertwehi(dcalqatidzkkoka(), xreaynobfrqbnip(), var370);
                                             String var290 = wjiertwehi(phrqeyljfgdamap(), xreaynobfrqbnip(), var370);
                                             AuctionComponent.send(var158, var255, var290);
                                             var370 = 1663718404 ^ var370;
                                             this.decorate();
                                             var370 = 1776854724 ^ var370;
                                             return;
                                          }

                                          var370 = 2127053044 ^ var370;
                                          Player var161 = this.player;
                                          String var256 = wjiertwehi(xceziexvlgblwhn(), xreaynobfrqbnip(), var370);
                                          String var291 = wjiertwehi(ogtswmaglayimvb(), xreaynobfrqbnip(), var370);
                                          AuctionComponent.play(var161, var256, var291);
                                          var370 = 1416782684 ^ var370;
                                          Player var163 = this.player;
                                          String var257 = wjiertwehi(yacmgodgkgfclyl(), xreaynobfrqbnip(), var370);
                                          String var292 = wjiertwehi(knxevbvxfpjubsd(), xreaynobfrqbnip(), var370);
                                          AuctionComponent.play(var163, var257, var292);
                                          var370 = 1756670595 ^ var370;
                                          Player var165 = this.player;
                                          String var258 = wjiertwehi(vztcmohyqgeqird(), xreaynobfrqbnip(), var370);
                                          String var293 = wjiertwehi(xfycfbhzqflhywx(), xreaynobfrqbnip(), var370);
                                          AuctionComponent.play(var165, var258, var293);
                                          var370 = 1045310560 ^ var370;
                                          this.decorate();
                                          var370 = 2077341748 ^ var370;
                                          return;
                                       }

                                       var370 = 178878806 ^ var370;
                                    } else {
                                       var370 = 751184324 ^ var370;
                                    }

                                    UUID var110 = var102.getSeller();
                                    Player var240 = this.player;
                                    UUID var241 = var240.getUniqueId();
                                    byte var111 = var110.equals(var241);
                                    if (var111 != (1385989455 ^ var370)) {
                                       var370 = 2142192657 ^ var370;
                                       Ko0KoOKoOK var132 = Ko0KoOKoOK.getInstance();
                                       byte var133 = var132.removeItem(var102);
                                       if (var133 == (758366558 ^ var370)) {
                                          var370 = 480063308 ^ var370;
                                          Player var135 = this.player;
                                          String var246 = wjiertwehi(gqdqogcbxgtaaab(), xreaynobfrqbnip(), var370);
                                          String var286 = wjiertwehi(igmulgkgktsyffj(), xreaynobfrqbnip(), var370);
                                          AuctionComponent.send(var135, var246, var286);
                                          var370 = 1875973539 ^ var370;
                                          Player var137 = this.player;
                                          String var247 = wjiertwehi(eookdgpwcfmzuvw(), xreaynobfrqbnip(), var370);
                                          String var287 = wjiertwehi(kyxkosrcltyxdnx(), xreaynobfrqbnip(), var370);
                                          AuctionComponent.play(var137, var247, var287);
                                          var370 = 431768619 ^ var370;
                                          this.decorate();
                                          var370 = 1014977288 ^ var370;
                                       } else {
                                          var370 = gvqzrkmahtxotvmd(var370, 1810068);
                                          ItemStack var140 = var102.getItemStack();
                                          ItemStack var141 = KoOo0oOo0oOK.thaw(var140);
                                          var370 = 411431698 ^ var370;
                                          Player var143 = this.player;
                                          PlayerInventory var144 = var143.getInventory();
                                          byte var248 = (byte)(900574425 ^ var370);
                                          ItemStack[] var249 = new ItemStack[var248];
                                          byte var323 = (byte)(900574424 ^ var370);
                                          var249[var323] = var141;
                                          HashMap var145 = var144.addItem(var249);
                                          var370 = 160112952 ^ var370;
                                          byte var147 = var145.isEmpty();
                                          if (var147 == (1009159648 ^ var370)) {
                                             var370 = 1573241718 ^ var370;
                                             Collection var149 = var145.values();
                                             Consumer var251 = (var1x) -> {
                                                int var12 = 62022253 ^ 955200301 ^ 378349300;
                                                var12 = 705286873 ^ var12;
                                                Player var5 = this.player;
                                                World var6 = var5.getWorld();
                                                Player var8 = this.player;
                                                Location var9 = var8.getLocation();
                                                var6.dropItem(var9, var1x);
                                             };
                                             var149.forEach(var251);
                                             var370 = 1450955564 ^ var370;
                                          } else {
                                             var370 = 197005402 ^ var370;
                                          }

                                          Player var151 = this.player;
                                          String var252 = wjiertwehi(vbvdkzhyogciblw(), xreaynobfrqbnip(), var370);
                                          String var288 = wjiertwehi(cfwiobpcaundyqk(), xreaynobfrqbnip(), var370);
                                          String var324 = wjiertwehi(reekgrncvzvkxwz(), xreaynobfrqbnip(), var370);
                                          var370 = 1842920598 ^ var370;
                                          Material var342 = var141.getType();
                                          String var343 = getMaterialName(var342);
                                          var370 = 958711279 ^ var370;
                                          AuctionComponent.send(var151, var252, var288, var324, var343);
                                          var370 = 1082270399 ^ var370;
                                          Player var153 = this.player;
                                          String var253 = wjiertwehi(iqavvwmyewrgqgz(), xreaynobfrqbnip(), var370);
                                          String var289 = wjiertwehi(mmgygwjoiaxuqgp(), xreaynobfrqbnip(), var370);
                                          byte var325 = (byte)(602326652 ^ var370);
                                          Object[] var326 = new Object[var325];
                                          oOoOo0oOK.bar(var153, var253, var289, var326);
                                          var370 = 543216709 ^ var370;
                                          this.decorate();
                                          var370 = 704520575 ^ var370;
                                       }
                                    } else {
                                       var370 = gvqzrkmahtxotvmd(var370, 1432209382);
                                       Ko0KoOKoOK var112 = Ko0KoOKoOK.getInstance();
                                       List var113 = var112.getActiveItems();
                                       byte var114 = var113.contains(var102);
                                       if (var114 == (130106025 ^ var370)) {
                                          var370 = 1954891532 ^ var370;
                                          Player var130 = this.player;
                                          String var244 = wjiertwehi(ijaoyrjbdhilaro(), xreaynobfrqbnip(), var370);
                                          String var285 = wjiertwehi(qjfvkdbcbnzqmhy(), xreaynobfrqbnip(), var370);
                                          byte var321 = (byte)(1933837733 ^ var370);
                                          Object[] var322 = new Object[var321];
                                          oOoOo0oOK.send(var130, var244, var285, var322);
                                          var370 = 1648077205 ^ var370;
                                          this.decorate();
                                          var370 = 389780850 ^ var370;
                                       } else {
                                          var370 = 1470535326 ^ var370;
                                          ItemStack var116 = var102.getItemStack();
                                          Material var117 = var116.getType();
                                          var370 = 992362637 ^ var370;
                                          String var119 = var117.name();
                                          String var243 = wjiertwehi(msuzixzkgguykhb(), xreaynobfrqbnip(), var370);
                                          byte var120 = var119.contains(var243);
                                          var370 = 662932484 ^ var370;
                                          ClickType var122 = var1.getClick();
                                          byte var123 = var122.isRightClick();
                                          if (var123 != (1287788734 ^ var370)) {
                                             var370 = 135611889 ^ var370;
                                             if (var120 != (1154964815 ^ var370)) {
                                                var370 = 2070933550 ^ var370;
                                                this.savePreferences();
                                                var370 = 920875200 ^ var370;
                                                Player var282 = this.player;
                                                ItemStack var319 = var102.getItemStack();
                                                AuctionItemDetailsGUI var126 = new AuctionItemDetailsGUI(var282, var319, this);
                                                var126.open();
                                                var370 = 1911547227 ^ var370;
                                                return;
                                             }

                                             var370 = 286172590 ^ var370;
                                          } else {
                                             var370 = gvqzrkmahtxotvmd(var370, 421257311);
                                          }

                                          this.savePreferences();
                                          var370 = 1156270975 ^ var370;
                                          Player var284 = this.player;
                                          AuctionItemEditorGUI var128 = new AuctionItemEditorGUI(var284, var102);
                                          var128.open();
                                          var370 = 46146067 ^ var370;
                                       }
                                    }
                                 }
                              }
                           } else {
                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var370)) {
                                    case 36207666:
                                       var370 = 566028634 ^ var370;
                                       return;
                                    case 236384406:
                                    default:
                                       throw new RuntimeException();
                                    case 646624228:
                                       break;
                                    case 785323227:
                                       return;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void openSearchSignGUI() {
      int var36 = 606597695 ^ 1242556301 ^ 378349300;
      var36 = 699057544 ^ var36;
      Player var8 = this.player;
      KoOKKo0K.detach(var8);
      var36 = 422580449 ^ var36;

      try {
         SignGUIBuilder var9 = SignGUI.builder();
         byte var2 = (byte)(1212147243 ^ var36);
         String[] var17 = new String[var2];
         byte var3 = (byte)(1212147247 ^ var36);
         String var4 = wjiertwehi(qpqyejfqmipjsvl(), xreaynobfrqbnip(), var36);
         var17[var3] = var4;
         byte var24 = (byte)(1212147246 ^ var36);
         var36 = 616814395 ^ var36;
         o0o0oOKo0K var27 = acfg();
         String var5 = wjiertwehi(fiodmvuephhkdul(), xreaynobfrqbnip(), var36);
         String var6 = wjiertwehi(dtwgkaeqdejhzqk(), xreaynobfrqbnip(), var36);
         String var28 = var27.rawStr(var5, var6);
         var17[var24] = var28;
         byte var25 = (byte)(1828466966 ^ var36);
         o0o0oOKo0K var29 = acfg();
         String var32 = wjiertwehi(vyxecgelafccegl(), xreaynobfrqbnip(), var36);
         String var33 = wjiertwehi(adqpqqawetzwvzv(), xreaynobfrqbnip(), var36);
         String var30 = var29.rawStr(var32, var33);
         var17[var25] = var30;
         byte var26 = (byte)(1828466967 ^ var36);
         String var31 = wjiertwehi(ptfzfjcklbilgyx(), xreaynobfrqbnip(), var36);
         var17[var26] = var31;
         SignGUIBuilder var10 = var9.setLines(var17);
         Material var18 = Material.OAK_SIGN;
         var36 = 1714102075 ^ var36;
         SignGUIBuilder var11 = var10.setType(var18);
         SignGUIFinishHandler var20 = (var1, var2x) -> {
            int var26 = 554988054 ^ 2101230200 ^ 378349300;
            var26 = 511419074 ^ var26;
            byte var4 = (byte)(1423756376 ^ var26);
            String var9 = var2x.getLineWithoutColor(var4);
            String var10 = var9.trim();
            var26 = 1062409575 ^ var26;
            byte var18 = var10.isEmpty();
            String var19;
            if (var18 != (1804589375 ^ var26)) {
               var26 = 407864518 ^ var26;
               var19 = wjiertwehi(mmhdwsuvpnzxvjg(), xreaynobfrqbnip(), var26);
               var26 = gvqzrkmahtxotvmd(var26, 1442882908);
            } else {
               label20:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var26)) {
                     case 6741861:
                        var26 ^= 1772219617;
                     case 1604144843:
                        var19 = var10;
                        var26 = 669961595 ^ var26;
                        break label20;
                     case 905117699:
                        break;
                     case 1620518509:
                     default:
                        throw new IllegalAccessException();
                  }
               }
            }

            this.searchQuery = var19;
            var26 = 1735145541 ^ var26;
            byte var20 = (byte)(1118617824 ^ var26);
            this.page = var20;
            var26 = 154877335 ^ var26;
            this.savePreferences();
            var26 = 834963001 ^ var26;
            KKoOoOo0oOK var14 = KKoOoOo0oOK.getInstance();
            Player var22 = this.player;
            Runnable var23 = this::open;
            long var6 = 1L;
            var26 = 283737844 ^ var26;
            var14.runAtEntityLater(var22, var23, var6);
            var26 = 1752046994 ^ var26;
            List var16 = Collections.emptyList();
            return var16;
         };
         var36 = 1712694369 ^ var36;
         SignGUIBuilder var12 = var11.setHandler(var20);
         var36 = 709544334 ^ var36;
         DonutSMPCore var21 = DonutSMPCore.getInstance();
         SignGUIBuilder var13 = var12.callHandlerSynchronously(var21);
         var36 = 1894953760 ^ var36;
         SignGUI var14 = var13.build();
         Player var23 = this.player;
         var36 = 307438926 ^ var36;
         var14.open(var23);
         var36 = 1590585020 ^ var36;
      } catch (Exception var37) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var36)) {
            case -1277720831 -> var36 = gvqzrkmahtxotvmd(var36, 807035157);
            case 558804337 -> var36 = 575226971 ^ var36;
            case 876748290 -> var36 = 1088999989 ^ var36;
            case 1107243386 -> var36 = 1314879450 ^ var36;
            case 1454993784 -> var36 = 213368794 ^ var36;
            case 1712607859 -> var36 = gvqzrkmahtxotvmd(var36, 1789008827);
            case 1742833827 -> var36 = gvqzrkmahtxotvmd(var36, 1788649697);
            default -> throw new RuntimeException("Error in hash");
         }

         var36 = 1791610425 ^ var36;
         var37.printStackTrace();
         var36 = 176664518 ^ var36;
         return;
      }

      while(true) {
         switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var36)) {
            case 237015061:
               var36 = 482951960 ^ var36;
               return;
            case 414260954:
               break;
            case 1329484201:
               return;
            case 2136700377:
            default:
               throw new IOException();
         }
      }
   }

   private String formatMaterialName(String var1) {
      int var24 = 1946851486 ^ 1870335033 ^ 378349300;
      var24 = 861457199 ^ var24;
      String var6 = o0oOoOo0oOK.material(var1);
      var24 = 719646815 ^ var24;
      if (var6 != null) {
         var24 = 1359056971 ^ var24;
         return var6;
      } else {
         var24 = 967356851 ^ var24;
         String var3 = wjiertwehi(sqsvpictddibaky(), xreaynobfrqbnip(), var24);
         String var4 = wjiertwehi(fxdlrkydiqmrnhi(), xreaynobfrqbnip(), var24);
         String var10 = var1.replace(var3, var4);
         String var11 = var10.toLowerCase();
         String var18 = wjiertwehi(ekchhsvaffctnql(), xreaynobfrqbnip(), var24);
         String[] var12 = var11.split(var18);
         Stream var13 = Arrays.stream(var12);
         Function var19 = (var0) -> {
            int var13 = 1120658157 ^ 2101330900 ^ 1243011330;
            var13 = 2141815229 ^ var13;
            byte var4 = var0.isEmpty();
            String var8;
            if (var4 != (172718470 ^ var13)) {
               var13 = 952953936 ^ var13;
               var8 = wjiertwehi(gxfheqrvlkpfaim(), xreaynobfrqbnip(), var13);
               var13 = 1903765443 ^ var13;
               return var8;
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var13)) {
                     case 66203960:
                        var13 ^= 1501124046;
                     case 871001626:
                        byte var2 = (byte)(1395797064 ^ var13);
                        char var6 = var0.charAt(var2);
                        char var7 = Character.toUpperCase(var6);
                        byte var3 = (byte)(1395797065 ^ var13);
                        String var10 = var0.substring(var3);
                        var8 = var7 + var10;
                        var13 = 281845341 ^ var13;
                        return var8;
                     case 720635785:
                        break;
                     case 1557043886:
                     default:
                        throw new IllegalAccessException();
                  }
               }
            }
         };
         Stream var14 = var13.map(var19);
         BinaryOperator var20 = (var0, var1x) -> {
            int var7 = 26407660 ^ 872966791 ^ 1243011330;
            var7 = 918641482 ^ var7;
            String var4 = var0 + " " + var1x;
            return var4;
         };
         Optional var15 = var14.reduce(var20);
         Object var16 = var15.orElse(var1);
         String var17 = (String)var16;
         return var17;
      }
   }

   static {
      int var11 = 1115773691 ^ 1989312952 ^ Integer.parseInt("1886352869");
      var11 = 1714553712 ^ var11;
      long var0 = 0L;
      configVersion = var0;
      var11 = 406359499 ^ var11;
      ConcurrentHashMap var2 = new ConcurrentHashMap();
      MATERIAL_NAME_CACHE = var2;
      var11 = 1190809378 ^ var11;
      ConcurrentHashMap var3 = new ConcurrentHashMap();
      playerPreferences = var3;
      var11 = 1717109717 ^ var11;
      DonutSMPCore var4 = DonutSMPCore.getInstance();
      String var8 = wjiertwehi(tcutqkgnvoubigw(), xreaynobfrqbnip(), var11);
      boolean var5 = var4.isRevampFeatureEnabled(var8);
      NEW_AUCTION_LORE = var5;
      var11 = 1340271855 ^ var11;
      long var6 = 0L;
      navConfigVersion = var6;
   }

   public static String wjiertwehi(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] xreaynobfrqbnip() {
      return new byte[]{93, 44, 8, 112, 108, 32, 89, 79, 28, 78, 42, 114, 123, 7, 28, 69, 97, 106, 113, 38, 3, 46, 114, 77, 6, 39, 35, 72, 125, 12, 10, 100, 13, 118, 88, 12, 105, 78, 99, 119, 72, 75, 78, 93, 73, 125, 70, 125, 110, 22, 75, 80, 39, 24, 120, 104, 95, 107, 52, 82, 11, 98, 41, 33, 68, 50, 80, 127, 56, 4, 116, 11, 75, 108, 14, 108, 35};
   }

   private static byte[] tcutqkgnvoubigw() {
      return new byte[]{-105, -26, 56, 39, 85, 113, 111, 24, 42, 14, 31, 55, 74, 76, 40, 22, 87, 47, 69, 61, 51, 113, 75, 28, 48, 102, 21, 81, 72, 93, 59, 40, 57, 35, 110, 78, 93, 18, 83, 41, 113, 17, 120, 70, 127, 46, 115, 56, 95, 70};
   }

   private static byte[] iecjwjftisijkcn() {
      return new byte[]{-110, -32, 62, 46, 95, 124, 96, 13, 47, 90, 27, 32, 77, 66, 47, 31, 88, 43, 66, 118, 50, 114, 68, 19, 53, 121, 26, 8, 78, 92};
   }

   private static byte[] xlkuymxozvqlknt() {
      return new byte[]{-108, -27, 62, 58, 93, 125, 104, 13, 36, 13, 28, 106, 66, 83, 46, 26, 81, 38, 70, 98, 53, 126, 67, 26, 55, 100};
   }

   private static byte[] ddzmwrbajhzkyun() {
      return new byte[]{-108, -27, 62, 5, 93, 93, 104, 40, 36, 60, 28, 23, 66, 98, 46, 43, 81, 2, 70, 66, 53, 94, 67, 60, 55, 82};
   }

   private static byte[] vxekjlmjfqxgrgv() {
      return new byte[]{-108, -27, 62, 1, 93, 91, 104, 56, 36, 49, 28, 1, 66, 101, 46, 32, 81, 13, 70, 64, 53, 69, 67, 54, 55, 84, 27, 58};
   }

   private static byte[] qtbmbxwdtcenxuo() {
      return new byte[]{-108, -27, 62, 27, 93, 87, 104, 60, 36, 60, 28, 10, 66, 98, 46, 56, 81, 11, 70, 79, 53, 91, 67, 54, 55, 68, 27, 43, 75, 127, 51, 17};
   }

   private static byte[] kiiokhnsxpwjszz() {
      return new byte[]{-110, -25, 59, 10, 88, 112, 110, 28, 44, 18, 27, 35, 72, 70, 40, 8, 86, 126, 65, 66, 50, 104, 65, 22, 50, 125, 20, 25};
   }

   private static byte[] bgoedvfrxhcnwvs() {
      return new byte[]{-110, -31, 49, 21, 90, 124, 106, 25, 42, 19, 27, 46, 66, 68, 42, 16, 82, 38, 71, 62, 50, 80, 75, 19, 48, 109, 16, 9, 75, 81, 59, 50};
   }

   private static byte[] oiqlwirpbgwdyqa() {
      return new byte[]{-110, -29, 56, 12, 93, 124, 109, 14, 40, 19, 27, 49, 75, 67, 45, 86, 85, 12, 69, 108, 50, 119, 66, 30, 55, 113};
   }

   private static byte[] wcpblmvlkrrbhqt() {
      return new byte[]{-110, -25, 63, 30};
   }

   private static byte[] gxfheqrvlkpfaim() {
      return new byte[0];
   }

   private static byte[] wlgemropadwhqtl() {
      return new byte[]{-101, -29, 62, 28};
   }

   private static byte[] mmhdwsuvpnzxvjg() {
      return new byte[0];
   }

   private static byte[] fqhtnjjkbsvincr() {
      return new byte[]{-110, -31, 48, 106, 94, 88, 111, 61, 46, 63, 27, 1, 67, 127, 46, 61, 87, 127, 67, 121, 50, 95, 74, 24, 52, 119, 21, 24, 79, 87, 59, 118, 53, 59, 106, 90, 95, 93, 81, 53, 121, 28, 118, 2, 123, 54, 112, 43, 92, 85, 122, 10, 31, 1, 74, 33, 105, 42, 6, 11, 58, 51, 17, 125, 118, 120};
   }

   private static byte[] vbwkrlfodukwryv() {
      return new byte[]{-110, -32, 58, 47, 91, 114, 106, 2, 45, 10, 27, 108, 73, 70, 43, 19, 82, 56, 64, 115};
   }

   private static byte[] zvquqmwlkdkklgo() {
      return new byte[]{-110, -32, 58, 98, 91, 86, 106, 59, 45, 63, 27, 0, 73, 119, 43, 51, 82, 28, 64, 122, 50, 116, 64, 31, 49, 123, 16, 93, 76, 72, 59, 56, 63, 103, 111, 77, 90, 18, 82, 34, 121, 15, 124, 76, 126, 36, 117, 45, 95, 94, 122, 23, 21, 9, 79, 47, 108, 63, 5, 5, 58, 52};
   }

   private static byte[] alqwstgordfddcf() {
      return new byte[]{-105, -28, 60, 51, 94, 97, 107, 24, 36, 22, 29, 42, 67, 80, 46, 5, 83, 47};
   }

   private static byte[] uulshntvmufqwkm() {
      return new byte[]{-112, -22, 58, 52, 94, 106, 104, 24, 41, 11, 19, 109, 79, 69, 36, 21, 83, 56, 66, 122};
   }

   private static byte[] okhuvqvwxbeswtb() {
      return new byte[]{-101, -28, 59, 41, 95, 118, 111, 13, 36, 84, 25, 36, 72, 65, 42, 19, 89, 41, 66, 120, 48, 114, 68, 22, 62, 119, 16, 10, 78, 86};
   }

   private static byte[] aohgqthpqbwxkpg() {
      return new byte[]{-110, -25, 61, 109, 88, 99, 111, 25, 37, 23, 27, 42, 78, 90, 40, 7, 87, 124};
   }

   private static byte[] qcohwxskqkgjulx() {
      return new byte[]{-110, -28, 60, 51, 93, 102, 106, 31, 47, 11, 27, 104, 79, 68, 45, 16, 82, 56, 66, 112};
   }

   private static byte[] enfjlusqokhrasb() {
      return new byte[]{-111, -29, 62, 101};
   }

   private static byte[] ugrziknmrgcyyet() {
      return new byte[]{-105, -25, 63, 40, 88, 100, 110, 24, 44, 23, 30, 107, 74, 95, 44, 29, 83, 40, 69, 119};
   }

   private static byte[] gbulrpagvvvxbai() {
      return new byte[]{-105, -25, 63, 98, 88, 33, 110, 74, 44, 28, 30, 38, 74, 3, 44, 65, 83, 126, 69, 50, 52, 57, 70, 27, 49, 48, 19, 12, 73, 73, 59, 57, 61, 34, 106, 89, 93, 95};
   }

   private static byte[] gvakeliajafubwp() {
      return new byte[]{-111, -30, 56, 39, 93, 115, 104, 4, 36, 8, 27, 111, 66, 70, 42, 21, 82, 53, 67, 114};
   }

   private static byte[] wztxikhiwfyehvq() {
      return new byte[]{-110, -26, 60, 97, 93, 120, 97, 10, 36, 24, 27, 42, 79, 22};
   }

   private static byte[] unewwgpbaqtinnl() {
      return new byte[]{-110, -30, 61, 54, 94, 121, 108, 23, 44, 28, 27, 110, 78, 89, 46, 16, 84, 57, 65, 101, 50, 50, 71, 25, 52, 120, 22, 15, 77, 86, 59, 52, 56, 48};
   }

   private static byte[] olqwhmdwjcsbyhd() {
      return new byte[]{-110, -30, 61, 100, 94, 39, 108, 46, 44, 16, 27, 46, 78, 80, 46, 85, 84, 19, 65, 116, 50, 121, 71, 11, 52, 45, 22, 93, 77, 30, 59, 33, 56, 45, 106, 81, 92, 30, 83, 101};
   }

   private static byte[] wcbeeqvwsthawib() {
      return new byte[]{-110, -30, 61, 103, 94, 100, 108, 19, 44, 20, 27, 38, 78, 16};
   }

   private static byte[] vflpvrbevdmtkqt() {
      return new byte[]{-106, -31, 60, 45, 93, 113, 111, 15, 41, 86, 24, 39, 72, 67, 40, 16, 86, 43, 68, 125, 55, 114, 67, 23, 48, 119, 22, 8, 79, 81};
   }

   private static byte[] toqtqdjdcitovvg() {
      return new byte[]{-111, -30, 60, 46, 92, 116, 109, 1, 45, 87, 24, 34, 79, 66, 44, 23, 85, 39, 64, 123, 49, 112, 70, 19, 54, 113, 23, 4, 76, 81};
   }

   private static byte[] ehtrqrgjhurpohq() {
      return new byte[]{-110, -22, 57, 59, 94, 112, 110, 20, 46, 15, 27, 102, 74, 75, 46, 20, 86, 51, 67, 117, 50, 58, 67, 25, 52, 122, 20, 26, 79, 78};
   }

   private static byte[] qkugvqnujtxpauh() {
      return new byte[]{-112, -30, 58, 101, 95, 102, 97, 10, 46, 20, 27, 35, 75, 81, 42, 88};
   }

   private static byte[] vwgdabulhxxqnfa() {
      return new byte[]{-110, -25, 61, 52, 92, 99, 111, 18, 45, 12, 31, 107, 75, 70, 42, 28, 80, 57, 68, 119};
   }

   private static byte[] eoxwfsudettfnjh() {
      return new byte[]{-111, -30, 58, 41, 93, 113, 96, 7, 45, 14, 24, 110, 73, 64, 45, 16, 88, 61, 64, 119};
   }

   private static byte[] leqqmlxmysnocru() {
      return new byte[]{-111, -30, 58, 100, 93, 82, 96, 57, 45, 60, 24, 5, 73, 118, 45, 55, 88, 20, 64, 119, 49, 103, 64, 14, 55, 51, 26, 40, 76, 89, 56, 50, 63, 36};
   }

   private static byte[] asdnsybgfpoowgk() {
      return new byte[]{-110, -29, 48, 100, 88, 89, 106, 56, 40, 60, 27, 3, 67, 113, 40, 60, 82, 122, 69, 122, 50, 92, 74, 15, 50, 102, 16, 94, 73, 94, 59, 58, 53, 37, 108, 20, 90, 11, 87, 33, 121, 23, 118, 6, 125, 101, 117, 34, 90, 81, 122, 5, 31, 66, 76, 35};
   }

   private static byte[] hmgyaxlqtmpkeip() {
      return new byte[]{-110, -21, 56, 51, 95, 96, 111, 21, 44, 30, 27, 33, 75, 24, 47, 18, 87, 44, 65, 108, 50, 59, 66, 29, 53, 103, 21, 15, 77, 75, 59, 51, 61, 42};
   }

   private static byte[] uzqplpcwrcebjdr() {
      return new byte[]{-110, -21, 56, 97, 95, 83, 111, 58, 44, 59, 27, 12, 75, 115, 47, 54, 87, 8, 65, 96, 50, 127, 66, 28, 53, 121, 21, 91, 77, 125, 59, 41, 61, 61};
   }

   private static byte[] wkkpfdmlihgpqwo() {
      return new byte[]{-106, -25, 60, 96, 91, 86, 109, 63, 44, 58, 30, 7, 72, 113, 43, 48, 80, 124, 68, 125, 55, 94, 69, 22, 50, 127, 19, 30, 73, 83, 57, 115, 58, 54, 105, 83, 92, 90, 87, 50, 127, 21, 122, 9, 121, 63};
   }

   private static byte[] nfbjabznjbjxzbb() {
      return new byte[]{-111, -29, 57, 96, 85, 97, 97, 14, 40, 21, 24, 33, 74, 87, 37, 43, 89, 63, 69, 97, 49, 114, 67, 20, 63, 51};
   }

   private static byte[] ekthnwqhaislcyk() {
      return new byte[]{-110, -29, 57, 32, 90, 120, 111, 16, 41, 15, 27, 54, 74, 64, 42, 31, 87, 43, 68, 113, 50, 113, 67, 11, 48, 117, 21, 87, 72, 89, 59, 33, 60, 33, 110, 79, 95, 22, 86, 44, 121, 21, 127, 71, 127, 43, 112, 40, 91, 79, 122, 9, 22, 66, 78, 45, 105, 63, 1, 11, 58, 61, 24, 99, 114, 96, 102, 39, 13, 68, 69, 94, 122, 53, 56, 40};
   }

   private static byte[] iytchyvslgiqqlk() {
      return new byte[]{-110, -29, 48, 61, 92, 121, 97, 12, 43, 13, 27, 111, 67, 90, 44, 7, 89, 57, 70, 122, 50, 109, 74, 84, 54, 115, 27, 11, 74, 73, 59, 32, 53, 45, 104, 84};
   }

   private static byte[] anhqyhplqmuauyp() {
      return new byte[]{-110, -29, 48, 103, 92, 80, 97, 63, 43, 57, 27, 4, 67, 117, 44, 53, 89, 5, 70, 120, 50, 107, 74, 11, 54, 49, 27, 55, 74, 73, 59, 49, 53, 47, 104, 73};
   }

   private static byte[] dqfeilfgilziwfi() {
      return new byte[]{-102, -22, 49, 41, 90, 98, 111, 30, 44, 3, 19, 34, 67, 94, 43, 29, 83, 119, 72, 125, 58, 99, 68, 14, 48, 97, 19, 30, 68, 91};
   }

   private static byte[] vcudlckloskhxtb() {
      return new byte[]{-102, -22, 49, 107, 90, 81, 111, 59, 44, 49, 19, 13, 67, 119, 43, 53, 83, 27, 72, 106, 58, 117, 68, 14, 48, 124, 19, 30, 68, 91};
   }

   private static byte[] otdqtxqbtffcbkv() {
      return new byte[]{-110, -21, 59, 47, 90, 101, 97, 30, 36, 22, 27, 100, 72, 90, 42, 17, 89, 59, 73, 99, 50, 59, 65, 20, 48, 100, 27, 21, 69, 94, 59, 53, 62, 46, 110, 92, 81, 22, 91, 111, 121, 31, 125, 4, 127, 62, 126, 44};
   }

   private static byte[] fqtezvbohxiryvw() {
      return new byte[]{-107, -26, 62, 50, 89, 98, 96, 31, 41, 21, 31, 33, 66, 109, 42, 16, 88, 58, 71, 117, 53, 99, 71, 6};
   }

   private static byte[] qtxkzyhpgwebkok() {
      return new byte[]{-110, -28, 57, 100, 92, 103, 107, 30, 43, 18, 27, 32, 74, 19};
   }

   private static byte[] jjfmxpqfkwtsvkk() {
      return new byte[]{-110, -27, 56, 60, 93, 125, 106, 9, 40, 30, 27, 41, 75, 111, 45, 31, 82, 57, 69, 126, 50, 125, 66, 7};
   }

   private static byte[] cfftgezedxmgcvl() {
      return new byte[]{-110, -31, 63, 59, 93, 100, 110, 10, 45, 20, 27, 35, 76, 82, 45, 12};
   }

   private static byte[] ogolyrfqjuxsvgn() {
      return new byte[]{-107, -32, 48, 48, 91, 124, 104, 22, 41, 10, 25, 41, 72, 88};
   }

   private static byte[] izyfhhpukxgblqs() {
      return new byte[]{-107, -32, 48, 96, 91, 95, 104, 49, 41, 62, 25, 12, 72, 118, 37, 50, 89, 12, 71, 112, 59, 124, 69, 6, 55, 124, 22, 22};
   }

   private static byte[] yobyfbaeskdgbjq() {
      return new byte[]{-110, -32, 48, 61, 85, 102, 97, 8, 41, 29, 27, 51, 67, 72, 37, 15};
   }

   private static byte[] mrerclwnhjilepf() {
      return new byte[]{-110, -27, 58, 49, 89, 124, 108, 26, 36, 8, 27, 39, 73, 93};
   }

   private static byte[] otocfnimuzmptpk() {
      return new byte[]{-110, -27, 58, 97, 89, 88, 108, 58, 36, 59, 27, 5, 73, 116, 41, 61, 84, 120, 73, 125, 50, 91, 64, 19, 51, 119, 22, 31, 69, 83, 59, 114, 63, 48, 109, 90, 92, 90, 91, 48, 121, 24, 124, 14, 124, 54, 115, 42, 86, 74};
   }

   private static byte[] uebflnnflyjwzfv() {
      return new byte[]{-111, -29, 60, 54, 92, 113, 104, 22, 46, 11, 24, 33, 79, 90};
   }

   private static byte[] dtimtpspfnnaynh() {
      return new byte[]{-111, -30, 48, 61, 94, 119, 108, 5, 41, 8, 27, 100, 66, 70, 46, 21, 83, 62, 67, 101, 59, 116, 64, 23, 51, 56, 22, 11, 76, 65, 51, 51, 63, 49, 106, 64, 91, 82, 91, 34, 122, 16, 123, 1, 124, 42};
   }

   private static byte[] vtneqwuolomomgl() {
      return new byte[]{-111, -30, 48, 106, 94, 83, 108, 60, 41, 61, 27, 11, 66, 116, 46, 49, 83, 121, 67, 120, 59, 53, 64, 90, 51, 100, 22, 15, 76, 81, 51, 36, 63, 58, 106, 28, 91, 93};
   }

   private static byte[] pgzmigzkejnjvfx() {
      return new byte[]{-111, -30, 48, 108, 94, 99, 108, 8, 41, 25, 27, 56, 66, 76, 46, 85};
   }

   private static byte[] tucofigodjpwyyv() {
      return new byte[]{-101, -22, 58, 101, 94, 123, 97, 26, 46, 20, 19, 37, 75, 89, 43, 88};
   }

   private static byte[] unqvtewbnsjconf() {
      return new byte[]{-110, -28, 63, 51, 92, 122, 109, 15, 36, 10, 27, 107, 76, 95, 44, 21, 85, 57, 73, 114, 50, 124, 69, 15};
   }

   private static byte[] iejsyyxvaervcgl() {
      return new byte[]{-110, -28, 63, 99, 92, 84, 109, 60, 36, 63, 27, 4, 76, 118, 44, 49, 85, 126, 73, 121, 50, 90, 69, 17, 54, 123, 23, 25, 69, 87, 59, 115, 58, 50, 104, 86, 93, 92, 91, 36, 121, 20, 121, 12, 121, 38, 114, 40, 86, 67};
   }

   private static byte[] wrjvbyxcacwqcrq() {
      return new byte[0];
   }

   private static byte[] icdzokctyoevunq() {
      return new byte[]{-106, -27, 62, 48, 94, 122, 97, 14, 42, 15, 28, 105, 72, 91, 41, 18, 82, 46, 68, 125, 53, 124, 64, 20, 62, 57, 21, 30, 75, 85, 57, 58, 56, 33, 107, 72};
   }

   private static byte[] pyifofgpkzoyorj() {
      return new byte[]{-106, -27, 62, -28, 94, 115};
   }

   private static byte[] csmfsynfhdzmqlr() {
      return new byte[]{-110, -25, 59, 59, 95, 120, 96, 10, 42, 14, 27, 104, 72, 81, 47, 29, 88, 47, 71, 127, 50, 123, 65, 25, 53, 61, 26, 15, 75, 74, 59, 53, 62, 40, 107, 82, 80, 1};
   }

   private static byte[] pdwusuxdeplgnux() {
      return new byte[]{-110, -25, 59, 107, 95, 34, 96, 77, 42, 79, 27, 115, 72, 10, 47, 71, 125, -9, 71, 50};
   }

   private static byte[] ewarbjuukhxmjlt() {
      return new byte[]{-110, -28, 56, 55, 94, 127, 96, 9, 41, 14};
   }

   private static byte[] wwfsjrovunwouct() {
      return new byte[]{-110, -28, 56, 103, 94, 86, 96, 61, 41, 60, 27, 3, 75, 117, 46, 51, 88, 24, 68, 123, 50, 117, 66, 13, 52, 114, 26, 14};
   }

   private static byte[] guhebklrsesefyn() {
      return new byte[]{-111, -30, 58, 37, 84, 99, 110, 17, 44, 9, 24, 108, 73, 84, 36, 6, 86, 62, 65, 102, 49, 118, 64, 16, 62, 127, 20, 80, 77, 75, 56, 58, 63, 54, 96, 78, 94, 31, 83, 42, 122, 22, 124, 27, 113, 46, 113, 56};
   }

   private static byte[] lfbsextdubtbcuu() {
      return new byte[]{-102, -29, 57, 54, 88, 126, 110, 12, 40, 3, 26, 110, 78, 95, 45, 27, 80, 48, 72, 115, 50, 104, 70, 82, 49, 90, 23, 62, 77, 106, 63, 21, 60, 18, 105, 108, 80, 33, 82, 18, 124, 40, 121, 37, 125, 7, 118, 9};
   }

   private static byte[] hueleleunnxguel() {
      return new byte[]{-102, -29, 25, 103, 88, 49, 110, 50, 40, 24, 26, 52, 78, 86, 45, 1, 80, 42, 72, 54, 50, 75, 70, 14, 49, 127, 23, 18, 77, 88};
   }

   private static byte[] fmaubuzjuisqiys() {
      return new byte[]{-111, -29, 56, 109, 84, 99, 96, 11, 47, 31, 24, 36, 75, 86, 36, 14, 88, 121};
   }

   private static byte[] zjgajjqcyymzbvh() {
      return new byte[]{-110, -31, 56, 53, 93, 119, 109, 10, 36, 9, 27, 110, 75, 66, 45, 24, 85, 49, 73, 112, 50, 127, 66, 15, 55, 122, 23, 27, 69, 18, 59, 38, 61, 50, 105, 81, 93, 31, 91, 45, 121, 1};
   }

   private static byte[] mtxcdydadkwhtsa() {
      return new byte[]{-110, -31, 56, 101, 93, 94, 109, 62, 36, 59, 27, 6, 75, 119, 45, 59, 112, -9, 73, 53};
   }

   private static byte[] zmglitzbiolggtc() {
      return new byte[]{-105, -28, 60, 49, 94, 126, 108, 8, 43, 14, 29, 107, 73, 89, 45, 25, 84, 51, 69, 116, 55, 111, 64, 82, 51, 64, 20, 57, 74, 123, 56, 19, 60, 13, 109, 111, 93, 53, 87, 28, 122, 37, 123, 36, 126, 0, 113, 26, 92, 112, 122, 32, 18, 107};
   }

   private static byte[] lekpzouboqremvl() {
      return new byte[]{-105, -28, 28, 96, 94, 49, 108, 40, 43, 31, 29, 37, 73, 80, 45, 30, 84, 41, 69, 125, 55, 101, 64, 92, 51, 94, 20, 21, 74, 75, 56, 34, 60, 38, 109, 95};
   }

   private static byte[] rfkhxqcjmztnrul() {
      return new byte[]{-107, -22, 60, 58, 94, 118, 97, 13, 40, 12, 19, 107, 66, 89, 37, 20, 81, 48, 71, 122, 55, 100, 64, 90, 62, 95, 23, 55, 68, 127, 51, 30, 52, 11, 104, 107, 95, 35, 87, 17, 122, 34, 118, 63, 125, 2, 127, 10, 87, 97};
   }

   private static byte[] ekrjvczkeweladr() {
      return new byte[]{-107, -22, 28, 107, 94, 57, 97, 55, 40, 17, 19, 33, 66, 93, 37, 24, 81, 45, 71, 107, 55, 55, 64, 36, 62, 101, 23, 23, 68, 91, 51, 51};
   }

   private static byte[] otlcrodyvsxxwjz() {
      return new byte[]{-102, -29, 59, 48, 94, 119, 108, 15, 41, 3};
   }

   private static byte[] avdfahnzahfawyz() {
      return new byte[]{-108, -26, 62, 58, 93, 127, 97, 12, 46, 13, 31, 105, 66, 90, 44, 20, 80, 54, 70, 118, 53, 100, 67, 83, 62, 90, 17, 62, 72, 105, 51, 1, 61, 17, 105, 114, 94, 50, 85, 29, 121, 47, 118, 41, 123, 14};
   }

   private static byte[] dzwfmmubmlxvont() {
      return new byte[]{-108, -26, 30, 107, 93, 48, 97, 50, 46, 24, 31, 55, 66, 66, 44, 93, 80, 20, 70, 122, 53, 100, 67, 9, 62, 115, 17, 27};
   }

   private static byte[] myuynzcikpmaodj() {
      return new byte[]{-111, -29, 57, 59, 84, 119, 97, 8, 46, 15, 24, 108, 74, 83, 36, 20, 89, 49, 67, 118, 49, 51, 67, 19, 62, 112, 27, 15, 79, 84, 56, 53, 60, 58};
   }

   private static byte[] mswtkclbuqpqgma() {
      return new byte[]{-111, -29, 57, 109, 84, 104, 97, 8, 46, 30, 24, 36, 74, 86, 36, 5, 89, 122, 67, 54, 49, 114, 67, 20, 62, 125, 27, 24, 79, 85, 56, 113};
   }

   private static byte[] rfjywpotbftqstw() {
      return new byte[]{-110, -29, 57, 55, 90, 123, 108, 8, 42, 12, 27, 111, 74, 64, 42, 20, 84, 51, 71, 117, 50, 125, 67, 13, 48, 118, 22, 25, 75, 23, 59, 55, 60, 45, 110, 84, 92, 20, 85, 51};
   }

   private static byte[] lshhldmmvjsvlsn() {
      return new byte[]{-110, -29, 57, 103, 90, 37, 108, 60, 42, 62, 27, 6, 74, 10, 42, 73};
   }

   private static byte[] wjlggtijjskgrzb() {
      return new byte[0];
   }

   private static byte[] mzdvzwhgqjftcxb() {
      return new byte[]{-110, -31, 62, 34, 88, 127, 109, 20, 46, 11, 24, 33, 79, 65, 42, 92, 86, 52, 64, 125, 53, 116, 70, 30, 50, 61, 17, 31, 79, 85, 62, 34, 59, 47, 111, 95, 88, 8};
   }

   private static byte[] xccodpftzjvossk() {
      return new byte[]{-110, -31, 62, 97, 88, 117, 109, 23, 46, 19, 24, 43, 79, 65, 42, 84, 118, 122, 64, 52, 53, 63, 70, 23, 50, 113, 17, 27, 79, 95, 62, 60, 59, 103};
   }

   private static byte[] gcyvinpoejbvdni() {
      return new byte[]{-110, -21, 57, 39, 93, 121, 106, 20, 40, 11, 18, 38, 74, 68, 44, 91, 86, 45, 64, 123, 50, 115, 67, 24, 53, 115, 23, 13, 69, 88, 59, 49, 61, 104, 111, 91, 88, 25, 82, 42, 121, 20, 125, 24};
   }

   private static byte[] ucaijdulmytpjue() {
      return new byte[]{-110, -21, 57, 98, 93, 33, 106, 62, 40, 57, 18, 7, 74, 15, 44, 78};
   }

   private static byte[] slldubkratskieg() {
      return new byte[]{-110, -27, 56, 102, 94, 117, 108, 21, 36, 16, 27, 43, 75, 70, 46, 86};
   }

   private static byte[] ssdxgspnmstmqva() {
      return new byte[]{-107, -27, 48, 109, 84, 124, 105, 26, 42, 26, 18, 47, 67, 91, 44, 84};
   }

   private static byte[] vhvrbmtpjezjzua() {
      return new byte[]{-111, -29, 62, 34, 93, 126, 97, 21, 41, 8, 26, 33, 79, 68, 43, 80, 87, 49, 67, 121, 53, 104, 67, 23, 62, 112, 22, 22, 77, 23, 62, 54, 58, 33, 110, 85, 91, 17, 85, 49};
   }

   private static byte[] hlyxisalagyphjv() {
      return new byte[]{-111, -29, 62, 98, 93, 113};
   }

   private static byte[] bfrlujaspoinema() {
      return new byte[]{-112, -28, 63, 34, 88, 97, 107, 18, 45, 14, 29, 106, 78, 82, 40, 2, 85, 56, 66, 101, 52, 114, 70, 22, 52, 125, 18, 84, 74, 72, 63, 63, 57, 54, 108, 73, 90, 31, 84, 43, 124, 19, 124, 29, 120, 43, 113, 56};
   }

   private static byte[] njnlrxkltoaxjsv() {
      return new byte[]{-110, -25, 63, 45, 85, 124, 107, 24, 41, 8, 27, 50, 76, 77, 37, 27, 83, 35, 68, 118, 50, 117, 69, 6, 63, 113, 17, 95, 72, 94, 59, 37, 58, 44, 97, 75, 91, 30, 86, 43, 121, 17, 121, 74, 112, 47, 116, 32, 91, 72, 122, 13, 16, 79, 65, 41, 109, 55, 1, 12, 58, 57, 30, 110, 125, 100, 98, 47, 13, 67, 69, 90, 124, 56, 55, 44};
   }

   private static byte[] vbvdkzhyogciblw() {
      return new byte[]{-102, -32, 58, 36, 88, 119, 110, 16, 44, 27, 25, 37, 76, 80, 36, 6, 82, 63, 72, 113};
   }

   private static byte[] cfwiobpcaundyqk() {
      return new byte[]{-102, -32, 58, 97, 88, 47, 110, 37, 44, 24, 25, 53, 76, 19, 36, 17, 82, 53, 72, 121, 49, 117, 70, 16, 49, 119, 19, 5, 78, 91, 61, 52, 53, 97, 107, 69, 80, 18, 81, 53, 124, 1, 121, 78, 121, 98, 117, 41, 89, 7, 115, 14, 20, 92, 65, 62, 109, 49, 0, 79, 60, 119, 25, 47, 119, 46};
   }

   private static byte[] reekgrncvzvkxwz() {
      return new byte[]{-102, -32, 58, 98, 88, 113, 110, 8, 44, 18, 25, 45, 76, 22};
   }

   private static byte[] dcalqatidzkkoka() {
      return new byte[]{-105, -31, 58, 44, 89, 100, 109, 27, 47, 23, 24, 109, 78, 71, 44, 31, 80, 56, 69, 98, 49, 122, 71, 20, 50, 122, 16, 29, 79, 92, 63, 61, 61, 39};
   }

   private static byte[] phrqeyljfgdamap() {
      return new byte[]{-105, -31, 58, 99, 89, 115, 109, 42, 47, 18, 24, 41, 78, 65, 44, 81, 80, 48, 69, 96, 49, 126, 71, 16, 50, 54, 16, 21, 79, 77, 63, 113, 61, 44, 105, 80, 93, 92, 81, 46, 125, 20, 122, 2, 122, 46, 116, 42, 91, 81, 123, 68, 22, 74, 76, 44, 109, 63, 1, 11, 63, 63, 26, 116, 118, 98, 101, 38, 8, 85, 69, 22};
   }

   private static byte[] ubflfpzxmbnehwl() {
      return new byte[]{-107, -21, 62, 34, 92, 109, 109, 25, 45, 12, 18, 45, 72, 88, 36, 31, 84, 117, 71, 109, 53, 114, 66, 7, 50, 102};
   }

   private static byte[] xceziexvlgblwhn() {
      return new byte[]{-110, -28, 57, 37, 89, 119, 105, 26, 36, 21, 27, 32, 74, 82, 41, 9, 81, 126, 73, 32};
   }

   private static byte[] ogtswmaglayimvb() {
      return new byte[]{-110, -28, 57, 19, 89, 81, 105, 41, 36, 59, 27, 16, 74, 101, 41, 41, 81, 28, 73, 95, 50, 70, 67, 56, 51, 83, 19, 56, 69, 120, 59, 24};
   }

   private static byte[] yacmgodgkgfclyl() {
      return new byte[]{-101, -25, 57, 34, 94, 121, 104, 27, 47, 26, 30, 38, 74, 86, 42, 0, 89, 116, 73, 32};
   }

   private static byte[] knxevbvxfpjubsd() {
      return new byte[]{-101, -25, 57, 4, 94, 88, 104, 35, 47, 63, 30, 23, 74, 108, 42, 43, 89, 15, 73, 91, 50, 83, 64, 55, 55, 94, 16, 55, 73, 120, 59, 4, 59, 24, 96, 102, 81, 63, 82, 21};
   }

   private static byte[] eookdgpwcfmzuvw() {
      return new byte[]{-110, -26, 48, 33, 88, 113, 108, 25, 44, 14};
   }

   private static byte[] kyxkosrcltyxdnx() {
      return new byte[]{-110, -26, 48, 0, 88, 90, 108, 35, 44, 62, 27, 19, 67, 107, 40, 46, 84, 4, 65, 86, 50, 87, 74, 52, 50, 82, 22, 55, 77, 112, 59, 3, 53, 28, 108, 118, 92, 57};
   }

   private static byte[] vztcmohyqgeqird() {
      return new byte[]{-110, -26, 57, 42, 91, 118, 108, 18, 44, 26, 27, 34, 74, 93, 43, 8, 84, 118, 65, 45};
   }

   private static byte[] xfycfbhzqflhywx() {
      return new byte[]{-110, -26, 57, 12, 91, 87, 108, 42, 44, 63, 27, 19, 74, 103, 43, 35, 84, 30, 65, 70, 50, 75, 67, 49, 49, 76, 22, 48, 77, 113, 59, 31, 60, 12, 111, 112, 92, 32, 83, 0, 121, 44, 127, 38, 126, 27, 115, 28, 94, 103, 122, 38, 22, 106, 79, 4, 106, 10};
   }

   private static byte[] iqavvwmyewrgqgz() {
      return new byte[]{-107, -29, 58, 34, 94, 99, 111, 25, 46, 12, 26, 41, 72, 90, 42, 29, 84, 118, 71, 117, 49, 114, 64, 23, 48, 126, 17, 27, 77, 93, 57, 34, 59, 37, 109, 90, 95, 83, 81, 37, 122, 30, 120, 28, 123, 34, 118, 32, 93, 74, 125, 4, 18, 75, 78, 42};
   }

   private static byte[] mmgygwjoiaxuqgp() {
      return new byte[]{-107, -29, 58, 101, 94, 33, 111, 35, 46, 23, 26, 53, 72, 21, 42, 16, 84, 55, 71, 122, 49, 113, 64, 30, 48, 113, 17, 10, 77, 91, 57, 50, 59, 96, 109, 71, 95, 17, 81, 49, 122, 15, 120, 72, 123, 34, 118, 59, 93, 65, 125, 11, 18, 4};
   }

   private static byte[] poxdmjkkmfjkvlz() {
      return new byte[]{-110, -22, 63, 40, 90, 96, 111, 26, 45, 2, 27, 34, 76, 81, 42, 30};
   }

   private static byte[] txhgamyimwdwtfp() {
      return new byte[]{-110, -22, 63, 61, 90, 112, 111, 1, 45, 2, 27, 101, 76, 77, 42, 21, 87, 61, 64, 108, 50, 116, 69, 28, 48, 63, 21, 26, 76, 93, 59, 60, 58, 35, 110, 86, 95, 31, 82, 98, 121, 6, 121, 13, 127, 60, 112, 39, 95, 75};
   }

   private static byte[] twobhiraglbkkhx() {
      return new byte[]{-110, -22, 63, 106, 90, 83, 111, 63, 45, 48, 27, 13, 76, 120, 42, 54, 87, 15, 64, 123, 50, 118, 69, 6, 48, 113, 21, 22, 76, 20, 59, 28, 58, 58, 110, 90, 95, 12, 82, 38, 121, 29, 121, 10};
   }

   private static byte[] iwotpslhcflekce() {
      return new byte[0];
   }

   private static byte[] msuzixzkgguykhb() {
      return new byte[]{-110, -28, 49, 26, 88, 94, 105, 42, 46, 52, 27, 14, 66, 123, 40, 33, 81, 5, 67, 82, 50, 86, 75, 44};
   }

   private static byte[] ncfwiwxkjiaplii() {
      return new byte[]{-111, -30, 58, 49, 91, 122, 110, 8, 43, 16, 24, 39, 73, 70, 43, 94, 86, 59, 70, 122, 49, 118, 64, 28, 49, 121, 20, 87, 74, 74, 56, 58, 63, 40, 111, 76, 94, 17, 84, 34};
   }

   private static byte[] sbalkhyfrufvpmc() {
      return new byte[]{-102, -32, 58, 32, 91, 97, 106, 29, 45, 26, 25, 109, 66, 87, 41, 25, 86, 53, 72, 112};
   }

   private static byte[] wpvnrnlixeuaakj() {
      return new byte[]{-102, -32, 58, 111, 91, 118, 106, 44, 45, 31, 25, 41, 66, 67, 41, 86, 86, 50, 72, 97, 49, 114, 69, 21, 53, 48, 18, 31, 78, 81, 51, 115, 56, 41, 111, 82, 80, 19, 81, 41, 127, 27, 125, 24, 120, 100, 117, 42, 87, 89, 126, 10, 16, 90, 65, 47, 109, 33, 3, 73};
   }

   private static byte[] laypqmuiqffemuh() {
      return new byte[]{-102, -22, 58, 37, 85, 103, 111, 29, 46, 3, 19, 41, 79, 81, 46, 29, 80, 118, 72, 121, 49, 115, 75, 19, 48, 98, 17, 20, 68, 76};
   }

   private static byte[] tmahtxpdsokriib() {
      return new byte[]{-107, -29, 58, 58, 95, 123, 105, 2, 36, 22, 26, 36, 66, 71, 40, 91, 89, 49, 71, 122, 49, 126, 65, 26, 54, 116, 27, 83, 77, 78, 51, 62, 57, 50, 96, 87, 95, 22};
   }

   private static byte[] wkqvoniuvrsrerp() {
      return new byte[]{-111, -29, 59, 50, 84, 127, 108, 15, 44, 24, 24, 38, 72, 69, 36, 91, 84, 45, 65, 123, 49, 120, 65, 14, 62, 114, 22, 14, 77, 92};
   }

   private static byte[] zmdhfhlmszfhjkg() {
      return new byte[]{-111, -29, 59, 20, 84, 89, 108, 37, 44, 34, 24, 13, 72, 119, 36, 38, 84, 11, 65, 65, 49, 87, 65, 50};
   }

   private static byte[] gqdqogcbxgtaaab() {
      return new byte[]{-101, -32, 59, 36, 88, 123, 110, 4, 40, 19, 25, 32, 78, 87, 43, 11, 88, 115, 73, 119, 48, 116, 70, 15, 49, 121, 23, 24, 78, 75};
   }

   private static byte[] igmulgkgktsyffj() {
      return new byte[]{-101, -32, 59, 99, 88, 116, 110, 34, 40, 30, 25, 40, 78, 64, 43, 82, 88, 55, 73, 97, 48, 126, 70, 23, 49, 62, 23, 7, 78, 94, 63, 35, 58, 97, 97, 89, 81, 17, 80, 48, 124, 25, 121, 5, 125, 33, 117, 55, 91, 2, 124, 5, 30, 67, 64, 46, 108, 57, 0, 13, 60, 47, 29, 57, 119, 110, 101, 57, 15, 19, 77, 86, 115, 44, 61, 121, 23, 4, 27, 94, 68, 116, 19, 6, 122, 71, 121, 115, 75, 40, 63, 74, 118, 38, 94, 102, 17, 91, 26, 60, 126, 84, 18, 126, 127, 38, 53, 95, 92, 92, 69, 1, 56, 59, 121, 123};
   }

   private static byte[] ijaoyrjbdhilaro() {
      return new byte[]{-110, -22, 59, 34, 84, 102, 110, 27, 47, 9, 27, 34, 72, 91, 36, 24, 86, 115, 66, 124, 50, 99, 65, 27, 62, 121, 20, 82, 78, 94, 59, 49, 62, 55, 96, 90, 94, 24, 80, 32, 121, 11, 125, 67, 113, 44, 113, 37, 93, 80, 122, 14, 20, 67, 64, 47};
   }

   private static byte[] qjfvkdbcbnzqmhy() {
      return new byte[]{-110, -22, 59, 101, 84, 112, 110, 44, 47, 21, 27, 34, 72, 71, 36, 86, 86, 52, 66, 97, 50, 114, 65, 19, 62, 52, 20, 8, 78, 94, 59, 46, 62, 101, 96, 94, 94, 21, 80, 54, 121, 23, 125, 15, 113, 42, 113, 51, 93, 5, 122, 11, 20, 68, 64, 46, 104, 59, 7, 9, 58, 47, 26, 60};
   }

   private static byte[] kgounbtjfkatupt() {
      return new byte[]{-105, -29, 62, 49, 85, 121, 111, 13, 36, 20, 26, 32, 73, 77, 42, 93, 86, 49, 69, 122, 53, 117, 75, 24, 48, 123};
   }

   private static byte[] mbtdhqfwznybrro() {
      return new byte[]{-105, -29, 62, 0, 85, 90, 111, 55, 36, 57, 26, 15, 73, 97, 42, 48, 86, 26, 69, 83, 53, 78, 75, 41, 48, 73, 27, 35, 77, 109, 56, 18, 59, 15, 111, 112, 93, 33, 85, 7, 113, 40, 120, 62, 113, 29, 118, 4, 92, 97, 125, 57, 16, 99, 76, 20, 105, 16, 13, 39, 61, 30, 17, 74, 116, 75, 98, 8};
   }

   private static byte[] fiodmvuephhkdul() {
      return new byte[]{-110, -21, 58, 60, 88, 115, 111, 14, 42, 14, 27, 100, 73, 76, 40, 22, 87, 50, 71, 96, 50, 117, 64, 29, 50, 60, 21, 2, 75, 81, 59, 59, 63, 32, 108, 23, 95, 22, 85, 49, 121, 1, 124, 10, 125, 60, 112, 55};
   }

   private static byte[] dtwgkaeqdejhzqk() {
      return new byte[]{-110, -21, 27, -39, 121, -121, 78, -25, 11, -21, 58, -37, 104, -82, 9, -30, 118, -62, 102, -125, 19, -121, 97, -28, 19, -128};
   }

   private static byte[] vyxecgelafccegl() {
      return new byte[]{-110, -21, 58, 60, 88, 115, 111, 14, 42, 14, 27, 100, 73, 76, 40, 22, 87, 50, 71, 96, 50, 117, 64, 29, 50, 60, 21, 2, 75, 81, 59, 59, 63, 32, 108, 23, 95, 27, 85, 34, 121, 17, 124, 0, 125, 39};
   }

   private static byte[] adqpqqawetzwvzv() {
      return new byte[]{-110, -21, 58, 27, 88, 115, 111, 23, 42, 8, 27, 41, 73, 87};
   }

   private static byte[] ptfzfjcklbilgyx() {
      return new byte[0];
   }

   private static byte[] qpqyejfqmipjsvl() {
      return new byte[0];
   }

   private static byte[] sqsvpictddibaky() {
      return new byte[]{-108, -28, 56, 30};
   }

   private static byte[] fxdlrkydiqmrnhi() {
      return new byte[]{-108, -28, 56, 97};
   }

   private static byte[] ekchhsvaffctnql() {
      return new byte[]{-108, -28, 56, 97};
   }

   private static int gvqzrkmahtxotvmd(int var0, int var1) {
      return var0 ^ var1;
   }

   private static class K {
      final AuctionSortOrder sort;
      final AuctionCategory filter;
      final int page;

      K(AuctionSortOrder var1, AuctionCategory var2, int var3) {
         this.sort = var1;
         this.filter = var2;
         this.page = var3;
      }

      static {
      }
   }
}
