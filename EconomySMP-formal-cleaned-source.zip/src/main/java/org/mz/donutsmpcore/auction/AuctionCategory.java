package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.bukkit.Material;
import skido.o0o0oOKo0K;

public enum AuctionCategory {
   ALL,
   BLOCKS,
   TOOLS,
   FOOD,
   COMBAT,
   POTIONS,
   BOOKS,
   INGREDIENTS,
   UTILITIES;

   public String getDisplay() {
      int var23 = 56488599 ^ 1414025286 ^ 1412717272;
      var23 = 1450645296 ^ var23;
      String var6 = this.name();
      byte var2 = (byte)(1431760697 ^ var23);
      char var7 = var6.charAt(var2);
      String var14 = this.name();
      byte var3 = (byte)(1431760696 ^ var23);
      String var15 = var14.substring(var3);
      String var16 = var15.toLowerCase();
      String var8 = var7 + var16;
      String var4 = var8;
      var23 = 1521478009 ^ var23;

      try {
         String var9 = mhbxnqeitu(miwxzredkgklkwy(), ryfmeqmmzpmaxut(), var23);
         var23 = 22089425 ^ var23;
         String var18 = this.name();
         String var19 = "filter." + var18;
         String var10 = o0o0oOKo0K.t(var9, var19, var4);
         var23 = 191627793 ^ var23;
         return var10;
      } catch (Throwable var24) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var23)) {
            case 1967146120 -> var23 = anfvgckrvfmpyvtc(var23, 1330461733);
            case 2143826432 -> var23 = 1310470900 ^ var23;
            default -> throw new IllegalAccessException("Error in hash");
         }

         var23 = 1557046296 ^ var23;
         return var8;
      }
   }

   public boolean matches(Material var1) {
      int var114 = 152324334 ^ 192046126 ^ 1412717272;
      var114 = 1939924735 ^ var114;
      int var4 = this.ordinal();
      byte var78;
      switch (var4) {
         case 0:
            label223:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                  case 159767885:
                     var114 ^= 329480282;
                     break label223;
                  case 276488441:
                  default:
                     throw new IOException();
                  case 486101813:
                     break label223;
                  case 1046780058:
               }
            }

            var78 = (byte)(911337660 ^ var114);
            var114 = 160923649 ^ var114;
            break;
         case 1:
            var114 = anfvgckrvfmpyvtc(var114, 2102489137);
            byte var74 = var1.isBlock();
            if (var74 != (1487134934 ^ var114)) {
               var114 = 541941234 ^ var114;
               byte var76 = var1.hasGravity();
               if (var76 == (2028911908 ^ var114)) {
                  var114 = 541079724 ^ var114;
                  Material var107 = Material.AIR;
                  if (var1 != var107) {
                     var114 = 311916424 ^ var114;
                     var78 = (byte)(1245311489 ^ var114);
                     var114 = anfvgckrvfmpyvtc(var114, 1979685564);
                     break;
                  }

                  var114 = anfvgckrvfmpyvtc(var114, 2104505091);
               } else {
                  label175:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                        case 172947099:
                           var114 ^= 1563429807;
                           break label175;
                        case 1271007223:
                           break;
                        case 1271707223:
                           break label175;
                        case 1556032460:
                        default:
                           throw new IOException();
                     }
                  }
               }
            } else {
               var114 = anfvgckrvfmpyvtc(var114, 2105366109);
            }

            var78 = (byte)(635352715 ^ var114);
            var114 = anfvgckrvfmpyvtc(var114, 437837367);
            break;
         case 2:
            label389:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                  case 159767885:
                     var114 ^= 1048816419;
                     break label389;
                  case 310505623:
                     break;
                  case 1401656892:
                  default:
                     throw new IOException();
                  case 1697082824:
                     break label389;
               }
            }

            String var7 = var1.name();
            String var3 = mhbxnqeitu(qcapsxvgucmibvo(), ryfmeqmmzpmaxut(), var114);
            byte var8 = var7.contains(var3);
            if (var8 == (460405700 ^ var114)) {
               var114 = 312788784 ^ var114;
               String var10 = var1.name();
               String var83 = mhbxnqeitu(loyxzukqwmypqfh(), ryfmeqmmzpmaxut(), var114);
               byte var11 = var10.contains(var83);
               if (var11 == (165018868 ^ var114)) {
                  var114 = 1318147544 ^ var114;
                  String var13 = var1.name();
                  String var84 = mhbxnqeitu(nczynswolxmvrxd(), ryfmeqmmzpmaxut(), var114);
                  byte var14 = var13.contains(var84);
                  if (var14 == (1195682092 ^ var114)) {
                     var114 = 1713187003 ^ var114;
                     String var16 = var1.name();
                     String var85 = mhbxnqeitu(fykpetzhaltifzw(), ryfmeqmmzpmaxut(), var114);
                     byte var17 = var16.contains(var85);
                     if (var17 == (559514007 ^ var114)) {
                        var114 = 1731286452 ^ var114;
                        String var19 = var1.name();
                        String var86 = mhbxnqeitu(xjukwfiviseltqm(), ryfmeqmmzpmaxut(), var114);
                        byte var20 = var19.contains(var86);
                        if (var20 == (1181275171 ^ var114)) {
                           label352:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                                 case 141253995:
                                    var114 ^= 1162238437;
                                    break label352;
                                 case 381616494:
                                    break;
                                 case 1416274817:
                                    break label352;
                                 case 1552076395:
                                 default:
                                    throw new IOException();
                              }
                           }

                           var78 = (byte)(53382598 ^ var114);
                           var114 = anfvgckrvfmpyvtc(var114, 1021896058);
                           break;
                        }

                        var114 = 145476603 ^ var114;
                     } else {
                        var114 = anfvgckrvfmpyvtc(var114, 1872404047);
                     }
                  } else {
                     label376:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                           case 169164929:
                              var114 ^= 159889140;
                              break label376;
                           case 290544862:
                              break;
                           case 1082654748:
                           default:
                              throw new IOException();
                           case 1671935234:
                              break label376;
                        }
                     }
                  }
               } else {
                  var114 = anfvgckrvfmpyvtc(var114, 1192682284);
               }
            } else {
               var114 = anfvgckrvfmpyvtc(var114, 1437738012);
            }

            var78 = (byte)(1321410521 ^ var114);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                  case 144327537:
                     var114 = 1896183652 ^ var114;
                     return (boolean)var78;
                  case 628251492:
                     break;
                  case 1068671897:
                  default:
                     throw new IOException();
                  case 2005908762:
                     return (boolean)var78;
               }
            }
         case 3:
            var114 = 1189223210 ^ var114;
            var78 = var1.isEdible();

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                  case 130423901:
                     return (boolean)var78;
                  case 267414989:
                     var114 = 1557586801 ^ var114;
                     return (boolean)var78;
                  case 916120016:
                     break;
                  case 1044847880:
                  default:
                     throw new IOException();
               }
            }
         case 4:
            var114 = anfvgckrvfmpyvtc(var114, 417342374);
            String var37 = var1.name();
            String var92 = mhbxnqeitu(ntwoepjruqycmyw(), ryfmeqmmzpmaxut(), var114);
            byte var38 = var37.contains(var92);
            if (var38 == (1024635713 ^ var114)) {
               var114 = 1026831135 ^ var114;
               String var40 = var1.name();
               String var93 = mhbxnqeitu(qqketemfrngasxh(), ryfmeqmmzpmaxut(), var114);
               byte var41 = var40.contains(var93);
               if (var41 == (2523230 ^ var114)) {
                  var114 = 1652875248 ^ var114;
                  String var43 = var1.name();
                  String var94 = mhbxnqeitu(tjvvenndxeefrok(), ryfmeqmmzpmaxut(), var114);
                  byte var44 = var43.contains(var94);
                  if (var44 == (1654808494 ^ var114)) {
                     var114 = 1935501749 ^ var114;
                     String var46 = var1.name();
                     String var95 = mhbxnqeitu(luknykhinsgjkxv(), ryfmeqmmzpmaxut(), var114);
                     byte var47 = var46.contains(var95);
                     if (var47 == (301938203 ^ var114)) {
                        var114 = 1272924618 ^ var114;
                        String var49 = var1.name();
                        String var96 = mhbxnqeitu(dccjyvyrtzivkys(), ryfmeqmmzpmaxut(), var114);
                        byte var50 = var49.contains(var96);
                        if (var50 == (1512079313 ^ var114)) {
                           var114 = anfvgckrvfmpyvtc(var114, 710045822);
                           var78 = (byte)(1886523311 ^ var114);

                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                                 case 141397747:
                                    return (boolean)var78;
                                 case 165449233:
                                    var114 = 1337222931 ^ var114;
                                    return (boolean)var78;
                                 case 386190281:
                                    break;
                                 case 1237991082:
                                 default:
                                    throw new IOException();
                              }
                           }
                        }

                        var114 = 488714749 ^ var114;
                     } else {
                        var114 = 1459517495 ^ var114;
                     }
                  } else {
                     var114 = anfvgckrvfmpyvtc(var114, 631443842);
                  }
               } else {
                  var114 = 1193791090 ^ var114;
               }
            } else {
               label341:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                     case 106169951:
                        var114 ^= 2048130413;
                        break label341;
                     case 384956529:
                        break;
                     case 495986604:
                        break label341;
                     case 1527524271:
                     default:
                        throw new IOException();
                  }
               }
            }

            var78 = (byte)(1191267885 ^ var114);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                  case 160612468:
                     var114 = 2026317456 ^ var114;
                     return (boolean)var78;
                  case 997554076:
                  default:
                     throw new IOException();
                  case 1114156287:
                     return (boolean)var78;
                  case 1901811958:
               }
            }
         case 5:
            label305:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                  case 58612121:
                     break;
                  case 159767885:
                     var114 ^= 224606014;
                  case 1764069134:
                     break label305;
                  case 2100053608:
                  default:
                     throw new IOException();
               }
            }

            Material var103 = Material.POTION;
            if (var1 != var103) {
               var114 = 104617633 ^ var114;
               Material var104 = Material.SPLASH_POTION;
               if (var1 != var104) {
                  var114 = 1440109142 ^ var114;
                  Material var105 = Material.LINGERING_POTION;
                  if (var1 != var105) {
                     var114 = 276671045 ^ var114;
                     Material var106 = Material.TIPPED_ARROW;
                     if (var1 != var106) {
                        var114 = anfvgckrvfmpyvtc(var114, 541722381);
                        var78 = (byte)(1263275622 ^ var114);

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                              case 31658153:
                                 var114 = 1955227354 ^ var114;
                                 return (boolean)var78;
                              case 724581829:
                                 break;
                              case 1242045459:
                              default:
                                 throw new IOException();
                              case 1831153270:
                                 return (boolean)var78;
                           }
                        }
                     }

                     var114 = 777147751 ^ var114;
                  } else {
                     var114 = anfvgckrvfmpyvtc(var114, 1043332898);
                  }
               } else {
                  label293:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                        case 27291455:
                           break;
                        case 175189365:
                           var114 ^= 1811524980;
                           break label293;
                        case 1270358962:
                        default:
                           throw new IOException();
                        case 2051493464:
                           break label293;
                     }
                  }
               }
            } else {
               var114 = 1841691605 ^ var114;
            }

            var78 = (byte)(1163156493 ^ var114);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                  case 106116867:
                     var114 = 2056402096 ^ var114;
                     return (boolean)var78;
                  case 930627703:
                     return (boolean)var78;
                  case 1642010889:
                     break;
                  case 1817596959:
                  default:
                     throw new IOException();
               }
            }
         case 6:
            var114 = anfvgckrvfmpyvtc(var114, 1330872018);
            Material var108 = Material.BOOK;
            if (var1 != var108) {
               var114 = 2147167988 ^ var114;
               Material var109 = Material.ENCHANTED_BOOK;
               if (var1 != var109) {
                  var114 = 1892344702 ^ var114;
                  Material var110 = Material.WRITTEN_BOOK;
                  if (var1 != var110) {
                     var114 = 2051276731 ^ var114;
                     Material var111 = Material.WRITABLE_BOOK;
                     if (var1 != var111) {
                        label243:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                              case 148844289:
                                 break label243;
                              case 229270932:
                                 var114 ^= 1735248709;
                                 break label243;
                              case 1365786874:
                                 break;
                              case 1995903915:
                              default:
                                 throw new IOException();
                           }
                        }

                        var78 = (byte)(2025723713 ^ var114);
                        var114 = 1199079421 ^ var114;
                        break;
                     }

                     var114 = 1541436270 ^ var114;
                  } else {
                     label256:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                           case 80158930:
                              var114 ^= 564366549;
                              break label256;
                           case 216790770:
                           default:
                              throw new IOException();
                           case 657852093:
                              break;
                           case 799860212:
                              break label256;
                        }
                     }
                  }
               } else {
                  var114 = anfvgckrvfmpyvtc(var114, 1365864363);
               }
            } else {
               var114 = anfvgckrvfmpyvtc(var114, 781336927);
            }

            var78 = (byte)(1144237931 ^ var114);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                  case 41615128:
                     return (boolean)var78;
                  case 69494766:
                     var114 = 2079705046 ^ var114;
                     return (boolean)var78;
                  case 443649545:
                     break;
                  case 1744089526:
                  default:
                     throw new IOException();
               }
            }
         case 7:
            var114 = anfvgckrvfmpyvtc(var114, 1457557872);
            String var22 = var1.name();
            String var87 = mhbxnqeitu(nhvpajtzecpxeis(), ryfmeqmmzpmaxut(), var114);
            byte var23 = var22.contains(var87);
            if (var23 == (1930559895 ^ var114)) {
               var114 = 1523966125 ^ var114;
               String var25 = var1.name();
               String var88 = mhbxnqeitu(jrqdjiocexdqnuv(), ryfmeqmmzpmaxut(), var114);
               byte var26 = var25.contains(var88);
               if (var26 == (700965178 ^ var114)) {
                  var114 = 1316516272 ^ var114;
                  String var28 = var1.name();
                  String var89 = mhbxnqeitu(jcppxkdjgwknsar(), ryfmeqmmzpmaxut(), var114);
                  byte var29 = var28.contains(var89);
                  if (var29 == (1740607626 ^ var114)) {
                     var114 ^= 323166711;
                     String var31 = var1.name();
                     String var90 = mhbxnqeitu(kvnextgamznzwys(), ryfmeqmmzpmaxut(), var114);
                     byte var32 = var31.contains(var90);
                     if (var32 == (1962717565 ^ var114)) {
                        var114 = 1242646784 ^ var114;
                        String var34 = var1.name();
                        String var91 = mhbxnqeitu(lnknanxhduwozwi(), ryfmeqmmzpmaxut(), var114);
                        byte var35 = var34.contains(var91);
                        if (var35 == (1055783037 ^ var114)) {
                           label187:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                                 case 166539167:
                                    var114 ^= 659236598;
                                 case 733342248:
                                    break label187;
                                 case 1660330500:
                                    break;
                                 case 1728441870:
                                 default:
                                    throw new IOException();
                              }
                           }

                           var78 = (byte)(430366347 ^ var114);
                           var114 = 643872311 ^ var114;
                           break;
                        }

                        var114 = 333491970 ^ var114;
                     } else {
                        label209:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                              case 44688158:
                                 var114 ^= 1509025282;
                              case 725377221:
                                 break label209;
                              case 1950316233:
                              default:
                                 throw new IOException();
                              case 1984215681:
                           }
                        }
                     }
                  } else {
                     label200:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                           case 151211956:
                              var114 ^= 1253230581;
                              break label200;
                           case 742235838:
                              break;
                           case 1353950010:
                           default:
                              throw new IOException();
                           case 1681776067:
                              break label200;
                        }
                     }
                  }
               } else {
                  var114 = anfvgckrvfmpyvtc(var114, 80393797);
               }
            } else {
               var114 = anfvgckrvfmpyvtc(var114, 1579112168);
            }

            var78 = (byte)(755849086 ^ var114);
            var114 = anfvgckrvfmpyvtc(var114, 315310019);
            break;
         case 8:
            var114 = anfvgckrvfmpyvtc(var114, 425578467);
            String var52 = var1.name();
            String var97 = mhbxnqeitu(kycededvndegyof(), ryfmeqmmzpmaxut(), var114);
            byte var53 = var52.contains(var97);
            if (var53 == (1018126084 ^ var114)) {
               var114 ^= 466513449;
               String var55 = var1.name();
               String var98 = mhbxnqeitu(wnaehltccotsfov(), ryfmeqmmzpmaxut(), var114);
               byte var56 = var55.contains(var98);
               if (var56 == (660681005 ^ var114)) {
                  var114 = 1956106877 ^ var114;
                  String var58 = var1.name();
                  String var99 = mhbxnqeitu(osyjjwugpucbicr(), ryfmeqmmzpmaxut(), var114);
                  byte var59 = var58.contains(var99);
                  if (var59 == (1408688976 ^ var114)) {
                     var114 = 744832692 ^ var114;
                     String var61 = var1.name();
                     String var100 = mhbxnqeitu(yqvsikiiigldogz(), ryfmeqmmzpmaxut(), var114);
                     byte var62 = var61.contains(var100);
                     if (var62 == (2140397028 ^ var114)) {
                        var114 = 1538894274 ^ var114;
                        String var64 = var1.name();
                        String var101 = mhbxnqeitu(dqwarjnfmrexxoo(), ryfmeqmmzpmaxut(), var114);
                        byte var65 = var64.contains(var101);
                        if (var65 == (606762022 ^ var114)) {
                           var114 = 1805585783 ^ var114;
                           String var67 = var1.name();
                           String var102 = mhbxnqeitu(jntaejbiswkfokt(), ryfmeqmmzpmaxut(), var114);
                           byte var68 = var67.contains(var102);
                           if (var68 == (1337293137 ^ var114)) {
                              var114 = anfvgckrvfmpyvtc(var114, 121004875);
                              var78 = (byte)(1216551450 ^ var114);
                              var114 = 2001040038 ^ var114;
                              break;
                           }

                           var114 = 1254609818 ^ var114;
                        } else {
                           var114 = 559472365 ^ var114;
                        }
                     } else {
                        label149:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                              case 120455802:
                                 var114 ^= 2061596463;
                                 break label149;
                              case 340638960:
                              default:
                                 throw new IOException();
                              case 953660403:
                                 break;
                              case 1287769583:
                                 break label149;
                           }
                        }
                     }
                  } else {
                     var114 = 1451510171 ^ var114;
                  }
               } else {
                  label160:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                        case 206333990:
                           var114 ^= 571710438;
                           break label160;
                        case 933515650:
                        default:
                           throw new IOException();
                        case 1117677265:
                           break label160;
                        case 1158662296:
                     }
                  }
               }
            } else {
               label140:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var114)) {
                     case 34977535:
                     default:
                        throw new IOException();
                     case 93582520:
                        var114 ^= 970847695;
                        break label140;
                     case 337393444:
                        break;
                     case 1248809098:
                        break label140;
                  }
               }
            }

            var78 = (byte)(91400906 ^ var114);
            var114 = 984924791 ^ var114;
            break;
         default:
            var114 = 1133405841 ^ var114;
            var78 = (byte)(1719465591 ^ var114);
            var114 = 1505402570 ^ var114;
      }

      return (boolean)var78;
   }

   private static AuctionCategory[] $values() {
      int var22 = 1384142395 ^ 300226158 ^ 466922081;
      var22 = 2140929779 ^ var22;
      byte var0 = (byte)(657069262 ^ var22);
      AuctionCategory[] var3 = new AuctionCategory[var0];
      byte var1 = (byte)(657069255 ^ var22);
      AuctionCategory var2 = ALL;
      var3[var1] = var2;
      byte var4 = (byte)(657069254 ^ var22);
      AuctionCategory var12 = BLOCKS;
      var3[var4] = var12;
      byte var5 = (byte)(657069253 ^ var22);
      AuctionCategory var13 = TOOLS;
      var3[var5] = var13;
      byte var6 = (byte)(657069252 ^ var22);
      AuctionCategory var14 = FOOD;
      var3[var6] = var14;
      byte var7 = (byte)(657069251 ^ var22);
      AuctionCategory var15 = COMBAT;
      var3[var7] = var15;
      byte var8 = (byte)(657069250 ^ var22);
      AuctionCategory var16 = POTIONS;
      var3[var8] = var16;
      byte var9 = (byte)(657069249 ^ var22);
      AuctionCategory var17 = BOOKS;
      var3[var9] = var17;
      byte var10 = (byte)(657069248 ^ var22);
      AuctionCategory var18 = INGREDIENTS;
      var3[var10] = var18;
      byte var11 = (byte)(657069263 ^ var22);
      AuctionCategory var19 = UTILITIES;
      var3[var11] = var19;
      return var3;
   }

   static {
      int var30 = 191554572 ^ 1343430516 ^ Integer.parseInt("987437371");
      var30 = 1519486662 ^ var30;
      String var1 = mhbxnqeitu(aihxuwagajqoxpz(), ryfmeqmmzpmaxut(), var30);
      byte var2 = (byte)(993223813 ^ var30);
      AuctionCategory var0 = new AuctionCategory(var1, var2);
      ALL = var0;
      var30 = 2027554734 ^ var30;
      String var12 = mhbxnqeitu(gdhkmotuqcfndyq(), ryfmeqmmzpmaxut(), var30);
      byte var20 = (byte)(1139368746 ^ var30);
      AuctionCategory var3 = new AuctionCategory(var12, var20);
      BLOCKS = var3;
      var30 = 278823510 ^ var30;
      String var13 = mhbxnqeitu(zculqacridnzpup(), ryfmeqmmzpmaxut(), var30);
      byte var21 = (byte)(1400365439 ^ var30);
      AuctionCategory var4 = new AuctionCategory(var13, var21);
      TOOLS = var4;
      var30 = 741420275 ^ var30;
      String var14 = mhbxnqeitu(hrhfsqonmqdfkjm(), ryfmeqmmzpmaxut(), var30);
      byte var22 = (byte)(2135346573 ^ var30);
      AuctionCategory var5 = new AuctionCategory(var14, var22);
      FOOD = var5;
      var30 = 1331207463 ^ var30;
      String var15 = mhbxnqeitu(xnovuizwaznerpt(), ryfmeqmmzpmaxut(), var30);
      byte var23 = (byte)(807293101 ^ var30);
      AuctionCategory var6 = new AuctionCategory(var15, var23);
      COMBAT = var6;
      var30 = 535560338 ^ var30;
      String var16 = mhbxnqeitu(sedfakeedkfaclg(), ryfmeqmmzpmaxut(), var30);
      byte var24 = (byte)(804409406 ^ var30);
      AuctionCategory var7 = new AuctionCategory(var16, var24);
      POTIONS = var7;
      var30 = 157757418 ^ var30;
      String var17 = mhbxnqeitu(zsypzaaenkosgxh(), ryfmeqmmzpmaxut(), var30);
      byte var25 = (byte)(647331799 ^ var30);
      AuctionCategory var8 = new AuctionCategory(var17, var25);
      BOOKS = var8;
      var30 = 70045178 ^ var30;
      String var18 = mhbxnqeitu(adryuyldqnhgwgl(), ryfmeqmmzpmaxut(), var30);
      byte var26 = (byte)(582595116 ^ var30);
      AuctionCategory var9 = new AuctionCategory(var18, var26);
      INGREDIENTS = var9;
      var30 = 1442303840 ^ var30;
      String var19 = mhbxnqeitu(bedrgfavadqzlhv(), ryfmeqmmzpmaxut(), var30);
      byte var27 = (byte)(2001632579 ^ var30);
      AuctionCategory var10 = new AuctionCategory(var19, var27);
      UTILITIES = var10;
      var30 = 1678433834 ^ var30;
      AuctionCategory[] var11 = $values();
   }

   public static String mhbxnqeitu(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] ryfmeqmmzpmaxut() {
      return new byte[]{87, 82, 117};
   }

   private static byte[] gdhkmotuqcfndyq() {
      return new byte[]{-104, -100, 70, 44, 97, 15, 111, 42, 65, 35, 99, 15, 100, 56};
   }

   private static byte[] zculqacridnzpup() {
      return new byte[]{-104, -103, 69, 51, 97, 12, 98, 41, 70, 44, 99, 18};
   }

   private static byte[] xnovuizwaznerpt() {
      return new byte[]{-111, -99, 66, 38, 107, 9, 103, 38, 66, 45, 98, 3, 101, 63};
   }

   private static byte[] zsypzaaenkosgxh() {
      return new byte[]{-97, -103, 66, 38, 97, 11, 96, 36, 70, 42, 102, 17};
   }

   private static byte[] sedfakeedkfaclg() {
      return new byte[]{-111, -99, 65, 51, 98, 3, 99, 54, 70, 38, 98, 14, 99, 44, 76, 48};
   }

   private static byte[] bedrgfavadqzlhv() {
      return new byte[]{-101, -99, 69, 51, 100, 18, 101, 46, 77, 44, 96, 12, 103, 55, 67, 45, 96, 5, 111, 54};
   }

   private static byte[] aihxuwagajqoxpz() {
      return new byte[]{-112, -108, 70, 36, 96, 10, 111, 47};
   }

   private static byte[] hrhfsqonmqdfkjm() {
      return new byte[]{-101, -100, 70, 36, 97, 14, 97, 40, 66, 39};
   }

   private static byte[] adryuyldqnhgwgl() {
      return new byte[]{-100, -107, 71, 43, 107, 14, 102, 36, 64, 48, 106, 2, 98, 47, 64, 47, 99, 5, 98, 36, 71, 54, 107, 19};
   }

   private static byte[] miwxzredkgklkwy() {
      return new byte[]{-101, -101, 66, 9, 101, 56, 100, 11, 65, 22, 100, 109, 110, 4, 77, 17, 98, 34, 101, 16, 66, 7, 101, 34, 100, 12, 65, 74, 100, 49, 110, 10, 77, 22, 98, 53, 101, 2, 66, 7, 101, 33, 100, 22, 65, 0, 100, 48};
   }

   private static byte[] dccjyvyrtzivkys() {
      return new byte[]{-104, -104, 68, 54, 98, 10, 110, 40, 68, 33, 99, 12, 102, 36};
   }

   private static byte[] kycededvndegyof() {
      return new byte[]{-104, -99, 68, 44, 99, 8, 97, 47, 77, 51, 99, 4, 102, 57, 68, 54};
   }

   private static byte[] luknykhinsgjkxv() {
      return new byte[]{-102, -99, 68, 58, 97, 31, 101, 43, 70, 32, 98, 1, 110, 47, 77, 49};
   }

   private static byte[] kvnextgamznzwys() {
      return new byte[]{-104, -108, 67, 33, 101, 17, 96, 52, 67, 54};
   }

   private static byte[] tjvvenndxeefrok() {
      return new byte[]{-104, -101, 64, 32, 106, 23, 111, 41, 76, 48, 99, 16, 98, 36, 77, 40, 106, 22};
   }

   private static byte[] jntaejbiswkfokt() {
      return new byte[]{-104, -98, 70, 38, 96, 5, 100, 48, 70, 40, 99, 15, 100, 43, 71, 41, 97, 27, 100, 55, 68, 43, 97, 6};
   }

   private static byte[] nczynswolxmvrxd() {
      return new byte[]{-104, -100, 76, 49, 100, 5, 101, 45, 76, 51, 99, 1, 110, 43};
   }

   private static byte[] xjukwfiviseltqm() {
      return new byte[]{-104, -100, 77, 53, 96, 21, 98, 44, 66, 52, 99, 0};
   }

   private static byte[] jrqdjiocexdqnuv() {
      return new byte[]{-98, -99, 69, 41, 100, 5, 102, 40};
   }

   private static byte[] fykpetzhaltifzw() {
      return new byte[]{-100, -104, 76, 42, 99, 14, 103, 39};
   }

   private static byte[] lnknanxhduwozwi() {
      return new byte[]{-104, -99, 64, 44, 101, 24, 100, 37, 70, 39, 99, 0, 98, 51};
   }

   private static byte[] osyjjwugpucbicr() {
      return new byte[]{-104, -103, 69, 45, 100, 24, 111, 40, 66, 42, 99, 4, 103, 62};
   }

   private static byte[] nhvpajtzecpxeis() {
      return new byte[]{-104, -108, 70, 46, 103, 14, 110, 45, 76, 45, 99, 24};
   }

   private static byte[] loyxzukqwmypqfh() {
      return new byte[]{-104, -101, 64, 38, 99, 21, 111, 33};
   }

   private static byte[] wnaehltccotsfov() {
      return new byte[]{-97, -101, 69, 34, 106, 8, 103, 45, 64, 34, 100, 14};
   }

   private static byte[] dqwarjnfmrexxoo() {
      return new byte[]{-97, -99, 67, 51, 100, 15, 103, 37, 71, 32, 98, 17, 96, 55};
   }

   private static byte[] yqvsikiiigldogz() {
      return new byte[]{-101, -100, 65, 33, 97, 0, 96, 43, 71, 33, 96, 16};
   }

   private static byte[] jcppxkdjgwknsar() {
      return new byte[]{-104, -102, 65, 52, 100, 13, 96, 37, 71, 51, 99, 6};
   }

   private static byte[] qqketemfrngasxh() {
      return new byte[]{-101, -104, 71, 38, 96, 9, 103, 55};
   }

   private static byte[] qcapsxvgucmibvo() {
      return new byte[]{-99, -101, 69, 51, 98, 9, 96, 33, 69, 40, 100, 4, 99, 58, 64, 37};
   }

   private static byte[] ntwoepjruqycmyw() {
      return new byte[]{-104, -99, 71, 48, 100, 17, 98, 42, 68, 54, 99, 1};
   }

   private static int anfvgckrvfmpyvtc(int var0, int var1) {
      return var0 ^ var1;
   }
}
