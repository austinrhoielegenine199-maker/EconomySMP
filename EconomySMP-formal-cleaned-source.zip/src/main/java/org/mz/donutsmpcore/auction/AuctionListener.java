package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Stream;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import skido.KKo0KoOoOK;
import skido.KKoOoOo0oOK;

public class AuctionListener implements Listener {
   private static final Map<UUID, List<String>> pending;
   private static String tdpayfbkoo;

   public static void addNotification(UUID var0, String var1) {
      int var9 = 556028925 ^ 1314210502 ^ 1606206322;
      var9 = 1019899796 ^ var9;
      Map var2 = pending;
      BiFunction var6 = (var1x, var2x) -> {
         int var12 = 293286649 ^ 519748394 ^ 1606206322;
         var12 = 215340538 ^ var12;
         Object var9;
         if (var2x != null) {
            var12 = 748127890 ^ var12;
            var9 = var2x;

            label23:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                  case 167129482:
                     var12 ^= 1039171347;
                  case 359919629:
                     break label23;
                  case 511155211:
                  default:
                     throw new RuntimeException();
                  case 1031333198:
               }
            }
         } else {
            label34:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                  case 67299368:
                     var12 ^= 1397843899;
                  case 256319708:
                     break label34;
                  case 922379913:
                  default:
                     throw new RuntimeException();
                  case 1151066508:
               }
            }

            var9 = new ArrayList();
            var12 = 1110875706 ^ var12;
         }

         var12 = 1663590594 ^ var12;
         ((List)var9).add(var1);
         var12 = 611418267 ^ var12;
         return (List)var9;
      };
      var2.compute(var0, var6);
      var9 = 451504962 ^ var9;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent var1) {
      int var23 = 692990327 ^ 931189780 ^ 34589555;
      var23 = 1958625223 ^ var23;
      Player var8 = var1.getPlayer();
      var23 = 1148379663 ^ var23;
      Map var9 = pending;
      UUID var17 = var8.getUniqueId();
      Object var10 = var9.remove(var17);
      List var11 = (List)var10;
      var23 = 170967569 ^ var23;
      if (var11 != null) {
         var23 = 1236044994 ^ var23;
         byte var14 = var11.isEmpty();
         if (var14 == (1871822091 ^ var23)) {
            var23 = 216897491 ^ var23;
            KKoOoOo0oOK var15 = KKoOoOo0oOK.getInstance();
            Runnable var19 = () -> {
               int var24 = 2123083909 ^ 1702151911 ^ 1606206322;
               var24 = 649239299 ^ var24;
               byte var9 = var8.isOnline();
               if (var9 != (1659973139 ^ var24)) {
                  var24 = 476799718 ^ var24;
                  Iterator var11x = var11.iterator();
                  Iterator var7 = var11x;
                  var24 = 2086993708 ^ var24;

                  while(true) {
                     byte var13 = var7.hasNext();
                     if (var13 == (50246617 ^ var24)) {
                        var24 = 2061029724 ^ var24;
                        return;
                     }

                     var24 = 1820169461 ^ var24;
                     Object var15 = var7.next();
                     String var16 = (String)var15;
                     var24 = 1329959813 ^ var24;
                     var8.sendMessage(var16);
                     var24 = 1268796660 ^ var24;
                     var8.sendActionBar(var16);
                     var24 = 1521721384 ^ var24;
                     String var21 = mydlmecbno(qqgfslejeyzrahx(), var24);
                     Sound var4 = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;
                     float var5 = 1.0F;
                     float var6 = 1.2F;
                     KKo0KoOoOK.play(var8, var21, var4, var5, var6);
                     var24 = 1421152988 ^ var24;
                     var24 = 1721694576 ^ var24;
                  }
               } else {
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var24)) {
                        case 263400373:
                           var24 = 450317462 ^ var24;
                           return;
                        case 399337189:
                           return;
                        case 1332179273:
                        default:
                           throw new IllegalAccessException();
                        case 1520394732:
                     }
                  }
               }
            };
            long var20 = 40L;
            var15.runAtEntityLater(var8, var19, var20);
            var23 = 1759323687 ^ var23;
         } else {
            var23 = 1680912884 ^ var23;
         }
      } else {
         var23 = 765214006 ^ var23;
      }

   }

   public static String getFormattedItemName(ItemStack var0) {
      int var31 = 273952647 ^ 1621362654 ^ 1606206322;
      var31 = 113588446 ^ var31;
      byte var5 = var0.hasItemMeta();
      if (var5 != (696898549 ^ var31)) {
         var31 = 1404557178 ^ var31;
         ItemMeta var7 = var0.getItemMeta();
         byte var8 = var7.hasDisplayName();
         if (var8 != (2050884751 ^ var31)) {
            var31 = 1407726732 ^ var31;
            ItemMeta var22 = var0.getItemMeta();
            String var23 = var22.getDisplayName();
            String var24 = ChatColor.stripColor(var23);
            return var24;
         }

         var31 = 742612135 ^ var31;
      } else {
         var31 = 2146733021 ^ var31;
      }

      Material var10 = var0.getType();
      String var11 = var10.name();
      String var2 = mydlmecbno(qlwrvaxwrhlsyfi(), var31);
      String var3 = mydlmecbno(kleysclyywuwhqj(), var31);
      String var12 = var11.replace(var2, var3);
      String var13 = var12.toLowerCase();
      var31 = 2033297274 ^ var31;
      String var25 = mydlmecbno(dpxbssdqdlaxnaa(), var31);
      String[] var15 = var13.split(var25);
      Stream var16 = Arrays.stream(var15);
      Function var26 = (var0x) -> {
         int var13 = 1596182929 ^ 513200903 ^ 1606206322;
         var13 = 1154289375 ^ var13;
         byte var4 = var0x.isEmpty();
         String var8;
         if (var4 != (1522847547 ^ var13)) {
            var13 = 1602433877 ^ var13;
            var8 = mydlmecbno(latynuaqnmafdpv(), var13);
            var13 = vwhygiyfviriwykr(var13, 135621848);
         } else {
            var13 = vwhygiyfviriwykr(var13, 1220833517);
            byte var2 = (byte)(302038998 ^ var13);
            char var6 = var0x.charAt(var2);
            char var7 = Character.toUpperCase(var6);
            byte var3 = (byte)(302038999 ^ var13);
            String var10 = var0x.substring(var3);
            var8 = var7 + var10;
            var13 = 525479776 ^ var13;
         }

         return var8;
      };
      Stream var17 = var16.map(var26);
      BinaryOperator var27 = (var0x, var1) -> {
         int var7 = 385343690 ^ 1340242595 ^ 1606206322;
         var7 = 1747000324 ^ var7;
         String var4 = var0x + " " + var1;
         return var4;
      };
      Optional var18 = var17.reduce(var27);
      Object var19 = var18.orElse(var13);
      String var20 = (String)var19;
      return var20;
   }

   static {
      int var3 = 197426092 ^ 1756336737 ^ Integer.parseInt("2085889827");
      tdpayfbkoo = ByteBuffer.wrap(jrqmxluwbiarxsw()).asCharBuffer().toString();
      var3 = 1623081894 ^ var3;
      ConcurrentHashMap var0 = new ConcurrentHashMap();
      pending = var0;
      var3 = 1771524091 ^ var3;
   }

   public static String mydlmecbno(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = tdpayfbkoo;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] qlwrvaxwrhlsyfi() {
      return new byte[]{0, 0, 0, 1, 0, 0, 0, 0};
   }

   private static byte[] kleysclyywuwhqj() {
      return new byte[]{0, 0, 0, 1, 0, 0, 0, 1};
   }

   private static byte[] dpxbssdqdlaxnaa() {
      return new byte[]{0, 0, 0, 1, 0, 0, 0, 2};
   }

   private static byte[] latynuaqnmafdpv() {
      return new byte[]{0, 0, 0, 0, 0, 0, 0, 3};
   }

   private static byte[] qqgfslejeyzrahx() {
      return new byte[]{0, 0, 0, 35, 0, 0, 0, 3};
   }

   private static byte[] jrqmxluwbiarxsw() {
      return new byte[]{49, 107, 49, 20, 55, 25, 56, 80, 57, 71, 56, 91, 49, 76, 49, 81, 49, 86, 50, 86, 56, 31, 56, 65, 56, 84, 57, 92, 56, 92, 49, 81, 49, 86, 49, 94, 50, 86, 56, 94, 56, 69, 56, 88, 57, 84, 56, 81, 49, 91, 49, 89, 49, 77, 50, 81, 56, 94, 56, 95, 56, 66, 57, 28, 56, 74, 49, 93, 49, 79, 49, 88, 50, 74, 56, 85};
   }

   private static int vwhygiyfviriwykr(int var0, int var1) {
      return var0 ^ var1;
   }
}
