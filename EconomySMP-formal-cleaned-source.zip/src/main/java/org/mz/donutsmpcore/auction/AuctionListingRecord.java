package org.mz.donutsmpcore.auction;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.bukkit.inventory.ItemStack;
import skido.oOo0KKoOoOK;

public class AuctionListingRecord {
   private int id;
   private final UUID seller;
   private final String sellerName;
   private final ItemStack item;
   private final double price;
   private final long expiredAt;
   private final long deletesAt;
   private static final String TIME_COLOR;
   private static byte[] lnqabplhxn;

   public AuctionListingRecord(int var1, UUID var2, String var3, ItemStack var4, double var5, long var7, long var9) {
      byte var12 = -1;
      this.id = var12;
      this.id = var1;
      this.seller = var2;
      String var24;
      if (var3 != null) {
         var24 = var3;
      } else {
         var24 = "Unknown";
      }

      this.sellerName = var24;
      ItemStack var26 = var4.clone();
      this.item = var26;
      this.price = var5;
      this.expiredAt = var7;
      this.deletesAt = var9;
   }

   public AuctionListingRecord(UUID var1, String var2, ItemStack var3, double var4, long var6, long var8) {
      byte var11 = -1;
      this.id = var11;
      this.seller = var1;
      String var29;
      if (var2 != null) {
         var29 = var2;
      } else {
         var29 = "Unknown";
      }

      this.sellerName = var29;
      ItemStack var22 = var3.clone();
      this.item = var22;
      this.price = var4;
      this.expiredAt = var6;
      this.deletesAt = var8;
   }

   public int getId() {
      int var5 = 129405831 ^ 422133371 ^ 1368445651;
      var5 = 661867287 ^ var5;
      int var2 = this.id;
      return var2;
   }

   public void setId(int var1) {
      int var6 = 1630559725 ^ 2065284211 ^ 1368445651;
      var6 = 432168657 ^ var6;
      this.id = var1;
      var6 = 283304724 ^ var6;
   }

   public UUID getSeller() {
      int var5 = 479661898 ^ 72103495 ^ 1368445651;
      var5 = 1406637960 ^ var5;
      UUID var2 = this.seller;
      return var2;
   }

   public String getSellerName() {
      int var5 = 1789521978 ^ 1556085073 ^ 1368445651;
      var5 = 2062489914 ^ var5;
      String var2 = this.sellerName;
      return var2;
   }

   public ItemStack getItemStack() {
      int var6 = 213832099 ^ 787156141 ^ 1368445651;
      var6 = 1147989258 ^ var6;
      ItemStack var2 = this.item;
      ItemStack var3 = var2.clone();
      return var3;
   }

   public double getPrice() {
      int var5 = 1437875131 ^ 45156867 ^ 1368445651;
      var5 = 267693163 ^ var5;
      double var2 = this.price;
      return var2;
   }

   public long getExpiredAt() {
      int var5 = 1645767554 ^ 2101292360 ^ 1368445651;
      var5 = 2036650438 ^ var5;
      long var2 = this.expiredAt;
      return var2;
   }

   public long getDeletesAt() {
      int var5 = 769687768 ^ 596798030 ^ 1368445651;
      var5 = 854953855 ^ var5;
      long var2 = this.deletesAt;
      return var2;
   }

   public boolean shouldDelete() {
   }

   public String getTimeUntilDeletion() {
   }

   static {
      int var4 = 1337510221 ^ 1302027243 ^ Integer.parseInt("125853040");
      lnqabplhxn = gxmptaeowyfysmm();
      var4 = 604774892 ^ var4;
      String var0 = cffazzwjvj(ekmodbokplvjrxz(), var4);
      String var1 = oOo0KKoOoOK.translateHex(var0);
      TIME_COLOR = var1;
   }

   public static String cffazzwjvj(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = lnqabplhxn;
         byte[] var34 = lnqabplhxn;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] gxmptaeowyfysmm() {
      return new byte[]{79, 84, 44, 48, 110, 36, 99, 33, 33, 67, 70, 61, 115, 124, 80, 73, 7, 119, 34, 27, 64, 7, 17, 9, 121, 125, 38, 125, 61, 102, 87, 102, 21, 72, 54, 97, 5, 127, 29, 57, 8, 79, 47, 98, 102, 75, 114, 90, 103, 42, 99, 127, 43, 102, 59, 105, 15, 93, 17, 3, 101, 52, 14, 107, 64, 31, 6, 53, 108, 47, 37, 40, 31, 88, 58, 10, 51, 38, 85};
   }

   private static byte[] ekmodbokplvjrxz() {
      return new byte[]{-124, -99, 25, 34, 89, 38, 90, 37, 21, 67, 112, 61, 66, 126, 103, 69};
   }

   private static byte[] cpotcaizpuzrawa() {
      return new byte[]{-125, -101, 26, 104};
   }

   private static byte[] xgqmknknketdila() {
      return new byte[]{-124, -109, 31, 98, 88, 50};
   }

   private static byte[] xujqddrikzyeoqy() {
      return new byte[]{-125, -101, 30, 32, 87, 64, 87, 125, 21, 7, 116, 100, 65, 32, 105, 88, 51, 12, 22, 95, 114, 82, 35, 84, 64, 108, 18, 11, 9, 51, 101, 58, 39, 29, 15, 36, 49, 40, 41, 122};
   }

   private static byte[] bqxizqqnaklzumt() {
      return new byte[]{-128, -110, 24, 110, 93, 53};
   }

   private static byte[] lljyjdbqzlacgko() {
      return new byte[]{-128, -104, 27, -82, 87, 117, 86, 93, 22, 30, 119, 98, 68, 32, 105, 15, 50, 38, 21, 77, 113, 83, 38, 30, 64, 97, 19, 107};
   }

   private static int flwobophxtzxdfgm(int var0, int var1) {
      return var1 ^ var0;
   }
}
