package org.mz.donutsmpcore.auction;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class AuctionListingCommand implements CommandExecutor {

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
   }

   public static String ecsuffospu(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] lduwuptemfqhxii() {
      return new byte[]{117, 78, 39, 52, 101, 116, 115, 19, 127, 77, 41, 52, 8, 8, 68, 120, 101, 102, 78, 78, 58, 112, 12, 33, 115, 52, 103, 28, 124, 60, 40, 95, 65, 51, 18, 71, 58, 103, 12, 103, 65, 89, 18, 121, 9, 104, 47, 52, 8, 30, 19, 91, 58, 49, 121, 100, 54, 84, 44, 104, 8, 122, 81, 28, 84, 6, 64, 37, 1, 80, 49, 95, 20, 100};
   }

   private static byte[] gzamezhqicvguxt() {
      return new byte[]{-71, -128, 21, 100, 86, 57, 74, 66, 72, 12, 27, 108, 58, 86, 119, 46, 92, 122, 121, 18, 8, 47, 62, 102, 64, 109, 94, 66, 75, 96, 26, 10, 115, 47, 33, 15, 3, 39, 59, 59, 115, 11, 32, 45};
   }

   private static byte[] ylobmzntcjcohdd() {
      return new byte[]{-71, -128, 21, 35, 86, 47, 74, 104, 72, 22, 27, 115, 58, 88, 119, 44, 92, 61, 121, 31, 8, 97, 62, 96, 64, 126, 94, 71, 75, 106, 26, 11, 115, 34, 33, 25, 3, 58, 59, 32, 115, 5, 32, 41, 58, 36, 22, 39, 63, 11, 33, 62, 8, 114, 74, 37, 15, 92, 27, 125, 58, 126, 99, 29, 103, 14, 121, 59, 54, 69, 3, 95, 38, 62, 70, 90, 30, 38, 82, 116, 65, 18, 77, 49};
   }

   private static byte[] rmoyprtdbgxuicy() {
      return new byte[]{-66, -120, 30, 96, 93, 53, 75, 66, 77, 12, 16, 100, 61, 95, 112, 46, 87, 122, 123, 27, 3, 44, 52, 102, 75, 114, 85, 64, 69, 107, 29, 0, 117, 38, 32, 25, 15, 55, 53, 63, 121, 4, 42, 63};
   }

   private static byte[] fwsodveqksyilao() {
      return new byte[]{-66, -120, 30, 39, 93, 35, 75, 120, 77, 23, 16, 120, 61, 16, 112, 40, 87, 53, 123, 1, 3, 32, 52, 53, 75, 116, 85, 76, 69, 100, 29, 4, 117, 99, 32, 16, 15, 58, 53, 114, 121, 20, 42, 36, 59, 40, 22, 127, 61, 6, 39, 15, 8, 106, 76, 46, 15, 21, 20, 53, 48, 38, 99, 78, 109, 31, 117, 113, 53, 1, 3, 0, 33, 52, 76, 15, 31, 33, 93, 102, 65, 14, 70, 81, 28, 111, 60, 69, 118, 56, 80, 45, 119, 30, 2, 42, 52, 103, 65, 36, 94, 10, 73, 33, 28, 11, 115, 104, 39, 19, 3, 59, 52, 39, 121, 78, 32, 101};
   }

   private static byte[] jnoklgthgagbpbn() {
      return new byte[]{-66, -120, 30, 36, 93, 35, 75, 84, 77, 10, 16, 127, 61, 85, 112, 46, 87, 32, 123, 82};
   }

   private static byte[] ghbytizqewmsvcr() {
      return new byte[]{-66, -120, 30, 36, 93, 44, 75, 72, 77, 21, 16, 100, 61, 68, 112, 101};
   }

   private static byte[] saznrkaxvvlpkrp() {
      return new byte[]{-71, -120, 16, 102, 86, 57, 69, 72, 77, 0, 30, 110, 59, 95, 114, 46, 87, 113, 121, 28, 9, 61, 58, 122, 65, 121, 80, 70, 79, 107, 30, 9, 115, 121, 37, 17, 9, 51, 58, 51, 115, 3, 37, 37, 58, 61, 25, 97, 58, 70, 36, 6, 9, 109, 79, 114, 4, 9, 27, 62, 59, 44, 103, 93};
   }

   private static byte[] kixrzkehemwjulf() {
      return new byte[]{-70, -123, 21, 100, 81, 55, 68, 71, 78, 9, 24, 105, 58, 86, 112, 32, 82, 127, 127, 18, 11, 45, 62, 99, 71, 118, 80, 66, 77, 98, 25, 12, 115, 47, 38, 29, 13, 57, 61, 58, 112, 4, 32, 60, 61, 115, 24, 98, 57, 77, 34, 27, 8, 105, 77, 61, 1, 13, 29, 58, 57, 47, 99, 95};
   }

   private static byte[] apwbajgvkvpihem() {
      return new byte[]{-70, -123, 21, 35, 81, 33, 68, 104, 78, 20, 24, 115, 58, 77, 112, 39, 82, 63, 127, 25, 11, 100, 62, 124, 71, 107, 80, 70, 77, 101, 25, 31, 115, 34, 38, 3, 13, 53, 61, 54, 112, 14, 32, 32, 61, 59, 24, 103, 57, 15};
   }

   private static byte[] vslreliyekrgreh() {
      return new byte[]{-72, -121, 16, 109, 86, 52, 67, 65, 76, 15, 30, 101, 59, 82, 116, 39, 86, 126, 121, 5, 9, 32, 60, 124, 64, 110, 80, 9, 79, 124, 24, 29, 114, 100, 37, 24, 9, 55};
   }

   private static byte[] qcjsnnuaslhifgj() {
      return new byte[]{-72, -121, 16, 42, 86, 34, 67, 119, 76, 8, 30, 109, 59, 90, 116, 44, 86, 106, 121, 86, 9, 106, 60, 113, 64, 106, 80, 4, 79, 122, 24, 11, 114, 105, 37, 19, 9, 114, 60, 106, 114, 31, 37, 51, 58, 52, 31, 102, 59, 77, 36, 93};
   }

   private static byte[] nakfwvxgaialeiq() {
      return new byte[]{-70, -122, 20, 99, 87, 56, 70, 72, 71, 1, 24, 106, 59, 81, 118, 47, 80, 112, 118, 6, 11, 53, 63, 126, 65, 110, 82, 65, 68, 41, 25, 6, 114, 106, 32, 10, 15, 114, 52, 47, 112, 1, 33, 60, 59, 56, 26, 120, 48, 79, 34, 26, 9, 98};
   }

   private static byte[] yeezcjsukdblchx() {
      return new byte[]{-70, -122, 20, 36, 87, 46, 70, 123, 71, 7, 24, 106, 59, 93, 118, 36, 80, 126, 118, 27, 11, 50, 63, 100, 65, 121, 82, 4, 68, 102, 25, 13, 114, 37, 32, 25, 15, 45, 52, 58, 112, 15, 33, 59, 59, 52, 26, 126, 48, 6, 34, 24, 9, 111, 75, 60, 3, 2, 20, 112, 57, 125, 98, 11};
   }

   private static byte[] xsozhvgynpgropm() {
      return new byte[]{-65, -126, 16, 97, 80, 52, 75, 73, 73, 13, 26, 106, 60, 82, 113, 46, 92, 126, 122, 14, 13, 33, 57, 120, 75, 97, 81, 5, 79, 101, 28, 5, 116, 38, 43, 24, 14, 32, 59, 54, 116, 1};
   }

   private static byte[] mwdfbvxjnhbrtbe() {
      return new byte[]{-65, -126, 16, 38, 80, 34, 75, 115, 73, 22, 26, 118, 60, 29, 113, 45, 92, 37, 122, 14, 13, 48, 57, 52, 75, 101, 81, 71, 79, 103, 28, 14, 116, 43, 43, 16, 14, 58, 59, 115, 116, 5, 42, 52, 63, 57, 28, 110, 60, 11, 38, 10, 3, 105, 77, 119, 1, 25, 25, 50, 48, 54, 103, 90, 103, 17, 116, 125, 52, 9, 8, 0, 32, 57, 66, 90, 18, 105, 93, 44, 69, 73, 76, 30, 29, 32};
   }

   private static int qnwloeyndimtbpfq(int var0, int var1) {
      return var1 ^ var0;
   }

   static {
   }
}
