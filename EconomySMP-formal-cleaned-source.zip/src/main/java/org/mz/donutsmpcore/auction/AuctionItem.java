package org.mz.donutsmpcore.auction;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.bukkit.inventory.ItemStack;
import skido.oOo0KKoOoOK;

public class AuctionItem {
   private int id;
   private final UUID seller;
   private final String sellerName;
   private final ItemStack item;
   private final double price;
   private final long listedAt;
   private final long expiresAt;
   private static final String TIME_COLOR;
   private static final String EXPIRED_TEXT = "§cExpired";
   private static String fgdaldndxx;

   public AuctionItem(UUID var1, String var2, ItemStack var3, double var4) {
      byte var7 = -1;
      this.id = var7;
      this.seller = var1;
      String var19;
      if (var2 != null) {
         var19 = var2;
      } else {
         var19 = "Unknown";
      }

      this.sellerName = var19;
      ItemStack var21 = var3.clone();
      this.item = var21;
      this.price = var4;
      long var24 = System.currentTimeMillis();
      this.listedAt = var24;
      long var27 = this.listedAt;
      long var8 = Ko0KoOKoOK.getDefaultExpirationMs();
      long var29 = var27 + var8;
      this.expiresAt = var29;
   }

   public AuctionItem(int var1, UUID var2, String var3, ItemStack var4, double var5, long var7, long var9) {
      byte var12 = -1;
      this.id = var12;
      this.id = var1;
      this.seller = var2;
      String var32;
      if (var3 != null) {
         var32 = var3;
      } else {
         var32 = "Unknown";
      }

      this.sellerName = var32;
      ItemStack var25 = var4.clone();
      this.item = var25;
      this.price = var5;
      this.listedAt = var7;
      this.expiresAt = var9;
   }

   public int getId() {
      int var5 = 996172391 ^ 1316324335 ^ 1781006046;
      var5 = 19253319 ^ var5;
      int var2 = this.id;
      return var2;
   }

   public void setId(int var1) {
      int var6 = 1672888224 ^ 1220670486 ^ 1781006046;
      var6 = 1372102081 ^ var6;
      this.id = var1;
      var6 = 1491184991 ^ var6;
   }

   public UUID getSeller() {
      int var5 = 886618693 ^ 1864213013 ^ 1781006046;
      var5 = 51833246 ^ var5;
      UUID var2 = this.seller;
      return var2;
   }

   public String getSellerName() {
      int var5 = 117729715 ^ 42138694 ^ 1781006046;
      var5 = 1033771346 ^ var5;
      String var2 = this.sellerName;
      return var2;
   }

   public ItemStack getItemStack() {
      int var6 = 174540376 ^ 1687347866 ^ 1781006046;
      var6 = 300174361 ^ var6;
      ItemStack var2 = this.item;
      ItemStack var3 = var2.clone();
      return var3;
   }

   public ItemStack getItemStackDirect() {
      int var5 = 1730416031 ^ 2011951328 ^ 1781006046;
      var5 = 1570020177 ^ var5;
      ItemStack var2 = this.item;
      return var2;
   }

   public double getPrice() {
      int var5 = 1778805843 ^ 579294673 ^ 1781006046;
      var5 = 455919483 ^ var5;
      double var2 = this.price;
      return var2;
   }

   public long getListedAt() {
      int var5 = 1245166398 ^ 190870855 ^ 1781006046;
      var5 = 2048365788 ^ var5;
      long var2 = this.listedAt;
      return var2;
   }

   public long getExpiresAt() {
      int var5 = 2090203607 ^ 996673142 ^ 1781006046;
      var5 = 910765403 ^ var5;
      long var2 = this.expiresAt;
      return var2;
   }

   public String getTimeLeft() {
   }

   public boolean isExpired() {
   }

   static {
      int var4 = 1856399787 ^ 438700377 ^ Integer.parseInt("1721963204");
      fgdaldndxx = ByteBuffer.wrap(cqrrtuuidctklko()).asCharBuffer().toString();
      var4 = 1900590936 ^ var4;
      String var0 = bbkxsvlrom(ufletoxqprekoub(), var4);
      String var1 = oOo0KKoOoOK.translateHex(var0);
      TIME_COLOR = var1;
   }

   public static String bbkxsvlrom(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = fgdaldndxx;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] ufletoxqprekoub() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, 0};
   }

   private static byte[] kuteuzstiupaxdj() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, 7};
   }

   private static byte[] cqrrtuuidctklko() {
      return new byte[]{49, 21, 54, 9, 48, 118, 55, 116, 55, 124, 49, 15, 54, 0, 53, -106, 54, 86, 51, 125, 55, 76, 50, 69, 49, 95, 53, 65, 56, 82, 52, 86};
   }
}
