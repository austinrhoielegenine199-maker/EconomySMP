package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import java.util.function.ToLongFunction;
import java.util.stream.Stream;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.mz.donutsmpcore.DonutSMPCore;
import org.mz.donutsmpcore.libs.signgui.SignGUI;
import org.mz.donutsmpcore.libs.signgui.SignGUIBuilder;
import org.mz.donutsmpcore.libs.signgui.SignGUIFinishHandler;
import skido.KKoOoOo0oOK;
import skido.KoOKKo0K;
import skido.KoOo0oOo0oOK;
import skido.o0KoOKKo0K;
import skido.o0o0oOKo0K;
import skido.o0o0oOKoOK;
import skido.o0o0oOoOoOK;
import skido.o0oOo0Ko0K;
import skido.oOo0KKoOoOK;
import skido.oOo0o0oOK;

public class AuctionListingEditorGUI extends KoOKKo0K {
   private static final List<String> DEFAULT_SORTS;
   private final AuctionGUI returnGui;
   private final String sort;
   private final String search;
   private int page;
   private static String fzzseuavve;

   private static o0o0oOKo0K cfg() {
      int var4 = 817507746 ^ 379415366 ^ 1920577792;
      var4 = 403465784 ^ var4;
      String var0 = sgizisyzdz(kdeqwhxbkqzdqcb(), var4);
      o0o0oOKo0K var1 = o0o0oOKo0K.of(var0);
      return var1;
   }

   private static List<String> sortKeys() {
      int var10 = 1507150871 ^ 764118110 ^ 1920577792;
      var10 = 709656068 ^ var10;
      o0o0oOKo0K var0 = cfg();
      String var1 = sgizisyzdz(nobaflgefvnrvjo(), var10);
      List var2 = DEFAULT_SORTS;
      List var4 = var0.rawListAt(var1, var2);
      var10 = 1000886023 ^ var10;
      byte var6 = var4.isEmpty();
      List var7;
      if (var6 != (398673994 ^ var10)) {
         var10 = 2114886652 ^ var10;
         var7 = DEFAULT_SORTS;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var10)) {
               case 218014717:
                  var10 = 144025378 ^ var10;
                  return var7;
               case 395518208:
                  return var7;
               case 670483442:
               default:
                  throw new IOException();
               case 839483972:
            }
         }
      } else {
         label34:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var10)) {
               case 235555788:
                  var10 ^= 1553976150;
               case 319054976:
                  break label34;
               case 358306696:
               default:
                  throw new IOException();
               case 2052964969:
            }
         }

         var7 = var4;
         var10 = 704968584 ^ var10;
         return var7;
      }
   }

   public AuctionListingEditorGUI(Player var1, AuctionGUI var2) {
      List var6 = sortKeys();
      byte var7 = 0;
      Object var8 = var6.get(var7);
      String var9 = (String)var8;
      this(var1, var2, var9);
   }

   public AuctionListingEditorGUI(Player var1, AuctionGUI var2, String var3) {
      byte var8 = 0;
      this(var1, var2, var3, var8);
   }

   public AuctionListingEditorGUI(Player var1, AuctionGUI var2, String var3, int var4) {
      String var10 = "";
      this(var1, var2, var3, var4, var10);
   }

   public AuctionListingEditorGUI(Player var1, AuctionGUI var2, String var3, int var4, String var5) {
      String var8 = "new-auctiongui";
      o0o0oOKo0K var26 = o0o0oOKo0K.of(var8);
      String var9 = "your-items-size";
      byte var10 = 54;
      int var27 = var26.intAt(var9, var10);
      String var30 = "new-auctiongui";
      o0o0oOKo0K var31 = o0o0oOKo0K.of(var30);
      String var33 = "your-items-title";
      String var11 = "Your Items";
      String var32 = var31.str(var33, var11);
      super(var1, var27, var32);
      this.returnGui = var2;
      String var25;
      if (var3 == null) {
         List var18 = sortKeys();
         byte var28 = 0;
         Object var19 = var18.get(var28);
         var25 = (String)var19;
      } else {
         var25 = var3;
      }

      this.sort = var25;
      byte var20 = 0;
      int var21 = Math.max(var20, var4);
      this.page = var21;
      String var24;
      if (var5 == null) {
         var24 = "";
      } else {
         var24 = var5.trim();
      }

      this.search = var24;
   }

   public void decorate() {
      byte var14;
      List var29;
      ArrayList var30;
      int var375;
      int var369 = 418642369 ^ 696467273 ^ 345759920;
      int var370 = 1657062799 ^ var369;
      Inventory var25 = this.inventory;
      var25.clear();
      int var371 = 596879612 ^ var370;
      Map var27 = this.buttons;
      var27.clear();
      int var372 = 1222489347 ^ var371;
      Ko0KoOKoOK var28 = Ko0KoOKoOK.getInstance();
      Player var160 = this.player;
      UUID var161 = var160.getUniqueId();
      var29 = var28.getExpiredItems(var161);
      int var373 = 1062860175 ^ var372;
      Ko0KoOKoOK var3 = Ko0KoOKoOK.getInstance();
      List var230 = var3.getActiveItems();
      Stream var231 = var230.stream();
      Predicate var273 = (var1) -> {
         int var10 = 60211825 ^ 2045706009 ^ 345759920;
         var10 = 1224752365 ^ var10;
         UUID var4 = var1.getSeller();
         Player var6 = this.player;
         UUID var7 = var6.getUniqueId();
         boolean var5 = var4.equals(var7);
         return var5;
      };
      int var374 = 1889497795 ^ var373;
      Stream var232 = var231.filter(var273);
      List var233 = var232.toList();
      var30 = new ArrayList(var233);
      var375 = 1780894263 ^ var374;
      String var32 = this.sort;
      byte var33 = (byte)(-159462196 ^ var375);
      var14 = var33;
      int var35 = var32.hashCode();
      label354:
      switch (var35) {
         case -1596402763:
            label332:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                  case 40524467:
                     var375 ^= 1263553980;
                     break label332;
                  case 324548922:
                  default:
                     throw new RuntimeException();
                  case 738530340:
                     break;
                  case 886174472:
                     break label332;
               }
            }

            String var229 = sgizisyzdz(mcjrzofyauqledg(), var375);
            byte var157 = var32.equals(var229);
            if (var157 != (1121025679 ^ var375)) {
               var375 = 1309550608 ^ var375;
               byte var158 = (byte)(215963293 ^ var375);
               var14 = var158;
               var375 = 1836633922 ^ var375;
            } else {
               var375 ^= 594995026;
            }
            break;
         case -1086182771:
            label352:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                  case 2368744:
                     break label352;
                  case 40524467:
                     var375 ^= 682776435;
                     break label352;
                  case 136898013:
                  default:
                     throw new RuntimeException();
                  case 2132816040:
               }
            }

            String var228 = sgizisyzdz(qesojbiigycwonv(), var375);
            byte var154 = var32.equals(var228);
            if (var154 != (557016128 ^ var375)) {
               var375 = 1829794369 ^ var375;
               byte var155 = (byte)(1277367808 ^ var375);
               var14 = var155;
               var375 = ejxnibgvvcgmqgxt(var375, 763662300);
               break;
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                     case 5485327:
                        var375 ^= 1083506077;
                        break label354;
                     case 1014370187:
                        break;
                     case 1421663051:
                     default:
                        throw new RuntimeException();
                     case 1921846164:
                        break label354;
                  }
               }
            }
         case -1027878565:
            label322:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                  case 40524467:
                     var375 ^= 933100221;
                     break label322;
                  case 481544329:
                     break;
                  case 1684168411:
                  default:
                     throw new RuntimeException();
                  case 2144895590:
                     break label322;
               }
            }

            String var162 = sgizisyzdz(czqwnhofyyfaxkf(), var375);
            byte var37 = var32.equals(var162);
            if (var37 != (1042073998 ^ var375)) {
               var375 = 1247656504 ^ var375;
               byte var38 = (byte)(1950446518 ^ var375);
               var14 = var38;
               var375 = 367454827 ^ var375;
            } else {
               var375 = ejxnibgvvcgmqgxt(var375, 1606111315);
            }
            break;
         default:
            var375 = ejxnibgvvcgmqgxt(var375, 1747364590);
      }

      label312:
      switch (var14) {
         case 0:
            label310:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                  case 221567931:
                     var375 ^= 88592743;
                  case 1248867977:
                     break label310;
                  case 1303410656:
                     break;
                  case 1818103230:
                  default:
                     throw new RuntimeException();
               }
            }

            ToDoubleFunction var224 = AuctionItem::getPrice;
            Comparator var225 = Comparator.comparingDouble(var224);
            var30.sort(var225);
            var375 = ejxnibgvvcgmqgxt(var375, 1501265760);
            break;
         case 1:
            label300:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                  case 221567931:
                     var375 ^= 1484722234;
                  case 305197620:
                     break label300;
                  case 766605327:
                  default:
                     throw new RuntimeException();
                  case 868189354:
               }
            }

            ToDoubleFunction var226 = (var0) -> {
               int var7 = 67314634 ^ 760818955 ^ 1920577792;
               var7 = 1034460199 ^ var7;
               double var2 = var0.getPrice();
               double var4 = -var2;
               return var4;
            };
            Comparator var227 = Comparator.comparingDouble(var226);
            var30.sort(var227);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                  case 1290999:
                     var375 ^= 71548477;
                     break label312;
                  case 336811076:
                  default:
                     throw new RuntimeException();
                  case 885855583:
                     break;
                  case 926458631:
                     break label312;
               }
            }
         case 2:
            var375 = ejxnibgvvcgmqgxt(var375, 766735166);
            ToLongFunction var163 = (var0) -> {
               int var5 = 160006734 ^ 1994773555 ^ 1920577792;
               var5 = 2036834586 ^ var5;
               long var2 = var0.getListedAt();
               return var2;
            };
            Comparator var164 = Comparator.comparingLong(var163);
            var30.sort(var164);
            var375 = 1905253689 ^ var375;
            break;
         default:
            var375 = ejxnibgvvcgmqgxt(var375, 1547480583);
      }

      ArrayList var41 = new ArrayList();
      ArrayList var354 = var41;
      var375 = 1021049036 ^ var375;
      ArrayList var42 = new ArrayList();
      ArrayList var355 = var42;
      var375 = 1323441813 ^ var375;
      String var44 = this.search;
      Locale var165 = Locale.ROOT;
      String var45 = var44.toLowerCase(var165);
      String var15 = var45;
      var375 = 1902679446 ^ var375;
      Iterator var47 = var29.iterator();
      Iterator var16 = var47;
      var375 = 214313580 ^ var375;

      o0o0oOKo0K var95;
      ArrayList var97;
      label280:
      while(true) {
         byte var49 = var16.hasNext();
         if (var49 == (839675513 ^ var375)) {
            label247:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                  case 16262150:
                     var375 ^= 1160581602;
                  case 446051399:
                     break label247;
                  case 537873645:
                  default:
                     throw new RuntimeException();
                  case 819993540:
               }
            }

            Iterator var67 = var30.iterator();
            Iterator var356 = var67;
            var375 = 1690933218 ^ var375;

            label237:
            while(true) {
               byte var69 = var356.hasNext();
               if (var69 == (334030969 ^ var375)) {
                  var375 = 980630130 ^ var375;
                  Ko0KoOKoOK var70 = Ko0KoOKoOK.getInstance();
                  Player var173 = this.player;
                  int var71 = var70.getPlayerListingLimit(var173);
                  var375 = 1049550274 ^ var375;
                  Inventory var73 = this.inventory;
                  int var74 = var73.getSize();
                  o0o0oOKo0K var174 = cfg();
                  String var237 = sgizisyzdz(cwojqzidabkidsq(), var375);
                  byte var277 = (byte)(387256292 ^ var375);
                  int var175 = var174.intAt(var237, var277);
                  int var75 = oOo0o0oOK.cells(var74, var175);
                  int var358 = var75;
                  var375 = 1198249540 ^ var375;
                  int var176 = 796993138 ^ var375;
                  byte var77;
                  if (var71 == var176) {
                     var375 = 747579316 ^ var375;
                     var77 = (byte)(2096234040 ^ var375);

                     label187:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                           case 34906239:
                              var375 ^= 1573917641;
                              break label187;
                           case 302520293:
                           default:
                              throw new RuntimeException();
                           case 358481606:
                              break;
                           case 874803748:
                              break label187;
                        }
                     }
                  } else {
                     var375 = ejxnibgvvcgmqgxt(var375, 1548511483);
                     var77 = (byte)(204648822 ^ var375);
                     var375 = 756243590 ^ var375;
                  }

                  var375 = 1729439547 ^ var375;
                  byte var79 = var15.isEmpty();
                  int var81;
                  if (var79 == (1177864907 ^ var375)) {
                     var375 = 840784551 ^ var375;
                     var81 = var355.size();
                     var375 = 1196484075 ^ var375;
                  } else {
                     label175:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                           case 134614749:
                              var375 ^= 963438490;
                              break label175;
                           case 1036307365:
                              break;
                           case 1712151426:
                              break label175;
                           case 2120987844:
                           default:
                              throw new RuntimeException();
                        }
                     }

                     if (var77 != (2136485201 ^ var375)) {
                        var375 = 1830204187 ^ var375;
                        var81 = 1840341429 ^ var375;
                        var375 = ejxnibgvvcgmqgxt(var375, 557312973);
                     } else {
                        var375 = 304541163 ^ var375;
                        byte var129 = (byte)(1837023418 ^ var375);
                        var81 = Math.max(var129, var71);
                        var375 = 1577563453 ^ var375;
                     }
                  }

                  int var19 = var81;
                  var375 = 965402355 ^ var375;
                  byte var83 = var15.isEmpty();
                  int var159;
                  if (var83 == (183741300 ^ var375)) {
                     var375 = 1209940308 ^ var375;
                     byte var127 = (byte)(1122865697 ^ var375);
                     int var216 = var355.size();
                     var159 = Math.max(var127, var216);
                     var375 = ejxnibgvvcgmqgxt(var375, 944168793);
                  } else {
                     var375 = 1994029144 ^ var375;
                     if (var77 != (2083115820 ^ var375)) {
                        var375 = 1556470146 ^ var375;
                        int var86 = var355.size();
                        byte var177 = (byte)(552340143 ^ var375);
                        var159 = var86 + var177;
                        var375 = ejxnibgvvcgmqgxt(var375, 1514620887);
                     } else {
                        var375 = ejxnibgvvcgmqgxt(var375, 875007018);
                        int var126 = var355.size();
                        var159 = Math.max(var126, var81);
                        var375 = 849678975 ^ var375;
                     }
                  }

                  var375 = 480549862 ^ var375;
                  int var88 = oOo0o0oOK.pages(var159, var75);
                  var375 = 542976224 ^ var375;
                  int var180 = this.page;
                  int var181 = oOo0o0oOK.clamp(var180, var88);
                  this.page = var181;
                  var375 = 1277440795 ^ var375;
                  byte var90 = (byte)(175557988 ^ var375);
                  int var22 = var90;

                  for(var375 = 1548761646 ^ var375; var22 < var358; var375 = 800601245 ^ var375) {
                     var375 = 1664853075 ^ var375;
                     int var110 = this.page;
                     int var111 = var110 * var358;
                     int var112 = var111 + var22;
                     var375 = 2100163685 ^ var375;
                     int var206 = var355.size();
                     if (var112 < var206) {
                        var375 = 1777149093 ^ var375;
                        Object var122 = var354.get(var112);
                        Runnable var123 = (Runnable)var122;
                        var375 = 951593094 ^ var375;
                        o0KoOKKo0K var267 = new o0KoOKKo0K();
                        Object var312 = var355.get(var112);
                        ItemStack var313 = (ItemStack)var312;
                        o0KoOKKo0K var268 = var267.item(var313);
                        Consumer var315 = (var2) -> {
                           int var7 = 1877266073 ^ 8516667 ^ 345759920;
                           var7 = 394411701 ^ var7;
                           var123.run();
                           this.refresh();
                        };
                        o0KoOKKo0K var269 = var268.consumer(var315);
                        this.addButton(var22, var269);
                        var375 = 1275107149 ^ var375;

                        label135:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                              case 50742926:
                                 break label135;
                              case 79585569:
                              default:
                                 throw new RuntimeException();
                              case 91517191:
                                 var375 ^= 754712517;
                                 break label135;
                              case 1649374065:
                           }
                        }
                     } else {
                        label161:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                              case 112587219:
                                 break label161;
                              case 199101616:
                                 var375 ^= 1928522551;
                                 break label161;
                              case 638240442:
                                 break;
                              case 1146364783:
                              default:
                                 throw new RuntimeException();
                           }
                        }

                        if (var112 >= var19) {
                           var375 = 1652229639 ^ var375;
                           String var118 = sgizisyzdz(jtjhdijuqmycyaa(), var375);
                           Material var210 = Material.RED_STAINED_GLASS_PANE;
                           String var263 = sgizisyzdz(psravzppyytxwkt(), var375);
                           String var306 = sgizisyzdz(derdywpjvrddsoo(), var375);
                           var375 = 664880340 ^ var375;
                           List var307 = List.of(var306);
                           var375 = 593973365 ^ var375;
                           ItemStack var119 = pane(var118, var210, var263, var307);
                           var375 = 272529978 ^ var375;
                           o0KoOKKo0K var264 = new o0KoOKKo0K();
                           o0KoOKKo0K var265 = var264.item(var119);
                           Consumer var310 = (var1) -> {
                              int var16 = 379949760 ^ 1569815122 ^ 345759920;
                              var16 = 239001101 ^ var16;
                              Player var7 = this.player;
                              Player var8 = this.player;
                              Location var9 = var8.getLocation();
                              var16 = 992158537 ^ var16;
                              o0o0oOKo0K var4 = cfg();
                              String var5 = sgizisyzdz(yhcifheiueiiayt(), var16);
                              String var6 = sgizisyzdz(kgppakgpotrihoe(), var16);
                              String var10 = var4.rawStr(var5, var6);
                              var16 = 833966383 ^ var16;
                              Sound var11 = o0o0oOKoOK.valueOf(var10);
                              float var12 = 1.0F;
                              float var13 = 1.0F;
                              var16 = 1917875839 ^ var16;
                              var7.playSound(var9, var11, var12, var13);
                           };
                           o0KoOKKo0K var266 = var265.consumer(var310);
                           this.addButton(var22, var266);
                           var375 = 903866112 ^ var375;
                        } else {
                           var375 = 168594323 ^ var375;
                           String var115 = sgizisyzdz(rrbqgijgkthlqxe(), var375);
                           Material var208 = Material.GRAY_STAINED_GLASS_PANE;
                           String var259 = sgizisyzdz(tjduburdfmnyjzm(), var375);
                           String var301 = sgizisyzdz(vzyiymlrrvpgabg(), var375);
                           var375 = 1641290092 ^ var375;
                           List var302 = List.of(var301);
                           var375 = 1591973961 ^ var375;
                           ItemStack var116 = pane(var115, var208, var259, var302);
                           var375 = 1472997156 ^ var375;
                           o0KoOKKo0K var260 = new o0KoOKKo0K();
                           o0KoOKKo0K var261 = var260.item(var116);
                           Consumer var305 = (var1) -> {
                              int var12 = 1195202107 ^ 2050639080 ^ 345759920;
                              var12 = 1128313534 ^ var12;
                              Player var8 = this.player;
                              AuctionGUI var9 = this.returnGui;
                              oOKo0oOKoOK var2 = new oOKo0oOKoOK(var8, var9);
                              Runnable var7 = () -> {
                                 int var14 = 1049335764 ^ 471430001 ^ 345759920;
                                 var14 = 187106842 ^ var14;
                                 Player var7 = this.player;
                                 AuctionGUI var8 = this.returnGui;
                                 String var9 = this.sort;
                                 int var10 = this.page;
                                 String var11 = this.search;
                                 AuctionListingEditorGUI var1 = new AuctionListingEditorGUI(var7, var8, var9, var10, var11);
                                 var1.open();
                              };
                              var12 = 1831397770 ^ var12;
                              oOKo0oOKoOK var5 = var2.backTo(var7);
                              var12 = 548430195 ^ var12;
                              var5.open();
                              var12 = 1871404647 ^ var12;
                           };
                           o0KoOKKo0K var262 = var261.consumer(var305);
                           this.addButton(var22, var262);
                           var375 = 699312069 ^ var375;

                           label150:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                                 case 203275853:
                                    var375 ^= 134546891;
                                    break label150;
                                 case 916086396:
                                 default:
                                    throw new RuntimeException();
                                 case 1748113579:
                                    break;
                                 case 1909006247:
                                    break label150;
                              }
                           }
                        }
                     }

                     var22 += 2040447958 ^ var375;
                  }

                  var375 = ejxnibgvvcgmqgxt(var375, 1514130230);
                  Player var184 = this.player;
                  o0o0oOKo0K var239 = cfg();
                  int var279 = this.page;
                  IntConsumer var326 = (var1) -> {
                     int var14 = 1795856750 ^ 750283558 ^ 345759920;
                     var14 = 269876133 ^ var14;
                     Player var8 = this.player;
                     AuctionGUI var9 = this.returnGui;
                     String var10 = this.sort;
                     String var11 = this.search;
                     AuctionListingEditorGUI var2 = new AuctionListingEditorGUI(var8, var9, var10, var1, var11);
                     var2.open();
                  };
                  oOo0o0oOK.arrows(this, var184, var239, var279, var88, var326);
                  var375 = 1695690395 ^ var375;
                  o0o0oOKo0K var185 = cfg();
                  String var240 = sgizisyzdz(qiehxwyfgnenrsr(), var375);
                  byte var280 = (byte)(1762333384 ^ var375);
                  int var186 = var185.slot(var240, var280);
                  o0KoOKKo0K var242 = this.filterButton();
                  this.addButton(var186, var242);
                  var375 = 1869353925 ^ var375;
                  String var94 = sgizisyzdz(gtjabzirdgnngyh(), var375);
                  var95 = o0o0oOKo0K.of(var94);
                  var375 = 22173581 ^ var375;
                  String var243 = sgizisyzdz(nvrwqfwszbhayiy(), var375);
                  byte var281 = (byte)(120936094 ^ var375);
                  int var188 = var95.slot(var243, var281);
                  o0KoOKKo0K var244 = new o0KoOKKo0K();
                  String var320 = sgizisyzdz(gpdejtgqfwsuxok(), var375);
                  Material var327 = Material.ANVIL;
                  var375 = 1901209741 ^ var375;
                  o0o0oOKo0K var7 = cfg();
                  String var8 = sgizisyzdz(pvgknewpuxjeaza(), var375);
                  String var9 = sgizisyzdz(ozqyzyrbpboylsq(), var375);
                  String var330 = var7.rawStr(var8, var9);
                  String var331 = oOo0KKoOoOK.color(var330);
                  var375 = 262832503 ^ var375;
                  o0o0oOKo0K var338 = cfg();
                  String var349 = sgizisyzdz(jlrlrlvlvjvabnq(), var375);
                  String var10 = sgizisyzdz(iagvdiqexjimkor(), var375);
                  String var339 = var338.rawStr(var349, var10);
                  String var340 = oOo0KKoOoOK.color(var339);
                  List var341 = List.of(var340);
                  var375 = 1111455096 ^ var375;
                  ItemStack var283 = var95.button(var320, var327, var331, var341);
                  var375 = 221219217 ^ var375;
                  o0KoOKKo0K var245 = var244.item(var283);
                  Consumer var285 = (var1) -> {
                     int var11 = 1375553065 ^ 2111612188 ^ 345759920;
                     var11 = 1376920933 ^ var11;
                     AuctionGUI var4 = this.returnGui;
                     if (var4 == null) {
                        var11 = 1752772280 ^ var11;
                        Player var8 = this.player;
                        AuctionGUI var5 = new AuctionGUI(var8);
                        var5.open();
                        var11 = 501176868 ^ var11;
                     } else {
                        var11 = 447457515 ^ var11;
                        AuctionGUI var7 = this.returnGui;
                        var7.open();

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var11)) {
                              case 151425846:
                                 var11 = 1863179383 ^ var11;
                                 return;
                              case 829154287:
                              default:
                                 throw new RuntimeException();
                              case 1853282685:
                                 break;
                              case 1983947188:
                                 return;
                           }
                        }
                     }
                  };
                  var375 = 225823134 ^ var375;
                  o0KoOKKo0K var246 = var245.consumer(var285);
                  var375 = 1403652922 ^ var375;
                  this.addButton(var188, var246);
                  var375 = 435182742 ^ var375;
                  var97 = new ArrayList();
                  var375 = 682721641 ^ var375;
                  o0o0oOKo0K var189 = cfg();
                  String var247 = sgizisyzdz(vuzuxipwxvhuobg(), var375);
                  String var286 = sgizisyzdz(msupsfbjdvnrqyk(), var375);
                  String var190 = var189.rawStr(var247, var286);
                  String var191 = oOo0KKoOoOK.color(var190);
                  var97.add(var191);
                  var375 = 1305265848 ^ var375;
                  String var101 = this.search;
                  byte var102 = var101.isEmpty();
                  if (var102 == (344971871 ^ var375)) {
                     var375 = 2103732823 ^ var375;
                     o0o0oOKo0K var192 = cfg();
                     String var248 = sgizisyzdz(fupvegldwkjprwz(), var375);
                     String var287 = sgizisyzdz(bwubdirprbvupmp(), var375);
                     String var193 = var192.rawStr(var248, var287);
                     String var249 = sgizisyzdz(woesnlbkhwbddix(), var375);
                     String var289 = this.search;
                     String var194 = var193.replace(var249, var289);
                     String var195 = oOo0KKoOoOK.color(var194);
                     var97.add(var195);
                     var375 = 169538439 ^ var375;
                     o0o0oOKo0K var196 = cfg();
                     String var250 = sgizisyzdz(wklyvpttgqwzbjs(), var375);
                     String var290 = sgizisyzdz(zlplrypekbgamlu(), var375);
                     String var197 = var196.rawStr(var250, var290);
                     String var198 = oOo0KKoOoOK.color(var197);
                     var97.add(var198);
                     var375 = 615827280 ^ var375;
                     break label280;
                  }

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                        case 131507095:
                           var375 ^= 1405771392;
                        case 285288903:
                           break label280;
                        case 1931769837:
                        default:
                           throw new RuntimeException();
                        case 2138401285:
                     }
                  }
               }

               var375 = 1007972488 ^ var375;
               Object var131 = var356.next();
               AuctionItem var132 = (AuctionItem)var131;
               var375 = 1295539856 ^ var375;
               byte var134 = var15.isEmpty();
               if (var134 == (1657063009 ^ var375)) {
                  var375 = 496131061 ^ var375;
                  ItemStack var136 = var132.getItemStack();
                  byte var137 = matches(var136, var15);
                  if (var137 == (2136382868 ^ var375)) {
                     var375 = 851040327 ^ var375;

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                           case 3763518:
                              break;
                           case 117430951:
                              var375 ^= 1577561514;
                           case 289740076:
                              continue label237;
                           case 675572116:
                           default:
                              throw new RuntimeException();
                        }
                     }
                  }

                  label215:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                        case 112700952:
                           var375 ^= 1421658977;
                           break label215;
                        case 213096253:
                           break;
                        case 611171599:
                        default:
                           throw new RuntimeException();
                        case 1410811113:
                           break label215;
                     }
                  }
               } else {
                  var375 = ejxnibgvvcgmqgxt(var375, 1227788436);
               }

               ItemStack var139 = var132.getItemStack();
               ItemStack var140 = var139.clone();
               var375 = 1558509858 ^ var375;
               double var142 = var132.getPrice();
               String var144 = oOo0KKoOoOK.formatPrice(var142);
               String var145 = stripDollar(var144);
               var375 = 1568532847 ^ var375;
               o0o0oOKo0K var219 = cfg();
               String var270 = sgizisyzdz(dsooxlgwwiewudm(), var375);
               String var316 = sgizisyzdz(pqulchcblahhrur(), var375);
               String var325 = sgizisyzdz(lurbsjpksvdqevj(), var375);
               var375 = 1799899701 ^ var375;
               List var317 = List.of(var316, var325);
               var375 = 922244162 ^ var375;
               List var220 = var219.rawListAt(var270, var317);
               String var271 = sgizisyzdz(naxjzianrvixzah(), var375);
               tagLore(var140, var220, var271, var145);
               var375 = 1087558894 ^ var375;
               var355.add(var140);
               var375 = 488512349 ^ var375;
               Runnable var223 = () -> {
                  int var6 = 919951906 ^ 108493597 ^ 345759920;
                  var6 = 1246408645 ^ var6;
                  this.cancelActive(var132);
               };
               boolean var150 = var354.add(var223);
               var375 = 1815108985 ^ var375;

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                     case 136040790:
                        var375 ^= 1440162428;
                        continue label237;
                     case 463748453:
                     default:
                        throw new RuntimeException();
                     case 1798822216:
                        continue label237;
                     case 2042114959:
                  }
               }
            }
         }

         var375 = 353111541 ^ var375;
         Object var51 = var16.next();
         AuctionListingRecord var52 = (AuctionListingRecord)var51;
         var375 = 1469135115 ^ var375;
         byte var54 = var15.isEmpty();
         if (var54 == (1888574087 ^ var375)) {
            var375 = 298786944 ^ var375;
            ItemStack var56 = var52.getItemStack();
            byte var57 = matches(var56, var15);
            if (var57 == (1633581575 ^ var375)) {
               var375 = 1984711399 ^ var375;
               var375 = 622747289 ^ var375;
               continue;
            }

            label273:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
                  case 29321351:
                     break;
                  case 212299059:
                     var375 ^= 126627922;
                     break label273;
                  case 334167393:
                  default:
                     throw new RuntimeException();
                  case 1246144631:
                     break label273;
               }
            }
         } else {
            var375 = ejxnibgvvcgmqgxt(var375, 373493970);
         }

         ItemStack var59 = var52.getItemStack();
         ItemStack var60 = var59.clone();
         var375 = 31263561 ^ var375;
         o0o0oOKo0K var167 = cfg();
         String var234 = sgizisyzdz(ssxyluwxetadlvz(), var375);
         String var274 = sgizisyzdz(jmdihsabhbhelcq(), var375);
         String var5 = sgizisyzdz(cbsyegajjwchdih(), var375);
         var375 = 25496751 ^ var375;
         List var275 = List.of(var274, var5);
         var375 = 240352988 ^ var375;
         List var168 = var167.rawListAt(var234, var275);
         Object var235 = null;
         Object var276 = null;
         tagLore(var60, var168, (String)var235, (String)var276);
         var375 = 937268631 ^ var375;
         var355.add(var60);
         var375 = 1137701620 ^ var375;
         Runnable var171 = () -> {
            int var6 = 492014280 ^ 171080148 ^ 345759920;
            var6 = 1216166001 ^ var6;
            this.collectExpired(var52);
         };
         boolean var65 = var354.add(var171);
         var375 = 1681512635 ^ var375;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var375)) {
               case 173377616:
                  var375 ^= 1258218190;
                  continue label280;
               case 924245195:
               default:
                  throw new RuntimeException();
               case 1380342797:
                  continue label280;
               case 2058087930:
            }
         }
      }

      String var251 = sgizisyzdz(gcnilxppybsoquc(), var375);
      byte var291 = (byte)(1195738349 ^ var375);
      int var200 = var95.slot(var251, var291);
      o0KoOKKo0K var252 = new o0KoOKKo0K();
      String var321 = sgizisyzdz(bwhxrptzpvwlgjw(), var375);
      Material var328 = Material.OAK_SIGN;
      var375 = 1608332405 ^ var375;
      o0o0oOKo0K var332 = cfg();
      String var342 = sgizisyzdz(uwnlmmtzviabbed(), var375);
      String var350 = sgizisyzdz(wweefwzsloqjabq(), var375);
      String var333 = var332.rawStr(var342, var350);
      String var334 = oOo0KKoOoOK.color(var333);
      ItemStack var293 = var95.button(var321, var328, var334, var97);
      var375 = 1455380030 ^ var375;
      o0KoOKKo0K var253 = var252.item(var293);
      Consumer var295 = (var1) -> {
         int var12 = 1091700972 ^ 222072206 ^ 345759920;
         var12 = 2111485585 ^ var12;
         byte var4 = var1.isRightClick();
         if (var4 != (628085571 ^ var12)) {
            var12 = 1282559973 ^ var12;
            String var6 = this.search;
            byte var7 = var6.isEmpty();
            if (var7 == (1763548326 ^ var12)) {
               var12 = 327916086 ^ var12;
               String var3 = sgizisyzdz(mbcdugspftjtdsb(), var12);
               this.reopen(var3);

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                     case 142321866:
                        break;
                     case 226678305:
                        var12 = 1045060067 ^ var12;
                        return;
                     case 935984659:
                     default:
                        throw new RuntimeException();
                     case 1327238093:
                        return;
                  }
               }
            }

            label36:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                  case 166328806:
                     break label36;
                  case 169538830:
                     break;
                  case 195638940:
                     var12 ^= 1113344751;
                     break label36;
                  case 908553556:
                  default:
                     throw new RuntimeException();
               }
            }
         } else {
            var12 = 237896970 ^ var12;
         }

         this.openSearch();
         var12 = 1872595258 ^ var12;
      };
      var375 = 407214857 ^ var375;
      o0KoOKKo0K var254 = var253.consumer(var295);
      var375 = 1473191215 ^ var375;
      this.addButton(var200, var254);
      var375 = 2104213563 ^ var375;
      String var255 = sgizisyzdz(qxobxhdpqmttuuk(), var375);
      byte var296 = (byte)(2093392058 ^ var375);
      int var202 = var95.slot(var255, var296);
      o0KoOKKo0K var256 = new o0KoOKKo0K();
      String var322 = sgizisyzdz(wbfprpglfazasdz(), var375);
      Material var329 = Material.WRITABLE_BOOK;
      var375 = 724634028 ^ var375;
      o0o0oOKo0K var335 = cfg();
      String var344 = sgizisyzdz(usysblcetyqzjzr(), var375);
      String var351 = sgizisyzdz(fiolltbumzeuxzw(), var375);
      String var336 = var335.rawStr(var344, var351);
      String var337 = oOo0KKoOoOK.color(var336);
      var375 = 364771344 ^ var375;
      o0o0oOKo0K var345 = cfg();
      String var352 = sgizisyzdz(dccbiqglzztuzci(), var375);
      String var353 = sgizisyzdz(veofyoyoufsltjq(), var375);
      String var346 = var345.rawStr(var352, var353);
      String var347 = oOo0KKoOoOK.color(var346);
      List var348 = List.of(var347);
      var375 = 1021416335 ^ var375;
      ItemStack var298 = var95.button(var322, var329, var337, var348);
      var375 = 73159589 ^ var375;
      o0KoOKKo0K var257 = var256.item(var298);
      Consumer var300 = (var1) -> {
         int var8 = 1021971366 ^ 573830642 ^ 345759920;
         var8 = 2080131193 ^ var8;
         Player var5 = this.player;
         AuctionTransactionsGUI var2 = new AuctionTransactionsGUI(var5);
         byte var4 = (byte)(1908299420 ^ var8);
         var2.open(var4);
      };
      var375 = 1330944056 ^ var375;
      o0KoOKKo0K var258 = var257.consumer(var300);
      var375 = 1069358626 ^ var375;
      this.addButton(var202, var258);
      var375 = 772232592 ^ var375;
   }

   private o0KoOKKo0K filterButton() {
      int var103 = 678327462 ^ 1977429107 ^ 345759920;
      var103 = 1211497186 ^ var103;
      o0o0oOKo0K var2 = cfg();
      String var3 = sgizisyzdz(msinojrrozoyhtu(), var103);
      Material var4 = Material.HOPPER;
      Material var76 = var2.material(var3, var4);
      ItemStack var1 = new ItemStack(var76);
      var103 = 1825170348 ^ var103;
      ItemMeta var16 = var1.getItemMeta();
      var103 = 273404090 ^ var103;
      o0o0oOKo0K var51 = cfg();
      String var77 = sgizisyzdz(fkrjwrtmgixoyib(), var103);
      String var88 = sgizisyzdz(reqqagmdvkndclc(), var103);
      String var52 = var51.rawStr(var77, var88);
      String var53 = oOo0KKoOoOK.color(var52);
      var16.setDisplayName(var53);
      var103 = 732129149 ^ var103;
      ArrayList var18 = new ArrayList();
      ArrayList var8 = var18;
      var103 = 1797626877 ^ var103;
      o0o0oOKo0K var54 = cfg();
      String var78 = sgizisyzdz(fzxvnduectlaxio(), var103);
      String var89 = sgizisyzdz(ltfwahftkjollzp(), var103);
      String var55 = var54.rawStr(var78, var89);
      String var56 = oOo0KKoOoOK.color(var55);
      var18.add(var56);
      var103 = 921519732 ^ var103;
      String var57 = sgizisyzdz(eebseafpyeoukwm(), var103);
      var18.add(var57);
      var103 = 1519060542 ^ var103;
      o0o0oOKo0K var23 = cfg();
      String var58 = sgizisyzdz(zglixqwevuzdegv(), var103);
      String var79 = sgizisyzdz(fflmzmbtsvcickt(), var103);
      String var24 = var23.rawStr(var58, var79);
      String var9 = var24;
      var103 = 1165879096 ^ var103;
      o0o0oOKo0K var25 = cfg();
      String var59 = sgizisyzdz(actxeuxhpymvaci(), var103);
      String var80 = sgizisyzdz(ncnixekfjwfogqg(), var103);
      String var26 = var25.rawStr(var59, var80);
      String var10 = var26;
      var103 = 1445987293 ^ var103;
      o0o0oOKo0K var27 = cfg();
      String var60 = sgizisyzdz(ahdqmcgvuupweeg(), var103);
      String var81 = sgizisyzdz(yyertqnxfbknkbo(), var103);
      String var28 = var27.rawStr(var60, var81);
      String var11 = var28;
      var103 = 508755857 ^ var103;
      List var29 = sortKeys();
      Iterator var30 = var29.iterator();
      Iterator var12 = var30;
      var103 = 1323562133 ^ var103;

      while(true) {
         byte var32 = var12.hasNext();
         if (var32 == (310583994 ^ var103)) {
            var103 = ejxnibgvvcgmqgxt(var103, 1854397042);
            var16.setLore(var8);
            var103 = 1460067386 ^ var103;
            var1.setItemMeta(var16);
            var103 = 1864519279 ^ var103;
            List var41 = sortKeys();
            var103 = 101177637 ^ var103;
            String var68 = this.sort;
            int var43 = var41.indexOf(var68);
            var103 = 552152084 ^ var103;
            byte var84 = (byte)(1657708461 ^ var103);
            int var70 = var43 + var84;
            int var86 = var41.size();
            int var71 = var70 % var86;
            Object var45 = var41.get(var71);
            String var46 = (String)var45;
            var103 = 791470728 ^ var103;
            o0KoOKKo0K var47 = new o0KoOKKo0K();
            o0KoOKKo0K var48 = var47.item(var1);
            String var73 = sgizisyzdz(flgkdhgzutathsv(), var103);
            o0KoOKKo0K var49 = var48.filterSound(var73);
            Consumer var75 = (var2x) -> {
               int var14 = 609227283 ^ 1521958178 ^ 345759920;
               var14 = 331663654 ^ var14;
               Player var9 = this.player;
               AuctionGUI var10 = this.returnGui;
               byte var7 = (byte)(2042103463 ^ var14);
               String var11 = this.search;
               AuctionListingEditorGUI var3 = new AuctionListingEditorGUI(var9, var10, var46, var7, var11);
               var3.open();
            };
            o0KoOKKo0K var50 = var49.consumer(var75);
            return var50;
         }

         var103 = 1011616227 ^ var103;
         Object var34 = var12.next();
         String var35 = (String)var34;
         var103 = 2001621601 ^ var103;
         String var82 = sgizisyzdz(yucwlveqbqzivqc(), var103);
         var103 = 2057622890 ^ var103;
         String var96 = this.sort;
         byte var91 = var35.equals(var96);
         String var94;
         if (var91 != (589671506 ^ var103)) {
            var103 = 465996590 ^ var103;
            var94 = var9;

            label25:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var103)) {
                  case 238560355:
                     var103 ^= 159873734;
                     break label25;
                  case 785126603:
                  default:
                     throw new RuntimeException();
                  case 1000972942:
                     break;
                  case 1174984303:
                     break label25;
               }
            }
         } else {
            var103 = ejxnibgvvcgmqgxt(var103, 1672542338);
            var94 = var10;
            var103 = 1911621994 ^ var103;
         }

         String var62 = var11.replace(var82, var94);
         String var83 = sgizisyzdz(ibjkezhfqygshlg(), var103);
         var103 = 1806932175 ^ var103;
         o0o0oOKo0K var92 = cfg();
         String var98 = "filter.labels." + var35;
         String var93 = var92.rawStr(var98, var35);
         String var63 = var62.replace(var83, var93);
         var103 = 1068715888 ^ var103;
         String var64 = oOo0KKoOoOK.color(var63);
         boolean var37 = var8.add(var64);
         var103 = 208952853 ^ var103;
         var103 = ejxnibgvvcgmqgxt(var103, 2073294506);
      }
   }

   private void collectExpired(AuctionListingRecord var1) {
      int var24 = 1872086161 ^ 1761170071 ^ 345759920;
      var24 = 1036500109 ^ var24;
      Ko0KoOKoOK var2 = Ko0KoOKoOK.getInstance();
      byte var7 = var2.collectExpiredItem(var1);
      if (var7 == (774949435 ^ var24)) {
         var24 = 1680221245 ^ var24;
      } else {
         var24 = ejxnibgvvcgmqgxt(var24, 1751812287);
         Player var9 = this.player;
         PlayerInventory var10 = var9.getInventory();
         byte var16 = (byte)(1180320389 ^ var24);
         ItemStack[] var17 = new ItemStack[var16];
         byte var4 = (byte)(1180320388 ^ var24);
         ItemStack var20 = var1.getItemStack();
         ItemStack var21 = KoOo0oOo0oOK.thaw(var20);
         var17[var4] = var21;
         HashMap var11 = var10.addItem(var17);
         var24 = 925396826 ^ var24;
         Player var13 = this.player;
         o0o0oOoOoOK.refresh(var13);
         var24 = 226194280 ^ var24;
         Collection var15 = var11.values();
         Consumer var19 = (var1x) -> {
            int var12 = 2035389623 ^ 1466757810 ^ 345759920;
            var12 = 636262070 ^ var12;
            Player var5 = this.player;
            World var6 = var5.getWorld();
            Player var8 = this.player;
            Location var9 = var8.getLocation();
            var6.dropItem(var9, var1x);
         };
         var15.forEach(var19);
         var24 = 1842068975 ^ var24;
      }
   }

   private void cancelActive(AuctionItem var1) {
      int var22 = 1554210719 ^ 1572564467 ^ 345759920;
      var22 = 1391502467 ^ var22;
      Ko0KoOKoOK var2 = Ko0KoOKoOK.getInstance();
      byte var7 = var2.removeItem(var1);
      if (var7 == (1198749279 ^ var22)) {
         var22 = 1277419880 ^ var22;
      } else {
         var22 = 810744721 ^ var22;
         Player var9 = this.player;
         PlayerInventory var10 = var9.getInventory();
         byte var14 = (byte)(1998687695 ^ var22);
         ItemStack[] var15 = new ItemStack[var14];
         byte var4 = (byte)(1998687694 ^ var22);
         ItemStack var18 = var1.getItemStack();
         ItemStack var19 = KoOo0oOo0oOK.thaw(var18);
         var15[var4] = var19;
         HashMap var11 = var10.addItem(var15);
         var22 = 1875847491 ^ var22;
         Collection var13 = var11.values();
         Consumer var17 = (var1x) -> {
            int var12 = 1645312435 ^ 809257749 ^ 345759920;
            var12 = 290143036 ^ var12;
            Player var5 = this.player;
            World var6 = var5.getWorld();
            Player var8 = this.player;
            Location var9 = var8.getLocation();
            var6.dropItem(var9, var1x);
         };
         var13.forEach(var17);
         var22 = 744088873 ^ var22;
      }
   }

   private void reopen(String var1) {
      int var13 = 1779472787 ^ 171659771 ^ 345759920;
      var13 = 2140666342 ^ var13;
      Player var8 = this.player;
      AuctionGUI var9 = this.returnGui;
      String var10 = this.sort;
      byte var6 = (byte)(187158846 ^ var13);
      AuctionListingEditorGUI var2 = new AuctionListingEditorGUI(var8, var9, var10, var6, var1);
      var2.open();
      var13 = 1089284497 ^ var13;
   }

   private void openSearch() {
      int var72 = 1903814500 ^ 219956566 ^ 345759920;
      var72 = 1257940459 ^ var72;
      Player var11 = this.player;
      String var2 = sgizisyzdz(fzofumlcecmmwtv(), var72);
      String var3 = sgizisyzdz(ylaqmgatkaoxnhu(), var72);
      String var58 = this.search;
      BiConsumer var63 = (var1, var2x) -> {
         int var7 = 258517092 ^ 885076071 ^ 345759920;
         var7 = 278332263 ^ var7;
         this.reopen(var2x);
      };
      Consumer var67 = (var1) -> {
         int var7 = 579614228 ^ 511447761 ^ 345759920;
         var7 = 1404531621 ^ var7;
         String var4 = this.search;
         this.reopen(var4);
      };
      byte var12 = o0oOo0Ko0K.open(var11, var2, var3, var58, var63, var67);
      if (var12 != (570746729 ^ var72)) {
         var72 = 639997733 ^ var72;
      } else {
         label90:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var72)) {
               case 32088671:
                  var72 ^= 654816886;
               case 1980978448:
                  Player var14 = this.player;
                  var14.closeInventory();
                  var72 = 73299266 ^ var72;
                  Player var16 = this.player;
                  KoOKKo0K.detach(var16);
                  var72 = 1930604643 ^ var72;

                  label97: {
                     ArrayList var9;
                     try {
                        o0o0oOKo0K var49 = cfg();
                        String var59 = sgizisyzdz(nfhnamqunirypfd(), var72);
                        String var64 = sgizisyzdz(gccfisgpexvzonj(), var72);
                        String var68 = sgizisyzdz(uauoecqpusyyumo(), var72);
                        String var7 = sgizisyzdz(dnthsmhaxgxgyhx(), var72);
                        String var8 = sgizisyzdz(hlhyqdxfjqwunbu(), var72);
                        List var65 = List.of(var64, var68, var7, var8);
                        List var50 = var49.rawListAt(var59, var65);
                        ArrayList var17 = new ArrayList(var50);
                        var9 = var17;
                        var72 ^= 1855620083;
                     } catch (Exception var74) {
                        boolean var10001 = false;
                        break label97;
                     }

                     label80:
                     while(true) {
                        try {
                           int var19 = var9.size();
                           byte var32 = (byte)(483727305 ^ var72);
                           if (var19 >= var32) {
                              break;
                           }

                           var72 ^= 1028059499;
                           String var33 = sgizisyzdz(xivxzbimqtbnhhw(), var72);
                           boolean var21 = var9.add(var33);
                        } catch (Exception var75) {
                           boolean var92 = false;
                           break label97;
                        }

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var72)) {
                              case 4515790:
                                 continue label80;
                              case 17739634:
                                 var72 ^= 1028059499;
                                 continue label80;
                              case 1272240472:
                              default:
                                 throw new IllegalAccessException();
                              case 1948868845:
                           }
                        }
                     }

                     label55:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var72)) {
                           case 131908296:
                              var72 ^= 1456222380;
                              break label55;
                           case 354897337:
                           default:
                              throw new IllegalAccessException();
                           case 881196397:
                              break;
                           case 1036171037:
                              break label55;
                        }
                     }

                     try {
                        byte var24 = (byte)(1243162465 ^ var72);
                        byte var36 = (byte)(1243162466 ^ var72);
                        o0o0oOKo0K var51 = cfg();
                        String var60 = sgizisyzdz(fmymfpiqiyhujnp(), var72);
                        byte var66 = (byte)(1243162465 ^ var72);
                        int var52 = var51.intAt(var60, var66);
                        int var37 = Math.min(var36, var52);
                        int var25 = Math.max(var24, var37);
                        var72 = 9202073 ^ var72;
                        SignGUIBuilder var26 = SignGUI.builder();
                        byte var53 = (byte)(1251299064 ^ var72);
                        byte var61 = (byte)(1251299068 ^ var72);
                        var72 = 78669414 ^ var72;
                        List var39 = var9.subList(var53, var61);
                        byte var54 = (byte)(1311058078 ^ var72);
                        String[] var55 = new String[var54];
                        Object[] var40 = var39.toArray(var55);
                        String[] var41 = (String[])var40;
                        SignGUIBuilder var27 = var26.setLines(var41);
                        var72 = 591476848 ^ var72;
                        o0o0oOKo0K var42 = cfg();
                        String var56 = sgizisyzdz(kxinrwrsdrdxwaa(), var72);
                        Material var62 = Material.OAK_SIGN;
                        Material var43 = var42.materialAt(var56, var62);
                        SignGUIBuilder var28 = var27.setType(var43);
                        SignGUIFinishHandler var45 = (var2x, var3x) -> {
                           int var19 = 684118878 ^ 168999213 ^ 345759920;
                           var19 = 1810787 ^ var19;
                           String var9 = var3x.getLineWithoutColor(var25);
                           String var10 = var9.trim();
                           var19 = 1965693963 ^ var19;
                           KKoOoOo0oOK var11 = KKoOoOo0oOK.getInstance();
                           Runnable var15 = () -> {
                              int var6 = 1077654304 ^ 2135022466 ^ 345759920;
                              var6 = 314350930 ^ var6;
                              this.reopen(var10);
                           };
                           long var16 = 1L;
                           var11.runAtEntityLater(var2x, var15, var16);
                           var19 = 2037994642 ^ var19;
                           List var13 = Collections.emptyList();
                           return var13;
                        };
                        var72 = 399449228 ^ var72;
                        SignGUIBuilder var29 = var28.setHandler(var45);
                        var72 = 1989715707 ^ var72;
                        DonutSMPCore var46 = DonutSMPCore.getInstance();
                        SignGUIBuilder var30 = var29.callHandlerSynchronously(var46);
                        var72 = 1719997747 ^ var72;
                        SignGUI var31 = var30.build();
                        Player var48 = this.player;
                        var72 = 1188702976 ^ var72;
                        var31.open(var48);
                        var72 = 940842272 ^ var72;
                        break label90;
                     } catch (Exception var73) {
                        boolean var93 = false;
                     }
                  }

                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var72)) {
                     case -1837325837 -> var72 = ejxnibgvvcgmqgxt(var72, 1599464547);
                     case -715627757 -> var72 = ejxnibgvvcgmqgxt(var72, 1471249471);
                     case -425148824 -> var72 = ejxnibgvvcgmqgxt(var72, 835676048);
                     case 211760433 -> var72 = ejxnibgvvcgmqgxt(var72, 210343675);
                     case 1355365130 -> var72 = ejxnibgvvcgmqgxt(var72, 1728272188);
                     case 1420457922 -> var72 = ejxnibgvvcgmqgxt(var72, 1737440933);
                     case 1437990227 -> var72 = 1202507767 ^ var72;
                     case 1637700808 -> var72 = 556391108 ^ var72;
                     case 1667540305 -> var72 = 24569079 ^ var72;
                     case 1797293939 -> var72 = 1082024115 ^ var72;
                     case 1898530034 -> var72 = ejxnibgvvcgmqgxt(var72, 1665095875);
                     default -> throw new IOException("Error in hash");
                  }

                  var72 = 381965957 ^ var72;
                  String var35 = this.search;
                  this.reopen(var35);
                  var72 = 853227651 ^ var72;
                  return;
               case 1284896472:
                  break;
               case 1501740601:
               default:
                  throw new IllegalAccessException();
            }
         }

         var72 = 494770129 ^ var72;
      }
   }

   private static boolean matches(ItemStack var0, String var1) {
      int var58 = 1886029181 ^ 497777958 ^ 1920577792;
      var58 = 1380830393 ^ var58;
      if (var0 == null) {
         var58 = 856231133 ^ var58;
         byte var9 = (byte)(2130479423 ^ var58);
         return (boolean)var9;
      } else {
         var58 = 747734865 ^ var58;
         Material var11 = var0.getType();
         String var12 = var11.name();
         Locale var3 = Locale.ROOT;
         String var13 = var12.toLowerCase(var3);
         var58 = 1052245840 ^ var58;
         byte var15 = var13.contains(var1);
         if (var15 == (1607728611 ^ var58)) {
            var58 = 1892777705 ^ var58;
            byte var50 = (byte)(788693845 ^ var58);
            byte var4 = (byte)(788693802 ^ var58);
            String var17 = var13.replace((char)var50, (char)var4);
            byte var18 = var17.contains(var1);
            if (var18 == (788693770 ^ var58)) {
               label75:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var58)) {
                     case 185922273:
                        var58 ^= 1279606279;
                        break label75;
                     case 861991169:
                     default:
                        throw new IllegalAccessException();
                     case 1133722296:
                        break;
                     case 1738271718:
                        break label75;
                  }
               }

               ItemMeta var21 = var0.getItemMeta();
               var58 = 914387700 ^ var58;
               if (var21 == null) {
                  var58 = 1120374483 ^ var58;
                  byte var23 = (byte)(385892650 ^ var58);
                  return (boolean)var23;
               }

               var58 = 866624292 ^ var58;
               byte var25 = var21.hasDisplayName();
               if (var25 != (1717595357 ^ var58)) {
                  var58 = 1192555245 ^ var58;
                  String var27 = var21.getDisplayName();
                  String var28 = ChatColor.stripColor(var27);
                  Locale var52 = Locale.ROOT;
                  String var29 = var28.toLowerCase(var52);
                  byte var30 = var29.contains(var1);
                  if (var30 != (561290800 ^ var58)) {
                     var58 = 752673300 ^ var58;
                     byte var31 = (byte)(229145637 ^ var58);
                     return (boolean)var31;
                  }

                  var58 = 915464901 ^ var58;
               } else {
                  label63:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var58)) {
                        case 106607756:
                           var58 ^= 1904480296;
                        case 169968847:
                           break label63;
                        case 1717020415:
                        default:
                           throw new IllegalAccessException();
                        case 1937136791:
                     }
                  }
               }

               byte var33 = var21.hasLore();
               if (var33 != (400850165 ^ var58)) {
                  var58 = 1164739330 ^ var58;
                  List var35 = var21.getLore();
                  Iterator var36 = var35.iterator();
                  Iterator var7 = var36;
                  var58 = 1572165673 ^ var58;

                  while(true) {
                     byte var38 = var7.hasNext();
                     if (var38 == (255698910 ^ var58)) {
                        var58 = 187620016 ^ var58;
                        break;
                     }

                     var58 = 1330957126 ^ var58;
                     Object var41 = var7.next();
                     String var42 = (String)var41;
                     var58 = 1321392382 ^ var58;
                     if (var42 != null) {
                        var58 = 1259665090 ^ var58;
                        String var45 = ChatColor.stripColor(var42);
                        Locale var54 = Locale.ROOT;
                        String var46 = var45.toLowerCase(var54);
                        byte var47 = var46.contains(var1);
                        if (var47 != (1170162340 ^ var58)) {
                           var58 = 1590940820 ^ var58;
                           byte var48 = (byte)(460101169 ^ var58);
                           return (boolean)var48;
                        }

                        var58 = 1288566167 ^ var58;
                     } else {
                        var58 = ejxnibgvvcgmqgxt(var58, 131662677);
                     }

                     var58 = ejxnibgvvcgmqgxt(var58, 105844973);
                  }
               } else {
                  var58 = ejxnibgvvcgmqgxt(var58, 334954907);
               }

               byte var39 = (byte)(68386158 ^ var58);
               return (boolean)var39;
            }

            var58 = 99963491 ^ var58;
         } else {
            label89:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var58)) {
                  case 162194484:
                     var58 ^= 1965304970;
                     break label89;
                  case 624319875:
                  default:
                     throw new IllegalAccessException();
                  case 899166103:
                     break;
                  case 1200499713:
                     break label89;
               }
            }
         }

         byte var19 = (byte)(720884072 ^ var58);
         return (boolean)var19;
      }
   }

   private void refresh() {
      int var6 = 1724240052 ^ 1056113597 ^ 345759920;
      var6 = 576485460 ^ var6;
      this.decorate();
      var6 = 233413446 ^ var6;
      Player var3 = this.player;
      var3.updateInventory();
      var6 = 883701108 ^ var6;
   }

   private static void tagLore(ItemStack var0, List<String> var1, String var2, String var3) {
      int var38 = 1957260804 ^ 1876322104 ^ 1920577792;
      var38 = 671109558 ^ var38;
      ItemMeta var11 = var0.getItemMeta();
      var38 = 210177096 ^ var38;
      if (var11 == null) {
         var38 = 548737536 ^ var38;
      } else {
         var38 = ejxnibgvvcgmqgxt(var38, 395324187);
         byte var14 = var11.hasLore();
         ArrayList var15;
         if (var14 != (1511116505 ^ var38)) {
            var38 = 87631653 ^ var38;
            List var34 = var11.getLore();
            var15 = new ArrayList(var34);
            var38 = ejxnibgvvcgmqgxt(var38, 92466825);
         } else {
            var38 = 328024142 ^ var38;
            var15 = new ArrayList();
            var38 = 322341346 ^ var38;
         }

         ArrayList var8 = var15;
         var38 = 480927225 ^ var38;
         Iterator var17 = var1.iterator();
         Iterator var9 = var17;
         var38 = 1848224150 ^ var38;

         while(true) {
            byte var19 = var9.hasNext();
            if (var19 == (673837850 ^ var38)) {
               var38 = ejxnibgvvcgmqgxt(var38, 504559541);
               var11.setLore(var8);
               var38 = 1228937498 ^ var38;
               var0.setItemMeta(var11);
               var38 = 425471567 ^ var38;
               return;
            }

            var38 = 1162378180 ^ var38;
            Object var21 = var9.next();
            String var22 = (String)var21;
            var38 = 1051995744 ^ var38;
            String var33;
            if (var2 == null) {
               var38 = 1813998565 ^ var38;
               var33 = var22;
               var38 = 687063583 ^ var38;
            } else {
               label36:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var38)) {
                     case 40739013:
                        var38 ^= 893822976;
                        break label36;
                     case 195026528:
                        break;
                     case 612350107:
                        break label36;
                     case 703057404:
                     default:
                        throw new IllegalAccessException();
                  }
               }

               var33 = var22.replace(var2, var3);
               var38 = 1906967034 ^ var38;
            }

            String var30 = oOo0KKoOoOK.color(var33);
            boolean var24 = var8.add(var30);
            var38 = 744937951 ^ var38;
            var38 = ejxnibgvvcgmqgxt(var38, 326509953);
         }
      }
   }

   private static ItemStack pane(String var0, Material var1, String var2, List<String> var3) {
      int var28 = 127348213 ^ 1091482190 ^ 1920577792;
      var28 = 956708800 ^ var28;
      ArrayList var4 = new ArrayList();
      ArrayList var8 = var4;
      var28 = 1622420946 ^ var28;
      Iterator var12 = var3.iterator();
      Iterator var9 = var12;
      var28 = 1805500289 ^ var28;

      while(true) {
         byte var14 = var9.hasNext();
         if (var14 == (114264872 ^ var28)) {
            var28 = 2094443454 ^ var28;
            o0o0oOKo0K var15 = cfg();
            String var25 = oOo0KKoOoOK.color(var2);
            ItemStack var16 = var15.button(var0, var1, var25, var8);
            return var16;
         }

         var28 = 1370100277 ^ var28;
         Object var18 = var9.next();
         String var19 = (String)var18;
         var28 = 106901035 ^ var28;
         String var24 = oOo0KKoOoOK.color(var19);
         boolean var21 = var8.add(var24);
         var28 = 1856771406 ^ var28;
         var28 = ejxnibgvvcgmqgxt(var28, 962144592);
      }
   }

   private static String stripDollar(String var0) {
      int var9 = 1688091910 ^ 1237005573 ^ 1920577792;
      var9 = 2140633421 ^ var9;
      String var2 = sgizisyzdz(xtfxxkzzkjdushj(), var9);
      byte var3 = var0.startsWith(var2);
      String var5;
      if (var3 != (550223950 ^ var9)) {
         var9 = 1601733788 ^ var9;
         byte var6 = (byte)(2142454995 ^ var9);
         var5 = var0.substring(var6);
         var9 = 1066662204 ^ var9;
      } else {
         var9 = ejxnibgvvcgmqgxt(var9, 1496812271);
         var5 = var0;
         var9 = 970782543 ^ var9;
      }

      return var5;
   }

   static {
      int var7 = 1098545212 ^ 1095816576 ^ Integer.parseInt("1868335418");
      fzzseuavve = ByteBuffer.wrap(kwdkhmvmjjuvfky()).asCharBuffer().toString();
      var7 = 620004387 ^ var7;
      String var0 = sgizisyzdz(gvrhxhdynphvwcr(), var7);
      String var1 = sgizisyzdz(vxbtlqthzysvrgh(), var7);
      String var2 = sgizisyzdz(frzuuvzrhxewygf(), var7);
      String var3 = sgizisyzdz(pcmxesfolvaojsw(), var7);
      var7 = 1386095110 ^ var7;
      List var4 = List.of(var0, var1, var2, var3);
      DEFAULT_SORTS = var4;
      var7 = 617400573 ^ var7;
   }

   public static String sgizisyzdz(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = fzzseuavve;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] gvrhxhdynphvwcr() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, 0};
   }

   private static byte[] vxbtlqthzysvrgh() {
      return new byte[]{0, 0, 0, 12, 0, 0, 0, 7};
   }

   private static byte[] frzuuvzrhxewygf() {
      return new byte[]{0, 0, 0, 13, 0, 0, 0, 19};
   }

   private static byte[] pcmxesfolvaojsw() {
      return new byte[]{0, 0, 0, 15, 0, 0, 0, 32};
   }

   private static byte[] kdeqwhxbkqzdqcb() {
      return new byte[]{0, 0, 0, 28, 0, 0, 0, 47};
   }

   private static byte[] nobaflgefvnrvjo() {
      return new byte[]{0, 0, 0, 14, 0, 0, 0, 75};
   }

   private static byte[] xtfxxkzzkjdushj() {
      return new byte[]{0, 0, 0, 1, 0, 0, 0, 89};
   }

   private static byte[] mbcdugspftjtdsb() {
      return new byte[]{0, 0, 0, 0, 0, 0, 0, 90};
   }

   private static byte[] yhcifheiueiiayt() {
      return new byte[]{0, 0, 0, 13, 0, 0, 0, 90};
   }

   private static byte[] kgppakgpotrihoe() {
      return new byte[]{0, 0, 0, 18, 0, 0, 0, 103};
   }

   private static byte[] dccbiqglzztuzci() {
      return new byte[]{0, 0, 0, 36, 0, 0, 0, 121};
   }

   private static byte[] veofyoyoufsltjq() {
      return new byte[]{0, 0, 0, 38, 0, 0, 0, -99};
   }

   private static byte[] nvrwqfwszbhayiy() {
      return new byte[]{0, 0, 0, 18, 0, 0, 0, -61};
   }

   private static byte[] gpdejtgqfwsuxok() {
      return new byte[]{0, 0, 0, 18, 0, 0, 0, -43};
   }

   private static byte[] jlrlrlvlvjvabnq() {
      return new byte[]{0, 0, 0, 18, 0, 0, 0, -25};
   }

   private static byte[] iagvdiqexjimkor() {
      return new byte[]{0, 0, 0, 20, 0, 0, 0, -7};
   }

   private static byte[] ssxyluwxetadlvz() {
      return new byte[]{0, 0, 0, 12, 0, 0, 1, 13};
   }

   private static byte[] jmdihsabhbhelcq() {
      return new byte[]{0, 0, 0, 14, 0, 0, 1, 25};
   }

   private static byte[] cbsyegajjwchdih() {
      return new byte[]{0, 0, 0, 23, 0, 0, 1, 39};
   }

   private static byte[] wklyvpttgqwzbjs() {
      return new byte[]{0, 0, 0, 25, 0, 0, 1, 62};
   }

   private static byte[] zlplrypekbgamlu() {
      return new byte[]{0, 0, 0, 27, 0, 0, 1, 87};
   }

   private static byte[] dsooxlgwwiewudm() {
      return new byte[]{0, 0, 0, 11, 0, 0, 1, 114};
   }

   private static byte[] pqulchcblahhrur() {
      return new byte[]{0, 0, 0, 18, 0, 0, 1, 125};
   }

   private static byte[] lurbsjpksvdqevj() {
      return new byte[]{0, 0, 0, 23, 0, 0, 1, -113};
   }

   private static byte[] qxobxhdpqmttuuk() {
      return new byte[]{0, 0, 0, 23, 0, 0, 1, -90};
   }

   private static byte[] wbfprpglfazasdz() {
      return new byte[]{0, 0, 0, 23, 0, 0, 1, -67};
   }

   private static byte[] rrbqgijgkthlqxe() {
      return new byte[]{0, 0, 0, 4, 0, 0, 1, -44};
   }

   private static byte[] tjduburdfmnyjzm() {
      return new byte[]{0, 0, 0, 11, 0, 0, 1, -40};
   }

   private static byte[] vzyiymlrrvpgabg() {
      return new byte[]{0, 0, 0, 28, 0, 0, 1, -29};
   }

   private static byte[] fupvegldwkjprwz() {
      return new byte[]{0, 0, 0, 22, 0, 0, 1, -1};
   }

   private static byte[] bwubdirprbvupmp() {
      return new byte[]{0, 0, 0, 18, 0, 0, 2, 21};
   }

   private static byte[] woesnlbkhwbddix() {
      return new byte[]{0, 0, 0, 7, 0, 0, 2, 39};
   }

   private static byte[] jtjhdijuqmycyaa() {
      return new byte[]{0, 0, 0, 6, 0, 0, 2, 46};
   }

   private static byte[] psravzppyytxwkt() {
      return new byte[]{0, 0, 0, 13, 0, 0, 2, 52};
   }

   private static byte[] derdywpjvrddsoo() {
      return new byte[]{0, 0, 0, 61, 0, 0, 2, 65};
   }

   private static byte[] gtjabzirdgnngyh() {
      return new byte[]{0, 0, 0, 14, 0, 0, 2, 126};
   }

   private static byte[] usysblcetyqzjzr() {
      return new byte[]{0, 0, 0, 17, 0, 0, 2, -116};
   }

   private static byte[] fiolltbumzeuxzw() {
      return new byte[]{0, 0, 0, 19, 0, 0, 2, -99};
   }

   private static byte[] czqwnhofyyfaxkf() {
      return new byte[]{0, 0, 0, 12, 0, 0, 2, -80};
   }

   private static byte[] pvgknewpuxjeaza() {
      return new byte[]{0, 0, 0, 12, 0, 0, 2, -68};
   }

   private static byte[] ozqyzyrbpboylsq() {
      return new byte[]{0, 0, 0, 14, 0, 0, 2, -56};
   }

   private static byte[] cwojqzidabkidsq() {
      return new byte[]{0, 0, 0, 10, 0, 0, 2, -42};
   }

   private static byte[] vuzuxipwxvhuobg() {
      return new byte[]{0, 0, 0, 20, 0, 0, 2, -32};
   }

   private static byte[] msupsfbjdvnrqyk() {
      return new byte[]{0, 0, 0, 22, 0, 0, 2, -12};
   }

   private static byte[] qiehxwyfgnenrsr() {
      return new byte[]{0, 0, 0, 6, 0, 0, 3, 10};
   }

   private static byte[] qesojbiigycwonv() {
      return new byte[]{0, 0, 0, 13, 0, 0, 3, 16};
   }

   private static byte[] mcjrzofyauqledg() {
      return new byte[]{0, 0, 0, 15, 0, 0, 3, 29};
   }

   private static byte[] uwnlmmtzviabbed() {
      return new byte[]{0, 0, 0, 11, 0, 0, 3, 44};
   }

   private static byte[] wweefwzsloqjabq() {
      return new byte[]{0, 0, 0, 13, 0, 0, 3, 55};
   }

   private static byte[] naxjzianrvixzah() {
      return new byte[]{0, 0, 0, 7, 0, 0, 3, 68};
   }

   private static byte[] gcnilxppybsoquc() {
      return new byte[]{0, 0, 0, 17, 0, 0, 3, 75};
   }

   private static byte[] bwhxrptzpvwlgjw() {
      return new byte[]{0, 0, 0, 17, 0, 0, 3, 92};
   }

   private static byte[] yucwlveqbqzivqc() {
      return new byte[]{0, 0, 0, 8, 0, 0, 3, 109};
   }

   private static byte[] msinojrrozoyhtu() {
      return new byte[]{0, 0, 0, 6, 0, 0, 3, 117};
   }

   private static byte[] zglixqwevuzdegv() {
      return new byte[]{0, 0, 0, 22, 0, 0, 3, 123};
   }

   private static byte[] fflmzmbtsvcickt() {
      return new byte[]{0, 0, 0, 9, 0, 0, 3, -111};
   }

   private static byte[] ibjkezhfqygshlg() {
      return new byte[]{0, 0, 0, 7, 0, 0, 3, -102};
   }

   private static byte[] eebseafpyeoukwm() {
      return new byte[]{0, 0, 0, 0, 0, 0, 3, -95};
   }

   private static byte[] flgkdhgzutathsv() {
      return new byte[]{0, 0, 0, 14, 0, 0, 3, -95};
   }

   private static byte[] ahdqmcgvuupweeg() {
      return new byte[]{0, 0, 0, 18, 0, 0, 3, -81};
   }

   private static byte[] yyertqnxfbknkbo() {
      return new byte[]{0, 0, 0, 15, 0, 0, 3, -63};
   }

   private static byte[] actxeuxhpymvaci() {
      return new byte[]{0, 0, 0, 24, 0, 0, 3, -48};
   }

   private static byte[] ncnixekfjwfogqg() {
      return new byte[]{0, 0, 0, 9, 0, 0, 3, -24};
   }

   private static byte[] fkrjwrtmgixoyib() {
      return new byte[]{0, 0, 0, 11, 0, 0, 3, -15};
   }

   private static byte[] reqqagmdvkndclc() {
      return new byte[]{0, 0, 0, 13, 0, 0, 3, -4};
   }

   private static byte[] fzxvnduectlaxio() {
      return new byte[]{0, 0, 0, 20, 0, 0, 4, 9};
   }

   private static byte[] ltfwahftkjollzp() {
      return new byte[]{0, 0, 0, 22, 0, 0, 4, 29};
   }

   private static byte[] xivxzbimqtbnhhw() {
      return new byte[]{0, 0, 0, 0, 0, 0, 4, 51};
   }

   private static byte[] kxinrwrsdrdxwaa() {
      return new byte[]{0, 0, 0, 20, 0, 0, 4, 51};
   }

   private static byte[] fmymfpiqiyhujnp() {
      return new byte[]{0, 0, 0, 22, 0, 0, 4, 71};
   }

   private static byte[] nfhnamqunirypfd() {
      return new byte[]{0, 0, 0, 17, 0, 0, 4, 93};
   }

   private static byte[] gccfisgpexvzonj() {
      return new byte[]{0, 0, 0, 0, 0, 0, 4, 110};
   }

   private static byte[] uauoecqpusyyumo() {
      return new byte[]{0, 0, 0, 12, 0, 0, 4, 110};
   }

   private static byte[] dnthsmhaxgxgyhx() {
      return new byte[]{0, 0, 0, 6, 0, 0, 4, 122};
   }

   private static byte[] hlhyqdxfjqwunbu() {
      return new byte[]{0, 0, 0, 0, 0, 0, 4, -128};
   }

   private static byte[] fzofumlcecmmwtv() {
      return new byte[]{0, 0, 0, 10, 0, 0, 4, -128};
   }

   private static byte[] ylaqmgatkaoxnhu() {
      return new byte[]{0, 0, 0, 24, 0, 0, 4, -118};
   }

   private static byte[] kwdkhmvmjjuvfky() {
      return new byte[]{49, 118, 54, 83, 56, 83, 50, 81, 48, 64, 49, 94, 54, 66, 49, 126, 54, 89, 56, 66, 50, 85, 48, 70, 49, 70, 54, 22, 56, 101, 50, 66, 48, 92, 49, 81, 54, 83, 49, 122, 54, 95, 56, 82, 50, 88, 48, 80, 49, 65, 54, 66, 56, 21, 50, 96, 48, 71, 49, 91, 54, 85, 56, 80, 49, 96, 54, 83, 56, 86, 50, 85, 48, 91, 49, 70, 54, 90, 56, 76, 50, 16, 48, 121, 49, 91, 54, 69, 56, 65, 50, 85, 48, 81, 49, 85, 56, 69, 52, 94, 57, 68, 48, 23, 49, 83, 56, 69, 52, 84, 57, 67, 48, 81, 49, 93, 56, 94, 52, 24, 57, 89, 48, 93, 49, 69, 56, 73, 52, 88, 57, 66, 48, 74, 49, 91, 56, 68, 52, 82, 57, 90, 48, 75, 49, 85, 56, 69, 52, 94, 55, 82, 53, 91, 49, 93, 55, 70, 53, 82, 52, 71, 50, 31, 49, 82, 50, 91, 55, 64, 53, 64, 49, 88, 55, 87, 53, 68, 53, 17, 49, 68, 57, 95, 49, 68, 51, 95, 50, 82, 49, 68, 57, 30, 49, 93, 51, 94, 50, 85, 49, 92, 57, 85, 49, 85, 49, 114, 57, 126, 49, 101, 51, 120, 50, 98, 49, 110, 57, 111, 49, 103, 51, 120, 50, 122, 49, 123, 57, 113, 49, 118, 51, 116, 50, 100, 49, 104, 57, 126, 49, 126, 49, 69, 49, 87, 49, 78, 54, 67, 48, 23, 49, 82, 49, 94, 49, 95, 54, 84, 48, 82, 49, 28, 49, 70, 49, 89, 54, 26, 48, 79, 49, 88, 49, 87, 49, 65, 54, 26, 48, 64, 49, 94, 49, 71, 49, 68, 54, 26, 48, 77, 49, 67, 49, 83, 49, 88, 54, 68, 48, 88, 49, 82, 49, 70, 49, 95, 54, 88, 48, 87, 49, 66, 49, 18, 49, 115, 49, 119, 54, 118, 48, 120, 49, 112, 49, 115, 49, 117, 54, 91, 48, 80, 49, 82, 49, 89, 49, 22, 54, 67, 48, 86, 49, 17, 49, 68, 49, 95, 54, 82, 48, 78, 49, 17, 49, 75, 49, 89, 54, 66, 48, 75, 49, 17, 49, 70, 49, 68, 54, 86, 48, 87, 49, 66, 49, 83, 49, 85, 54, 67, 48, 80, 49, 94, 49, 92, 49, 69, 49, 75, 48, 86, 51, 67, 49, 67, 49, 28, 50, 89, 57, 71, 54, 84, 49, 92, 49, 65, 48, 20, 51, 87, 49, 68, 49, 82, 50, 68, 57, 90, 54, 94, 49, 95, 49, 75, 48, 86, 51, 67, 49, 67, 49, 28, 50, 89, 57, 71, 54, 84, 49, 92, 49, 65, 48, 20, 51, 87, 49, 68, 49, 82, 50, 68, 57, 90, 54, 94, 49, 95, 50, 68, 52, 86, 53, 76, 51, 71, 56, 31, 50, 83, 52, 95, 53, 93, 51, 80, 56, 90, 50, 29, 52, 71, 53, 91, 51, 30, 56, 71, 50, 89, 52, 86, 53, 67, 50, 19, 52, 114, 53, 117, 51, 114, 56, 112, 50, 113, 52, 114, 53, 119, 51, 95, 56, 88, 50, 83, 52, 88, 53, 20, 51, 71, 56, 94, 50, 16, 52, 69, 53, 93, 51, 86, 56, 70, 49, 82, 50, 65, 48, 69, 50, 80, 53, 68, 49, 82, 50, 93, 48, 24, 50, 85, 53, 89, 49, 69, 50, 92, 49, 20, 50, 127, 48, 115, 50, 12, 53, 3, 49, 2, 50, 12, 48, 112, 50, 65, 53, 70, 49, 94, 50, 75, 48, 80, 50, 93, 49, 20, 50, 120, 48, 116, 50, 120, 53, 119, 49, 118, 50, 120, 48, 118, 50, 85, 53, 95, 49, 84, 50, 82, 48, 21, 50, 77, 53, 89, 49, 23, 50, 90, 48, 90, 50, 85, 53, 90, 49, 82, 50, 90, 48, 65, 49, 66, 55, 83, 55, 77, 53, 76, 53, 27, 49, 68, 55, 95, 55, 82, 53, 80, 53, 65, 49, 27, 55, 85, 55, 89, 53, 81, 53, 86, 49, 93, 55, 27, 55, 65, 53, 87, 53, 24, 49, 85, 55, 90, 55, 80, 53, 89, 53, 71, 49, 21, 55, 119, 55, 116, 53, 121, 53, 116, 49, 119, 55, 119, 55, 103, 53, 81, 53, 82, 49, 94, 55, 66, 55, 24, 53, 91, 53, 89, 49, 95, 55, 85, 55, 94, 53, 24, 53, 65, 49, 89, 55, 22, 55, 86, 53, 84, 53, 80, 49, 87, 55, 68, 55, 93, 50, 88, 57, 68, 56, 69, 54, 82, 49, 86, 49, 20, 55, 84, 49, 89, 55, 67, 50, 84, 55, 18, 50, 0, 57, 0, 56, 87, 54, 84, 49, 2, 49, 10, 55, 28, 49, 22, 55, 23, 50, 87, 57, 18, 56, 65, 54, 69, 49, 91, 49, 90, 55, 93, 49, 19, 55, 18, 50, 112, 57, 118, 56, 112, 54, 118, 49, 115, 49, 120, 55, 123, 49, 90, 55, 88, 50, 82, 57, 92, 56, 17, 54, 67, 49, 93, 49, 25, 55, 91, 49, 89, 55, 93, 50, 93, 57, 82, 56, 82, 54, 67, 50, 73, 57, 92, 51, 76, 50, 66, 48, 20, 50, 89, 57, 71, 51, 92, 50, 93, 48, 74, 50, 29, 57, 71, 51, 75, 50, 81, 48, 87, 50, 67, 57, 82, 51, 90, 50, 68, 48, 80, 50, 95, 57, 93, 51, 74, 50, 73, 57, 92, 51, 76, 50, 66, 48, 20, 50, 89, 57, 71, 51, 92, 50, 93, 48, 74, 50, 29, 57, 71, 51, 75, 50, 81, 48, 87, 50, 67, 57, 82, 51, 90, 50, 68, 48, 80, 50, 95, 57, 93, 51, 74, 56, 93, 56, 81, 53, 68, 57, 64, 56, 18, 56, 126, 53, 113, 57, 114, 52, 126, 49, 126, 56, 115, 55, 117, 52, 93, 56, 66, 56, 76, 56, 18, 56, 121, 53, 118, 57, 117, 52, 121, 49, 121, 56, 116, 55, 122, 52, 88, 56, 88, 56, 91, 53, 92, 57, 20, 52, 76, 49, 87, 56, 21, 55, 74, 52, 81, 56, 93, 56, 84, 53, 23, 57, 85, 52, 86, 49, 24, 56, 92, 55, 77, 52, 81, 56, 92, 49, 67, 55, 82, 48, 77, 51, 67, 48, 26, 49, 68, 55, 82, 48, 84, 51, 69, 48, 87, 49, 95, 55, 26, 48, 68, 51, 66, 48, 81, 49, 69, 55, 78, 48, 24, 51, 91, 48, 93, 49, 89, 55, 82, 49, 20, 55, 118, 48, 116, 51, 118, 48, 117, 49, 118, 55, 118, 48, 19, 51, 88, 48, 22, 49, 18, 55, 70, 48, 64, 51, 82, 48, 70, 49, 78, 55, 18, 48, 23, 49, 18, 55, 70, 48, 64, 51, 82, 48, 70, 49, 78, 55, 18, 49, 88, 56, 87, 53, 80, 56, 90, 56, 93, 49, 80, 49, 23, 56, 126, 53, 117, 56, 4, 56, 13, 49, 1, 56, 13, 53, 127, 56, 94, 56, 91, 49, 95, 56, 93, 53, 87, 49, 23, 56, 121, 53, 114, 56, 112, 56, 121, 49, 117, 56, 121, 53, 113, 56, 68, 56, 65, 49, 20, 56, 27, 53, 117, 56, 119, 56, 126, 49, 114, 56, 126, 53, 117, 56, 117, 56, 87, 49, 90, 56, 77, 53, 71, 56, 18, 56, 8, 49, 4, 56, 121, 53, 5, 56, 119, 56, 126, 49, 31, 56, 24, 53, 16, 56, 112, 56, 121, 49, 117, 56, 121, 53, 114, 56, 112, 56, 94, 49, 91, 56, 74, 53, 19, 56, 92, 56, 87, 49, 70, 56, 93, 53, 19, 56, 80, 56, 77, 49, 87, 56, 76, 53, 90, 56, 94, 56, 86, 49, 20, 56, 75, 53, 95, 56, 94, 56, 76, 49, 71, 49, 94, 55, 81, 49, 68, 55, 20, 52, 80, 48, 66, 52, 82, 51, 67, 57, 93, 49, 95, 55, 90, 49, 84, 55, 76, 52, 88, 49, 64, 55, 80, 56, 76, 56, 64, 56, 27, 49, 64, 55, 71, 56, 85, 56, 90, 56, 70, 49, 85, 55, 86, 56, 64, 56, 93, 56, 90, 49, 90, 55, 70, 49, 23, 55, 115, 56, 114, 56, 114, 56, 115, 49, 114, 55, 115, 56, 96, 56, 70, 56, 84, 49, 90, 55, 70, 56, 85, 56, 87, 56, 65, 49, 93, 55, 90, 56, 90, 56, 71, 49, 124, 52, 93, 48, 64, 51, 92, 57, 75, 49, 68, 52, 18, 48, 103, 51, 75, 57, 81, 49, 83, 52, 87, 49, 77, 56, 83, 52, 65, 51, 77, 56, 24, 49, 88, 56, 67, 52, 90, 51, 77, 56, 95, 49, 86, 56, 88, 49, 26, 56, 112, 52, 127, 51, 127, 56, 112, 49, 127, 56, 112, 52, 120, 51, 76, 56, 85, 49, 77, 56, 95, 52, 86, 51, 87, 51, 91, 55, 87, 53, 90, 50, 90, 53, 30, 56, 68, 50, 89, 54, 93, 54, 65, 51, 75, 49, 64, 57, 82, 53, 79, 48, 65, 51, 27, 49, 87, 57, 91, 53, 94, 48, 86, 51, 94, 49, 25, 57, 67, 53, 88, 48, 24, 51, 70, 49, 81, 57, 86, 53, 69, 48, 86, 51, 93, 49, 23, 57, 118, 53, 118, 48, 116, 51, 116, 49, 117, 57, 118, 53, 116, 48, 89, 51, 92, 49, 87, 57, 92, 53, 23, 48, 65, 51, 90, 49, 20, 57, 68, 53, 82, 48, 84, 51, 71, 49, 87, 57, 95, 49, 81, 54, 91, 51, 95, 51, 64, 49, 80, 49, 69, 53, 125, 55, 89, 49, 81, 49, 90, 56, 80, 53, 68, 48, 69, 54, 17, 50, 104, 53, 71, 55, 89, 49, 85, 49, 87, 49, 99, 50, 84, 48, 81, 53, 83, 55, 87, 49, 69, 50, 93, 48, 75, 53, 22, 55, 117, 49, 88, 50, 66, 48, 70, 53, 83, 55, 93, 52, 69, 50, 83, 53, 65, 56, 76, 50, 26, 49, 65, 54, 80, 57, 89, 56, 64, 52, 82, 50, 94, 52, 18, 50, 112, 53, 127, 56, 126, 50, 114, 49, 116, 54, 115, 57, 107, 56, 87, 52, 80, 50, 68, 53, 90, 56, 80, 50, 21, 48, 73, 50, 75, 48, 80, 53, 90, 50, 85, 48, 28, 49, 72, 57, 90, 55, 70, 56, 65, 51, 24, 49, 88, 57, 65, 55, 86, 56, 94, 51, 70, 49, 28, 57, 70, 55, 86, 56, 82, 51, 71, 49, 82, 57, 93, 49, 72, 57, 90, 55, 70, 56, 65, 51, 24, 49, 88, 57, 65, 55, 86, 56, 94, 51, 70, 49, 28, 57, 70, 55, 86, 56, 82, 51, 71, 49, 82, 57, 93, 49, 16, 48, 65, 54, 71, 55, 81, 48, 86, 49, 92, 48, 73, 54, 16, 49, 94, 54, 80, 52, 91, 57, 69, 49, 93, 54, 75, 49, 85, 54, 94, 51, 95, 48, 69, 51, 92, 49, 65, 54, 25, 51, 64, 48, 84, 51, 85, 49, 86, 54, 84, 51, 71, 48, 84, 51, 93, 49, 30, 54, 71, 51, 65, 48, 84, 51, 95, 49, 90, 54, 79, 49, 16, 54, 113, 51, 117, 48, 119, 51, 127, 49, 117, 54, 113, 22, -103, 48, 17, 56, 23, 56, 90, 54, 80, 49, 85, 56, 93, 50, 84, 54, 19, 49, 82, 48, 67, 54, 91, 56, 76, 48, 93, 49, 92, 48, 88, 54, 22, 56, 94, 48, 93, 49, 95, 48, 66, 54, 93, 56, 74, 49, 87, 49, 89, 53, 84, 51, 67, 52, 87, 49, 67, 49, 30, 53, 84, 51, 94, 52, 92, 49, 84, 49, 29, 53, 94, 51, 88, 52, 64, 49, 92, 49, 81, 53, 76, 49, 20, 49, 64, 53, 74, 51, 82, 52, 84, 49, 88, 49, 72, 53, 29, 51, 18, 52, 94, 49, 80, 49, 82, 53, 93, 51, 91, 52, 23, 51, 85, 53, 95, 56, 90, 50, 64, 51, 86, 51, 71, 54, 22, 54, 71, 52, 93, 51, 64, 53, 83, 56, 90, 50, 81, 51, 80, 51, 65, 54, 93, 54, 86, 52, 30, 51, 67, 53, 68, 56, 83, 50, 82, 51, 90, 51, 77, 51, 16, 53, 3, 56, 3, 50, 1, 51, 6, 51, 0, 54, 13, 19, -104, 52, 19, 50, 69, 48, 82, 54, 72, 49, 70, 57, 25, 50, 87, 48, 94, 54, 92, 49, 70, 57, 82, 50, 67, 50, 18, 48, 113, 54, 118, 49, 116, 57, 113, 50, 119, 48, 113, 54, 118, 49, 91, 57, 91, 50, 69, 48, 82, 54, 66, 49, 68, 50, 80, 48, 64, 52, 66, 56, 23, 49, 83, 50, 89, 48, 81, 52, 85, 56, 82, 49, 29, 50, 65, 48, 87, 52, 27, 56, 90, 49, 88, 50, 84, 48, 86, 52, 81, 56, 92, 49, 19, 50, 116, 48, 121, 52, 119, 56, 120, 49, 113, 50, 116, 48, 123, 52, 90, 56, 80, 49, 83, 50, 94, 48, 24, 52, 66, 56, 86, 49, 16, 50, 86, 48, 80, 52, 87, 56, 87, 49, 87, 50, 80, 49, 75, 51, 80, 50, 86, 52, 70, 55, 91, 49, 80, 51, 24, 50, 68, 52, 93, 55, 95, 49, 86, 51, 27, 50, 90, 52, 85, 55, 76, 49, 93, 51, 71, 50, 94, 52, 85, 55, 84, 49, 65, 52, 86, 49, 87, 50, 70, 54, 86, 49, 90, 52, 30, 49, 69, 50, 93, 54, 82, 49, 92, 52, 29, 49, 95, 50, 90, 54, 69, 49, 71, 52, 71, 49, 27, 50, 88, 54, 92, 49, 92, 52, 86, 49, 74, 49, 82, 56, 80, 55, 75, 49, 91, 49, 81, 49, 26, 56, 66, 55, 80, 49, 95, 49, 87, 49, 25, 56, 93, 55, 80, 49, 86, 49, 92, 49, 68, 16, -88, 16, -90, 25, -96, 22, -88, 16, -87, 16, -88, 16, -90, 25, -96, 22, -88, 16, -87, 16, -88, 16, -90, 49, 106, 49, 82, 56, 80, 55, 75, 49, 91, 49, 81, 53, 78, 48, 88, 52, 67, 55, 64, 57, 24, 55, 89, 55, 64, 54, 82, 50, 84, 53, 68, 53, 20, 48, 113, 52, 112, 55, 116, 57, 115, 55, 118, 55, 114, 54, 100, 50, 92, 53, 86, 48, 69, 52, 85, 55, 90, 57, 21, 55, 105, 55, 91, 54, 66, 50, 75, 53, 23, 48, 126, 52, 66, 55, 87, 57, 88, 55, 67};
   }

   private static int ejxnibgvvcgmqgxt(int var0, int var1) {
      return var1 ^ var0;
   }
}
