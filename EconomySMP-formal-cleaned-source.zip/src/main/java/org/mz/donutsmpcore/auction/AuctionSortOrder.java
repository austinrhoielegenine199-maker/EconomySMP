package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import skido.o0o0oOKo0K;

public enum AuctionSortOrder {
   HIGHEST_PRICE,
   LOWEST_PRICE,
   LAST_LISTED,
   RECENTLY_LISTED;

   private final String display;
   private static String fkvbyadnzy;

   private AuctionSortOrder(final String var3) {
      this.display = var3;
   }

   public String getDisplay() {
      int var14 = 1638893083 ^ 1993683094 ^ 1518372345;
      var14 = 953307783 ^ var14;

      try {
         String var1 = ynjyhidjyt(vvfreakcngwffsl(), var14);
         var14 = 771079000 ^ var14;
         String var9 = this.name();
         String var10 = "sort." + var9;
         String var11 = this.display;
         String var5 = o0o0oOKo0K.t(var1, var10, var11);
         var14 = 1799614865 ^ var14;
         return var5;
      } catch (Throwable var15) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var14)) {
            case -1455222885 -> var14 = 552589787 ^ var14;
            case -957426342 -> var14 = 219832963 ^ var14;
            default -> throw new IllegalAccessException("Error in hash");
         }

         var14 = 1574784488 ^ var14;
         String var8 = this.display;
         return var8;
      }
   }

   public String getDefaultDisplay() {
      int var5 = 1483366816 ^ 1297922608 ^ 1518372345;
      var5 = 1670961042 ^ var5;
      String var2 = this.display;
      return var2;
   }

   private static AuctionSortOrder[] $values() {
      int var12 = 1752201253 ^ 301945283 ^ 658626048;
      var12 = 295879500 ^ var12;
      byte var0 = (byte)(1332493486 ^ var12);
      AuctionSortOrder[] var3 = new AuctionSortOrder[var0];
      byte var1 = (byte)(1332493482 ^ var12);
      AuctionSortOrder var2 = HIGHEST_PRICE;
      var3[var1] = var2;
      byte var4 = (byte)(1332493483 ^ var12);
      AuctionSortOrder var7 = LOWEST_PRICE;
      var3[var4] = var7;
      byte var5 = (byte)(1332493480 ^ var12);
      AuctionSortOrder var8 = LAST_LISTED;
      var3[var5] = var8;
      byte var6 = (byte)(1332493481 ^ var12);
      AuctionSortOrder var9 = RECENTLY_LISTED;
      var3[var6] = var9;
      return var3;
   }

   static {
      int var19 = 281592285 ^ 1929694168 ^ Integer.parseInt("230830582");
      fkvbyadnzy = ByteBuffer.wrap(xtbqmxjjckdaawo()).asCharBuffer().toString();
      var19 = 687226181 ^ var19;
      String var1 = ynjyhidjyt(weudgjeataakjyz(), var19);
      byte var2 = (byte)(1190659766 ^ var19);
      String var3 = ynjyhidjyt(jktowhsyoixrtvo(), var19);
      AuctionSortOrder var0 = new AuctionSortOrder(var1, var2, var3);
      HIGHEST_PRICE = var0;
      var19 = 147994555 ^ var19;
      String var8 = ynjyhidjyt(zskorxskcdxshcl(), var19);
      byte var11 = (byte)(1311387916 ^ var19);
      String var14 = ynjyhidjyt(gndlhfgpbyhjbrb(), var19);
      AuctionSortOrder var4 = new AuctionSortOrder(var8, var11, var14);
      LOWEST_PRICE = var4;
      var19 = 1389376590 ^ var19;
      String var9 = ynjyhidjyt(gklfsliepakltjg(), var19);
      byte var12 = (byte)(486147393 ^ var19);
      String var15 = ynjyhidjyt(xcqjgxkaberstig(), var19);
      AuctionSortOrder var5 = new AuctionSortOrder(var9, var12, var15);
      LAST_LISTED = var5;
      var19 = 344502402 ^ var19;
      String var10 = ynjyhidjyt(ueamgpnpldbqnqb(), var19);
      byte var13 = (byte)(141735362 ^ var19);
      String var16 = ynjyhidjyt(eobdwszjuxndbmf(), var19);
      AuctionSortOrder var6 = new AuctionSortOrder(var10, var13, var16);
      RECENTLY_LISTED = var6;
      var19 = 1999486685 ^ var19;
      AuctionSortOrder[] var7 = $values();
   }

   public static String ynjyhidjyt(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = fkvbyadnzy;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] weudgjeataakjyz() {
      return new byte[]{0, 0, 0, 13, 0, 0, 0, 0};
   }

   private static byte[] jktowhsyoixrtvo() {
      return new byte[]{0, 0, 0, 13, 0, 0, 0, 13};
   }

   private static byte[] zskorxskcdxshcl() {
      return new byte[]{0, 0, 0, 12, 0, 0, 0, 26};
   }

   private static byte[] gndlhfgpbyhjbrb() {
      return new byte[]{0, 0, 0, 12, 0, 0, 0, 38};
   }

   private static byte[] ueamgpnpldbqnqb() {
      return new byte[]{0, 0, 0, 15, 0, 0, 0, 50};
   }

   private static byte[] eobdwszjuxndbmf() {
      return new byte[]{0, 0, 0, 15, 0, 0, 0, 65};
   }

   private static byte[] gklfsliepakltjg() {
      return new byte[]{0, 0, 0, 11, 0, 0, 0, 80};
   }

   private static byte[] xcqjgxkaberstig() {
      return new byte[]{0, 0, 0, 11, 0, 0, 0, 91};
   }

   private static byte[] vvfreakcngwffsl() {
      return new byte[]{0, 0, 0, 23, 0, 0, 0, 102};
   }

   private static byte[] xtbqmxjjckdaawo() {
      return new byte[]{49, 121, 57, 121, 54, 114, 57, 127, 54, 115, 49, 98, 57, 100, 54, 106, 57, 103, 54, 100, 49, 120, 57, 115, 54, 112, 49, 121, 57, 89, 54, 82, 57, 95, 54, 83, 49, 66, 57, 68, 54, 21, 57, 103, 54, 68, 49, 88, 57, 83, 54, 80, 49, 127, 49, 126, 51, 111, 55, 124, 49, 100, 49, 103, 49, 110, 51, 104, 55, 107, 49, 126, 49, 112, 49, 116, 49, 127, 49, 94, 51, 79, 55, 92, 49, 68, 49, 71, 49, 17, 51, 104, 55, 75, 49, 94, 49, 80, 49, 84, 49, 102, 49, 114, 51, 118, 51, 115, 49, 127, 52, 101, 55, 127, 53, 106, 54, 110, 49, 120, 49, 126, 51, 102, 51, 98, 49, 116, 52, 117, 49, 102, 49, 82, 51, 86, 51, 83, 49, 95, 52, 69, 55, 95, 53, 74, 54, 17, 49, 120, 49, 94, 51, 70, 51, 66, 49, 84, 52, 85, 52, 116, 54, 112, 52, 100, 51, 109, 53, 107, 56, 122, 49, 125, 55, 96, 57, 97, 52, 125, 54, 117, 52, 116, 54, 80, 52, 68, 51, 77, 53, 20, 56, 122, 49, 93, 55, 64, 57, 65, 52, 93, 54, 85, 49, 94, 54, 64, 53, 81, 48, 68, 56, 24, 49, 88, 54, 64, 53, 91, 48, 67, 56, 94, 49, 86, 54, 91, 53, 23, 48, 68, 56, 88, 49, 75, 54, 65, 53, 94, 48, 94, 56, 91, 49, 77, 54, 80, 53, 74};
   }
}
