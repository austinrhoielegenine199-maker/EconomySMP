package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.KoOKKo0K;
import skido.KoOo0oOo0oOK;
import skido.o0KoOKKo0K;
import skido.o0o0K;
import skido.o0o0oOKo0K;
import skido.o0o0oOoOoOK;
import skido.o0oOKKoOoOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;

public class AuctionItemSearchGUI extends KoOKKo0K {
   private static final int BACK_SLOT = 49;
   private static final int FILTER_SLOT = 47;
   private static final int REFRESH_SLOT = 48;
   private static final int EDIT_SLOT = 53;
   private static final List<String> DEFAULT_SORTS;
   private String sort;
   private boolean editMode;
   private final Set<Integer> markedForRemoval;
   private static byte[] vhucyovxyb;

   private static o0o0oOKo0K cfg() {
      int var4 = 639777839 ^ 1189051159 ^ 2145051212;
      var4 = 1800592067 ^ var4;
      String var0 = fwljnweozs(lafhjvksllajlqb(), var4);
      o0o0oOKo0K var1 = o0o0oOKo0K.of(var0);
      return var1;
   }

   public AuctionItemSearchGUI(Player var1) {
      String var4 = "new-auctiongui";
      o0o0oOKo0K var14 = o0o0oOKo0K.of(var4);
      String var5 = "quick-buy-size";
      byte var6 = 54;
      int var15 = var14.intAt(var5, var6);
      String var16 = "new-auctiongui";
      o0o0oOKo0K var17 = o0o0oOKo0K.of(var16);
      String var19 = "quick-buy-title";
      String var7 = "Quick Buy";
      String var18 = var17.str(var19, var7);
      super(var1, var15, var18);
      String var11 = "Default";
      this.sort = var11;
      boolean var12 = false;
      this.editMode = var12;
      ConcurrentHashMap.KeySetView var13 = ConcurrentHashMap.newKeySet();
      this.markedForRemoval = var13;
   }

   public void open() {
      int var14 = 1684203128 ^ 837886000 ^ 1554628369;
      var14 = 1413099861 ^ var14;
      super.open();
      var14 = 156509798 ^ var14;
      Ko0KoOKoOK var4 = Ko0KoOKoOK.getInstance();
      Player var6 = this.player;
      UUID var7 = var6.getUniqueId();
      var4.addQuickBuyViewer(var7, this);
      var14 = 1827057242 ^ var14;
      oOoOKo0o0K var5 = oOoOKo0o0K.getInstance();
      Inventory var9 = this.inventory;
      Runnable var11 = () -> {
         int var7 = 171333225 ^ 1607705461 ^ 1554628369;
         var7 = 121020297 ^ var7;
         Ko0KoOKoOK var1 = Ko0KoOKoOK.getInstance();
         Player var3 = this.player;
         UUID var4 = var3.getUniqueId();
         var1.removeQuickBuyViewer(var4);
      };
      var5.setCloseAction(var9, var11);
      var14 = 2102649030 ^ var14;
   }

   public void decorate() {
      int var97 = 1683824182 ^ 1639014632 ^ 1554628369;
      var97 = 1612480591 ^ var97;
      Inventory var17 = this.inventory;
      var17.clear();
      var97 = 1725110237 ^ var97;
      Map var19 = this.buttons;
      var19.clear();
      var97 = 1257095675 ^ var97;
      Player var21 = this.player;
      UUID var22 = var21.getUniqueId();
      var97 = 275295053 ^ var97;
      oOoOKo0oOK var23 = oOoOKo0oOK.getInstance();
      Map var24 = var23.getBoard(var22);
      var97 = 1424446657 ^ var97;
      String var25 = fwljnweozs(wgbovmuwjujafci(), var97);
      o0o0oOKo0K var26 = o0o0oOKo0K.of(var25);
      String var44 = fwljnweozs(tdoipfjoslboweg(), var97);
      byte var3 = (byte)(1374185478 ^ var97);
      int var27 = var26.intAt(var44, var3);
      int var13 = var27;
      var97 = 68892888 ^ var97;
      Map var29 = this.applySort(var24, var27);
      Map var14 = var29;
      var97 = 18078120 ^ var97;
      byte var30 = (byte)(1424001370 ^ var97);
      int var15 = var30;
      var97 = 1891740921 ^ var97;

      label44:
      while(var15 <= var13) {
         var97 = 1052946823 ^ var97;
         Integer var48 = var15;
         Object var33 = var14.get(var48);
         oOoOKo0oOK.K var34 = (oOoOKo0oOK.K)var33;
         var97 = 1049714325 ^ var97;
         if (var34 == null) {
            var97 = 589517683 ^ var97;
            o0KoOKKo0K var63 = this.emptyButton(var15);
            this.addButton(var15, var63);

            label39:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var97)) {
                  case 115115892:
                     var97 ^= 537174594;
                     break label39;
                  case 967903223:
                     break;
                  case 1448484201:
                     break label39;
                  case 1810637470:
                  default:
                     throw new IOException();
               }
            }
         } else {
            var97 = boiqzfwkwayfvesb(var97, 771742154);
            o0KoOKKo0K var61 = this.filledButton(var15, var34);
            this.addButton(var15, var61);
            var97 = 785918203 ^ var97;
         }

         var15 += 659897217 ^ var97;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var97)) {
               case 204801053:
                  var97 ^= 57941539;
                  continue label44;
               case 865886358:
               default:
                  throw new IOException();
               case 1591453891:
                  continue label44;
               case 1691424211:
            }
         }
      }

      var97 = boiqzfwkwayfvesb(var97, 889693647);
      String var38 = fwljnweozs(kqocounssuwbwdq(), var97);
      o0o0oOKo0K var39 = o0o0oOKo0K.of(var38);
      var97 = 4443737 ^ var97;
      String var64 = fwljnweozs(ekwjieziespclwe(), var97);
      byte var78 = (byte)(291851780 ^ var97);
      int var52 = var39.slot(var64, var78);
      o0KoOKKo0K var65 = new o0KoOKKo0K();
      String var86 = fwljnweozs(jhzdrakiztrirlp(), var97);
      Material var6 = Material.ANVIL;
      var97 = 2126828642 ^ var97;
      o0o0oOKo0K var7 = cfg();
      String var8 = fwljnweozs(dicyzbpajgjvkes(), var97);
      String var9 = fwljnweozs(reslhwhnlctmmhc(), var97);
      String var87 = var7.rawStr(var8, var9);
      String var88 = oOo0KKoOoOK.color(var87);
      var97 = 655107097 ^ var97;
      o0o0oOKo0K var89 = cfg();
      String var93 = fwljnweozs(ijiwqenpswtapgi(), var97);
      String var10 = fwljnweozs(ujlpndffpbnsiss(), var97);
      String var90 = var89.rawStr(var93, var10);
      String var91 = oOo0KKoOoOK.color(var90);
      List var92 = List.of(var91);
      var97 = 1386910142 ^ var97;
      ItemStack var80 = var39.button(var86, var6, var88, var92);
      o0KoOKKo0K var66 = var65.item(var80);
      Consumer var82 = (var1) -> {
         int var7 = 1674557337 ^ 811390807 ^ 1554628369;
         var7 = 447942061 ^ var7;
         Player var4 = this.player;
         AuctionGUI var2 = new AuctionGUI(var4);
         var2.open();
      };
      var97 = 1513238876 ^ var97;
      o0KoOKKo0K var67 = var66.consumer(var82);
      var97 = 441956708 ^ var97;
      this.addButton(var52, var67);
      var97 = 134969776 ^ var97;
      String var68 = fwljnweozs(khwegdweuogyjmh(), var97);
      byte var83 = (byte)(1382669911 ^ var97);
      int var54 = var39.slot(var68, var83);
      o0KoOKKo0K var70 = this.filterButton();
      this.addButton(var54, var70);
      var97 = 138305356 ^ var97;
      String var71 = fwljnweozs(znjhxxifikudgsj(), var97);
      byte var84 = (byte)(1515684100 ^ var97);
      int var56 = var39.slot(var71, var84);
      o0KoOKKo0K var73 = this.refreshButton();
      this.addButton(var56, var73);
      var97 = 1457027873 ^ var97;
      String var74 = fwljnweozs(wveoierpkmtskmd(), var97);
      byte var85 = (byte)(210762272 ^ var97);
      int var58 = var39.slot(var74, var85);
      o0KoOKKo0K var76 = this.editStick();
      this.addButton(var58, var76);
      var97 = 1201164062 ^ var97;
   }

   private static List<String> sortCycle() {
      int var10 = 582059925 ^ 509975927 ^ 2145051212;
      var10 = 149464220 ^ var10;
      o0o0oOKo0K var0 = cfg();
      String var1 = fwljnweozs(ztsagbitvwrsmoo(), var10);
      List var2 = DEFAULT_SORTS;
      List var4 = var0.rawListAt(var1, var2);
      var10 = 947770983 ^ var10;
      byte var6 = var4.isEmpty();
      List var7;
      if (var6 != (1939573333 ^ var10)) {
         var10 = 513128527 ^ var10;
         var7 = DEFAULT_SORTS;
         var10 = boiqzfwkwayfvesb(var10, 1576043073);
      } else {
         var10 = 1038391321 ^ var10;
         var7 = var4;
         var10 = 2122424855 ^ var10;
      }

      return var7;
   }

   private Map<Integer, oOoOKo0oOK.K> applySort(Map<Integer, oOoOKo0oOK.K> var1, int var2) {
      int var77 = 765963281 ^ 1745427613 ^ 1554628369;
      var77 = 1742425936 ^ var77;
      String var3 = fwljnweozs(yddfxhgomoxhlnm(), var77);
      String var55 = this.sort;
      byte var11 = var3.equalsIgnoreCase(var55);
      if (var11 != (2128363725 ^ var77)) {
         var77 = 206811430 ^ var77;
         return var1;
      } else {
         var77 = boiqzfwkwayfvesb(var77, 1157175152);
         ArrayList var13 = new ArrayList();
         ArrayList var7 = var13;
         var77 = 1946504982 ^ var77;
         byte var14 = (byte)(1310726315 ^ var77);
         int var8 = var14;

         for(var77 = 742320599 ^ var77; var8 <= var2; var77 = 1310272208 ^ var77) {
            var77 = 1354999346 ^ var77;
            Integer var67 = var8;
            Object var50 = var1.get(var67);
            oOoOKo0oOK.K var51 = (oOoOKo0oOK.K)var50;
            var77 = 1324477201 ^ var77;
            if (var51 != null) {
               var77 = 2039477909 ^ var77;
               var7.add(var51);
               var77 = 698650982 ^ var77;
            } else {
               var77 = 1345021939 ^ var77;
            }

            var8 += 738712493 ^ var77;
         }

         byte var10;
         var77 = 1271819428 ^ var77;
         String var17 = this.sort;
         byte var18 = (byte)(-701537753 ^ var77);
         var10 = var18;
         int var20 = var17.hashCode();
         label117:
         switch (var20) {
            case 2420395:
               var77 = boiqzfwkwayfvesb(var77, 1094985701);
               String var64 = fwljnweozs(rycnqhwtqwvtzey(), var77);
               byte var44 = var17.equals(var64);
               if (var44 != (1754577469 ^ var77)) {
                  var77 = 1445539759 ^ var77;
                  byte var45 = (byte)(1052611984 ^ var77);
                  var10 = var45;
                  var77 = 1991880030 ^ var77;
               } else {
                  var77 = boiqzfwkwayfvesb(var77, 546341617);
               }
               break;
            case 1333277614:
               var77 = 1014247300 ^ var77;
               String var65 = fwljnweozs(kzsiddnvjfdluck(), var77);
               byte var47 = var17.equals(var65);
               if (var47 != (363115100 ^ var77)) {
                  var77 = 193580585 ^ var77;
                  byte var48 = (byte)(506297460 ^ var77);
                  var10 = var48;

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var77)) {
                        case 73124856:
                           break;
                        case 175652623:
                           var77 ^= 1445545145;
                           break label117;
                        case 905136937:
                        default:
                           throw new IOException();
                        case 1902353219:
                           break label117;
                     }
                  }
               } else {
                  var77 = boiqzfwkwayfvesb(var77, 1570802320);
                  break;
               }
            case 1599840887:
               var77 = 935848827 ^ var77;
               String var57 = fwljnweozs(bmtdjiooogaonjd(), var77);
               byte var22 = var17.equals(var57);
               if (var22 != (504854179 ^ var77)) {
                  var77 = 1373499822 ^ var77;
                  byte var23 = (byte)(1338672909 ^ var77);
                  var10 = var23;
                  var77 = boiqzfwkwayfvesb(var77, 130990017);
                  break;
               } else {
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var77)) {
                        case 172846028:
                           var77 ^= 1444105839;
                           break label117;
                        case 314903485:
                           break;
                        case 573481240:
                           break label117;
                        case 1465389099:
                        default:
                           throw new IOException();
                     }
                  }
               }
            default:
               var77 = 1641325844 ^ var77;
         }

         Comparator var71;
         label94:
         switch (var10) {
            case 0:
               var77 = 2012931532 ^ var77;
               ToDoubleFunction var38 = this::priceOf;
               Comparator var39 = Comparator.comparingDouble(var38);
               var71 = var39;
               var77 = 672904965 ^ var77;

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var77)) {
                     case 239889036:
                        var77 ^= 1971017270;
                        break label94;
                     case 1684026809:
                     default:
                        throw new IOException();
                     case 1728523001:
                        break;
                     case 2077065179:
                        break label94;
                  }
               }
            case 1:
               var77 = boiqzfwkwayfvesb(var77, 976697585);
               ToDoubleFunction var26 = this::priceOf;
               Comparator var27 = Comparator.comparingDouble(var26);
               Comparator var28 = var27.reversed();
               var71 = var28;
               var77 = 1913976867 ^ var77;
               var77 = 1656341549 ^ var77;
               break;
            case 2:
               var77 = boiqzfwkwayfvesb(var77, 1225241487);
               Function var40 = (var0) -> {
                  int var6 = 1739581571 ^ 912561581 ^ 2145051212;
                  var6 = 1038611144 ^ var6;
                  Material var2 = var0.material;
                  String var3 = var2.name();
                  return var3;
               };
               Comparator var41 = Comparator.comparing(var40);
               var71 = var41;
               var77 = 1515807162 ^ var77;
               var77 = boiqzfwkwayfvesb(var77, 969201354);
               break;
            default:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var77)) {
                     case 193488399:
                        var77 = 1023725171 ^ var77;
                        return var1;
                     case 788850345:
                        break;
                     case 1260215056:
                     default:
                        throw new IOException();
                     case 1893636702:
                        return var1;
                  }
               }
         }

         var7.sort(var71);
         var77 = 2071956259 ^ var77;
         HashMap var30 = new HashMap();
         HashMap var72 = var30;
         var77 = 2066454856 ^ var77;
         byte var31 = (byte)(1657417304 ^ var77);
         int var74 = var31;
         var77 = 1659678005 ^ var77;

         while(true) {
            int var60 = var7.size();
            if (var74 < var60) {
               var77 = 443798843 ^ var77;
               if (var74 <= var2) {
                  var77 = 917144190 ^ var77;
                  Integer var63 = var74;
                  Object var69 = var7.get(var74);
                  oOoOKo0oOK.K var70 = (oOoOKo0oOK.K)var69;
                  var72.put(var63, var70);
                  var77 = 2092485976 ^ var77;
                  var74 += 1346836849 ^ var77;
                  var77 = boiqzfwkwayfvesb(var77, 1348573725);
                  continue;
               }

               var77 = 1706181242 ^ var77;
               return var72;
            }

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var77)) {
                  case 2366224:
                     var77 = 2143393601 ^ var77;
                     return var72;
                  case 564142585:
                     return var72;
                  case 794097337:
                  default:
                     throw new IOException();
                  case 1320902328:
               }
            }
         }
      }
   }

   private double priceOf(oOoOKo0oOK.K var1) {
      int var14 = 1572901203 ^ 1549671584 ^ 1554628369;
      var14 = 2098056805 ^ var14;
      Material var5 = var1.material;
      Map var11 = var1.enchants;
      AuctionItem var6 = cheapestListing(var5, var11);
      var14 = 1940371434 ^ var14;
      double var9;
      if (var6 == null) {
         var14 = 1138361878 ^ var14;
         var9 = Double.MAX_VALUE;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var14)) {
               case 260716121:
                  var14 = 516849950 ^ var14;
                  return var9;
               case 577110465:
                  break;
               case 1433177061:
               default:
                  throw new IllegalAccessException();
               case 1774576861:
                  return var9;
            }
         }
      } else {
         label34:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var14)) {
               case 33591742:
                  var14 ^= 1510396879;
                  break label34;
               case 373127874:
                  break;
               case 496177713:
               default:
                  throw new IllegalAccessException();
               case 1281515867:
                  break label34;
            }
         }

         var9 = var6.getPrice();
         var14 = 118641863 ^ var14;
         return var9;
      }
   }

   private o0KoOKKo0K filterButton() {
      int var98 = 814299452 ^ 2141150334 ^ 1554628369;
      var98 = 785359362 ^ var98;
      o0o0oOKo0K var1 = cfg();
      o0o0oOKo0K var6 = var1;
      var98 = 452970226 ^ var98;
      String var3 = fwljnweozs(bbopqbwxqaunfjg(), var98);
      Material var4 = Material.HOPPER;
      Material var73 = var1.material(var3, var4);
      ItemStack var15 = new ItemStack(var73);
      var98 = 740212112 ^ var98;
      ItemMeta var17 = var15.getItemMeta();
      var98 = 1754649110 ^ var98;
      if (var17 != null) {
         var98 = 1743561582 ^ var98;
         String var74 = fwljnweozs(qfwtgihvzcknhpy(), var98);
         String var82 = fwljnweozs(vqmbjnwcwrwjpsp(), var98);
         String var83 = oOo0KKoOoOK.color(var82);
         String var54 = var1.name(var74, var83);
         var17.setDisplayName(var54);
         var98 = 989707004 ^ var98;
         String var55 = fwljnweozs(pgjojqyxgyglpwt(), var98);
         String var75 = fwljnweozs(nswqwjuyoekqoas(), var98);
         String var21 = var1.rawStr(var55, var75);
         String var9 = var21;
         var98 = 640170192 ^ var98;
         String var56 = fwljnweozs(gkmgerljjgqmpka(), var98);
         String var76 = fwljnweozs(aruckocmgblrwnv(), var98);
         String var23 = var1.rawStr(var56, var76);
         String var10 = var23;
         var98 = 2053336259 ^ var98;
         String var57 = fwljnweozs(nyxzjlbyywretbi(), var98);
         String var77 = fwljnweozs(ffcsrnibfbggzji(), var98);
         String var25 = var1.rawStr(var57, var77);
         String var11 = var25;
         var98 = 1637508448 ^ var98;
         ArrayList var26 = new ArrayList();
         ArrayList var12 = var26;
         var98 = 1485723893 ^ var98;
         String var58 = fwljnweozs(xngbsjbsmzklury(), var98);
         String var78 = fwljnweozs(wznbhphspwxwliz(), var98);
         String var84 = fwljnweozs(knhmshqdjpycwkc(), var98);
         var98 = 1818888522 ^ var98;
         List var79 = List.of(var78, var84);
         var98 = 1294596996 ^ var98;
         List var28 = var1.rawListAt(var58, var79);
         Iterator var29 = var28.iterator();
         Iterator var13 = var29;
         var98 = 798248743 ^ var98;

         label91:
         while(true) {
            byte var31 = var13.hasNext();
            if (var31 == (1436359896 ^ var98)) {
               var98 = boiqzfwkwayfvesb(var98, 1252330407);
               List var37 = sortCycle();
               Iterator var38 = var37.iterator();
               Iterator var94 = var38;
               var98 = 1787330128 ^ var98;

               while(true) {
                  byte var40 = var94.hasNext();
                  if (var40 == (1974495535 ^ var98)) {
                     var98 = boiqzfwkwayfvesb(var98, 856638662);
                     var17.setLore(var12);
                     var98 = 1139671127 ^ var98;
                     var15.setItemMeta(var17);
                     var98 = 851107637 ^ var98;
                     break label91;
                  }

                  var98 = 293749299 ^ var98;
                  Object var49 = var94.next();
                  String var50 = (String)var49;
                  var98 = 1460725344 ^ var98;
                  String var80 = fwljnweozs(gogmzkbkphzaidr(), var98);
                  var98 = 715108080 ^ var98;
                  String var91 = this.sort;
                  byte var86 = var50.equals(var91);
                  String var87;
                  if (var86 != (431842188 ^ var98)) {
                     var98 = 1824738850 ^ var98;
                     var87 = var9;
                     var98 = boiqzfwkwayfvesb(var98, 1448180086);
                  } else {
                     var98 = boiqzfwkwayfvesb(var98, 957860738);
                     var87 = var10;
                     var98 = 59112662 ^ var98;
                  }

                  String var70 = var11.replace(var80, var87);
                  String var81 = fwljnweozs(iwassnmkbgtkxiy(), var98);
                  String var93 = "quick-buy.sort.labels." + var50;
                  var98 = 367986362 ^ var98;
                  String var89 = var6.rawStr(var93, var50);
                  String var71 = var70.replace(var81, var89);
                  var98 = 478077945 ^ var98;
                  String var72 = oOo0KKoOoOK.color(var71);
                  boolean var52 = var12.add(var72);
                  var98 = 314219436 ^ var98;
                  var98 = boiqzfwkwayfvesb(var98, 1303659288);
               }
            }

            var98 = 754894733 ^ var98;
            Object var33 = var13.next();
            String var34 = (String)var33;
            var98 = 51588806 ^ var98;
            byte var60 = var34.isEmpty();
            String var61;
            if (var60 != (2054223251 ^ var98)) {
               var98 = 1037600444 ^ var98;
               var61 = fwljnweozs(rrwisulhazbdzro(), var98);

               label59:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var98)) {
                     case 181803139:
                        var98 ^= 1425236851;
                        break label59;
                     case 1146486886:
                        break;
                     case 1212441041:
                        break label59;
                     case 1349465884:
                     default:
                        throw new IllegalAccessException();
                  }
               }
            } else {
               label72:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var98)) {
                     case 221946300:
                        var98 ^= 1157848638;
                     case 689570235:
                        break label72;
                     case 956358351:
                        break;
                     case 2086165602:
                     default:
                        throw new IllegalAccessException();
                  }
               }

               var61 = oOo0KKoOoOK.color(var34);
               var98 = 740867057 ^ var98;
            }

            var12.add(var61);
            var98 = 1424511158 ^ var98;

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var98)) {
                  case 183175798:
                     var98 ^= 305028146;
                     continue label91;
                  case 1090823921:
                  default:
                     throw new IllegalAccessException();
                  case 1577055678:
                     continue label91;
                  case 1987571073:
               }
            }
         }
      } else {
         label45:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var98)) {
               case 265893427:
                  var98 ^= 1424958382;
                  break label45;
               case 652770460:
               default:
                  throw new IllegalAccessException();
               case 712705272:
                  break;
               case 1454402458:
                  break label45;
            }
         }
      }

      o0KoOKKo0K var44 = new o0KoOKKo0K();
      o0KoOKKo0K var45 = var44.item(var15);
      String var66 = fwljnweozs(ldeqdsgiiasgbzh(), var98);
      o0KoOKKo0K var46 = var45.filterSound(var66);
      Consumer var68 = (var1x) -> {
         int var24 = 386309432 ^ 166783006 ^ 1554628369;
         var24 = 922618265 ^ var24;
         List var2 = sortCycle();
         var24 = 681487486 ^ var24;
         String var14 = this.sort;
         int var9 = var2.indexOf(var14);
         var24 = 982992562 ^ var24;
         byte var5 = (byte)(1722296675 ^ var24);
         int var18 = var9 + var5;
         int var21 = var2.size();
         int var19 = var18 % var21;
         Object var16 = var2.get(var19);
         String var17 = (String)var16;
         this.sort = var17;
         var24 = 1693650851 ^ var24;
         this.decorate();
         var24 = 1670285393 ^ var24;
         Player var13 = this.player;
         var13.updateInventory();
         var24 = 216611350 ^ var24;
      };
      o0KoOKKo0K var47 = var46.consumer(var68);
      return var47;
   }

   private o0KoOKKo0K refreshButton() {
      int var37 = 591925424 ^ 390160614 ^ 1554628369;
      var37 = 1782361927 ^ var37;
      o0o0oOKo0K var1 = cfg();
      var37 = 101412864 ^ var37;
      String var3 = fwljnweozs(ljngsbkxyctvyzb(), var37);
      Material var4 = Material.ENDER_CHEST;
      Material var27 = var1.material(var3, var4);
      ItemStack var8 = new ItemStack(var27);
      var37 = 997722583 ^ var37;
      ItemMeta var10 = var8.getItemMeta();
      var37 = 1694621549 ^ var37;
      if (var10 != null) {
         var37 = 841517455 ^ var37;
         String var28 = fwljnweozs(ggbcaubmtsnrsyd(), var37);
         String var30 = fwljnweozs(niumbagfyyrapmq(), var37);
         String var31 = oOo0KKoOoOK.color(var30);
         String var20 = var1.name(var28, var31);
         var10.setDisplayName(var20);
         var37 = 599923834 ^ var37;
         String var29 = fwljnweozs(dhnpilixvxfgfjh(), var37);
         String var32 = fwljnweozs(sxmvticyxmrtmfh(), var37);
         var37 = 381736126 ^ var37;
         String var33 = oOo0KKoOoOK.color(var32);
         var37 = 594151121 ^ var37;
         List var34 = List.of(var33);
         List var22 = var1.lore(var29, var34);
         var10.setLore(var22);
         var37 = 1601575615 ^ var37;
         var8.setItemMeta(var10);
         var37 = 310517248 ^ var37;
      } else {
         label18:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var37)) {
               case 3079142:
                  var37 = 1773421349 ^ var37;
                  break label18;
               case 1121605206:
               default:
                  throw new IOException();
               case 1580233320:
                  break label18;
               case 1687709470:
            }
         }
      }

      o0KoOKKo0K var16 = new o0KoOKKo0K();
      o0KoOKKo0K var17 = var16.item(var8);
      Consumer var26 = (var1x) -> {
         int var7 = 802834266 ^ 1744742127 ^ 1554628369;
         var7 = 916564350 ^ var7;
         this.decorate();
         var7 = 853096493 ^ var7;
         Player var4 = this.player;
         var4.updateInventory();
         var7 = 1032640676 ^ var7;
      };
      o0KoOKKo0K var18 = var17.consumer(var26);
      return var18;
   }

   private o0KoOKKo0K emptyButton(int var1) {
      int var33 = 1031158636 ^ 1429453717 ^ 1554628369;
      var33 = 379138187 ^ var33;
      o0o0oOKo0K var2 = cfg();
      String var3 = fwljnweozs(zsxyetcsehvdywi(), var33);
      Material var4 = Material.GRAY_STAINED_GLASS_PANE;
      Material var11 = var2.material(var3, var4);
      var33 = 1684454733 ^ var33;
      o0o0oOKo0K var16 = cfg();
      String var21 = fwljnweozs(htkypbvbvzmoptd(), var33);
      String var5 = fwljnweozs(fapwzemtstogrxm(), var33);
      String var17 = var16.rawStr(var21, var5);
      byte var22 = (byte)(1175695916 ^ var33);
      String[] var23 = new String[var22];
      byte var6 = (byte)(1175695918 ^ var33);
      var33 = 735185543 ^ var33;
      o0o0oOKo0K var7 = cfg();
      String var8 = fwljnweozs(prceqasbpfxfswh(), var33);
      String var9 = fwljnweozs(iqopwhprxdrlkqd(), var33);
      String var26 = var7.rawStr(var8, var9);
      var23[var6] = var26;
      byte var25 = (byte)(1841412264 ^ var33);
      var33 = 996414575 ^ var33;
      o0o0oOKo0K var27 = cfg();
      String var29 = fwljnweozs(squtsxwvmhjfhws(), var33);
      String var30 = fwljnweozs(zvpjriucunyhlvz(), var33);
      String var28 = var27.rawStr(var29, var30);
      var23[var25] = var28;
      var33 = 2085666699 ^ var33;
      ItemStack var12 = simple(var11, var17, var23);
      var33 = 1889667986 ^ var33;
      o0KoOKKo0K var13 = new o0KoOKKo0K();
      o0KoOKKo0K var14 = var13.item(var12);
      Consumer var20 = (var2x) -> {
         int var19 = 471437068 ^ 971645165 ^ 1554628369;
         var19 = 711607867 ^ var19;
         byte var11 = this.editMode;
         if (var11 != (1395676875 ^ var19)) {
            var19 = 1088173083 ^ var19;
         } else {
            label34:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var19)) {
                  case 19790617:
                     var19 ^= 2128293846;
                  case 906938940:
                     Player var13 = this.player;
                     byte var14 = o0o0K.open(var13, var1);
                     if (var14 != (770406685 ^ var19)) {
                        var19 = 1267253525 ^ var19;
                        return;
                     }

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var19)) {
                           case 150476611:
                              var19 ^= 1908376791;
                              break label34;
                           case 222368096:
                           default:
                              throw new IllegalAccessException();
                           case 514319661:
                              break label34;
                           case 1865852540:
                        }
                     }
                  case 1242707528:
                     break;
                  case 1354314923:
                  default:
                     throw new IllegalAccessException();
               }
            }

            Player var16 = this.player;
            byte var7 = (byte)(1549073867 ^ var19);
            String var8 = fwljnweozs(ftcvnxflxtgfazv(), var19);
            String var9 = fwljnweozs(qwzsdwlvgzoliqf(), var19);
            String var10 = fwljnweozs(caozfyzvhiplbtz(), var19);
            AuctionPageNavigation var15 = new AuctionPageNavigation(var16, var1, var7, var8, var9, var10);
            var15.open();
            var19 = 1346530498 ^ var19;
         }
      };
      o0KoOKKo0K var15 = var14.consumer(var20);
      return var15;
   }

   private o0KoOKKo0K filledButton(int var1, oOoOKo0oOK.K var2) {
      int var121 = 1910174972 ^ 1407565107 ^ 1554628369;
      var121 = 949308744 ^ var121;
      Material var90 = var2.material;
      byte var5 = (byte)(1174649751 ^ var121);
      byte var6 = (byte)(1174649814 ^ var121);
      int var116 = var2.amount;
      int var115 = Math.min(var6, var116);
      int var105 = Math.max(var5, var115);
      ItemStack var3 = new ItemStack(var90, var105);
      ItemStack var8 = var3;
      var121 = 1258336905 ^ var121;
      Map var16 = var2.enchants;
      Set var17 = var16.entrySet();
      Iterator var18 = var17.iterator();
      Iterator var9 = var18;
      var121 = 402288856 ^ var121;

      while(true) {
         byte var20 = var9.hasNext();
         if (var20 == (452557255 ^ var121)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var121)) {
                  case 71516424:
                     var121 ^= 2010664525;
                  case 373101598:
                     break;
                  case 1765808615:
                     continue;
                  case 2004476829:
                  default:
                     throw new RuntimeException();
               }

               ItemMeta var26 = var8.getItemMeta();
               var121 = 398433160 ^ var121;
               if (var26 != null) {
                  var121 = 864266248 ^ var121;
                  ArrayList var28 = new ArrayList();
                  var121 = 1189875047 ^ var121;
                  Material var30 = var2.material;
                  Map var64 = var2.enchants;
                  AuctionItem var31 = cheapestListing(var30, var64);
                  var121 = 181333556 ^ var121;
                  if (var31 == null) {
                     var121 = 2137197834 ^ var121;
                     o0o0oOKo0K var65 = cfg();
                     String var95 = fwljnweozs(sybzpjwnfaczwyf(), var121);
                     String var106 = fwljnweozs(vuhdjhrsnfrfbly(), var121);
                     String var66 = var65.rawStr(var95, var106);
                     String var67 = oOo0KKoOoOK.color(var66);
                     var28.add(var67);
                     var121 = 781612805 ^ var121;
                  } else {
                     var121 = boiqzfwkwayfvesb(var121, 1914577854);
                     double var46 = var31.getPrice();
                     String var48 = oOo0KKoOoOK.formatPrice(var46);
                     String var49 = stripDollar(var48);
                     var121 = 1917941252 ^ var121;
                     o0o0oOKo0K var79 = cfg();
                     String var101 = fwljnweozs(dhsgpzkmegcmefp(), var121);
                     String var110 = fwljnweozs(qvvyqukzajvxpsf(), var121);
                     String var80 = var79.rawStr(var101, var110);
                     String var102 = fwljnweozs(medspnhavcayjyg(), var121);
                     var121 = 540960755 ^ var121;
                     String var81 = var80.replace(var102, var49);
                     var121 = 186359287 ^ var121;
                     String var82 = oOo0KKoOoOK.color(var81);
                     var28.add(var82);
                     var121 = 79626669 ^ var121;
                     ItemStack var53 = var31.getItemStackDirect();
                     var121 = 1850644029 ^ var121;
                     int var59;
                     if (var53 == null) {
                        var121 = 452889955 ^ var121;
                        var59 = (byte)(1582977557 ^ var121);
                        var121 = boiqzfwkwayfvesb(var121, 2075305656);
                     } else {
                        label58:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var121)) {
                              case 83833938:
                                 var121 ^= 200512472;
                                 break label58;
                              case 890189234:
                                 break;
                              case 1002963493:
                              default:
                                 throw new RuntimeException();
                              case 1971352129:
                                 break label58;
                           }
                        }

                        var59 = var53.getAmount();
                        var121 = 1790949379 ^ var121;
                     }

                     var121 = 1774081715 ^ var121;
                     int var84 = var2.amount;
                     if (var59 != var84) {
                        var121 = 349086407 ^ var121;
                        o0o0oOKo0K var85 = cfg();
                        String var103 = fwljnweozs(izftjorbicnuwyu(), var121);
                        String var112 = fwljnweozs(pgctczoslxljzhg(), var121);
                        String var86 = var85.rawStr(var103, var112);
                        String var104 = fwljnweozs(csojljvhqfnxshy(), var121);
                        var121 = 1090745266 ^ var121;
                        String var114 = String.valueOf(var59);
                        String var87 = var86.replace(var104, var114);
                        var121 = 90368080 ^ var121;
                        String var88 = oOo0KKoOoOK.color(var87);
                        var28.add(var88);
                        var121 = 1211303532 ^ var121;
                     } else {
                        var121 = 412893001 ^ var121;
                     }
                  }

                  byte var36 = this.editMode;
                  if (var36 != (1422564694 ^ var121)) {
                     var121 = 898772375 ^ var121;
                     Set var69 = this.markedForRemoval;
                     Integer var97 = var1;
                     byte var70 = var69.contains(var97);
                     String var89;
                     if (var70 != (1633202369 ^ var121)) {
                        var121 = 341349816 ^ var121;
                        o0o0oOKo0K var78 = cfg();
                        String var100 = fwljnweozs(kalmhzrakcdgfwr(), var121);
                        String var109 = fwljnweozs(ukutjljqtmhyfcn(), var121);
                        var89 = var78.rawStr(var100, var109);
                        var121 = boiqzfwkwayfvesb(var121, 666397409);
                     } else {
                        var121 = boiqzfwkwayfvesb(var121, 557799769);
                        o0o0oOKo0K var71 = cfg();
                        String var98 = fwljnweozs(xlfwxgxtzfcvwzi(), var121);
                        String var107 = fwljnweozs(pbylaycpxcfuqeo(), var121);
                        var89 = var71.rawStr(var98, var107);
                        var121 = 316646912 ^ var121;
                     }

                     String var72 = oOo0KKoOoOK.color(var89);
                     var28.add(var72);
                     var121 = 1314317758 ^ var121;
                  } else {
                     var121 = 1210333040 ^ var121;
                  }

                  var26.setLore(var28);
                  var121 = 1020911683 ^ var121;
                  var8.setItemMeta(var26);
                  var121 = 1355703939 ^ var121;
               } else {
                  var121 = 174555364 ^ var121;
               }

               o0KoOKKo0K var42 = new o0KoOKKo0K();
               o0KoOKKo0K var43 = var42.item(var8);
               Consumer var77 = (var3x) -> {
                  int var29 = 374273926 ^ 992302637 ^ 1554628369;
                  var29 = 322233989 ^ var29;
                  byte var7 = this.editMode;
                  if (var7 == (1660352575 ^ var29)) {
                     var29 = boiqzfwkwayfvesb(var29, 543035679);
                     Material var19 = var2.material;
                     Map var26 = var2.enchants;
                     this.buyCheapest(var19, var26);
                     var29 = 915850405 ^ var29;
                  } else {
                     var29 = 1596821178 ^ var29;
                     Set var10 = this.markedForRemoval;
                     Integer var21 = var1;
                     byte var11 = var10.contains(var21);
                     if (var11 != (1037792901 ^ var29)) {
                        var29 = 1398110761 ^ var29;
                        Set var13 = this.markedForRemoval;
                        Integer var23 = var1;
                        var13.remove(var23);
                        var29 = boiqzfwkwayfvesb(var29, 343182625);
                     } else {
                        label28:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var29)) {
                              case 131663994:
                                 var29 ^= 1129802255;
                                 break label28;
                              case 328528447:
                              default:
                                 throw new IllegalAccessException();
                              case 704274551:
                                 break label28;
                              case 1889629889:
                           }
                        }

                        Set var17 = this.markedForRemoval;
                        Integer var25 = var1;
                        var17.add(var25);
                        var29 = 74882311 ^ var29;
                     }

                     this.refresh();
                     var29 = boiqzfwkwayfvesb(var29, 247770120);
                  }

               };
               o0KoOKKo0K var44 = var43.consumer(var77);
               return var44;
            }
         }

         var121 = 1829887340 ^ var121;
         Object var22 = var9.next();
         Map.Entry var23 = (Map.Entry)var22;
         var121 = 1672011423 ^ var121;
         Object var61 = var23.getKey();
         Enchantment var62 = (Enchantment)var61;
         Object var92 = var23.getValue();
         Integer var93 = (Integer)var92;
         int var94 = var93;
         var8.addUnsafeEnchantment(var62, var94);
         var121 = 1886030761 ^ var121;
         var121 = boiqzfwkwayfvesb(var121, 2127792218);
      }
   }

   private o0KoOKKo0K editStick() {
      int var50 = 429962225 ^ 1720015 ^ 1554628369;
      var50 = 1983856322 ^ var50;
      String var1 = fwljnweozs(bnkwowrkeifaole(), var50);
      o0o0oOKo0K var9 = o0o0oOKo0K.of(var1);
      var50 = 1779186335 ^ var50;
      String var3 = fwljnweozs(nhcqntyrldicnbd(), var50);
      Material var4 = Material.STICK;
      Material var38 = var9.material(var3, var4);
      ItemStack var10 = new ItemStack(var38);
      var50 = 351790088 ^ var50;
      ItemMeta var12 = var10.getItemMeta();
      var50 = 1280089910 ^ var50;
      if (var12 == null) {
         var50 = boiqzfwkwayfvesb(var50, 1375386781);
      } else {
         var50 = 2067987171 ^ var50;
         String var39 = fwljnweozs(ylnpzkizwlepaqb(), var50);
         o0o0oOKo0K var41 = cfg();
         String var46 = fwljnweozs(vovtfrkpgdushcj(), var50);
         String var5 = fwljnweozs(pamywmrmsgdqcit(), var50);
         String var42 = var41.rawStr(var46, var5);
         String var43 = oOo0KKoOoOK.color(var42);
         String var25 = var9.name(var39, var43);
         var12.setDisplayName(var25);
         var50 = 1098487407 ^ var50;
         var50 = 1382440303 ^ var50;
         byte var27 = this.editMode;
         String var37;
         if (var27 != (1774615727 ^ var50)) {
            var50 = 1601595337 ^ var50;
            var37 = fwljnweozs(jhwdijgixbeetcm(), var50);
            var50 = boiqzfwkwayfvesb(var50, 836888276);
         } else {
            label27:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var50)) {
                  case 217118805:
                     var50 ^= 510799753;
                     break label27;
                  case 1387270836:
                  default:
                     throw new IllegalAccessException();
                  case 1527009938:
                     break label27;
                  case 1763180030:
               }
            }

            var37 = fwljnweozs(piprbckeqnztrpa(), var50);
            var50 = 1894100628 ^ var50;
         }

         String var28 = oOo0KKoOoOK.color(var37);
         List var29 = Collections.singletonList(var28);
         var12.setLore(var29);
         var50 = 1457570234 ^ var50;
         Enchantment var30 = o0oOKKoOoOK.UNBREAKING;
         byte var40 = (byte)(1370569737 ^ var50);
         byte var44 = (byte)(1370569737 ^ var50);
         var12.addEnchant(var30, var40, (boolean)var44);
         var50 = 590305092 ^ var50;
         byte var31 = (byte)(1922984781 ^ var50);
         ItemFlag[] var32 = new ItemFlag[var31];
         byte var45 = (byte)(1922984780 ^ var50);
         ItemFlag var47 = ItemFlag.HIDE_ENCHANTS;
         var32[var45] = var47;
         var12.addItemFlags(var32);
         var50 = 389783147 ^ var50;
         var10.setItemMeta(var12);
         var50 = 902038774 ^ var50;
      }

      o0KoOKKo0K var21 = new o0KoOKKo0K();
      o0KoOKKo0K var22 = var21.item(var10);
      Consumer var36 = (var1x) -> {
         int var29 = 1566824612 ^ 2035343004 ^ 1554628369;
         var29 = 1329677446 ^ var29;
         byte var7 = this.editMode;
         if (var7 != (937164207 ^ var29)) {
            var29 = 1041207094 ^ var29;
            Set var9 = this.markedForRemoval;
            Iterator var10 = var9.iterator();
            Iterator var5 = var10;
            var29 = 1266317168 ^ var29;

            label45:
            while(true) {
               byte var12 = var5.hasNext();
               if (var12 == (1118701033 ^ var29)) {
                  var29 = boiqzfwkwayfvesb(var29, 106616987);
                  Set var14 = this.markedForRemoval;
                  var14.clear();
                  var29 = 1425835993 ^ var29;
                  byte var3 = (byte)(268982955 ^ var29);
                  this.editMode = (boolean)var3;
                  var29 = 1879292207 ^ var29;
                  break;
               }

               var29 = 300342180 ^ var29;
               Object var18 = var5.next();
               Integer var19 = (Integer)var18;
               int var20 = var19;
               var29 = 1951884209 ^ var29;
               oOoOKo0oOK var21 = oOoOKo0oOK.getInstance();
               Player var24 = this.player;
               UUID var25 = var24.getUniqueId();
               var21.remove(var25, var20);
               var29 = 1325575602 ^ var29;

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var29)) {
                     case 40137956:
                     default:
                        throw new IOException();
                     case 163063690:
                        var29 ^= 716379559;
                        continue label45;
                     case 780989426:
                        break;
                     case 1370274035:
                        continue label45;
                  }
               }
            }
         } else {
            label25:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var29)) {
                  case 109155053:
                     break;
                  case 205130840:
                     var29 ^= 42387309;
                     break label25;
                  case 1248517993:
                  default:
                     throw new IOException();
                  case 1876081616:
                     break label25;
               }
            }

            byte var26 = (byte)(895302339 ^ var29);
            this.editMode = (boolean)var26;
            var29 = 1431755078 ^ var29;
         }

         this.refresh();
         var29 = 1884023160 ^ var29;
      };
      o0KoOKKo0K var23 = var22.consumer(var36);
      return var23;
   }

   private static AuctionItem cheapestListing(Material var0) {
      int var6 = 1553831042 ^ 1841321078 ^ 2145051212;
      var6 = 173381590 ^ var6;
      Object var2 = null;
      AuctionItem var3 = cheapestListing(var0, (Map)var2);
      return var3;
   }

   private static AuctionItem cheapestListing(Material var0, Map<Enchantment, Integer> var1) {
      int var42 = 1849484551 ^ 130965511 ^ 2145051212;
      var42 = 716207370 ^ var42;
      ArrayList var2 = new ArrayList();
      ArrayList var3 = var2;
      var42 = 454771628 ^ var42;
      Ko0KoOKoOK var7 = Ko0KoOKoOK.getInstance();
      List var8 = var7.getActiveItems();
      Iterator var9 = var8.iterator();
      Iterator var4 = var9;
      var42 = 132325004 ^ var42;

      while(true) {
         label65:
         while(true) {
            byte var11 = var4.hasNext();
            if (var11 == (543182694 ^ var42)) {
               var42 = boiqzfwkwayfvesb(var42, 1534050744);
               byte var28 = var3.isEmpty();
               if (var28 != (2064617182 ^ var42)) {
                  var42 = 121602842 ^ var42;
                  Object var29 = null;
                  return (AuctionItem)var29;
               }

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var42)) {
                     case 242114497:
                        var42 ^= 1854445901;
                        break label65;
                     case 265237059:
                        break;
                     case 307335555:
                        break label65;
                     case 1013514559:
                     default:
                        throw new IllegalAccessException();
                  }
               }
            }

            var42 = 1466023494 ^ var42;
            Object var13 = var4.next();
            AuctionItem var14 = (AuctionItem)var13;
            var42 = 874007105 ^ var42;
            ItemStack var16 = var14.getItemStackDirect();
            var42 = 203951550 ^ var42;
            if (var16 == null) {
               var42 = boiqzfwkwayfvesb(var42, 1867643321);
            } else {
               var42 = 646202696 ^ var42;
               Material var19 = var16.getType();
               if (var19 != var0) {
                  var42 = 1554499503 ^ var42;
                  var42 = boiqzfwkwayfvesb(var42, 359824222);
               } else {
                  var42 = 189231987 ^ var42;
                  if (var1 != null) {
                     var42 = 1903726284 ^ var42;
                     byte var22 = var1.isEmpty();
                     if (var22 == (327814696 ^ var42)) {
                        var42 = 1440878711 ^ var42;
                        byte var24 = hasAll(var16, var1);
                        if (var24 == (1181228639 ^ var42)) {
                           var42 = 1458914373 ^ var42;
                           var42 = 821892476 ^ var42;
                           continue;
                        }

                        label44:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var42)) {
                              case 141163696:
                                 var42 ^= 33383100;
                              case 678880556:
                                 break label44;
                              case 1071853696:
                                 break;
                              case 1800692905:
                              default:
                                 throw new IllegalAccessException();
                           }
                        }
                     } else {
                        var42 = 1411347147 ^ var42;
                     }
                  } else {
                     var42 = boiqzfwkwayfvesb(var42, 627571719);
                  }

                  var3.add(var14);
                  var42 = 1914958094 ^ var42;
                  var42 = 366396043 ^ var42;
               }
            }
         }

         ToDoubleFunction var37 = AuctionItem::getPrice;
         Comparator var38 = Comparator.comparingDouble(var37);
         var3.sort(var38);
         var42 = 1894385720 ^ var42;
         byte var39 = (byte)(1701650347 ^ var42);
         Object var32 = var3.get(var39);
         AuctionItem var33 = (AuctionItem)var32;
         return var33;
      }
   }

   private static boolean hasAll(ItemStack var0, Map<Enchantment, Integer> var1) {
      int var25 = 1382415393 ^ 1507080971 ^ 2145051212;
      var25 = 1898335482 ^ var25;
      Set var6 = var1.entrySet();
      Iterator var7 = var6.iterator();
      Iterator var4 = var7;
      var25 = 2038602318 ^ var25;

      while(true) {
         byte var9 = var4.hasNext();
         if (var9 == (2094003154 ^ var25)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var25)) {
                  case 30577833:
                     var25 ^= 1657727160;
                  case 1066836559:
                     byte var10 = (byte)(503389035 ^ var25);
                     return (boolean)var10;
                  case 1011660526:
                  default:
                     throw new IOException();
                  case 1484755691:
               }
            }
         }

         var25 = 424303416 ^ var25;
         Object var12 = var4.next();
         Map.Entry var13 = (Map.Entry)var12;
         var25 = 109837268 ^ var25;
         Object var17 = var13.getKey();
         Enchantment var18 = (Enchantment)var17;
         int var15 = var0.getEnchantmentLevel(var18);
         Object var20 = var13.getValue();
         Integer var21 = (Integer)var20;
         int var22 = var21;
         if (var15 < var22) {
            var25 = 633599767 ^ var25;
            byte var16 = (byte)(1187882025 ^ var25);
            return (boolean)var16;
         }

         var25 = boiqzfwkwayfvesb(var25, 1094921765);
         var25 = 1585614537 ^ var25;
      }
   }

   private void buyCheapest(Material var1, Map<Enchantment, Integer> var2) {
      int var84 = 1678973118 ^ 1834742620 ^ 1554628369;
      var84 = 984748571 ^ var84;
      AuctionItem var15 = cheapestListing(var1, var2);
      var84 = 864052751 ^ var84;
      if (var15 == null) {
         var84 = 1994661411 ^ var84;
         this.deny();
      } else {
         var84 = boiqzfwkwayfvesb(var84, 652719163);
         DonutSMPCore var17 = DonutSMPCore.getInstance();
         Economy var18 = var17.getEconomy();
         var84 = 1659658580 ^ var84;
         double var20 = var15.getPrice();
         var84 = 743436119 ^ var84;
         if (var18 != null) {
            var84 = 2017918483 ^ var84;
            Player var52 = this.player;
            byte var24 = var18.has(var52, var20);
            if (var24 != (1288824012 ^ var84)) {
               var84 = 355980836 ^ var84;
               Ko0KoOKoOK var25 = Ko0KoOKoOK.getInstance();
               byte var26 = var25.removeItem(var15);
               if (var26 == (1508258536 ^ var84)) {
                  var84 = 15021154 ^ var84;
                  this.deny();
                  return;
               }

               var84 = 106746454 ^ var84;
               Player var55 = this.player;
               var18.withdrawPlayer(var55, var20);
               var84 = 44369871 ^ var84;
               UUID var31 = var15.getSeller();
               OfflinePlayer var32 = Bukkit.getOfflinePlayer(var31);
               var84 = 2046294204 ^ var84;
               var18.depositPlayer(var32, var20);
               var84 = 829726154 ^ var84;
               Player var36 = this.player;
               PlayerInventory var37 = var36.getInventory();
               byte var57 = (byte)(362578438 ^ var84);
               ItemStack[] var58 = new ItemStack[var57];
               byte var7 = (byte)(362578439 ^ var84);
               ItemStack var79 = var15.getItemStack();
               ItemStack var80 = KoOo0oOo0oOK.thaw(var79);
               var58[var7] = var80;
               HashMap var38 = var37.addItem(var58);
               var84 = 1039171453 ^ var84;
               Player var40 = this.player;
               o0o0oOoOoOK.refresh(var40);
               var84 = 1260991180 ^ var84;
               Collection var42 = var38.values();
               Consumer var60 = (var1x) -> {
                  int var12 = 176351720 ^ 495680588 ^ 1554628369;
                  var12 = 1902804087 ^ var12;
                  Player var5 = this.player;
                  World var6 = var5.getWorld();
                  Player var8 = this.player;
                  Location var9 = var8.getLocation();
                  var6.dropItem(var9, var1x);
               };
               var42.forEach(var60);
               var84 = 155660441 ^ var84;
               Player var44 = this.player;
               UUID var45 = var44.getUniqueId();
               UUID var62 = var15.getSeller();
               ItemStack var70 = var15.getItemStack();
               TransactionHistory.logPurchase(var45, var62, var70, var20);
               var84 = 37610812 ^ var84;
               Ko0KoOKoOK var46 = Ko0KoOKoOK.getInstance();
               Player var72 = this.player;
               var46.notifySellerOfPurchase(var15, var72, var20);
               var84 = 440951471 ^ var84;
               Player var48 = this.player;
               String var64 = fwljnweozs(nfagdlevslunetc(), var84);
               String var73 = fwljnweozs(vpkkxffuahnjfjs(), var84);
               float var78 = 1.0F;
               float var81 = 1.2F;
               AuctionComponent.play(var48, var64, var73, var78, var81);
               var84 = 382258933 ^ var84;
               return;
            }

            var84 = 678412654 ^ var84;
         } else {
            var84 = 1344880509 ^ var84;
         }

         this.deny();
      }
   }

   private void deny() {
      int var7 = 989664612 ^ 1567585007 ^ 1554628369;
      var7 = 364209733 ^ var7;
      Player var4 = this.player;
      String var2 = fwljnweozs(vwzfzgwjllyipkc(), var7);
      String var3 = fwljnweozs(dplzyymobhbkdug(), var7);
      AuctionComponent.play(var4, var2, var3);
      var7 = 1950712853 ^ var7;
   }

   private void refresh() {
      int var6 = 1302197101 ^ 417302977 ^ 1554628369;
      var6 = 751090112 ^ var6;
      this.decorate();
      var6 = 1869236442 ^ var6;
      Player var3 = this.player;
      var3.updateInventory();
      var6 = 1228908055 ^ var6;
   }

   private static String stripDollar(String var0) {
      int var9 = 1811650854 ^ 1081976295 ^ 2145051212;
      var9 = 1502880784 ^ var9;
      String var2 = fwljnweozs(bnkribawpdabtyh(), var9);
      byte var3 = var0.startsWith(var2);
      String var4;
      if (var3 != (231275165 ^ var9)) {
         var9 = 1939911065 ^ var9;
         byte var6 = (byte)(2120764165 ^ var9);
         var4 = var0.substring(var6);

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var9)) {
               case 82472767:
                  var9 = 175732230 ^ var9;
                  return var4;
               case 390657952:
                  return var4;
               case 1098497973:
                  break;
               case 1936181653:
               default:
                  throw new RuntimeException();
            }
         }
      } else {
         label34:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var9)) {
               case 16879767:
                  break;
               case 179660888:
                  var9 ^= 151595969;
                  break label34;
               case 211194322:
               default:
                  throw new RuntimeException();
               case 2013239597:
                  break label34;
            }
         }

         var4 = var0;
         var9 = 1892740190 ^ var9;
         return var4;
      }
   }

   private static ItemStack simple(Material var0, String var1, String... var2) {
      int var42 = 1876523955 ^ 1807958688 ^ 2145051212;
      var42 = 1399352369 ^ var42;
      ItemStack var3 = new ItemStack(var0);
      var42 = 1744358590 ^ var42;
      ItemMeta var13 = var3.getItemMeta();
      var42 = 626026265 ^ var42;
      if (var13 == null) {
         var42 = 1193217097 ^ var42;
      } else {
         var42 = 665025955 ^ var42;
         String var33 = oOo0KKoOoOK.color(var1);
         var13.setDisplayName(var33);
         var42 = 545158911 ^ var42;
         ArrayList var16 = new ArrayList();
         ArrayList var7 = var16;
         var42 = 1373278913 ^ var42;
         String[] var8 = var2;
         int var19 = var2.length;
         int var9 = var19;
         byte var20 = (byte)(1007125844 ^ var42);
         int var10 = var20;
         var42 = 1710917816 ^ var42;

         label39:
         while(var10 < var9) {
            int var50 = 1168738464 ^ var42;
            String var23 = var8[var10];
            int var51 = 229873913 ^ var50;
            String var37 = oOo0KKoOoOK.color(var23);
            boolean var25 = var7.add(var37);
            var42 = 1078134797 ^ var51;
            var10 += 1369707961 ^ var42;

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var42)) {
                  case 237878192:
                     var42 ^= 140056660;
                     continue label39;
                  case 1355924211:
                  default:
                     throw new RuntimeException();
                  case 1446848574:
                     break;
                  case 1673797210:
                     continue label39;
               }
            }
         }

         var42 = 1245439012 ^ var42;
         byte var27 = var7.isEmpty();
         if (var27 == (331803080 ^ var42)) {
            var42 = 560125680 ^ var42;
            var13.setLore(var7);
            var42 = 1938033514 ^ var42;
         } else {
            var42 = 1390861722 ^ var42;
         }

         boolean var30 = var3.setItemMeta(var13);
         var42 = 1816077522 ^ var42;
      }

      return var3;
   }

   static {
      int var7 = 1988519481 ^ 1627845343 ^ Integer.parseInt("431880484");
      vhucyovxyb = zzfxhlaiivgdesk();
      var7 = 330139548 ^ var7;
      String var0 = fwljnweozs(fsqqhmfrjhpdqmi(), var7);
      String var1 = fwljnweozs(nzvrxgpghtyuuqy(), var7);
      String var2 = fwljnweozs(bxwfryqvptvmwmq(), var7);
      String var3 = fwljnweozs(lcfqrxtziawfskg(), var7);
      var7 = 1588846661 ^ var7;
      List var4 = List.of(var0, var1, var2, var3);
      DEFAULT_SORTS = var4;
      var7 = 359321632 ^ var7;
   }

   public static String fwljnweozs(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = vhucyovxyb;
         byte[] var34 = vhucyovxyb;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] zzfxhlaiivgdesk() {
      return new byte[]{97, 29, 33, 48, 92, 102, 28, 66, 61, 121, 122, 60, 65, 71, 105, 98, 71, 116, 115, 47, 100, 34, 19, 121, 57, 28, 20, 88, 17, 54, 78, 108, 56, 7, 70, 84, 127, 79, 101, 16, 13, 42, 66, 71, 104, 82, 96, 83, 126, 44, 113, 56, 44, 29, 59, 58, 83, 34, 46, 35, 2, 14, 109, 56, 13, 125, 50, 16, 90, 86, 105, 60, 89, 67, 122, 109, 114, 6, 65, 25, 78, 39, 63, 119, 85, 12, 11, 88, 58, 11, 119, 124};
   }

   private static byte[] fsqqhmfrjhpdqmi() {
      return new byte[]{-85, -37, 23, 68, 111, 53, 40, 16, 11, 44, 67, 127, 113, 24, 95, 34};
   }

   private static byte[] nzvrxgpghtyuuqy() {
      return new byte[]{-85, -37, 23, 67, 111, 56, 40, 19, 11, 44, 67, 122, 113, 17, 95, 37, 115, 54};
   }

   private static byte[] bxwfryqvptvmwmq() {
      return new byte[]{-85, -37, 23, 77, 111, 63, 40, 5, 11, 57, 67, 42, 113, 49, 95, 46, 115, 50, 71, 115, 82, 124, 32, 60, 13, 65, 34, 26, 40, 101};
   }

   private static byte[] lcfqrxtziawfskg() {
      return new byte[]{-85, -37, 23, 78, 111, 49, 40, 27, 11, 40};
   }

   private static byte[] lafhjvksllajlqb() {
      return new byte[]{-82, -37, 20, 100, 100, 38, 43, 31, 11, 57, 75, 42, 116, 21, 81, 34, 112, 35, 69, 104, 85, 114, 38, 37, 1, 71, 35, 67, 39, 116, 127, 32, 13, 93, 126, 2, 72, 16, 83, 65, 60, 102, 119, 13, 80, 0, 87, 18, 72, 118};
   }

   private static byte[] ztsagbitvwrsmoo() {
      return new byte[]{-82, -48, 22, 114, 111, 43, 36, 27, 5, 40, 75, 101, 118, 89, 90, 56, 127, 49, 75, 100, 85, 62, 36, 57, 10, 75, 44, 26, 41, 112, 127, 112, 15, 81, 117, 2, 71, 11, 93, 80, 60, 113, 117, 17, 91, 25};
   }

   private static byte[] bnkribawpdabtyh() {
      return new byte[]{-83, -47, 16, 38};
   }

   private static byte[] ftcvnxflxtgfazv() {
      return new byte[]{-82, -41, 21, 72, 108, 124, 47, 32};
   }

   private static byte[] qwzsdwlvgzoliqf() {
      return new byte[]{-82, -41, 21, 72, 108, 61, 47, 22};
   }

   private static byte[] caozfyzvhiplbtz() {
      return new byte[0];
   }

   private static byte[] wgbovmuwjujafci() {
      return new byte[]{-82, -47, 22, 106, 109, 59, 41, 0, 12, 96, 75, 110, 118, 6, 88, 57, 114, 53, 66, 114, 85, 126, 36, 35, 8, 67, 33, 24, 32, 107};
   }

   private static byte[] tdoipfjoslboweg() {
      return new byte[]{-82, -47, 22, 117, 109, 43, 41, 30, 12, 46, 75, 100, 118, 94, 88, 56, 114, 52, 66, 98, 85, 60, 36, 33, 8, 69, 33, 30, 32, 118, 127, 114, 15, 64, 119, 0, 74, 21, 84, 80};
   }

   private static byte[] ijiwqenpswtapgi() {
      return new byte[]{-82, -48, 16, 125, 111, 55, 41, 3, 4, 53, 75, 32, 112, 29, 90, 58, 114, 36, 74, 116, 85, 123, 34, 109, 10, 92, 33, 14, 40, 35, 127, 40, 9, 87, 117, 5, 74, 1};
   }

   private static byte[] ujlpndffpbnsiss() {
      return new byte[]{-82, -48, 16, 47, 111, 101, 41, 56, 4, 45, 75, 103, 112, 29, 90, 61, 114, 109, 74, 99, 85, 127, 34, 96, 10, 94, 33, 8, 40, 107, 127, 41};
   }

   private static byte[] dicyzbpajgjvkes() {
      return new byte[]{-82, -38, 22, 118, 100, 53, 45, 13, 5, 62, 75, 42, 118, 20, 81, 33, 118, 32, 75, 104, 85, 115, 36, 36, 1, 68};
   }

   private static byte[] reslhwhnlctmmhc() {
      return new byte[]{-82, -38, 22, 36, 100, 54, 45, 52, 5, 63, 75, 103, 118, 1, 81, 61, 118, 44, 75, 114};
   }

   private static byte[] wveoierpkmtskmd() {
      return new byte[]{-83, -45, 17, 98, 106, 48, 46, 29, 12, 63};
   }

   private static byte[] khwegdweuogyjmh() {
      return new byte[]{-82, -47, 25, 100, 106, 57, 37, 23, 9, 57, 75, 106, 121, 7};
   }

   private static byte[] kqocounssuwbwdq() {
      return new byte[]{-83, -38, 22, 105, 111, 54, 37, 4, 11, 102, 66, 106, 118, 1, 92, 56, 118, 54, 65, 126, 83, 122, 32, 34, 0, 74, 34, 31, 41, 104};
   }

   private static byte[] ekwjieziespclwe() {
      return new byte[]{-83, -37, 16, 105, 105, 34, 36, 19, 4, 63, 67, 100, 121, 29, 88, 52};
   }

   private static byte[] jhzdrakiztrirlp() {
      return new byte[]{-83, -37, 16, 105, 105, 34, 36, 19, 4, 63, 67, 100, 121, 29, 88, 52};
   }

   private static byte[] znjhxxifikudgsj() {
      return new byte[]{-82, -41, 16, 119, 106, 59, 40, 21, 9, 51, 75, 108, 112, 1, 95, 50};
   }

   private static byte[] yddfxhgomoxhlnm() {
      return new byte[]{-83, -45, 19, 76, 111, 53, 47, 19, 15, 45, 72, 120, 115, 19, 90, 32};
   }

   private static byte[] bmtdjiooogaonjd() {
      return new byte[]{-86, -46, 21, 75, 105, 58, 45, 16, 4, 45, 74, 120, 121, 23, 93, 32, 112, 57};
   }

   private static byte[] kzsiddnvjfdluck() {
      return new byte[]{-84, -44, 18, 76, 109, 60, 45, 1, 13, 62, 76, 47, 112, 51, 92, 43, 119, 52, 64, 124, 87, 125, 34, 63, 8, 69, 36, 29, 39, 96};
   }

   private static byte[] rycnqhwtqwvtzey() {
      return new byte[]{-82, -43, 20, 74, 105, 48, 43, 27, 11, 37};
   }

   private static byte[] rrwisulhazbdzro() {
      return new byte[0];
   }

   private static byte[] pgjojqyxgyglpwt() {
      return new byte[]{-82, -46, 21, 112, 106, 34, 41, 27, 14, 43, 75, 103, 117, 91, 95, 49, 114, 49, 64, 103, 85, 60, 39, 59, 15, 66, 33, 26, 34, 115, 127, 114, 12, 69, 112, 0, 74, 19, 86, 68, 60, 121, 118, 2, 94, 6, 85, 7, 77, 48, 64, 120, 24, 94, 13, 110, 102, 116, 29, 123, 51, 70};
   }

   private static byte[] nswqwjuyoekqoas() {
      return new byte[]{-82, -46, 21, 34, 106, 17, 41, 52, 14, 14, 75, 74, 117, 48, 95, 21, 87, -18, 64, 62};
   }

   private static byte[] nyxzjlbyywretbi() {
      return new byte[]{-82, -44, 20, 113, 111, 37, 43, 29, 8, 40, 75, 97, 116, 90, 90, 54, 112, 55, 70, 100, 85, 58, 38, 58, 10, 69, 35, 28, 36, 112, 127, 116, 13, 91, 117, 11, 72, 23, 80, 71, 60, 49, 119, 17, 91, 11, 87, 23, 75, 115, 64, 111, 25, 89};
   }

   private static byte[] ffcsrnibfbggzji() {
      return new byte[]{-82, -44, 20, 37, 111, 32, 43, 6, 8, 46, 75, 108, 116, 30, 90, 44, 112, 103, 70, 56, 85, 120, 38, 40, 10, 72, 35, 11, 36, 104, 127, 127};
   }

   private static byte[] qfwtgihvzcknhpy() {
      return new byte[]{-89, -48, 18, 98, 110, 59, 43, 27, 5, 63, 73, 109, 115, 1};
   }

   private static byte[] vqmbjnwcwrwjpsp() {
      return new byte[]{-89, -48, 18, 39, 110, 20, 43, 49, 5, 13, 73, 78, 115, 53, 94, 17, 127, 0, 64, 114, 86, 122, 36, 56, 1, 75, 39, 30};
   }

   private static byte[] ldeqdsgiiasgbzh() {
      return new byte[]{-90, -47, 25, 99, 108, 42, 37, 18, 12, 52, 73, 109, 115, 24, 80, 53, 116, 107, 74, 122, 92, 121, 35, 44, 0, 91, 37, 4, 34, 124};
   }

   private static byte[] gkmgerljjgqmpka() {
      return new byte[]{-85, -46, 23, 118, 109, 33, 40, 25, 14, 46, 74, 97, 118, 91, 91, 52, 117, 50, 71, 102, 82, 59, 34, 56, 13, 65, 39, 30, 33, 116, 121, 115, 10, 93, 116, 8, 75, 13, 83, 74, 60, 121, 118, 25, 91, 75, 80, 21, 73, 111, 67, 105, 30, 72, 15, 99, 101, 109};
   }

   private static byte[] aruckocmgblrwnv() {
      return new byte[]{-85, -46, 23, 36, 109, 97, 40, 69, 14, 120, 74, 63, 118, 67, 91, 99, 80, -19, 71, 63};
   }

   private static byte[] bbopqbwxqaunfjg() {
      return new byte[]{-87, -44, 18, 97, 111, 62, 36, 25, 8, 59, 76, 106, 118, 6};
   }

   private static byte[] xngbsjbsmzklury() {
      return new byte[]{-82, -41, 18, 112, 106, 34, 43, 30, 5, 47, 75, 98, 114, 91, 95, 49, 112, 52, 75, 99, 85, 57, 32, 59, 15, 66, 35, 31, 41, 119, 127, 119, 11, 94, 112, 0, 72, 27, 93, 65, 60, 122, 113, 4};
   }

   private static byte[] wznbhphspwxwliz() {
      return new byte[]{-82, -41, 18, 34, 106, 22, 43, 54, 5, 13, 75, 72, 114, 55, 95, 18, 112, 103, 75, 117, 85, 84, 32, 36, 15, 68, 35, 14, 41, 104, 127, 121, 11, 66, 112, 10, 72, 90, 93, 70, 60, 119, 113, 23, 94, 13, 87, 1, 70, 124};
   }

   private static byte[] knhmshqdjpycwkc() {
      return new byte[0];
   }

   private static byte[] gogmzkbkphzaidr() {
      return new byte[]{-89, -41, 22, 44, 109, 46, 36, 4, 9, 36, 79, 109, 120, 31, 81, 34, 115, 101};
   }

   private static byte[] iwassnmkbgtkxiy() {
      return new byte[]{-86, -37, 17, 38, 108, 62, 40, 20, 15, 46, 67, 105, 114, 27, 93, 115};
   }

   private static byte[] ljngsbkxyctvyzb() {
      return new byte[]{-88, -43, 17, 114, 100, 59, 37, 18, 10, 60, 74, 105, 121, 12, 80, 60};
   }

   private static byte[] dhnpilixvxfgfjh() {
      return new byte[]{-82, -48, 20, 122, 105, 52, 40, 18, 10, 58, 75, 107, 116, 12, 92, 61};
   }

   private static byte[] sxmvticyxmrtmfh() {
      return new byte[]{-82, -48, 20, 43, 105, 16, 40, 53, 10, 9, 75, 79, 116, 62, 92, 20, 115, 100, 68, 113, 85, 83, 38, 45, 12, 66, 32, 13, 38, 108, 127, 126, 13, 75, 115, 12, 75, 89, 82, 83, 60, 125, 119, 25, 93, 23, 84, 0, 73, 110, 64, 98, 25, 5, 14, 125, 103, 102, 25, 123, 51, 95, 88, 101, 56, 57};
   }

   private static byte[] ggbcaubmtsnrsyd() {
      return new byte[]{-82, -43, 20, 117, 100, 49, 42, 28, 11, 50, 75, 110, 116, 3, 81, 56};
   }

   private static byte[] niumbagfyyrapmq() {
      return new byte[]{-82, -43, 20, 36, 100, 18, 42, 60, 11, 6, 75, 77, 116, 54, 81, 22, 113, 29, 69, 99, 85, 124, 38, 45, 1, 69, 34, 64, 39, 77, 127, 46, 13, 73};
   }

   private static byte[] zsxyetcsehvdywi() {
      return new byte[]{-86, -43, 25, 101, 101, 61, 37, 11, 8, 56, 77, 125};
   }

   private static byte[] htkypbvbvzmoptd() {
      return new byte[]{-82, -45, 22, 113, 106, 58, 41, 3, 12, 53, 75, 35, 118, 23, 95, 54, 114, 61, 66, 99, 85, 106};
   }

   private static byte[] fapwzemtstogrxm() {
      return new byte[]{-82, -45, 22, 38, 106, 25, 41, 61, 12, 7, 75, 75, 118, 52, 95, 29, 114, 8, 66, 122, 85, 99, 36, 56, 15, 92};
   }

   private static byte[] prceqasbpfxfswh() {
      return new byte[]{-82, -38, 21, 117, 104, 50, 46, 8, 11, 56, 75, 42, 117, 21, 93, 63, 117, 47, 69, 121, 85, 113, 39, 101, 13, 89, 38, 5, 39, 46, 127, 55, 12, 94, 114, 10, 77, 18, 83, 86, 60, 119};
   }

   private static byte[] iqopwhprxdrlkqd() {
      return new byte[]{-82, -38, 21, 34, 104, 22, 46, 49, 11, 13, 75, 69, 117, 55, 93, 18, 117, 96, 69, 117, 85, 89, 39, 36, 13, 68, 38, 9, 39, 104, 127, 116, 12, 66, 114, 10, 77, 93, 83, 70, 60, 122, 118, 25, 92, 12, 82, 18, 72, 124};
   }

   private static byte[] squtsxwvmhjfhws() {
      return new byte[]{-82, -42, 20, 119, 106, 58, 36, 8, 9, 59, 75, 38, 116, 21, 95, 53, 127, 107, 71, 112, 85, 98, 38, 47, 15, 72, 44, 71, 37, 116, 127, 55, 13, 25, 112, 15, 71, 8, 81, 95};
   }

   private static byte[] zvpjriucunyhlvz() {
      return new byte[]{-82, -42, 20, 32, 106, 30, 36, 49, 9, 14, 75, 73, 116, 53, 95, 26, 127, 96, 71, 118, 85, 119, 38, 36, 15, 5, 44, 3, 37, 116, 127, 61, 13, 89, 112, 77, 71, 9, 81, 73, 60, 62, 119, 22, 94, 30, 88, 24};
   }

   private static byte[] dhsgpzkmegcmefp() {
      return new byte[]{-90, -45, 19, 115, 109, 58, 44, 13, 4, 60, 72, 37, 112, 14, 89, 39, 126, 44, 65, 123, 85, 126, 35, 99, 0, 65, 38, 6, 32, 97, 126, 62};
   }

   private static byte[] qvvyqukzajvxpsf() {
      return new byte[]{-90, -45, 19, 36, 109, 110, 44, 66, 4, 46, 72, 104, 112, 78, 89, 102, 126, 97, 65, 56, 85, 61, 35, 40, 0, 8, 38, 31, 32, 125, 126, 50, 1, 85, 116, 6, 78, 83};
   }

   private static byte[] medspnhavcayjyg() {
      return new byte[]{-90, -45, 19, 34, 109, 47, 44, 7, 4, 33, 72, 104, 112, 27, 89, 112};
   }

   private static byte[] sybzpjwnfaczwyf() {
      return new byte[]{-83, -46, 20, 118, 101, 51, 37, 12, 8, 60, 72, 34, 116, 27, 80, 61, 126, 111, 70, 114, 86, 123, 38, 56, 0, 88, 45, 7, 36, 105, 124, 59, 13, 70};
   }

   private static byte[] vuhdjhrsnfrfbly() {
      return new byte[]{-83, -46, 20, 36, 101, 53, 37, 58, 8, 39, 72, 44, 116, 25, 80, 59, 126, 49, 70, 106, 86, 123, 38, 37, 0, 75, 45, 29};
   }

   private static byte[] izftjorbicnuwyu() {
      return new byte[]{-82, -42, 25, 114, 111, 54, 42, 12, 4, 59, 75, 38, 121, 8, 90, 56, 113, 55, 74, 52, 85, 113, 43, 42, 10, 93, 34, 67, 40, 108, 127, 49, 0, 95, 117, 4};
   }

   private static byte[] pgctczoslxljzhg() {
      return new byte[]{-82, -42, 25, 32, 111, 100, 42, 45, 4, 32, 75, 125, 121, 81, 90, 48, 113, 39, 74, 109, 85, 44, 43, 111, 10, 15, 34, 8, 40, 120, 127, 125, 0, 80, 117, 12, 73, 22, 92, 83, 60, 112, 122, 5, 91, 66};
   }

   private static byte[] csojljvhqfnxshy() {
      return new byte[]{-82, -42, 25, 35, 111, 50, 42, 25, 4, 32, 75, 125, 121, 31, 90, 35, 113, 103};
   }

   private static byte[] kalmhzrakcdgfwr() {
      return new byte[]{-82, -37, 23, 118, 101, 55, 47, 2, 11, 56, 75, 43, 119, 22, 80, 58, 116, 37, 69, 121, 85, 112, 37, 102, 0, 92, 39, 15, 39, 46, 127, 52, 14, 81, 127, 4, 76, 90, 83, 71, 60, 114, 116, 22, 81, 13};
   }

   private static byte[] ukutjljqtmhyfcn() {
      return new byte[]{-82, -37, 23, 36, 101, 101, 47, 92, 11, 35, 75, 70, 119, 25, 80, 63, 116, 47, 69, 113, 85, 59, 37, 63, 0, 71, 39, 64, 39, 98, 127, 49, 14, 81, 127, 64, 76, 21, 83, 68, 60, 112, 116, 30};
   }

   private static byte[] xlfwxgxtzfcvwzi() {
      return new byte[]{-82, -46, 25, 116, 105, 54, 45, 2, 14, 63, 75, 34, 121, 20, 92, 59, 118, 37, 64, 126, 85, 121, 43, 100, 12, 93, 37, 15, 34, 41, 127, 46, 0, 82, 115, 12, 78, 24, 86, 84, 60, 127};
   }

   private static byte[] pbylaycpxcfuqeo() {
      return new byte[]{-82, -46, 25, 38, 105, 100, 45, 92, 14, 36, 75, 79, 121, 27, 92, 62, 118, 47, 64, 118, 85, 50, 43, 61, 12, 70, 37, 64, 34, 118, 127, 57, 0, 90, 115, 14, 78, 1, 86, 71};
   }

   private static byte[] piprbckeqnztrpa() {
      return new byte[]{-83, -46, 17, 46, 111, 97, 42, 80, 10, 38, 72, 79, 113, 19, 90, 59, 113, 35, 68, 116, 86, 50, 35, 53, 10, 67, 34, 76, 38, 99, 124, 56, 8, 86, 117, 16};
   }

   private static byte[] bnkwowrkeifaole() {
      return new byte[]{-89, -41, 25, 107, 110, 55, 37, 5, 4, 108, 79, 101, 116, 0, 93, 56, 119, 57, 75, 115, 92, 120, 33, 35, 0, 75, 45, 21, 36, 103};
   }

   private static byte[] ylnpzkizwlepaqb() {
      return new byte[]{-83, -46, 23, 100, 108, 58, 36, 29, 5, 58};
   }

   private static byte[] vovtfrkpgdushcj() {
      return new byte[]{-83, -46, 23, 117, 108, 59, 36, 12, 5, 58, 72, 34, 119, 19, 89, 62, 127, 43, 75, 108};
   }

   private static byte[] pamywmrmsgdqcit() {
      return new byte[]{-83, -46, 23, 39, 108, 56, 36, 49, 5, 42, 72, 101, 119, 2};
   }

   private static byte[] nhcqntyrldicnbd() {
      return new byte[]{-82, -42, 24, 96, 110, 58, 47, 24, 12, 57};
   }

   private static byte[] jhwdijgixbeetcm() {
      return new byte[]{-90, -45, 22, 35, 109, 96, 44, 85, 9, 47, 75, 72, 116, 26, 88, 59, 118, 35, 74, 117, 83, 55, 34, 60, 9, 66, 32, 65, 32, 114, 123, 60, 9, 65, 119, 5, 70, 94, 82, 70, 60, 115, 114, 23, 92, 5, 81, 3, 75, 120, 64, 123};
   }

   private static byte[] nfagdlevslunetc() {
      return new byte[]{-82, -37, 19, 112, 104, 32, 46, 3, 12, 44, 75, 109, 115, 22, 93, 34, 117, 34, 66, 52, 85, 104, 33, 60, 13, 76, 38, 8, 32, 101, 127, 38, 10, 68};
   }

   private static byte[] vpkkxffuahnjfjs() {
      return new byte[]{-82, -37, 19, 69, 104, 27, 46, 37, 12, 6, 75, 81, 115, 46, 93, 14, 117, 23, 66, 85, 85, 90, 33, 16, 13, 106, 38, 57, 32, 95, 127, 25, 10, 114, 114, 49, 77, 57, 84, 106, 60, 70, 112, 39};
   }

   private static byte[] vwzfzgwjllyipkc() {
      return new byte[]{-88, -38, 16, 101, 108, 53, 37, 29, 12, 55};
   }

   private static byte[] dplzyymobhbkdug() {
      return new byte[]{-88, -38, 16, 68, 108, 30, 37, 39, 12, 7, 66, 89, 112, 46, 95, 4, 118, 19, 68, 94, 85, 95, 35, 3, 0, 108, 37, 40, 41, 66, 127, 14, 14, 97, 119, 43, 72, 56};
   }

   private static int boiqzfwkwayfvesb(int var0, int var1) {
      return var1 ^ var0;
   }
}
