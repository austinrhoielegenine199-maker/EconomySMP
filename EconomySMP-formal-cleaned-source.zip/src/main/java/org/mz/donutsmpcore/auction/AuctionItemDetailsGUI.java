package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.BlockState;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import skido.KKoOK;
import skido.o0o0oOKo0K;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;

public class AuctionItemDetailsGUI implements KKoOK {
   private final Player player;
   private final ItemStack shulkerItem;
   private final AuctionGUI returnGui;
   private Inventory inventory;
   private static String dvbpuwsvrv;

   private static o0o0oOKo0K cfg() {
      int var4 = 833877326 ^ 1677521401 ^ 1577895404;
      var4 = 697711446 ^ var4;
      String var0 = azksttbgae(ycjudjfcmwmttie(), var4);
      o0o0oOKo0K var1 = o0o0oOKo0K.of(var0);
      return var1;
   }

   public AuctionItemDetailsGUI(Player var1, ItemStack var2, AuctionGUI var3) {
      this.player = var1;
      this.shulkerItem = var2;
      this.returnGui = var3;
   }

   public void open() {
      int var26 = 1700526469 ^ 2024895253 ^ 483010696;
      var26 = 1556306701 ^ var26;
      Object var2 = null;
      InventoryHolder var12 = (InventoryHolder)var2;
      o0o0oOKo0K var3 = cfg();
      String var4 = azksttbgae(boupyirhjvvfumo(), var26);
      byte var5 = (byte)(1575221553 ^ var26);
      int var18 = var3.intAt(var4, var5);
      o0o0oOKo0K var20 = cfg();
      String var23 = azksttbgae(rapdgbtzjyvomyb(), var26);
      String var6 = azksttbgae(yrilrwgrzagqrny(), var26);
      String var21 = var20.rawStr(var23, var6);
      String var22 = oOo0KKoOoOK.color(var21);
      Inventory var13 = Bukkit.createInventory(var12, var18, var22);
      this.inventory = var13;
      var26 = 205387823 ^ var26;
      oOoOKo0o0K var7 = oOoOKo0o0K.getInstance();
      Inventory var15 = this.inventory;
      var7.register(var15, this);
      var26 = 1577745095 ^ var26;
      this.decorate();
      var26 = 1065125051 ^ var26;
      Player var10 = this.player;
      Inventory var17 = this.inventory;
      var10.openInventory(var17);
      var26 = 1041495500 ^ var26;
   }

   public void decorate() {
      int var61 = 87406309 ^ 1011251746 ^ 483010696;
      var61 = 1109373277 ^ var61;
      Inventory var12 = this.inventory;
      var12.clear();
      var61 = 68989688 ^ var61;
      ItemStack var14 = this.shulkerItem;
      ItemMeta var15 = var14.getItemMeta();
      var61 = 1174624034 ^ var61;
      byte var17 = var15 instanceof BlockStateMeta;
      if (var17 != (632926408 ^ var61)) {
         var61 = 848034839 ^ var61;
         BlockStateMeta var19 = (BlockStateMeta)var15;
         var61 = 744192347 ^ var61;
         BlockState var21 = var19.getBlockState();
         var61 = 2033231995 ^ var61;
         byte var23 = var21 instanceof ShulkerBox;
         if (var23 != (1113169407 ^ var61)) {
            var61 = 1931540630 ^ var61;
            ShulkerBox var25 = (ShulkerBox)var21;
            ShulkerBox var8 = var25;
            var61 = 1003502722 ^ var61;
            byte var26 = (byte)(178870763 ^ var61);
            int var9 = var26;
            var61 = 1987760473 ^ var61;

            while(true) {
               byte var2 = (byte)(2094237865 ^ var61);
               if (var9 >= var2) {
                  var61 = qeedkjmruunxqtfy(var61, 738708246);
                  break;
               }

               var61 = 2081365810 ^ var61;
               Inventory var29 = var8.getInventory();
               ItemStack var30 = var29.getItem(var9);
               var61 = 387879460 ^ var61;
               if (var30 != null) {
                  var61 = 341809681 ^ var61;
                  ItemStack var33 = var30.clone();
                  var61 = 302661911 ^ var61;
                  Object var46 = null;
                  List var47 = (List)var46;
                  var33.setLore(var47);
                  var61 = 1844572705 ^ var61;
                  Inventory var36 = this.inventory;
                  var36.setItem(var9, var33);
                  var61 = 632456496 ^ var61;
               } else {
                  label45:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var61)) {
                        case 235404591:
                           var61 ^= 1310108695;
                           break label45;
                        case 958513970:
                        default:
                           throw new RuntimeException();
                        case 1154936538:
                           break label45;
                        case 1877535053:
                     }
                  }
               }

               var9 += 1507109298 ^ var61;
               var61 = 621224193 ^ var61;
            }
         } else {
            label29:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var61)) {
                  case 9297991:
                     var61 ^= 311287387;
                  case 235007702:
                     break label29;
                  case 695423643:
                     break;
                  case 1986995064:
                  default:
                     throw new RuntimeException();
               }
            }
         }
      } else {
         var61 = 1970140012 ^ var61;
      }

      Material var54 = Material.RED_STAINED_GLASS_PANE;
      ItemStack var37 = new ItemStack(var54);
      var61 = 1374447301 ^ var61;
      ItemMeta var39 = var37.getItemMeta();
      var61 = 2054326907 ^ var61;
      o0o0oOKo0K var49 = cfg();
      String var55 = azksttbgae(rjuskbfngqrvmrk(), var61);
      String var4 = azksttbgae(rosfjwvpgrqfofa(), var61);
      String var50 = var49.rawStr(var55, var4);
      String var51 = oOo0KKoOoOK.color(var50);
      var39.setDisplayName(var51);
      var61 = 323579174 ^ var61;
      var37.setItemMeta(var39);
      var61 = 551588268 ^ var61;
      Inventory var44 = this.inventory;
      byte var53 = (byte)(1222857611 ^ var61);
      var44.setItem(var53, var37);
      var61 = 785762778 ^ var61;
   }

   public void onClick(InventoryClickEvent var1) {
      int var11 = 1487738209 ^ 644413717 ^ 483010696;
      var11 = 1658177740 ^ var11;
      byte var3 = (byte)(14289969 ^ var11);
      var1.setCancelled((boolean)var3);
      var11 = 1117872986 ^ var11;
      int var5 = var1.getRawSlot();
      byte var8 = (byte)(1115385713 ^ var11);
      if (var5 == var8) {
         var11 = 1659791088 ^ var11;
         AuctionGUI var7 = this.returnGui;
         var7.open();
         var11 = 1818797570 ^ var11;
      } else {
         var11 = qeedkjmruunxqtfy(var11, 243712242);
      }

   }

   public Inventory createInventory() {
      int var4 = 860304446 ^ 1345137615 ^ 483010696;
      var4 = 1240422453 ^ var4;
      Object var1 = null;
      return (Inventory)var1;
   }

   public static String azksttbgae(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = dvbpuwsvrv;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] ycjudjfcmwmttie() {
      return new byte[]{0, 0, 0, 30, 0, 0, 0, 0};
   }

   private static byte[] boupyirhjvvfumo() {
      return new byte[]{0, 0, 0, 4, 0, 0, 0, 30};
   }

   private static byte[] rapdgbtzjyvomyb() {
      return new byte[]{0, 0, 0, 5, 0, 0, 0, 34};
   }

   private static byte[] yrilrwgrzagqrny() {
      return new byte[]{0, 0, 0, 15, 0, 0, 0, 39};
   }

   private static byte[] rjuskbfngqrvmrk() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, 54};
   }

   private static byte[] rosfjwvpgrqfofa() {
      return new byte[]{0, 0, 0, 11, 0, 0, 0, 63};
   }

   static {
      dvbpuwsvrv = ByteBuffer.wrap(bheembkpdlxdyth()).asCharBuffer().toString();
   }

   private static byte[] bheembkpdlxdyth() {
      return new byte[]{54, 84, 52, 66, 56, 89, 49, 68, 51, 25, 51, 85, 55, 77, 48, 82, 55, 71, 54, 90, 52, 88, 56, 94, 49, 24, 51, 69, 51, 92, 55, 77, 48, 93, 55, 88, 54, 86, 52, 69, 56, 64, 49, 69, 51, 83, 51, 66, 55, 81, 48, 84, 55, 68, 54, 84, 52, 66, 56, 89, 49, 70, 55, 92, 50, 72, 49, 80, 49, 65, 55, 92, 50, 70, 49, 89, 50, 80, 49, 102, 55, 93, 50, 71, 49, 89, 50, 94, 49, 80, 55, 71, 50, 18, 49, 101, 50, 71, 49, 80, 55, 67, 50, 91, 49, 80, 50, 66, 50, 68, 54, 93, 52, 65, 50, 68, 53, 22, 50, 82, 54, 89, 52, 90, 50, 91, 50, 19, 54, 126, 52, 127, 50, 1, 53, 124, 50, 1, 54, 124, 54, -96, 47, 48, 40, 60, 47, 59};
   }

   private static int qeedkjmruunxqtfy(int var0, int var1) {
      return var0 ^ var1;
   }
}
