package org.mz.donutsmpcore.auction;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.mz.donutsmpcore.DonutSMPCore;
import org.mz.donutsmpcore.libs.signgui.SignGUI;
import org.mz.donutsmpcore.libs.signgui.SignGUIBuilder;
import org.mz.donutsmpcore.libs.signgui.SignGUIFinishHandler;
import org.mz.donutsmpcore.libs.signgui.exception.SignGUIVersionException;
import skido.KKoOoOo0oOK;
import skido.KoOKKo0K;
import skido.o0KoOKKo0K;
import skido.o0KoOo0KoOK;
import skido.o0o0oOKo0K;
import skido.oOo0KKoOoOK;
import skido.oOoOo0oOKoOK;
import skido.oOoOoOoOo0K;

public class AuctionPageNavigation extends KoOKKo0K {
   private static final int PER_PAGE = 45;
   private static final String[] SORTS;
   private static final String[] FILTERS;
   private final int targetSlot;
   private final int page;
   private final String sort;
   private final String filter;
   private final String search;
   private List<oOoOoOoOo0K.K> filtered;

   private static o0o0oOKo0K cfg() {
      int var4 = 149948842 ^ 431596714 ^ 712623840;
      var4 = 1831050385 ^ var4;
      String var0 = hjdzjnvfmu(hurymdbeedgncoh(), sifccttswzxerec(), var4);
      o0o0oOKo0K var1 = o0o0oOKo0K.of(var0);
      return var1;
   }

   public AuctionPageNavigation(Player var1, int var2, int var3, String var4, String var5, String var6) {
      o0o0oOKo0K var9 = cfg();
      String var10 = "size";
      byte var11 = 54;
      int var32 = var9.intAt(var10, var11);
      o0o0oOKo0K var34 = cfg();
      String var37 = "title";
      String var12 = "Select Item";
      String var35 = var34.rawStr(var37, var12);
      String var36 = oOo0KKoOoOK.color(var35);
      super(var1, var32, var36);
      this.targetSlot = var2;
      byte var20 = 1;
      int var21 = Math.max(var20, var3);
      this.page = var21;
      String var30;
      if (var4 == null) {
         var30 = "A-Z";
      } else {
         var30 = var4;
      }

      this.sort = var30;
      String var24;
      if (var5 == null) {
         var24 = "All";
      } else {
         var24 = var5;
      }

      this.filter = var24;
      String var31;
      if (var6 == null) {
         var31 = "";
      } else {
         String var29 = var6.trim();
         var31 = var29.toLowerCase();
      }

      this.search = var31;
      List var27 = this.compute();
      this.filtered = var27;
   }

   public void decorate() {
      int var126 = 535929058 ^ 1958309511 ^ 1235333502;
      var126 = 205853829 ^ var126;
      Inventory var13 = this.inventory;
      var13.clear();
      var126 = 366394557 ^ var126;
      Map var15 = this.buttons;
      var15.clear();
      var126 = 951034412 ^ var126;
      int var17 = this.page;
      byte var2 = (byte)(64320782 ^ var126);
      int var18 = var17 - var2;
      byte var52 = (byte)(64320802 ^ var126);
      int var19 = var18 * var52;
      int var7 = var19;
      var126 = 1268684368 ^ var126;
      byte var53 = (byte)(1212932978 ^ var126);
      int var21 = var19 + var53;
      List var55 = this.filtered;
      int var56 = var55.size();
      int var22 = Math.min(var21, var56);
      int var8 = var22;
      var126 = 1367228376 ^ var126;
      int var9 = var19;
      var126 = 835223782 ^ var126;

      label117:
      while(true) {
         if (var9 < var8) {
            var126 = 196773157 ^ var126;
            List var26 = this.filtered;
            Object var27 = var26.get(var9);
            oOoOoOoOo0K.K var28 = (oOoOoOoOo0K.K)var27;
            var126 = 1069359045 ^ var126;
            Material var82 = var28.material;
            ItemStack var29 = new ItemStack(var82);
            var126 = 1599492086 ^ var126;
            ItemMeta var31 = var29.getItemMeta();
            var126 = 176830666 ^ var126;
            if (var31 != null) {
               var126 = 2118241337 ^ var126;
               String var60 = var28.displayName;
               String var61 = "#FFFFFF" + var60;
               String var62 = oOo0KKoOoOK.color(var61);
               var31.setDisplayName(var62);
               var126 = 633370111 ^ var126;
               o0o0oOKo0K var63 = cfg();
               String var83 = hjdzjnvfmu(wibhbkcuyajhjjl(), sifccttswzxerec(), var126);
               String var4 = hjdzjnvfmu(ouovtvioijwxqut(), sifccttswzxerec(), var126);
               String var64 = var63.rawStr(var83, var4);
               String var65 = oOo0KKoOoOK.color(var64);
               List var66 = Collections.singletonList(var65);
               var31.setLore(var66);
               var126 = 113482206 ^ var126;
               var29.setItemMeta(var31);
               var126 = 846152600 ^ var126;
            } else {
               label71:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var126)) {
                     case 230338936:
                        var126 ^= 1865245568;
                        break label71;
                     case 861232699:
                        break;
                     case 957772846:
                     default:
                        throw new IOException();
                     case 1703114311:
                        break label71;
                  }
               }
            }

            int var69 = var9 - var7;
            o0KoOKKo0K var85 = new o0KoOKKo0K();
            o0KoOKKo0K var86 = var85.item(var29);
            Consumer var105 = (var2x) -> {
               int var8 = 728569873 ^ 607747182 ^ 1235333502;
               var8 = 1016807826 ^ var8;
               Material var5 = var28.material;
               this.askAmount(var5);
            };
            o0KoOKKo0K var87 = var86.consumer(var105);
            this.addButton(var69, var87);
            var126 = 945872078 ^ var126;
            var9 += 510332658 ^ var126;

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var126)) {
                  case 183464605:
                     var126 ^= 915821202;
                     continue label117;
                  case 569606551:
                  default:
                     throw new IOException();
                  case 757006780:
                     continue label117;
                  case 1107932971:
               }
            }
         }

         label111:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var126)) {
               case 242591854:
               default:
                  throw new IOException();
               case 258656774:
                  var126 ^= 1240930710;
                  break label111;
               case 1560340751:
                  break;
               case 1869143470:
                  break label111;
            }
         }

         o0o0oOKo0K var70 = cfg();
         String var88 = hjdzjnvfmu(wadouwprhgdbrcv(), sifccttswzxerec(), var126);
         byte var106 = (byte)(1628063175 ^ var126);
         int var71 = var70.slot(var88, var106);
         o0KoOKKo0K var90 = this.sortButton();
         this.addButton(var71, var90);
         var126 = 1661379421 ^ var126;
         o0o0oOKo0K var72 = cfg();
         String var91 = hjdzjnvfmu(fvkgahjjnvoaglu(), sifccttswzxerec(), var126);
         byte var107 = (byte)(34399899 ^ var126);
         int var73 = var72.slot(var91, var107);
         o0KoOKKo0K var93 = this.filterButton();
         this.addButton(var73, var93);
         var126 = 1339331715 ^ var126;
         o0o0oOKo0K var74 = cfg();
         String var94 = hjdzjnvfmu(rtraxcdbvwklxyy(), sifccttswzxerec(), var126);
         byte var108 = (byte)(1306030619 ^ var126);
         int var75 = var74.slot(var94, var108);
         o0KoOKKo0K var96 = this.searchButton();
         this.addButton(var75, var96);
         var126 = 1175967834 ^ var126;
         List var77 = this.filtered;
         int var78 = var77.size();
         byte var51;
         if (var8 < var78) {
            var126 = 747555381 ^ var126;
            var51 = (byte)(658595911 ^ var126);

            label99:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var126)) {
                  case 83178605:
                     break label99;
                  case 202280390:
                     var126 ^= 1459424839;
                     break label99;
                  case 1536769561:
                  default:
                     throw new IOException();
                  case 2055205454:
               }
            }
         } else {
            var126 = gugjtlrrkosehmrg(var126, 840236423);
            var51 = (byte)(970676212 ^ var126);
            var126 = 1214724597 ^ var126;
         }

         var126 = 1556649646 ^ var126;
         int var43 = this.page;
         byte var79 = (byte)(762640558 ^ var126);
         byte var44;
         if (var43 > var79) {
            var126 = 557828393 ^ var126;
            var44 = (byte)(206254471 ^ var126);
            var126 = 503383354 ^ var126;
         } else {
            var126 = 513681324 ^ var126;
            var44 = (byte)(871030531 ^ var126);
            var126 = 564194239 ^ var126;
         }

         label88: {
            var126 = 1172939185 ^ var126;
            if (var51 == (1470338317 ^ var126)) {
               var126 = 707655986 ^ var126;
               byte var46 = o0KoOo0KoOK.always();
               if (var46 == (2106485823 ^ var126)) {
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var126)) {
                        case 54758452:
                           var126 ^= 1912209732;
                        case 717444854:
                           break label88;
                        case 968865076:
                           break;
                        case 1402362605:
                        default:
                           throw new IOException();
                     }
                  }
               }

               var126 = 764597275 ^ var126;
            } else {
               var126 = 129969449 ^ var126;
            }

            byte var80 = (byte)(1344059409 ^ var126);
            o0KoOKKo0K var97 = new o0KoOKKo0K();
            String var117 = hjdzjnvfmu(uztmbfothfvkouv(), sifccttswzxerec(), var126);
            String var6 = hjdzjnvfmu(vjgglmfzvlrwact(), sifccttswzxerec(), var126);
            ItemStack var110 = this.nav(var117, var6);
            o0KoOKKo0K var98 = var97.item(var110);
            Consumer var112 = (var2x) -> {
               int var19 = 1353708560 ^ 1585047223 ^ 1235333502;
               var19 = 1070905120 ^ var19;
               if (var51 == (2023953657 ^ var19)) {
                  var19 = 1374282790 ^ var19;
                  Player var9 = this.player;
                  o0KoOo0KoOK.edge(var9);
               } else {
                  var19 = gugjtlrrkosehmrg(var19, 328808828);
                  int var11 = this.page;
                  byte var5 = (byte)(1798974852 ^ var19);
                  int var12 = var11 + var5;
                  String var14 = this.sort;
                  String var15 = this.filter;
                  String var16 = this.search;
                  this.open(var12, var14, var15, var16);
                  var19 = 1592516058 ^ var19;
               }
            };
            var126 = 234265468 ^ var126;
            o0KoOKKo0K var99 = var98.consumer(var112);
            var126 = 894798582 ^ var126;
            this.addButton(var80, var99);
            var126 = 1691075797 ^ var126;
         }

         if (var44 == (208956795 ^ var126)) {
            var126 = 1561468307 ^ var126;
            byte var49 = o0KoOo0KoOK.always();
            if (var49 == (1365668072 ^ var126)) {
               var126 = 1555469279 ^ var126;
               return;
            }

            var126 = 1324517116 ^ var126;
         } else {
            var126 = 333486959 ^ var126;
         }

         byte var81 = (byte)(529856057 ^ var126);
         o0KoOKKo0K var100 = new o0KoOKKo0K();
         String var119 = hjdzjnvfmu(yjkczgkgpicjdom(), sifccttswzxerec(), var126);
         String var121 = hjdzjnvfmu(aznuhitpouhfjlp(), sifccttswzxerec(), var126);
         ItemStack var114 = this.nav(var119, var121);
         o0KoOKKo0K var101 = var100.item(var114);
         Consumer var116 = (var2x) -> {
            int var19 = 678714293 ^ 511065166 ^ 1235333502;
            var19 = 1656135846 ^ var19;
            if (var44 == (487945763 ^ var19)) {
               var19 = 598832643 ^ var19;
               Player var10 = this.player;
               o0KoOo0KoOK.edge(var10);
            } else {
               var19 = gugjtlrrkosehmrg(var19, 942785226);
               int var11 = this.page;
               byte var5 = (byte)(623162600 ^ var19);
               int var12 = var11 - var5;
               String var14 = this.sort;
               String var15 = this.filter;
               String var16 = this.search;
               this.open(var12, var14, var15, var16);
               var19 = 1806836460 ^ var19;
            }
         };
         var126 = 1807920659 ^ var126;
         o0KoOKKo0K var102 = var101.consumer(var116);
         var126 = 1559011599 ^ var126;
         this.addButton(var81, var102);
         var126 = 627710527 ^ var126;
         return;
      }
   }

   private void open(int var1, String var2, String var3, String var4) {
      int var16 = 878971687 ^ 1484508034 ^ 1235333502;
      var16 = 1570127626 ^ var16;
      Player var12 = this.player;
      int var13 = this.targetSlot;
      AuctionPageNavigation var5 = new AuctionPageNavigation(var12, var13, var1, var2, var3, var4);
      var5.open();
      var16 = 771144477 ^ var16;
   }

   private void askAmount(Material var1) {
      int var36 = 1252697230 ^ 1126379679 ^ 1235333502;
      var36 = 1876811869 ^ var36;
      Player var7 = this.player;
      var7.closeInventory();
      var36 = 1736187009 ^ var36;

      try {
         SignGUIBuilder var8 = SignGUI.builder();
         Material var3 = Material.OAK_SIGN;
         SignGUIBuilder var9 = var8.setType(var3);
         byte var16 = (byte)(1216993719 ^ var36);
         String[] var17 = new String[var16];
         byte var4 = (byte)(1216993715 ^ var36);
         String var5 = hjdzjnvfmu(oahqubpbnuxjlzs(), sifccttswzxerec(), var36);
         var17[var4] = var5;
         byte var28 = (byte)(1216993714 ^ var36);
         String var31 = hjdzjnvfmu(jqlczueuamyqnwz(), sifccttswzxerec(), var36);
         var17[var28] = var31;
         byte var29 = (byte)(1216993713 ^ var36);
         String var32 = hjdzjnvfmu(uavuhenmwnvpkou(), sifccttswzxerec(), var36);
         var17[var29] = var32;
         byte var30 = (byte)(1216993712 ^ var36);
         String var33 = hjdzjnvfmu(gncizluzbqstqjo(), sifccttswzxerec(), var36);
         var17[var30] = var33;
         SignGUIBuilder var10 = var9.setLines(var17);
         SignGUIFinishHandler var19 = (var2, var3x) -> {
            int var38 = 1020830507 ^ 923293946 ^ 1235333502;
            var38 = 1571512950 ^ var38;
            byte var5 = (byte)(534391001 ^ var38);
            String var12 = var3x.getLineWithoutColor(var5);
            String var13 = var12.trim();
            String var9 = var13;
            var38 = 1273473514 ^ var38;
            byte var14 = (byte)(1413316979 ^ var38);
            int var10 = var14;
            var38 = 2016423142 ^ var38;

            label31: {
               try {
                  String var26 = hjdzjnvfmu(rrxoqpcygnaceqz(), sifccttswzxerec(), var38);
                  String var6 = hjdzjnvfmu(ibiafauqlmyshoa(), sifccttswzxerec(), var38);
                  String var16 = var9.replaceAll(var26, var6);
                  int var17 = Integer.parseInt(var16);
                  var38 = 294800962 ^ var38;
                  var10 = var17;
                  var38 = 1739749994 ^ var38;
               } catch (NumberFormatException var39) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var38)) {
                     case -318825287 -> var38 = gugjtlrrkosehmrg(var38, 862673643);
                     case 1617784489 -> var38 = gugjtlrrkosehmrg(var38, 586749097);
                     default -> throw new RuntimeException("Error in hash");
                  }

                  var38 = 1838105042 ^ var38;
                  break label31;
               }

               var38 = gugjtlrrkosehmrg(var38, 961962323);
            }

            byte var27 = (byte)(1669068975 ^ var38);
            if (var10 < var27) {
               var38 = 244045435 ^ var38;
               byte var20 = (byte)(1844457172 ^ var38);
               var10 = var20;
               var38 = 1443494774 ^ var38;
            } else {
               var38 = 1484926221 ^ var38;
            }

            byte var28 = (byte)(1006228963 ^ var38);
            if (var10 > var28) {
               var38 = 738014313 ^ var38;
               byte var22 = (byte)(268755338 ^ var38);
               var10 = var22;
               var38 = 1011658726 ^ var38;
            } else {
               var38 = 397515663 ^ var38;
            }

            oOoOKo0oOK var23 = oOoOKo0oOK.getInstance();
            UUID var30 = var2.getUniqueId();
            int var33 = this.targetSlot;
            var23.set(var30, var33, var1, var10);
            var38 = 472466051 ^ var38;
            KKoOoOo0oOK var24 = KKoOoOo0oOK.getInstance();
            Runnable var35 = () -> {
               int var5 = 907139348 ^ 714694054 ^ 712623840;
               var5 = 984781301 ^ var5;
               AuctionItemSearchGUI var1 = new AuctionItemSearchGUI(var2);
               var1.open();
            };
            var24.runAtEntity(var2, var35);
            var38 = 1520693726 ^ var38;
            List var25 = Collections.emptyList();
            return var25;
         };
         SignGUIBuilder var11 = var10.setHandler(var19);
         var36 = 2057420019 ^ var36;
         DonutSMPCore var20 = DonutSMPCore.getInstance();
         SignGUIBuilder var12 = var11.callHandlerSynchronously(var20);
         SignGUI var13 = var12.build();
         Player var22 = this.player;
         var13.open(var22);
         var36 = 1846251867 ^ var36;
      } catch (SignGUIVersionException var37) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var36)) {
            case -1857869311 -> var36 = 17309657 ^ var36;
            case 1146015130 -> var36 = 2074714922 ^ var36;
            default -> throw new IllegalAccessException("Error in hash");
         }

         var36 = 24538894 ^ var36;
         KKoOoOo0oOK var15 = KKoOoOo0oOK.getInstance();
         Player var24 = this.player;
         Runnable var27 = () -> {
            int var6 = 173697339 ^ 1878991040 ^ 1235333502;
            var6 = 1481905420 ^ var6;
            Player var3 = this.player;
            AuctionItemSearchGUI var1 = new AuctionItemSearchGUI(var3);
            var1.open();
         };
         var15.runAtEntity(var24, var27);
         var36 = 861777093 ^ var36;
         return;
      }

      var36 = 1562922313 ^ var36;
   }

   private o0KoOKKo0K sortButton() {
      int var73 = 689779605 ^ 424717458 ^ 1235333502;
      var73 = 526586571 ^ var73;
      o0o0oOKo0K var2 = cfg();
      String var3 = hjdzjnvfmu(cpphfxsusakjcae(), sifccttswzxerec(), var73);
      Material var4 = Material.CAULDRON;
      Material var53 = var2.material(var3, var4);
      ItemStack var1 = new ItemStack(var53);
      var73 = 1314356477 ^ var73;
      ItemMeta var14 = var1.getItemMeta();
      var73 = 547298653 ^ var73;
      o0o0oOKo0K var35 = cfg();
      String var54 = hjdzjnvfmu(nbyprfdryaxperd(), sifccttswzxerec(), var73);
      String var63 = hjdzjnvfmu(ydladiehaqsophd(), sifccttswzxerec(), var73);
      String var36 = var35.rawStr(var54, var63);
      String var37 = oOo0KKoOoOK.color(var36);
      var14.setDisplayName(var37);
      var73 = 1469949084 ^ var73;
      ArrayList var16 = new ArrayList();
      ArrayList var8 = var16;
      var73 = 1964728119 ^ var73;
      String[] var17 = SORTS;
      String[] var9 = var17;
      int var19 = var17.length;
      int var10 = var19;
      byte var20 = (byte)(717334201 ^ var73);
      int var11 = var20;
      var73 = 583765688 ^ var73;

      label47:
      while(true) {
         if (var11 < var10) {
            int var83 = 433347451 ^ var73;
            String var23 = var9[var11];
            int var84 = 1977787000 ^ var83;
            String var65 = this.sort;
            boolean var56 = var23.equals(var65);
            o0o0oOKo0K var66 = cfg();
            String var69 = "sort.labels." + var23;
            String var67 = var66.rawStr(var69, var23);
            String var41 = this.optionLine(var56, var67);
            String var42 = oOo0KKoOoOK.color(var41);
            boolean var25 = var8.add(var42);
            var73 = 71648994 ^ var84;
            var11 += 1618581473 ^ var73;

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var73)) {
                  case 183236155:
                     var73 ^= 1752416225;
                     continue label47;
                  case 490572456:
                  default:
                     throw new IOException();
                  case 620976785:
                     break;
                  case 1601285737:
                     continue label47;
               }
            }
         } else {
            label40:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var73)) {
                  case 72088126:
                     break label40;
                  case 126455178:
                     var73 ^= 1637441800;
                     break label40;
                  case 310677343:
                     break;
                  case 610469261:
                  default:
                     throw new IOException();
               }
            }
         }

         var14.setLore(var8);
         var73 = 1682408077 ^ var73;
         var1.setItemMeta(var14);
         var73 = 1074507882 ^ var73;
         String[] var29 = SORTS;
         String[] var45 = SORTS;
         String var58 = this.sort;
         int var46 = indexOf(var45, var58);
         byte var59 = (byte)(1306491887 ^ var73);
         int var47 = var46 + var59;
         String[] var60 = SORTS;
         int var61 = var60.length;
         int var48 = var47 % var61;
         String var30 = var29[var48];
         var73 = 2050378763 ^ var73;
         o0KoOKKo0K var31 = new o0KoOKKo0K();
         o0KoOKKo0K var32 = var31.item(var1);
         String var50 = hjdzjnvfmu(ipmowfrlcilfeny(), sifccttswzxerec(), var73);
         o0KoOKKo0K var33 = var32.filterSound(var50);
         Consumer var52 = (var2x) -> {
            int var12 = 26270506 ^ 1508164770 ^ 1235333502;
            var12 = 1381305287 ^ var12;
            byte var4 = (byte)(1132504368 ^ var12);
            String var8 = this.filter;
            String var9 = this.search;
            this.open(var4, var30, var8, var9);
         };
         o0KoOKKo0K var34 = var33.consumer(var52);
         return var34;
      }
   }

   private o0KoOKKo0K filterButton() {
      int var73 = 395239070 ^ 721668001 ^ 1235333502;
      var73 = 1673104275 ^ var73;
      o0o0oOKo0K var2 = cfg();
      String var3 = hjdzjnvfmu(gtbcjwbyapbujyp(), sifccttswzxerec(), var73);
      Material var4 = Material.HOPPER;
      Material var53 = var2.material(var3, var4);
      ItemStack var1 = new ItemStack(var53);
      var73 = 251382987 ^ var73;
      ItemMeta var14 = var1.getItemMeta();
      var73 = 1059763753 ^ var73;
      o0o0oOKo0K var35 = cfg();
      String var54 = hjdzjnvfmu(vdescquztvxibxk(), sifccttswzxerec(), var73);
      String var63 = hjdzjnvfmu(peubmyfrnudamyp(), sifccttswzxerec(), var73);
      String var36 = var35.rawStr(var54, var63);
      String var37 = oOo0KKoOoOK.color(var36);
      var14.setDisplayName(var37);
      var73 = 130065169 ^ var73;
      ArrayList var16 = new ArrayList();
      ArrayList var8 = var16;
      var73 = 290322547 ^ var73;
      String[] var17 = FILTERS;
      String[] var9 = var17;
      int var19 = var17.length;
      int var10 = var19;
      byte var20 = (byte)(835256914 ^ var73);
      int var11 = var20;

      for(var73 = 161648793 ^ var73; var11 < var10; var73 = 142603213 ^ var73) {
         int var80 = 555368432 ^ var73;
         String var23 = var9[var11];
         int var81 = 954411871 ^ var80;
         String var65 = this.filter;
         boolean var56 = var23.equals(var65);
         o0o0oOKo0K var66 = cfg();
         String var69 = "filter.labels." + var23;
         String var67 = var66.rawStr(var69, var23);
         String var41 = this.optionLine(var56, var67);
         String var42 = oOo0KKoOoOK.color(var41);
         boolean var25 = var8.add(var42);
         var73 = 294053730 ^ var81;
         var11 += 806641927 ^ var73;
      }

      var73 = 499155832 ^ var73;
      var14.setLore(var8);
      var73 = 774479038 ^ var73;
      var1.setItemMeta(var14);
      var73 = 102593478 ^ var73;
      String[] var29 = FILTERS;
      String[] var45 = FILTERS;
      String var58 = this.filter;
      int var46 = indexOf(var45, var58);
      byte var59 = (byte)(228589258 ^ var73);
      int var47 = var46 + var59;
      String[] var60 = FILTERS;
      int var61 = var60.length;
      int var48 = var47 % var61;
      String var30 = var29[var48];
      var73 = 1239693188 ^ var73;
      o0KoOKKo0K var31 = new o0KoOKKo0K();
      o0KoOKKo0K var32 = var31.item(var1);
      String var50 = hjdzjnvfmu(lrsnsktmnbhlgnn(), sifccttswzxerec(), var73);
      o0KoOKKo0K var33 = var32.filterSound(var50);
      Consumer var52 = (var2x) -> {
         int var12 = 1167656294 ^ 1418388637 ^ 1235333502;
         var12 = 1834710337 ^ var12;
         byte var4 = (byte)(904472005 ^ var12);
         String var8 = this.sort;
         String var9 = this.search;
         this.open(var4, var8, var30, var9);
      };
      o0KoOKKo0K var34 = var33.consumer(var52);
      return var34;
   }

   private String optionLine(boolean var1, String var2) {
      int var24 = 1550106190 ^ 1950551092 ^ 1235333502;
      var24 = 1663095107 ^ var24;
      String var8;
      if (var1 != (44487239 ^ var24)) {
         var24 = 515759625 ^ var24;
         o0o0oOKo0K var13 = cfg();
         String var17 = hjdzjnvfmu(wigthxxhyusxgxe(), sifccttswzxerec(), var24);
         String var21 = hjdzjnvfmu(lpmjotwrfjcgpqo(), sifccttswzxerec(), var24);
         var8 = var13.rawStr(var17, var21);

         label32:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var24)) {
               case 108297164:
                  var24 ^= 1865219921;
                  break label32;
               case 1344427395:
                  break;
               case 1816285929:
               default:
                  throw new IllegalAccessException();
               case 1936437197:
                  break label32;
            }
         }
      } else {
         label22:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var24)) {
               case 41707396:
                  var24 ^= 2127862323;
                  break label22;
               case 230989404:
               default:
                  throw new IllegalAccessException();
               case 242597849:
                  break label22;
               case 698358653:
            }
         }

         o0o0oOKo0K var7 = cfg();
         String var4 = hjdzjnvfmu(xcbdxgponsaenfv(), sifccttswzxerec(), var24);
         String var5 = hjdzjnvfmu(fufpwggptvkfxih(), sifccttswzxerec(), var24);
         var8 = var7.rawStr(var4, var5);
         var24 = 256228203 ^ var24;
      }

      var24 = 1304884711 ^ var24;
      o0o0oOKo0K var9 = cfg();
      String var14 = hjdzjnvfmu(ewqsdmpakwddlfc(), sifccttswzxerec(), var24);
      String var18 = hjdzjnvfmu(hzvtcpwuiwihkdo(), sifccttswzxerec(), var24);
      String var10 = var9.rawStr(var14, var18);
      String var15 = hjdzjnvfmu(iywgxpqamsepqbh(), sifccttswzxerec(), var24);
      var24 = 1652189996 ^ var24;
      String var11 = var10.replace(var15, var8);
      String var16 = hjdzjnvfmu(czpftpxuwcjcmwr(), sifccttswzxerec(), var24);
      var24 = 1078407464 ^ var24;
      String var12 = var11.replace(var16, var2);
      var24 = 1671128853 ^ var24;
      return var12;
   }

   private o0KoOKKo0K searchButton() {
      int var34 = 1110542202 ^ 1318302511 ^ 1235333502;
      var34 = 1600074772 ^ var34;
      o0o0oOKo0K var2 = cfg();
      String var3 = hjdzjnvfmu(rrlkgcjopmfhmyg(), sifccttswzxerec(), var34);
      Material var4 = Material.OAK_SIGN;
      Material var27 = var2.material(var3, var4);
      ItemStack var1 = new ItemStack(var27);
      var34 = 1657133943 ^ var34;
      ItemMeta var8 = var1.getItemMeta();
      var34 = 143994438 ^ var34;
      o0o0oOKo0K var16 = cfg();
      String var28 = hjdzjnvfmu(ekwvhledgcaklfw(), sifccttswzxerec(), var34);
      String var30 = hjdzjnvfmu(jhkfkvwuwigxfad(), sifccttswzxerec(), var34);
      String var17 = var16.rawStr(var28, var30);
      String var18 = oOo0KKoOoOK.color(var17);
      var8.setDisplayName(var18);
      var34 = 1546295697 ^ var34;
      o0o0oOKo0K var19 = cfg();
      String var29 = hjdzjnvfmu(pzihadtfygfekxr(), sifccttswzxerec(), var34);
      String var31 = hjdzjnvfmu(hekrdkeimylplmc(), sifccttswzxerec(), var34);
      String var20 = var19.rawStr(var29, var31);
      String var21 = oOo0KKoOoOK.color(var20);
      List var22 = Collections.singletonList(var21);
      var8.setLore(var22);
      var34 = 1535689961 ^ var34;
      var1.setItemMeta(var8);
      var34 = 742259136 ^ var34;
      o0KoOKKo0K var13 = new o0KoOKKo0K();
      o0KoOKKo0K var14 = var13.item(var1);
      Consumer var26 = (var1x) -> {
         int var35 = 660300356 ^ 913546096 ^ 1235333502;
         var35 = 1734911708 ^ var35;
         Player var7 = this.player;
         var7.closeInventory();
         var35 = 1626102841 ^ var35;

         try {
            SignGUIBuilder var8 = SignGUI.builder();
            Material var3 = Material.OAK_SIGN;
            SignGUIBuilder var9 = var8.setType(var3);
            byte var16 = (byte)(1594733227 ^ var35);
            String[] var17 = new String[var16];
            byte var4 = (byte)(1594733231 ^ var35);
            String var5 = hjdzjnvfmu(hsjunwwqiwkpdxx(), sifccttswzxerec(), var35);
            var17[var4] = var5;
            byte var27 = (byte)(1594733230 ^ var35);
            String var30 = hjdzjnvfmu(uqdxljxrnrwuxcs(), sifccttswzxerec(), var35);
            var17[var27] = var30;
            byte var28 = (byte)(1594733229 ^ var35);
            String var31 = hjdzjnvfmu(tmowesovloczlia(), sifccttswzxerec(), var35);
            var17[var28] = var31;
            byte var29 = (byte)(1594733228 ^ var35);
            String var32 = hjdzjnvfmu(kdftrvtfoollrwz(), sifccttswzxerec(), var35);
            var17[var29] = var32;
            SignGUIBuilder var10 = var9.setLines(var17);
            SignGUIFinishHandler var19 = (var1, var2) -> {
               int var17 = 455509001 ^ 1898047873 ^ 1235333502;
               var17 = 1534140653 ^ var17;
               byte var4 = (byte)(2027420699 ^ var17);
               String var9 = var2.getLineWithoutColor(var4);
               String var10 = var9.trim();
               var17 = 2051365573 ^ var17;
               KKoOoOo0oOK var11 = KKoOoOo0oOK.getInstance();
               Runnable var14 = () -> {
                  int var15 = 1113587672 ^ 569704121 ^ 1235333502;
                  var15 = 378856584 ^ var15;
                  int var10x = this.targetSlot;
                  byte var6 = (byte)(1017009302 ^ var15);
                  String var11 = this.sort;
                  String var12 = this.filter;
                  AuctionPageNavigation var3 = new AuctionPageNavigation(var1, var10x, var6, var11, var12, var10);
                  var3.open();
               };
               var11.runAtEntity(var1, var14);
               var17 = 20106576 ^ var17;
               List var12 = Collections.emptyList();
               return var12;
            };
            SignGUIBuilder var11 = var10.setHandler(var19);
            var35 = 1278757229 ^ var35;
            DonutSMPCore var20 = DonutSMPCore.getInstance();
            SignGUIBuilder var12 = var11.callHandlerSynchronously(var20);
            SignGUI var13 = var12.build();
            Player var22 = this.player;
            var13.open(var22);
            var35 = 533168958 ^ var35;
         } catch (SignGUIVersionException var36) {
            switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var35)) {
               case -1716527600 -> var35 = 1804213115 ^ var35;
               case -127036038 -> var35 = 665997846 ^ var35;
               default -> throw new RuntimeException("Error in hash");
            }

            var35 = 1649520385 ^ var35;
            KKoOoOo0oOK var15 = KKoOoOo0oOK.getInstance();
            Player var24 = this.player;
            Runnable var26 = () -> {
               int var15 = 233181553 ^ 567765478 ^ 1235333502;
               var15 = 113148118 ^ var15;
               Player var8 = this.player;
               int var9 = this.targetSlot;
               byte var4 = (byte)(1663977790 ^ var15);
               String var10 = this.sort;
               String var11 = this.filter;
               String var12 = this.search;
               AuctionPageNavigation var1 = new AuctionPageNavigation(var8, var9, var4, var10, var11, var12);
               var1.open();
            };
            var15.runAtEntity(var24, var26);
            var35 = 1817413346 ^ var35;
            return;
         }

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var35)) {
               case 152422042:
                  var35 = 2052043174 ^ var35;
                  return;
               case 464522996:
                  return;
               case 1663167037:
               default:
                  throw new IOException();
               case 2121159879:
            }
         }
      };
      o0KoOKKo0K var15 = var14.consumer(var26);
      return var15;
   }

   private ItemStack nav(String var1, String var2) {
      int var22 = 632310116 ^ 2135943062 ^ 1235333502;
      var22 = 390714700 ^ var22;
      Material var4 = Material.ARROW;
      ItemStack var3 = new ItemStack(var4);
      var22 = 589539903 ^ var22;
      ItemMeta var8 = var3.getItemMeta();
      var22 = 1312843155 ^ var22;
      String var15 = oOo0KKoOoOK.color(var1);
      var8.setDisplayName(var15);
      var22 = 1066660357 ^ var22;
      String var17 = oOo0KKoOoOK.color(var2);
      List var18 = Collections.singletonList(var17);
      var8.setLore(var18);
      var22 = 25533338 ^ var22;
      var3.setItemMeta(var8);
      var22 = 1742605795 ^ var22;
      return var3;
   }

   private List<oOoOoOoOo0K.K> compute() {
      int var55 = 1291576616 ^ 98823303 ^ 1235333502;
      var55 = 238201633 ^ var55;
      List var2 = oOoOoOoOo0K.allItems();
      ArrayList var1 = new ArrayList(var2);
      var55 = 2037554291 ^ var55;
      String var7 = this.search;
      byte var8 = var7.isEmpty();
      if (var8 == (2012843907 ^ var55)) {
         var55 = 750075583 ^ var55;
         Predicate var37 = (var1x) -> {
            int var11 = 614071040 ^ 926491926 ^ 1235333502;
            var11 = 201107324 ^ var11;
            String var4 = var1x.displayName;
            String var5 = var4.toLowerCase();
            String var8 = this.search;
            byte var6 = var5.contains(var8);
            byte var7;
            if (var6 != (1375586324 ^ var11)) {
               var11 = 2096339949 ^ var11;
               var7 = (byte)(755913721 ^ var11);
               var11 = 1553726983 ^ var11;
               return (boolean)var7;
            } else {
               var11 = 833997946 ^ var11;
               var7 = (byte)(1615332463 ^ var11);

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var11)) {
                     case 176941277:
                        var11 = 299739536 ^ var11;
                        return (boolean)var7;
                     case 324091288:
                        return (boolean)var7;
                     case 1739904180:
                        break;
                     case 1771842898:
                     default:
                        throw new IOException();
                  }
               }
            }
         };
         var1.removeIf(var37);
         var55 = 1636235745 ^ var55;
      } else {
         var55 = gugjtlrrkosehmrg(var55, 1295239006);
      }

      String var12 = this.filter;
      String var38 = hjdzjnvfmu(bqpohvolcuexgib(), sifccttswzxerec(), var55);
      byte var13 = var12.equals(var38);
      if (var13 == (986335453 ^ var55)) {
         var55 = 532947536 ^ var55;
         Predicate var40 = (var1x) -> {
            int var10 = 346316461 ^ 1389528029 ^ 1235333502;
            var10 = 481108909 ^ var10;
            Material var4 = var1x.material;
            String var7 = this.filter;
            byte var5 = inCategory(var4, var7);
            byte var6;
            if (var5 == (326782883 ^ var10)) {
               var10 = 58792989 ^ var10;
               var6 = (byte)(284906431 ^ var10);
               var10 = 1579304344 ^ var10;
            } else {
               var10 = 2030240435 ^ var10;
               var6 = (byte)(1786334480 ^ var10);
               var10 = 614488886 ^ var10;
            }

            return (boolean)var6;
         };
         var1.removeIf(var40);
         var55 = 833312940 ^ var55;
      } else {
         label131:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var55)) {
               case 31971302:
                  var55 ^= 779057916;
                  break label131;
               case 146678655:
                  break;
               case 206489212:
                  break label131;
               case 1669354538:
               default:
                  throw new RuntimeException();
            }
         }
      }

      byte var5;
      String var17 = this.sort;
      byte var18 = (byte)(-346370594 ^ var55);
      var5 = var18;
      int var20 = var17.hashCode();
      label121:
      switch (var20) {
         case -1086182771:
            label80:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var55)) {
                  case 134219194:
                     var55 ^= 947627531;
                  case 189974680:
                     break label80;
                  case 1198795087:
                  default:
                     throw new RuntimeException();
                  case 1411208979:
               }
            }

            String var52 = hjdzjnvfmu(ztsbvgxokhwpztm(), sifccttswzxerec(), var55);
            byte var34 = var17.equals(var52);
            if (var34 != (752784426 ^ var55)) {
               var55 = 269667311 ^ var55;
               byte var35 = (byte)(1020026820 ^ var55);
               var5 = var35;
               var55 = gugjtlrrkosehmrg(var55, 987340398);
            } else {
               var55 = gugjtlrrkosehmrg(var55, 717968769);
            }
            break;
         case -1027878565:
            label90:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var55)) {
                  case 134219194:
                     var55 ^= 2142639878;
                  case 639100543:
                     break label90;
                  case 1107957891:
                  default:
                     throw new RuntimeException();
                  case 1539630024:
               }
            }

            String var41 = hjdzjnvfmu(mwyifrgnagupaix(), sifccttswzxerec(), var55);
            byte var22 = var17.equals(var41);
            if (var22 != (1796416807 ^ var55)) {
               var55 = 320253156 ^ var55;
               byte var23 = (byte)(2013628865 ^ var55);
               var5 = var23;
               var55 = 2114996328 ^ var55;
            } else {
               var55 = gugjtlrrkosehmrg(var55, 1829168268);
            }
            break;
         case 87950:
            label110:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var55)) {
                  case 134219194:
                     var55 ^= 329271726;
                     break label110;
                  case 1137949760:
                     break;
                  case 1218490070:
                     break label110;
                  case 1755325893:
                  default:
                     throw new RuntimeException();
               }
            }

            String var51 = hjdzjnvfmu(nyolymwafyfnmiw(), sifccttswzxerec(), var55);
            byte var31 = var17.equals(var51);
            if (var31 != (117799823 ^ var55)) {
               var55 = 1639216390 ^ var55;
               byte var32 = (byte)(1722879625 ^ var55);
               var5 = var32;
               var55 = gugjtlrrkosehmrg(var55, 1621413666);
               break;
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var55)) {
                     case 110437587:
                        var55 ^= 17873444;
                        break label121;
                     case 396000285:
                     default:
                        throw new RuntimeException();
                     case 993802326:
                        break label121;
                     case 1684505478:
                  }
               }
            }
         default:
            label120:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var55)) {
                  case 134219194:
                     var55 ^= 313586570;
                     break label120;
                  case 1554329774:
                  default:
                     throw new RuntimeException();
                  case 1807189593:
                     break;
                  case 1993900979:
                     break label120;
               }
            }
      }

      switch (var5) {
         case 0:
            var55 = 616421684 ^ var55;
            Function var48 = (var0) -> {
               int var5 = 2129030976 ^ 1204735967 ^ 712623840;
               var5 = 1884342349 ^ var5;
               String var2 = var0.displayName;
               return var2;
            };
            Comparator var49 = Comparator.comparing(var48);
            Comparator var50 = var49.reversed();
            var1.sort(var50);
            var55 = gugjtlrrkosehmrg(var55, 96799491);
            return var1;
         case 1:
            var55 = gugjtlrrkosehmrg(var55, 548239063);
            ToDoubleFunction var44 = (var0) -> {
               int var8 = 1596030850 ^ 119688603 ^ 712623840;
               var8 = 256284373 ^ var8;
               Material var2 = var0.material;
               double var3 = worth(var2);
               double var5 = -var3;
               return var5;
            };
            Comparator var45 = Comparator.comparingDouble(var44);
            var1.sort(var45);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var55)) {
                  case 184927544:
                     var55 = 30778592 ^ var55;
                     return var1;
                  case 705263066:
                  default:
                     throw new RuntimeException();
                  case 2014280476:
                     break;
                  case 2089206374:
                     return var1;
               }
            }
         case 2:
            var55 = gugjtlrrkosehmrg(var55, 1165397079);
            ToDoubleFunction var42 = (var0) -> {
               int var6 = 523456835 ^ 1525379492 ^ 712623840;
               var6 = 1806420321 ^ var6;
               Material var2 = var0.material;
               double var3 = worth(var2);
               return var3;
            };
            Comparator var43 = Comparator.comparingDouble(var42);
            var1.sort(var43);
            var55 = 1678663264 ^ var55;
            return var1;
         default:
            label69:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var55)) {
                  case 95708037:
                     var55 ^= 1674187502;
                     break label69;
                  case 657373556:
                  default:
                     throw new RuntimeException();
                  case 721034260:
                     break label69;
                  case 817411688:
               }
            }

            Function var46 = (var0) -> {
               int var5 = 1818044502 ^ 958171629 ^ 712623840;
               var5 = 1260106186 ^ var5;
               String var2 = var0.displayName;
               return var2;
            };
            Comparator var47 = Comparator.comparing(var46);
            var1.sort(var47);
            var55 = 1119011033 ^ var55;
            return var1;
      }
   }

   private static double worth(Material var0) {
      int var11 = 2102474130 ^ 1075564247 ^ 712623840;
      var11 = 856342159 ^ var11;
      oOoOo0oOKoOK var1 = oOoOo0oOKoOK.getInstance();
      ItemStack var2 = new ItemStack(var0);
      Double var5 = var1.getPrice(var2);
      var11 = 1589639676 ^ var11;
      double var8;
      if (var5 == null) {
         var11 = 1251558783 ^ var11;
         var8 = (double)0.0F;
         var11 = gugjtlrrkosehmrg(var11, 1582488407);
      } else {
         var11 = gugjtlrrkosehmrg(var11, 1951780966);
         var8 = var5;
         var11 = 1620987470 ^ var11;
      }

      return var8;
   }

   private static boolean inCategory(Material var0, String var1) {
      byte var6;
      String var7;
      int var137;
      int var135 = 1252850769 ^ 1722245143 ^ 712623840;
      int var136 = 1443305020 ^ var135;
      var7 = var0.name();
      var137 = 540521210 ^ var136;
      byte var9 = (byte)(-1883438689 ^ var137);
      var6 = var9;
      int var11 = var1.hashCode();
      label457:
      switch (var11) {
         case -1116154134:
            label404:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                  case 159497368:
                     var137 ^= 1808258058;
                  case 955535549:
                     break label404;
                  case 1269776080:
                  default:
                     throw new IOException();
                  case 1558262918:
               }
            }

            String var126 = hjdzjnvfmu(znqshgsdfpqdfbn(), sifccttswzxerec(), var137);
            byte var72 = var1.equals(var126);
            if (var72 != (461711978 ^ var137)) {
               var137 = 636592064 ^ var137;
               byte var73 = (byte)(1047836077 ^ var137);
               var6 = var73;
               var137 = 36515621 ^ var137;
               break;
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                     case 89266600:
                        var137 ^= 668774629;
                        break label457;
                     case 200180073:
                     default:
                        throw new IOException();
                     case 739678776:
                        break;
                     case 957797456:
                        break label457;
                  }
               }
            }
         case -435851102:
            var137 = 218306323 ^ var137;
            String var131 = hjdzjnvfmu(sotygqkbycsbjye(), sifccttswzxerec(), var137);
            byte var87 = var1.equals(var131);
            if (var87 != (2101471603 ^ var137)) {
               var137 = 980446674 ^ var137;
               byte var88 = (byte)(1194427559 ^ var137);
               var6 = var88;
               var137 = 2070421038 ^ var137;
            } else {
               var137 = gugjtlrrkosehmrg(var137, 1092121596);
            }
            break;
         case 2195582:
            label455:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                  case 159497368:
                     var137 ^= 1890636466;
                  case 241275303:
                     break label455;
                  case 300477551:
                  default:
                     throw new IOException();
                  case 1029341471:
               }
            }

            String var129 = hjdzjnvfmu(btkbrvmwxhekgbq(), sifccttswzxerec(), var137);
            byte var81 = var1.equals(var129);
            if (var81 != (15871186 ^ var137)) {
               var137 ^= 834891810;
               byte var82 = (byte)(825318642 ^ var137);
               var6 = var82;

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                     case 256873760:
                        var137 ^= 224970367;
                        break label457;
                     case 995818701:
                        break;
                     case 1805269575:
                        break label457;
                     case 1858887887:
                     default:
                        throw new IOException();
                  }
               }
            } else {
               var137 = gugjtlrrkosehmrg(var137, 1017886301);
               break;
            }
         case 64369290:
            var137 ^= 171658457;
            String var128 = hjdzjnvfmu(gjjydhowppxnlni(), sifccttswzxerec(), var137);
            byte var78 = var1.equals(var128);
            if (var78 != (2054795961 ^ var137)) {
               var137 = 1162754193 ^ var137;
               byte var79 = (byte)(1060604461 ^ var137);
               var6 = var79;
               var137 = gugjtlrrkosehmrg(var137, 57544871);
               break;
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                     case 154457028:
                        break;
                     case 223064127:
                        var137 ^= 1176512566;
                        break label457;
                     case 1353972761:
                     default:
                        throw new IOException();
                     case 2028959154:
                        break label457;
                  }
               }
            }
         case 80992699:
            var137 = 1728764273 ^ var137;
            String var132 = hjdzjnvfmu(lyitueflfcmskan(), sifccttswzxerec(), var137);
            byte var90 = var1.equals(var132);
            if (var90 != (390604561 ^ var137)) {
               var137 = 1038815470 ^ var137;
               byte var91 = (byte)(715339774 ^ var137);
               var6 = var91;
               var137 = gugjtlrrkosehmrg(var137, 385527152);
            } else {
               var137 = gugjtlrrkosehmrg(var137, 722582942);
            }
            break;
         case 1274052896:
            var137 = gugjtlrrkosehmrg(var137, 1571553554);
            String var3 = hjdzjnvfmu(vvygedyuifchnpp(), sifccttswzxerec(), var137);
            byte var13 = var1.equals(var3);
            if (var13 != (770637682 ^ var137)) {
               var137 = 1580462694 ^ var137;
               byte var14 = (byte)(1943866640 ^ var137);
               var6 = var14;
               var137 = gugjtlrrkosehmrg(var137, 1334089627);
            } else {
               var137 = 297231869 ^ var137;
            }
            break;
         case 1992669606:
            var137 = 226603427 ^ var137;
            String var127 = hjdzjnvfmu(jyaanrrqqwhgbbp(), sifccttswzxerec(), var137);
            byte var75 = var1.equals(var127);
            if (var75 != (2109951939 ^ var137)) {
               var137 = 1778899167 ^ var137;
               byte var76 = (byte)(398759708 ^ var137);
               var6 = var76;
               var137 = gugjtlrrkosehmrg(var137, 731712915);
            } else {
               var137 = gugjtlrrkosehmrg(var137, 1100666188);
            }
            break;
         case 2024008468:
            label434:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                  case 29967094:
                     break label434;
                  case 159497368:
                     var137 ^= 1427229974;
                     break label434;
                  case 1388230767:
                     break;
                  case 1422094121:
                  default:
                     throw new IOException();
               }
            }

            String var130 = hjdzjnvfmu(yycbajdqbblxkfp(), sifccttswzxerec(), var137);
            byte var84 = var1.equals(var130);
            if (var84 != (626209654 ^ var137)) {
               var137 = 439630001 ^ var137;
               byte var85 = (byte)(1063717828 ^ var137);
               var6 = var85;
               var137 = 54432072 ^ var137;
               break;
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                     case 139532007:
                        var137 ^= 420129273;
                        break label457;
                     case 1141300160:
                     default:
                        throw new IOException();
                     case 1596384812:
                        break;
                     case 1697057546:
                        break label457;
                  }
               }
            }
         default:
            var137 = gugjtlrrkosehmrg(var137, 1276863727);
      }

      label366:
      switch (var6) {
         case 0:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                  case 82683692:
                     var137 = 342864134 ^ var137;
                     break label366;
                  case 763713783:
                     break;
                  case 1627009319:
                  default:
                     throw new IOException();
                  case 1711862882:
                     break label366;
               }
            }
         case 1:
            var137 = 1822403836 ^ var137;
            String var119 = hjdzjnvfmu(bsmxxmpltkwtuyn(), sifccttswzxerec(), var137);
            byte var60 = var7.endsWith(var119);
            byte var70;
            if (var60 == (1355167347 ^ var137)) {
               var137 = 1920328151 ^ var137;
               String var120 = hjdzjnvfmu(moagthefelkpguu(), sifccttswzxerec(), var137);
               byte var62 = var7.endsWith(var120);
               if (var62 == (582211492 ^ var137)) {
                  var137 = 214628258 ^ var137;
                  String var121 = hjdzjnvfmu(vypgbhyidacjujj(), sifccttswzxerec(), var137);
                  byte var64 = var7.endsWith(var121);
                  if (var64 == (779689990 ^ var137)) {
                     var137 = 463908224 ^ var137;
                     String var122 = hjdzjnvfmu(inswdqbrvfxqjhq(), sifccttswzxerec(), var137);
                     byte var66 = var7.endsWith(var122);
                     if (var66 == (903843206 ^ var137)) {
                        var137 = 923771251 ^ var137;
                        Material var123 = Material.SHEARS;
                        if (var0 != var123) {
                           var137 = 569104970 ^ var137;
                           Material var124 = Material.FISHING_ROD;
                           if (var0 != var124) {
                              var137 = 1520667284 ^ var137;
                              Material var125 = Material.FLINT_AND_STEEL;
                              if (var0 != var125) {
                                 label355:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                                       case 194447627:
                                          var137 ^= 2065210152;
                                          break label355;
                                       case 592531867:
                                       default:
                                          throw new IOException();
                                       case 1906578404:
                                          break label355;
                                       case 2107450248:
                                    }
                                 }

                                 var70 = (byte)(42002179 ^ var137);
                                 var137 = 1169917113 ^ var137;
                                 return (boolean)var70;
                              }

                              var137 = 316680389 ^ var137;
                           } else {
                              var137 = gugjtlrrkosehmrg(var137, 1212392017);
                           }
                        } else {
                           var137 = 1772648475 ^ var137;
                        }
                     } else {
                        var137 = gugjtlrrkosehmrg(var137, 1588058472);
                     }
                  } else {
                     var137 = 1157723368 ^ var137;
                  }
               } else {
                  var137 = 1238074186 ^ var137;
               }
            } else {
               var137 = gugjtlrrkosehmrg(var137, 1002332829);
            }

            var70 = (byte)(1803048175 ^ var137);
            var137 = gugjtlrrkosehmrg(var137, 742602580);
            return (boolean)var70;
         case 2:
            var137 = gugjtlrrkosehmrg(var137, 426008669);
            boolean var45 = var0.isEdible();
            return var45;
         case 3:
            var137 = 348988641 ^ var137;
            String var102 = hjdzjnvfmu(udrsopusmtngtso(), sifccttswzxerec(), var137);
            byte var27 = var7.endsWith(var102);
            byte var41;
            if (var27 == (680836718 ^ var137)) {
               var137 = 251043879 ^ var137;
               String var103 = hjdzjnvfmu(lmoqedrapevawin(), sifccttswzxerec(), var137);
               byte var29 = var7.endsWith(var103);
               if (var29 == (643964489 ^ var137)) {
                  var137 = 1128259470 ^ var137;
                  String var104 = hjdzjnvfmu(nzjnqsloabqlszw(), sifccttswzxerec(), var137);
                  byte var31 = var7.endsWith(var104);
                  if (var31 == (1700643271 ^ var137)) {
                     var137 = 286886453 ^ var137;
                     String var105 = hjdzjnvfmu(eftstvmrnvmkgsn(), sifccttswzxerec(), var137);
                     byte var33 = var7.endsWith(var105);
                     if (var33 == (1950632946 ^ var137)) {
                        var137 = 1856185091 ^ var137;
                        String var106 = hjdzjnvfmu(xnwztpjphvyjrhc(), sifccttswzxerec(), var137);
                        byte var35 = var7.endsWith(var106);
                        if (var35 == (451373297 ^ var137)) {
                           var137 = 1088659264 ^ var137;
                           Material var107 = Material.BOW;
                           if (var0 != var107) {
                              var137 = 633171715 ^ var137;
                              Material var108 = Material.CROSSBOW;
                              if (var0 != var108) {
                                 var137 = 1272574511 ^ var137;
                                 Material var109 = Material.SHIELD;
                                 if (var0 != var109) {
                                    var137 = 781861043 ^ var137;
                                    Material var110 = Material.TRIDENT;
                                    if (var0 != var110) {
                                       var137 = 1383984262 ^ var137;
                                       Material var111 = Material.ARROW;
                                       if (var0 != var111) {
                                          label311:
                                          while(true) {
                                             switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                                                case 210196578:
                                                   var137 ^= 1905351014;
                                                case 666042797:
                                                   break label311;
                                                case 949775611:
                                                default:
                                                   throw new IOException();
                                                case 1314617895:
                                             }
                                          }

                                          var41 = (byte)(957784014 ^ var137);
                                          var137 = 854004360 ^ var137;
                                          return (boolean)var41;
                                       }

                                       var137 = 202080452 ^ var137;
                                    } else {
                                       var137 = gugjtlrrkosehmrg(var137, 1584819266);
                                    }
                                 } else {
                                    var137 = gugjtlrrkosehmrg(var137, 1894526193);
                                 }
                              } else {
                                 var137 = 993386206 ^ var137;
                              }
                           } else {
                              var137 = gugjtlrrkosehmrg(var137, 512274909);
                           }
                        } else {
                           var137 = 1584082589 ^ var137;
                        }
                     } else {
                        var137 = gugjtlrrkosehmrg(var137, 818417054);
                     }
                  } else {
                     var137 = gugjtlrrkosehmrg(var137, 567379883);
                  }
               } else {
                  label343:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                        case 173948111:
                           var137 ^= 1659787301;
                           break label343;
                        case 325933948:
                        default:
                           throw new IOException();
                        case 400835018:
                           break label343;
                        case 1742598883:
                     }
                  }
               }
            } else {
               var137 = 1813575682 ^ var137;
            }

            var41 = (byte)(1150043757 ^ var137);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                  case 80710909:
                     var137 = 1333644074 ^ var137;
                     return (boolean)var41;
                  case 754870233:
                     break;
                  case 1214142492:
                     return (boolean)var41;
                  case 1708202515:
                  default:
                     throw new IOException();
               }
            }
         case 4:
            label301:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                  case 82683692:
                     var137 ^= 1260932709;
                     break label301;
                  case 233118943:
                     break;
                  case 543721225:
                  default:
                     throw new IOException();
                  case 1378892761:
                     break label301;
               }
            }

            Material var99 = Material.POTION;
            byte var24;
            if (var0 != var99) {
               var137 ^= 1475928447;
               Material var100 = Material.SPLASH_POTION;
               if (var0 != var100) {
                  var137 = 675480964 ^ var137;
                  Material var101 = Material.LINGERING_POTION;
                  if (var0 != var101) {
                     var137 = 1559651419 ^ var137;
                     var24 = (byte)(1413239882 ^ var137);
                     var137 = 115865321 ^ var137;
                     return (boolean)var24;
                  }

                  var137 = 414021596 ^ var137;
               } else {
                  label289:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                        case 252311385:
                           var137 ^= 820933208;
                           break label289;
                        case 563445855:
                        default:
                           throw new IOException();
                        case 1196411371:
                           break;
                        case 1287897882:
                           break label289;
                     }
                  }
               }
            } else {
               label280:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                     case 124582900:
                        var137 ^= 1729532711;
                     case 624834926:
                        break label280;
                     case 745257157:
                     default:
                        throw new IOException();
                     case 1690188558:
                  }
               }
            }

            var24 = (byte)(275204044 ^ var137);
            var137 = 1119675758 ^ var137;
            return (boolean)var24;
         case 5:
            var137 = 1790927425 ^ var137;
            Material var94 = Material.BOOK;
            byte var93;
            if (var0 != var94) {
               var137 = 274923329 ^ var137;
               Material var95 = Material.ENCHANTED_BOOK;
               if (var0 != var95) {
                  var137 = 1736574711 ^ var137;
                  Material var96 = Material.BOOKSHELF;
                  if (var0 != var96) {
                     var137 = 611679831 ^ var137;
                     Material var97 = Material.WRITABLE_BOOK;
                     if (var0 != var97) {
                        var137 = 1543380849 ^ var137;
                        Material var98 = Material.WRITTEN_BOOK;
                        if (var0 != var98) {
                           var137 = 1819757268 ^ var137;
                           var93 = (byte)(855255690 ^ var137);
                           var137 = 1296102176 ^ var137;
                           return (boolean)var93;
                        }

                        var137 = 1872797598 ^ var137;
                     } else {
                        var137 = gugjtlrrkosehmrg(var137, 878608623);
                     }
                  } else {
                     label258:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                           case 268141534:
                              var137 ^= 271318712;
                              break label258;
                           case 474281112:
                              break;
                           case 507752907:
                           default:
                              throw new IOException();
                           case 2143040304:
                              break label258;
                        }
                     }
                  }
               } else {
                  var137 = gugjtlrrkosehmrg(var137, 2007627855);
               }
            } else {
               label269:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                     case 132696988:
                        break;
                     case 140498153:
                        var137 ^= 1741358862;
                     case 752337687:
                        break label269;
                     case 1025683473:
                     default:
                        throw new IOException();
                  }
               }
            }

            var93 = (byte)(825098177 ^ var137);

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                  case 256454313:
                     var137 = 1318528618 ^ var137;
                     return (boolean)var93;
                  case 469489439:
                  default:
                     throw new IOException();
                  case 823332333:
                     break;
                  case 1110895327:
                     return (boolean)var93;
               }
            }
         case 6:
            label235:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                  case 82683692:
                     var137 ^= 13762632;
                     break label235;
                  case 403374576:
                  default:
                     throw new IOException();
                  case 465409569:
                     break label235;
                  case 596828277:
               }
            }

            byte var56 = var0.isBlock();
            byte var92;
            if (var56 == (1015782087 ^ var137)) {
               var137 = 1663554076 ^ var137;
               byte var58 = var0.isEdible();
               if (var58 == (1605126363 ^ var137)) {
                  var137 = 133116264 ^ var137;
                  var92 = (byte)(1480817074 ^ var137);

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                        case 184738697:
                           var137 = 1924862980 ^ var137;
                           return (boolean)var92;
                        case 203129527:
                        default:
                           throw new IOException();
                        case 431689373:
                           break;
                        case 850172825:
                           return (boolean)var92;
                     }
                  }
               }

               var137 = 962629306 ^ var137;
            } else {
               var137 = gugjtlrrkosehmrg(var137, 1514626214);
            }

            var92 = (byte)(1724696161 ^ var137);
            var137 = 1278520278 ^ var137;
            return (boolean)var92;
         case 7:
            var137 = 1878423677 ^ var137;
            Material var112 = Material.ENDER_CHEST;
            byte var54;
            if (var0 != var112) {
               var137 = 673675075 ^ var137;
               Material var113 = Material.CHEST;
               if (var0 != var113) {
                  var137 = 12086896 ^ var137;
                  Material var114 = Material.HOPPER;
                  if (var0 != var114) {
                     var137 = 439445718 ^ var137;
                     Material var115 = Material.SHULKER_BOX;
                     if (var0 != var115) {
                        var137 = 746394972 ^ var137;
                        String var116 = hjdzjnvfmu(kdenlwfttuwxuzc(), sifccttswzxerec(), var137);
                        byte var51 = var7.endsWith(var116);
                        if (var51 == (1300006475 ^ var137)) {
                           var137 = 903558765 ^ var137;
                           Material var117 = Material.ANVIL;
                           if (var0 != var117) {
                              var137 = 620542946 ^ var137;
                              Material var118 = Material.CRAFTING_TABLE;
                              if (var0 != var118) {
                                 label190:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                                       case 49298064:
                                          var137 ^= 1713919981;
                                          break label190;
                                       case 737889401:
                                          break;
                                       case 1436608957:
                                          break label190;
                                       case 2094861447:
                                       default:
                                          throw new IOException();
                                    }
                                 }

                                 var54 = (byte)(980638761 ^ var137);
                                 var137 = 1404192494 ^ var137;
                                 return (boolean)var54;
                              }

                              var137 = 1878429742 ^ var137;
                           } else {
                              var137 = 1258957772 ^ var137;
                           }
                        } else {
                           label203:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var137)) {
                                 case 48847903:
                                    break;
                                 case 102828365:
                                    var137 ^= 2127633825;
                                    break label203;
                                 case 1320676397:
                                 default:
                                    throw new IOException();
                                 case 1482501166:
                                    break label203;
                              }
                           }
                        }
                     } else {
                        var137 = 1387006205 ^ var137;
                     }
                  } else {
                     var137 = gugjtlrrkosehmrg(var137, 1218273323);
                  }
               } else {
                  var137 = gugjtlrrkosehmrg(var137, 1210388059);
               }
            } else {
               var137 = gugjtlrrkosehmrg(var137, 1610774808);
            }

            var54 = (byte)(867015659 ^ var137);
            var137 = 1517060397 ^ var137;
            return (boolean)var54;
         default:
            var137 = gugjtlrrkosehmrg(var137, 1539006315);
            byte var25 = (byte)(1742915045 ^ var137);
            return (boolean)var25;
      }

      boolean var43 = var0.isBlock();
      return var43;
   }

   private static int indexOf(String[] var0, String var1) {
      int var16 = 921688044 ^ 897688998 ^ 712623840;
      var16 = 125166095 ^ var16;
      byte var2 = (byte)(778196645 ^ var16);
      int var4 = var2;
      var16 = 14280109 ^ var16;

      while(true) {
         int var11 = var0.length;
         if (var4 >= var11) {
            var16 = gugjtlrrkosehmrg(var16, 1108148567);
            byte var10 = (byte)(1823912543 ^ var16);
            return var10;
         }

         var16 = 416851704 ^ var16;
         String var7 = var0[var4];
         byte var8 = var7.equals(var1);
         if (var8 != (912463344 ^ var16)) {
            var16 = 525282368 ^ var16;
            return var4;
         }

         label25:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 157273314:
                  var16 ^= 924165591;
                  break label25;
               case 1473548094:
                  break;
               case 1563316861:
                  break label25;
               case 1903578563:
               default:
                  throw new RuntimeException();
            }
         }

         var4 += 24555558 ^ var16;
         var16 = 801964847 ^ var16;
      }
   }

   static {
      int var32 = 886725759 ^ 46572582 ^ Integer.parseInt("1786160090");
      var32 = 1083790569 ^ var32;
      byte var0 = (byte)(485691246 ^ var32);
      String[] var3 = new String[var0];
      byte var1 = (byte)(485691242 ^ var32);
      String var2 = hjdzjnvfmu(jvjiuommvvywcuq(), sifccttswzxerec(), var32);
      var3[var1] = var2;
      byte var6 = (byte)(485691243 ^ var32);
      String var18 = hjdzjnvfmu(dbvzcvtexziprvl(), sifccttswzxerec(), var32);
      var3[var6] = var18;
      byte var7 = (byte)(485691240 ^ var32);
      String var19 = hjdzjnvfmu(uiewjxnybwawuat(), sifccttswzxerec(), var32);
      var3[var7] = var19;
      byte var8 = (byte)(485691241 ^ var32);
      String var20 = hjdzjnvfmu(ivxpvxcsyzrnedd(), sifccttswzxerec(), var32);
      var3[var8] = var20;
      SORTS = var3;
      var32 = 1207986736 ^ var32;
      byte var4 = (byte)(1425237331 ^ var32);
      String[] var5 = new String[var4];
      byte var9 = (byte)(1425237338 ^ var32);
      String var21 = hjdzjnvfmu(sxzcyzprerfmvco(), sifccttswzxerec(), var32);
      var5[var9] = var21;
      byte var10 = (byte)(1425237339 ^ var32);
      String var22 = hjdzjnvfmu(hheqnjktehyurgd(), sifccttswzxerec(), var32);
      var5[var10] = var22;
      byte var11 = (byte)(1425237336 ^ var32);
      String var23 = hjdzjnvfmu(uobfjenmjfbejub(), sifccttswzxerec(), var32);
      var5[var11] = var23;
      byte var12 = (byte)(1425237337 ^ var32);
      String var24 = hjdzjnvfmu(ovbosdanzqpppin(), sifccttswzxerec(), var32);
      var5[var12] = var24;
      byte var13 = (byte)(1425237342 ^ var32);
      String var25 = hjdzjnvfmu(udflnljraldjyqp(), sifccttswzxerec(), var32);
      var5[var13] = var25;
      byte var14 = (byte)(1425237343 ^ var32);
      String var26 = hjdzjnvfmu(rhtzmkpzchzmjrg(), sifccttswzxerec(), var32);
      var5[var14] = var26;
      byte var15 = (byte)(1425237340 ^ var32);
      String var27 = hjdzjnvfmu(hwcllzsbkrelplb(), sifccttswzxerec(), var32);
      var5[var15] = var27;
      byte var16 = (byte)(1425237341 ^ var32);
      String var28 = hjdzjnvfmu(fwcsyiyzdtupfnb(), sifccttswzxerec(), var32);
      var5[var16] = var28;
      byte var17 = (byte)(1425237330 ^ var32);
      String var29 = hjdzjnvfmu(oalienqkopvrkbz(), sifccttswzxerec(), var32);
      var5[var17] = var29;
      FILTERS = var5;
   }

   public static String hjdzjnvfmu(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] sifccttswzxerec() {
      return new byte[]{7, 58, 83, 31, 114, 17, 88, 104, 11, 34, 111, 47, 7, 40, 62, 54, 22, 126, 8, 80, 56, 99, 37, 114, 16, 37, 51, 46, 116, 29, 118, 103, 113, 3, 13, 8, 53, 63, 114, 87, 37, 52, 98, 33, 29, 58, 97, 76, 110, 78, 93, 114, 68, 61, 83, 48, 105, 82, 71, 55, 59, 30, 125, 70, 102, 117, 53, 1, 65, 9, 66, 13, 94, 95, 61, 26, 70};
   }

   private static byte[] sxzcyzprerfmvco() {
      return new byte[]{-56, -15, 97, 107, 64, 78, 111, 55};
   }

   private static byte[] hheqnjktehyurgd() {
      return new byte[]{-56, -15, 97, 104, 64, 78, 111, 52, 56, 121, 94, 112, 53, 110};
   }

   private static byte[] uobfjenmjfbejub() {
      return new byte[]{-56, -15, 97, 126, 64, 77, 111, 52, 56, 118, 94, 104};
   }

   private static byte[] ovbosdanzqpppin() {
      return new byte[]{-56, -15, 97, 108, 64, 77, 111, 52, 56, 126};
   }

   private static byte[] udflnljraldjyqp() {
      return new byte[]{-56, -15, 97, 105, 64, 77, 111, 54, 56, 120, 94, 122, 53, 105};
   }

   private static byte[] rhtzmkpzchzmjrg() {
      return new byte[]{-56, -15, 97, 122, 64, 77, 111, 47, 56, 115, 94, 116, 53, 115, 12, 118};
   }

   private static byte[] hwcllzsbkrelplb() {
      return new byte[]{-56, -15, 97, 104, 64, 77, 111, 52, 56, 113, 94, 104};
   }

   private static byte[] fwcsyiyzdtupfnb() {
      return new byte[]{-56, -15, 97, 99, 64, 76, 111, 60, 56, 104, 94, 126, 53, 121, 12, 108, 33, 40, 59, 6, 9, 35, 23, 52};
   }

   private static byte[] oalienqkopvrkbz() {
      return new byte[]{-56, -15, 97, 127, 64, 86, 111, 50, 56, 118, 94, 114, 53, 105, 12, 108, 33, 40, 59, 27};
   }

   private static byte[] jvjiuommvvywcuq() {
      return new byte[]{-51, -3, 102, 104, 75, 13, 106, 6};
   }

   private static byte[] dbvzcvtexziprvl() {
      return new byte[]{-51, -3, 102, 115, 75, 13, 106, 29};
   }

   private static byte[] uiewjxnybwawuat() {
      return new byte[]{-51, -3, 102, 97, 75, 73, 106, 59, 57, 126, 87, 127, 49, 98, 15, 112, 34, 108, 60, 56, 13, 39, 28, 42, 34, 114, 1, 127};
   }

   private static byte[] ivxpvxcsyzrnedd() {
      return new byte[]{-51, -3, 102, 101, 75, 79, 106, 43, 57, 115, 87, 105, 49, 101, 15, 36, 34, 28, 60, 26, 13, 60, 28, 32, 34, 116};
   }

   private static byte[] hurymdbeedgncoh() {
      return new byte[]{-56, -15, 103, 76, 67, 80, 97, 48, 59, 100, 94, 52, 51, 125, 15, 119, 47, 44, 56, 17, 9, 62, 17, 41, 33, 127, 10, 48, 68, 89, 71, 38, 69, 94, 60, 95, 12, 101, 66, 0, 20, 117, 86, 108, 44, 103, 88, 9, 94, 30, 108, 43, 112, 122, 98, 97, 80, 15, 119, 103, 10, 73, 73, 6, 87, 38, 12, 69, 113, 85};
   }

   private static byte[] bsmxxmpltkwtuyn() {
      return new byte[]{-56, -10, 102, 117, 67, 119, 111, 18, 63, 86, 94, 87, 50, 92, 15, 88, 33, 8};
   }

   private static byte[] gjjydhowppxnlni() {
      return new byte[]{-53, -11, 102, 105, 69, 71, 109, 62, 61, 120, 93, 108};
   }

   private static byte[] eftstvmrnvmkgsn() {
      return new byte[]{-56, -4, 102, 112, 68, 110, 106, 20, 63, 83, 94, 81, 50, 81, 8, 75, 36, 0, 60, 53};
   }

   private static byte[] znqshgsdfpqdfbn() {
      return new byte[]{-51, -13, 98, 125, 67, 84, 97, 54, 51, 122, 89, 119, 48, 109, 15, 102, 33, 35, 60, 21};
   }

   private static byte[] lyitueflfcmskan() {
      return new byte[]{-54, -4, 99, 125, 66, 74, 109, 49, 58, 125, 86, 108};
   }

   private static byte[] yycbajdqbblxkfp() {
      return new byte[]{-49, -9, 101, 110, 66, 71, 110, 48, 63, 118, 93, 120, 53, 108};
   }

   private static byte[] nzjnqsloabqlszw() {
      return new byte[]{-56, -14, 99, 112, 68, 102, 107, 18, 60, 86, 94, 75, 55, 76, 8, 82, 37, 0, 63, 32, 9, 0, 21, 7};
   }

   private static byte[] btkbrvmwxhekgbq() {
      return new byte[]{-56, -16, 107, 110, 67, 79, 96, 49, 58, 115};
   }

   private static byte[] vypgbhyidacjujj() {
      return new byte[]{-50, -14, 106, 118, 74, 123, 97, 25, 59, 90, 88, 64, 49, 85, 7, 67};
   }

   private static byte[] vvygedyuifchnpp() {
      return new byte[]{-50, -14, 99, 121, 65, 73, 110, 36, 57, 124, 88, 112, 49, 117, 9, 115};
   }

   private static byte[] jyaanrrqqwhgbbp() {
      return new byte[]{-53, -12, 99, 100, 75, 72, 105, 62, 56, 120, 93, 117, 55, 98};
   }

   private static byte[] lmoqedrapevawin() {
      return new byte[]{-49, -15, 96, 121, 68, 109, 108, 21, 50, 88, 91, 81, 62, 91, 10, 86};
   }

   private static byte[] xnwztpjphvyjrhc() {
      return new byte[]{-51, -16, 98, 115, 69, 96, 106, 30, 60, 89, 90, 74, 52, 76};
   }

   private static byte[] kdenlwfttuwxuzc() {
      return new byte[]{-56, -10, 99, 112, 66, 114, 110, 20, 60, 66, 94, 80, 55, 83, 14, 67, 32, 24, 63, 58, 9, 18, 21, 13, 32, 77};
   }

   private static byte[] inswdqbrvfxqjhq() {
      return new byte[]{-64, -11, 96, 120, 70, 106, 106, 23, 61, 94};
   }

   private static byte[] udrsopusmtngtso() {
      return new byte[]{-49, -3, 99, 120, 65, 116, 111, 14, 51, 91, 87, 77, 63, 95};
   }

   private static byte[] sotygqkbycsbjye() {
      return new byte[]{-53, -12, 99, 103, 70, 72, 105, 57, 59, 99, 93, 123, 55, 125, 10, 104, 39, 45, 56, 13, 10, 38, 21, 48};
   }

   private static byte[] moagthefelkpguu() {
      return new byte[]{-52, -3, 97, 114, 67, 97, 108, 9, 57, 82};
   }

   private static byte[] hsjunwwqiwkpdxx() {
      return new byte[0];
   }

   private static byte[] uqdxljxrnrwuxcs() {
      return new byte[]{-56, -16, 75, -70, 100, -77, 74, -53, 25, -126, 127, -117, 31, -115, 40, -108, 4, -35, 26, -16, 40, -57, 61, -41, 6, -121};
   }

   private static byte[] tmowesovloczlia() {
      return new byte[]{-56, -16, 106, 120, 69, 71, 107, 59, 56, 97, 94, 121, 62, 116};
   }

   private static byte[] kdftrvtfoollrwz() {
      return new byte[0];
   }

   private static byte[] rrxoqpcygnaceqz() {
      return new byte[]{-50, -10, 106, 116, 75, 124, 97, 111, 56, 56, 92, 47, 55, 76};
   }

   private static byte[] ibiafauqlmyshoa() {
      return new byte[0];
   }

   private static byte[] wibhbkcuyajhjjl() {
      return new byte[]{-54, -12, 97, 82, 65, 66, 109, 39, 58, 101, 94, 51, 62, 120, 8, 111, 33, 38, 59, 2, 10, 49, 22, 105, 37, 102, 2, 114, 69, 2, 79, 39, 71, 83, 58, 85, 6, 107, 64, 13, 22, 118};
   }

   private static byte[] ouovtvioijwxqut() {
      return new byte[]{-54, -12, 97, 5, 65, 97, 109, 25, 58, 87, 94, 91, 62, 93, 8, 69, 33, 12, 59, 13, 10, 51, 22, 39, 37, 121, 2, 61, 69, 91, 79, 59, 71, 22, 58, 74, 6, 107, 64, 2, 22, 103, 87, 117, 44, 125};
   }

   private static byte[] yjkczgkgpicjdom() {
      return new byte[]{-52, -9, 106, 4, 71, 97, 104, 28, 59, 81, 93, 80, 63, 91, 8, 64, 36, 30, 61, 16, 1, 62, 16, 50, 32, 126, 3, 116, 70, 81, 78, 33, 71, 19, 63, 104, 0, 108, 75, 8, 16, 103};
   }

   private static byte[] aznuhitpouhfjlp() {
      return new byte[]{-52, -9, 106, 4, 71, 102, 104, 27, 59, 86, 93, 87, 63, 92, 8, 71, 36, 13, 61, 14, 1, 50, 16, 39, 32, 124, 3, 59, 70, 80, 78, 61, 71, 19, 63, 78, 0, 100, 75, 10, 16, 117, 82, 51, 45, 127, 83, 7, 86, 30, 107, 52, 118, 100, 102, 109, 80, 31, 114, 114, 11, 12, 77, 3, 84, 45, 13, 83, 119, 92};
   }

   private static byte[] fvkgahjjnvoaglu() {
      return new byte[]{-54, -15, 96, 64, 75, 65, 105, 48, 56, 98, 92, 115, 62, 99};
   }

   private static byte[] wadouwprhgdbrcv() {
      return new byte[]{-56, -13, 97, 84, 66, 72, 107, 40, 57, 101};
   }

   private static byte[] rtraxcdbvwklxyy() {
      return new byte[]{-56, -10, 99, 90, 66, 71, 104, 63, 56, 99, 94, 127, 55, 118};
   }

   private static byte[] uztmbfothfvkouv() {
      return new byte[]{-56, -10, 103, 8, 66, 98, 97, 26, 57, 92, 94, 90, 51, 90, 14, 69, 47, 4, 58, 13, 9, 40, 17, 50, 32, 48, 10, 74, 70, 68, 71, 51, 69, 82};
   }

   private static byte[] vjgglmfzvlrwact() {
      return new byte[]{-56, -10, 103, 8, 66, 101, 97, 29, 57, 91, 94, 93, 51, 93, 14, 66, 47, 9, 58, 4, 9, 57, 17, 37, 32, 123, 10, 58, 70, 81, 71, 59, 69, 23, 61, 75, 12, 98, 64, 10, 20, 112, 86, 53, 45, 97, 88, 29, 92, 14, 108, 53, 112, 41, 99, 117, 80, 7, 117, 104, 10, 72};
   }

   private static byte[] oahqubpbnuxjlzs() {
      return new byte[0];
   }

   private static byte[] jqlczueuamyqnwz() {
      return new byte[]{-56, -9, 67, -72, 106, -71, 74, -50, 27, -122, 127, -116, 23, -113, 38, -98, 4, -40, 24, -12, 40, -64, 53, -43, 8, -115};
   }

   private static byte[] uavuhenmwnvpkou() {
      return new byte[]{-56, -9, 98, 104, 75, 69, 107, 48, 58, 98, 94, 115, 54, 106};
   }

   private static byte[] gncizluzbqstqjo() {
      return new byte[0];
   }

   private static byte[] nbyprfdryaxperd() {
      return new byte[]{-56, -10, 107, 83, 75, 64, 110, 33, 59, 103, 92, 57, 63, 98, 10, 111, 39, 60, 57, 23};
   }

   private static byte[] ydladiehaqsophd() {
      return new byte[]{-56, -10, 107, 4, 75, 99, 110, 31, 59, 85, 92, 81, 63, 87, 10, 70, 39, 29, 57, 12, 0, 41, 28, 50};
   }

   private static byte[] ipmowfrlcilfeny() {
      return new byte[]{-64, -10, 107, 78, 65, 85, 104, 60, 60, 111, 92, 126, 55, 116, 15, 104, 33, 103, 49, 16, 0, 60, 22, 49, 32, 102};
   }

   private static byte[] cpphfxsusakjcae() {
      return new byte[]{-56, -14, 97, 92, 68, 72, 107, 40, 58, 110};
   }

   private static byte[] lrsnsktmnbhlgnn() {
      return new byte[]{-56, -12, 103, 70, 75, 82, 107, 58, 62, 103, 94, 119, 51, 127, 7, 110, 37, 97, 61, 7, 9, 59, 17, 38, 41, 103, 0, 122, 65, 94};
   }

   private static byte[] vdescquztvxibxk() {
      return new byte[]{-49, -16, 107, 92, 75, 68, 111, 32, 63, 96, 90, 57, 48, 119, 14, 104, 38, 38, 62, 17, 0, 49, 28, 48};
   }

   private static byte[] peubmyfrnudamyp() {
      return new byte[]{-49, -16, 107, 11, 75, 103, 111, 30, 63, 82, 90, 81, 48, 87, 14, 71, 38, 12, 62, 12, 0, 56, 28, 54, 39, 112, 7, 106};
   }

   private static byte[] gtbcjwbyapbujyp() {
      return new byte[]{-54, -14, 107, 65, 69, 74, 111, 60, 61, 101, 88, 114, 63, 109};
   }

   private static byte[] xcbdxgponsaenfv() {
      return new byte[]{-53, -11, 107, 71, 74, 87, 108, 40, 56, 125, 93, 112, 63, 113, 6, 115, 34, 100, 59, 19, 10, 61, 29, 54, 40, 118, 7, 118, 71, 78, 68, 52, 73, 64, 53, 91, 1, 111, 65, 76, 23, 116, 90, 100, 37, 105, 85, 30, 93, 17, 111, 58};
   }

   private static byte[] fufpwggptvkfxih() {
      return new byte[]{-53, -11, 107, 11, 74, 97, 108, 26, 56, 82, 93, 89, 63, 89, 6, 70, 2, 104, 59, 70};
   }

   private static byte[] ewqsdmpakwddlfc() {
      return new byte[]{-56, -11, 102, 69, 75, 89, 107, 47, 62, 121, 94, 112, 50, 115, 7, 125, 37, 99, 61, 14, 9, 58, 16, 41, 41, 120, 0, 48, 65, 73, 71, 56, 68, 68, 52, 93, 6, 109, 71, 17};
   }

   private static byte[] hzvtcpwuiwihkdo() {
      return new byte[]{-56, -11, 102, 15, 75, 89, 107, 41, 62, 117, 94, 121, 50, 116, 7, 118, 37, 104, 61, 71, 9, 63, 16, 38, 41, 127, 0, 120, 65, 67, 71, 114};
   }

   private static byte[] iywgxpqamsepqbh() {
      return new byte[]{-56, -11, 102, 15, 75, 89, 107, 41, 62, 117, 94, 121, 50, 116, 7, 118, 37, 104};
   }

   private static byte[] czpftpxuwcjcmwr() {
      return new byte[]{-56, -16, 102, 8, 68, 73, 105, 61, 50, 114, 94, 127, 50, 118, 8, 39};
   }

   private static byte[] wigthxxhyusxgxe() {
      return new byte[]{-51, -14, 98, 69, 65, 85, 110, 43, 59, 127, 88, 113, 50, 117, 10, 115, 33, 96, 60, 20, 9, 51, 22, 42, 38, 119, 3, 121, 67, 88, 67, 49, 69, 81, 58, 21, 1, 120, 67, 16, 22, 101, 84, 112, 45, 103, 86, 5};
   }

   private static byte[] lpmjotwrfjcgpqo() {
      return new byte[]{-51, -14, 98, 9, 65, 21, 110, 111, 59, 80, 88, 93, 50, 35, 10, 56, 1, 108, 60, 71};
   }

   private static byte[] pzihadtfygfekxr() {
      return new byte[]{-50, -15, 99, 92, 70, 64, 110, 32, 60, 97, 91, 49, 48, 127, 10, 108, 38, 32, 63, 7, 8, 63, 17, 107, 38, 97, 4, 118, 64, 0, 65, 32, 69, 80, 61, 94, 2, 121, 66, 3, 17, 104};
   }

   private static byte[] hekrdkeimylplmc() {
      return new byte[]{-50, -15, 99, 11, 70, 100, 110, 25, 60, 84, 91, 94, 48, 93, 10, 65, 38, 10, 63, 8, 8, 61, 17, 37, 38, 126, 4, 57, 64, 89, 65, 60, 69, 21, 61, 76, 2, 110, 66, 1, 17, 114, 84, 114, 42, 101};
   }

   private static byte[] ekwvhledgcaklfw() {
      return new byte[]{-56, -3, 100, 82, 74, 65, 106, 32, 63, 96, 94, 57, 48, 98, 6, 102, 36, 47, 60, 20, 9, 56, 18, 35};
   }

   private static byte[] jhkfkvwuwigxfad() {
      return new byte[]{-56, -3, 100, 5, 74, 98, 106, 30, 63, 82, 94, 81, 48, 87, 6, 69, 36, 29, 60, 3, 9, 58, 18, 57, 40, 115, 1, 118};
   }

   private static byte[] rrlkgcjopmfhmyg() {
      return new byte[]{-51, -15, 97, 94, 74, 70, 107, 57, 56, 100, 91, 126, 53, 120};
   }

   private static byte[] bqpohvolcuexgib() {
      return new byte[]{-64, -3, 101, 109, 65, 72, 108, 49};
   }

   private static byte[] mwyifrgnagupaix() {
      return new byte[]{-56, -14, 106, 101, 70, 79, 110, 39, 59, 112, 94, 107, 62, 106, 10, 39, 32, 22, 56, 21, 9, 61, 28, 39, 36, 113};
   }

   private static byte[] ztsbvgxokhwpztm() {
      return new byte[]{-50, -16, 97, 96, 74, 76, 108, 61, 61, 125, 90, 120, 48, 99, 10, 118, 36, 104, 63, 53, 10, 38, 29, 47, 36, 116, 5, 124};
   }

   private static byte[] nyolymwafyfnmiw() {
      return new byte[]{-56, -12, 100, 114, 75, 5, 96, 27};
   }

   private static int gugjtlrrkosehmrg(int var0, int var1) {
      return var1 ^ var0;
   }
}
