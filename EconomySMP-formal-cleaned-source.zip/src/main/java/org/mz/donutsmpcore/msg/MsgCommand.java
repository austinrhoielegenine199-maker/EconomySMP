package org.mz.donutsmpcore.msg;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.mz.donutsmpcore.crossserver.CrossServerRedisBridge;
import skido.KoOo0Ko0oOK;
import skido.oOo0KKoOoOK;

public final class MsgCommand implements CommandExecutor, TabCompleter {

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      int var33 = 1851614936 ^ 476824927 ^ 1541991788;
      var33 = 359271313 ^ var33;
      byte var10 = var1 instanceof Player;
      if (var10 == (1018447226 ^ var33)) {
         var33 = 486684941 ^ var33;
         String var6 = uumwcbwudj(gfrikndyqynvbfl(), qihmxaulvoqcjnt(), var33);
         var1.sendMessage(var6);
         var33 = 145502974 ^ var33;
         byte var12 = (byte)(689589896 ^ var33);
         return (boolean)var12;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var33)) {
               case 94206504:
                  var33 ^= 818565338;
               case 1093510007:
                  Player var14 = (Player)var1;
                  var33 = 1461308012 ^ var33;
                  String var16 = var2.getName();
                  String var17 = var16.toLowerCase();
                  var33 = 1485512255 ^ var33;
                  String var26 = uumwcbwudj(ljslrjqihvobipc(), qihmxaulvoqcjnt(), var33);
                  byte var19 = var17.equals(var26);
                  if (var19 == (65847795 ^ var33)) {
                     var33 = 1547044633 ^ var33;
                     String var27 = uumwcbwudj(fqlnbpfihyvafry(), qihmxaulvoqcjnt(), var33);
                     byte var21 = var17.equals(var27);
                     if (var21 == (1608173290 ^ var33)) {
                        var33 = nlwzmmcdeqtsomyj(var33, 1762793525);
                        boolean var23 = this.handleMsg(var14, var4);
                        return var23;
                     }

                     var33 = 21704631 ^ var33;
                  } else {
                     var33 = 1568483502 ^ var33;
                  }

                  boolean var25 = this.handleReply(var14, var4);
                  return var25;
               case 1200090767:
                  break;
               case 1897106652:
               default:
                  throw new RuntimeException();
            }
         }
      }
   }

   private boolean handleMsg(Player var1, String[] var2) {
      int var21 = 1462237753 ^ 1763094812 ^ 1541991788;
      var21 = 114109796 ^ var21;
      int var7 = var2.length;
      byte var4 = (byte)(1662290735 ^ var21);
      if (var7 < var4) {
         var21 = 612356766 ^ var21;
         String var12 = uumwcbwudj(htpuyuujiufirvk(), qihmxaulvoqcjnt(), var21);
         String var5 = uumwcbwudj(tqvuwszwwyajnsy(), qihmxaulvoqcjnt(), var21);
         String var13 = get(var12, var5);
         var1.sendMessage(var13);
         var21 = 1542344479 ^ var21;
         byte var9 = (byte)(478484141 ^ var21);
         return (boolean)var9;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var21)) {
               case 267890355:
                  var21 ^= 1469189670;
               case 1950139334:
                  byte var16 = (byte)(881231115 ^ var21);
                  String var15 = var2[var16];
                  byte var6 = (byte)(881231114 ^ var21);
                  String var18 = joinFrom(var2, var6);
                  MsgManager.sendMessage(var1, var15, var18);
                  var21 = 1909652979 ^ var21;
                  byte var11 = (byte)(1163163897 ^ var21);
                  return (boolean)var11;
               case 655219584:
               default:
                  throw new IOException();
               case 1256792562:
            }
         }
      }
   }

   private boolean handleReply(Player var1, String[] var2) {
      int var34 = 53275780 ^ 1867878108 ^ 1541991788;
      var34 = 1589888511 ^ var34;
      int var9 = var2.length;
      byte var4 = (byte)(1767000778 ^ var34);
      if (var9 < var4) {
         var34 = 1295182363 ^ var34;
         String var24 = uumwcbwudj(evcoztoynegzmlw(), qihmxaulvoqcjnt(), var34);
         String var5 = uumwcbwudj(ntdeavpfjbxvclw(), qihmxaulvoqcjnt(), var34);
         String var25 = get(var24, var5);
         var1.sendMessage(var25);
         var34 = 1484946954 ^ var34;
         byte var11 = (byte)(2095242971 ^ var34);
         return (boolean)var11;
      } else {
         var34 = nlwzmmcdeqtsomyj(var34, 996279645);
         UUID var13 = var1.getUniqueId();
         UUID var14 = MsgManager.getReplyUuid(var13);
         var34 = 1206188901 ^ var34;
         UUID var16 = var1.getUniqueId();
         String var17 = MsgManager.getReplyName(var16);
         var34 = 1153607481 ^ var34;
         if (var14 != null) {
            var34 = 245131780 ^ var34;
            if (var17 != null) {
               var34 = nlwzmmcdeqtsomyj(var34, 628895995);
               byte var6 = (byte)(2062960949 ^ var34);
               String var30 = joinFrom(var2, var6);
               MsgManager.sendMessage(var1, var17, var30);
               var34 = 1536540352 ^ var34;
               byte var21 = (byte)(560199668 ^ var34);
               return (boolean)var21;
            }

            var34 = 720855987 ^ var34;
         } else {
            var34 = nlwzmmcdeqtsomyj(var34, 610994615);
         }

         String var27 = uumwcbwudj(unpbsldfrmaxdwp(), qihmxaulvoqcjnt(), var34);
         String var31 = uumwcbwudj(ghbelcsevbpwhdt(), qihmxaulvoqcjnt(), var34);
         String var28 = get(var27, var31);
         var1.sendMessage(var28);
         var34 = 1045238937 ^ var34;
         byte var23 = (byte)(1261440741 ^ var34);
         return (boolean)var23;
      }
   }

   private static String joinFrom(String[] var0, int var1) {
      int var23 = 219088237 ^ 128468815 ^ 1823190194;
      var23 = 678224291 ^ var23;
      StringBuilder var2 = new StringBuilder();
      StringBuilder var4 = var2;
      var23 = 1028147962 ^ var23;
      int var5 = var1;
      var23 = 790804596 ^ var23;

      while(true) {
         label59: {
            int var16 = var0.length;
            if (var5 < var16) {
               var23 = 2021441184 ^ var23;
               if (var5 > var1) {
                  var23 = 488916814 ^ var23;
                  byte var18 = (byte)(961676403 ^ var23);
                  StringBuilder var12 = var4.append((char)var18);
                  var23 = 2055004027 ^ var23;
                  break label59;
               }

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var23)) {
                     case 52229908:
                     default:
                        throw new RuntimeException();
                     case 111478398:
                        var23 ^= 1733859381;
                     case 1406828191:
                        break label59;
                     case 1738975460:
                  }
               }
            } else {
               label41:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var23)) {
                     case 39131028:
                        var23 = 1225481724 ^ var23;
                        break label41;
                     case 1227349541:
                        break;
                     case 1822027570:
                        break label41;
                     case 1846575968:
                     default:
                        throw new RuntimeException();
                  }
               }
            }

            String var9 = var4.toString();
            return var9;
         }

         String var20 = var0[var5];
         StringBuilder var14 = var4.append(var20);
         var23 = 1169527571 ^ var23;
         var5 += 110839866 ^ var23;
         var23 = 1519498630 ^ var23;
      }
   }

   private static String get(String var0, String var1) {
      int var11 = 691199027 ^ 1001381482 ^ 1823190194;
      var11 = 2056080197 ^ var11;

      try {
         String var5 = KoOo0Ko0oOK.get(var0, var1);
         var11 = 2068633963 ^ var11;
         return var5;
      } catch (Throwable var12) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var11)) {
            case 635383152:
               var11 = nlwzmmcdeqtsomyj(var11, 287220252);
               var11 = 1019259596 ^ var11;
               String var8 = oOo0KKoOoOK.color(var1);
               return var8;
            default:
               throw new RuntimeException("Error in hash");
         }
      }
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      int var27 = 240243761 ^ 1421480627 ^ 1541991788;
      var27 = 2105661945 ^ var27;
      String var9 = var2.getName();
      String var10 = var9.toLowerCase();
      var27 = 1756038455 ^ var27;
      String var6 = uumwcbwudj(mhwvflqfrftecac(), qihmxaulvoqcjnt(), var27);
      byte var12 = var10.equals(var6);
      if (var12 == (338294560 ^ var27)) {
         var27 = 1951193349 ^ var27;
         String var21 = uumwcbwudj(cvkidpusublxkev(), qihmxaulvoqcjnt(), var27);
         byte var14 = var10.equals(var21);
         if (var14 == (1617243685 ^ var27)) {
            var27 = nlwzmmcdeqtsomyj(var27, 1800233404);
            int var16 = var4.length;
            byte var22 = (byte)(187191192 ^ var27);
            if (var16 == var22) {
               var27 = 617858773 ^ var27;
               byte var7 = (byte)(805013836 ^ var27);
               String var24 = var4[var7];
               List var18 = CrossServerRedisBridge.allOnlineNamesExcludingSender(var1, var24);
               return var18;
            }

            var27 = nlwzmmcdeqtsomyj(var27, 2067804880);
            List var19 = Collections.emptyList();
            return var19;
         }

         var27 = 1109256070 ^ var27;
      } else {
         var27 = nlwzmmcdeqtsomyj(var27, 911294083);
      }

      List var20 = Collections.emptyList();
      return var20;
   }

   public static String uumwcbwudj(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] qihmxaulvoqcjnt() {
      return new byte[]{12, 76, 103, 7, 2, 78, 16, 60, 12, 23, 68, 85, 91, 28, 72, 124, 101, 85, 46, 29, 26, 76, 59, 127, 77, 73, 28, 74, 97, 80, 21, 63, 85, 101, 92, 62, 31, 24, 111, 120, 67, 21, 39, 108, 98, 90, 120, 84, 4, 116, 100, 31, 77, 52, 27, 6, 125, 115, 24, 80, 82, 55, 15, 114, 45, 20, 110, 64, 120, 89, 44, 22, 69, 75, 68, 98, 79, 43, 110, 72, 125, 122, 59, 122, 126, 64, 95, 90, 118, 11, 94, 54, 89, 127, 65, 47, 73, 71, 8, 60, 83, 15, 34, 127, 52, 50, 38, 4, 100, 58, 119, 18, 9, 107, 54, 109, 56, 49, 96, 64, 13, 53, 25, 69, 36};
   }

   private static byte[] fqlnbpfihyvafry() {
      return new byte[]{-61, -123, 87, 77};
   }

   private static byte[] gfrikndyqynvbfl() {
      return new byte[]{-57, -123, 82, 126, 50, 23, 37, 100, 63, 91, 114, 64, 109, 92, 127, 37, 81, 7, 27, 82, 47, 31, 11, 58, 120, 14, 47, 95, 87, 6, 35, 110, 98, 62, 104, 45, 42, 93, 90, 43, 115, 76, 18, 60, 81, 79, 78, 17, 50, 54, 83, 67, 121, 113, 46, 81, 72, 49, 40, 2, 103, 35, 60, 42, 27, 68, 88, 3, 79, 31, 24, 68, 112, 26, 113, 49, 127, 111, 91, 82};
   }

   private static byte[] ljslrjqihvobipc() {
      return new byte[]{-60, -122, 95, 65, 53, 28, 41, 121, 58, 78, 124, 24};
   }

   private static byte[] htpuyuujiufirvk() {
      return new byte[]{-61, -126, 94, 82, 48, 12, 39, 109, 57, 8, 117, 17, 98, 87, 122, 44, 82, 4, 27, 73, 43, 80, 2, 42, 127, 11, 43, 27};
   }

   private static byte[] tqvuwszwwyajnsy() {
      return new byte[]{-61, -126, 94, 28, 48, 57, 39, 76, 57, 19, 117, 81, 98, 17, 122, 120, 82, 54, 27, 95, 43, 28, 2, 32, 127, 29, 43, 70, 84, 65, 36, 33, 108, 48, 110, 124, 40, 73, 90, 105, 114, 24, 30, 36, 80, 7, 79, 3, 49, 60, 85, 75, 116, 126, 41, 9, 74, 101, 45, 93, 99, 107, 54, 47, 31, 86, 89, 5, 77, 9, 29, 64, 124, 22, 118, 109};
   }

   private static byte[] unpbsldfrmaxdwp() {
      return new byte[]{-61, -118, 80, 91, 51, 14, 35, 107, 57, 10, 117, 2, 108, 66, 121, 98, 86, 23, 27, 75, 43, 5, 12, 34, 124, 3, 47, 87, 84, 23, 36, 103, 98, 38, 109, 106, 44, 77, 90, 63};
   }

   private static byte[] ghbelcsevbpwhdt() {
      return new byte[]{-61, -118, 80, 21, 51, 59, 35, 74, 57, 17, 117, 89, 108, 24, 121, 122, 86, 60, 27, 65, 43, 0, 12, 110, 124, 18, 47, 27, 84, 21, 36, 99, 98, 116, 109, 99, 44, 71, 90, 107, 114, 67, 16, 51, 83, 12, 75, 68, 49, 51, 85, 73, 122, 37, 42, 71, 78, 38, 45, 19, 99, 98, 56, 58, 28, 7, 93, 4, 77, 5, 29, 1};
   }

   private static byte[] evcoztoynegzmlw() {
      return new byte[]{-60, -126, 87, 89, 51, 15, 36, 107, 60, 15, 117, 16, 104, 94, 122, 41, 85, 2, 24, 73, 42, 82, 10, 63, 121, 28, 44, 12, 80, 12, 38, 119};
   }

   private static byte[] ntdeavpfjbxvclw() {
      return new byte[]{-60, -126, 87, 23, 51, 58, 36, 74, 60, 20, 117, 80, 104, 24, 122, 125, 85, 48, 24, 95, 42, 30, 10, 42, 121, 28, 44, 70, 80, 64, 38, 33, 103, 35, 108, 46, 41, 21, 95, 38, 114, 66, 19, 47, 82, 31, 73, 5, 55, 34, 86, 78, 125, 58};
   }

   private static byte[] mhwvflqfrftecac() {
      return new byte[]{-63, -128, 95, 71, 59, 31, 37, 122, 60, 72, 119, 20};
   }

   private static byte[] cvkidpusublxkev() {
      return new byte[]{-61, -123, 86, 66};
   }

   private static int nlwzmmcdeqtsomyj(int var0, int var1) {
      return var1 ^ var0;
   }

   static {
   }
}
