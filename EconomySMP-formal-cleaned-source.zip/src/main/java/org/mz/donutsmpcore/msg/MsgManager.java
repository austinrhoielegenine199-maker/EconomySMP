package org.mz.donutsmpcore.msg;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.KKo0KoOoOK;
import skido.KoOo0Ko0oOK;
import skido.oOo0KKoOoOK;
import skido.oOo0o0oOo0oOK;

public final class MsgManager {
   private static final int PRIVATE_MESSAGES_SLOT = 1;
   private static volatile MsgDispatcher dispatcher;
   private static final ConcurrentHashMap<UUID, UUID> REPLY_UUID;
   private static final ConcurrentHashMap<UUID, String> REPLY_NAME;

   private MsgManager() {
   }

   public static void setDispatcher(MsgDispatcher var0) {
      int var13 = 280240483 ^ 639043162 ^ 924920094;
      var13 = 1318755207 ^ var13;
      dispatcher = var0;
      var13 = 1768836444 ^ var13;

      label39: {
         try {
            if (var0 != null) {
               var13 = 1470676880 ^ var13;
               DonutSMPCore var5 = DonutSMPCore.getInstance();
               Logger var6 = var5.getLogger();
               var13 = 971978150 ^ var13;
               Class var8 = var0.getClass();
               String var9 = var8.getSimpleName();
               String var10 = "/msg cross-server dispatcher installed by " + var9 + ".";
               var13 = 244565160 ^ var13;
               var6.info(var10);
               var13 = 530452884 ^ var13;
               break label39;
            }
         } catch (Throwable var14) {
            switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var13)) {
               case -1896662173 -> var13 = 93126667 ^ var13;
               case 867616737 -> var13 = kxmsbxokyxrnkomp(var13, 1378205595);
               case 890549010 -> var13 = 854716677 ^ var13;
               case 1099601490 -> var13 = 1013069229 ^ var13;
               default -> throw new IllegalAccessException("Error in hash");
            }

            var13 = 1507980615 ^ var13;
            return;
         }

         label38:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var13)) {
               case 176579102:
                  var13 ^= 2135580426;
               case 228980818:
                  break label38;
               case 281746528:
                  break;
               case 1240396600:
               default:
                  throw new IOException();
            }
         }
      }

      var13 = kxmsbxokyxrnkomp(var13, 1955468758);
   }

   public static boolean hasDispatcher() {
      int var4 = 40873007 ^ 1634299271 ^ 924920094;
      var4 = 2013008416 ^ var4;
      MsgDispatcher var0 = dispatcher;
      byte var1;
      if (var0 != null) {
         var4 = 774125145 ^ var4;
         var1 = (byte)(234867918 ^ var4);
         var4 = kxmsbxokyxrnkomp(var4, 405197945);
      } else {
         var4 = kxmsbxokyxrnkomp(var4, 363999836);
         var1 = (byte)(912902346 ^ var4);
         var4 = 598790268 ^ var4;
      }

      return (boolean)var1;
   }

   public static void sendMessage(Player var0, String var1, String var2) {
      int var51 = 720088651 ^ 447612773 ^ 924920094;
      var51 = 1085309072 ^ var51;
      String var13 = var0.getName();
      byte var14 = var13.equalsIgnoreCase(var1);
      if (var14 != (1205076128 ^ var51)) {
         var51 = 1473002779 ^ var51;
         String var36 = qrqxrwajgl(obwmnelhvelvvtn(), rrgmbtguvphlbnb(), var51);
         String var5 = qrqxrwajgl(xebucxpmjntynkf(), rrgmbtguvphlbnb(), var51);
         String var37 = get(var36, var5);
         var0.sendMessage(var37);
         var51 = 1462055468 ^ var51;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var51)) {
               case 187336418:
                  var51 ^= 581057689;
               case 1068926062:
                  Player var17 = Bukkit.getPlayerExact(var1);
                  var51 = 1527993761 ^ var51;
                  if (var17 != null) {
                     var51 = 915759482 ^ var51;
                     byte var20 = var17.isOnline();
                     if (var20 != (149948642 ^ var51)) {
                        var51 = 3507981 ^ var51;
                        byte var33 = isPrivateMessagesDisabled(var17);
                        if (var33 != (147165167 ^ var51)) {
                           var51 = 2048012026 ^ var51;
                           String var41 = qrqxrwajgl(tofluurnailncxg(), rrgmbtguvphlbnb(), var51);
                           String var46 = qrqxrwajgl(mniciilvtgzmllz(), rrgmbtguvphlbnb(), var51);
                           String var42 = get(var41, var46);
                           var0.sendMessage(var42);
                           var51 = 868028281 ^ var51;
                           return;
                        }

                        var51 = kxmsbxokyxrnkomp(var51, 864938658);
                        deliverLocal(var0, var17, var2);
                        var51 = 1925118677 ^ var51;
                        return;
                     }

                     var51 = 956471773 ^ var51;
                  } else {
                     var51 = 261617831 ^ var51;
                  }

                  MsgDispatcher var21 = dispatcher;
                  if (var21 != null) {
                     var51 = 815892613 ^ var51;
                     Object var22 = null;
                     UUID var11 = (UUID)var22;
                     var51 = 1768840658 ^ var51;

                     label68: {
                        label67: {
                           try {
                              OfflinePlayer var24 = Bukkit.getOfflinePlayerIfCached(var1);
                              var51 = 47922865 ^ var51;
                              if (var24 != null) {
                                 var51 = 534577984 ^ var51;
                                 UUID var27 = var24.getUniqueId();
                                 var51 = 753856685 ^ var51;
                                 var11 = var27;
                                 var51 = 1967492423 ^ var51;
                                 break label67;
                              }
                           } catch (Throwable var52) {
                              switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var51)) {
                                 case -1445212981 -> var51 = 1983024111 ^ var51;
                                 case -827569758 -> var51 = 1524398914 ^ var51;
                                 case 1105863491 -> var51 = 1798616606 ^ var51;
                                 case 1463015115 -> var51 = kxmsbxokyxrnkomp(var51, 1777305775);
                                 default -> throw new RuntimeException("Error in hash");
                              }

                              var51 = 1191954829 ^ var51;
                              break label68;
                           }

                           var51 = 1182170794 ^ var51;
                        }

                        label57:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var51)) {
                              case 106374158:
                                 var51 ^= 1754414984;
                                 break label57;
                              case 1476310493:
                                 break;
                              case 1557334676:
                                 break label57;
                              case 1878617277:
                              default:
                                 throw new IOException();
                           }
                        }
                     }

                     if (var11 != null) {
                        var51 = 1307289887 ^ var51;
                        oOo0o0oOo0oOK var29 = oOo0o0oOo0oOK.getInstance();
                        byte var43 = (byte)(166302437 ^ var51);
                        Consumer var47 = (var3) -> {
                           int var15 = 197807206 ^ 613590201 ^ 924920094;
                           var15 = 2139898953 ^ var15;
                           byte var7 = var3;
                           if (var7 != (1744143752 ^ var15)) {
                              var15 = 62228222 ^ var15;
                              dispatchRemote(var0, var1, var2);
                              var15 = 1543646978 ^ var15;
                           } else {
                              var15 = kxmsbxokyxrnkomp(var15, 1804751941);
                              String var10 = qrqxrwajgl(mcfdsblbocaspib(), rrgmbtguvphlbnb(), var15);
                              String var12 = qrqxrwajgl(snftomnvurlwatm(), rrgmbtguvphlbnb(), var15);
                              String var11 = get(var10, var12);
                              var0.sendMessage(var11);
                              var15 = 874905017 ^ var15;
                           }

                        };
                        var29.checkAnywhere(var11, var43, var0, var47);
                        var51 = 1293351703 ^ var51;
                        return;
                     }

                     var51 = 2003149285 ^ var51;
                  } else {
                     var51 = kxmsbxokyxrnkomp(var51, 43322145);
                  }

                  dispatchRemote(var0, var1, var2);
                  var51 = 2103340320 ^ var51;
                  return;
               case 1395456857:
                  break;
               case 1471015784:
               default:
                  throw new IOException();
            }
         }
      }
   }

   private static void dispatchRemote(Player var0, String var1, String var2) {
      int var22 = 444996740 ^ 1655297952 ^ 924920094;
      var22 = 2006464627 ^ var22;
      MsgDispatcher var3 = dispatcher;
      MsgDispatcher var7 = var3;
      var22 = 952169308 ^ var22;
      if (var3 != null) {
         var22 = 563909256 ^ var22;

         byte var8;
         label40: {
            try {
               byte var12 = var7.dispatchCrossServer(var0, var1, var2);
               var8 = var12;
               var22 = 159359408 ^ var22;
            } catch (Throwable var23) {
               switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var22)) {
                  case 240508137:
                     var22 = 746841956 ^ var22;
                     var22 = 2142634348 ^ var22;
                     byte var16 = (byte)(1929338261 ^ var22);
                     var8 = var16;
                     var22 = 2045108552 ^ var22;
                     break label40;
                  default:
                     throw new IOException("Error in hash");
               }
            }

            var22 = kxmsbxokyxrnkomp(var22, 598714096);
         }

         if (var8 != (186301661 ^ var22)) {
            var22 = 662943609 ^ var22;
            return;
         }

         label32:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var22)) {
               case 92522230:
                  var22 ^= 1373477002;
                  break label32;
               case 129952767:
                  break;
               case 658870566:
               default:
                  throw new IllegalAccessException();
               case 879994615:
                  break label32;
            }
         }
      } else {
         var22 = 1519455554 ^ var22;
      }

      String var17 = qrqxrwajgl(uufbpmwuievrhcz(), rrgmbtguvphlbnb(), var22);
      String var19 = qrqxrwajgl(gnglrdtfycqgsgb(), rrgmbtguvphlbnb(), var22);
      String var18 = get(var17, var19);
      var0.sendMessage(var18);
      var22 = 370980479 ^ var22;
   }

   public static void renderSenderSide(Player var0, String var1, UUID var2, String var3) {
      int var28 = 1728084781 ^ 749206826 ^ 924920094;
      var28 = 1860085951 ^ var28;
      String var4 = qrqxrwajgl(exiukzkwbjdutcb(), rrgmbtguvphlbnb(), var28);
      String var5 = qrqxrwajgl(mpdtlvdozandgbx(), rrgmbtguvphlbnb(), var28);
      String var8 = get(var4, var5);
      String var17 = qrqxrwajgl(cqttifwxfidiewn(), rrgmbtguvphlbnb(), var28);
      var28 = 1642408663 ^ var28;
      String var22 = var0.getName();
      String var9 = var8.replace(var17, var22);
      String var18 = qrqxrwajgl(abzbkmarsdmxmlm(), rrgmbtguvphlbnb(), var28);
      var28 = 319454964 ^ var28;
      String var10 = var9.replace(var18, var1);
      String var19 = qrqxrwajgl(ckirkmrwolupyia(), rrgmbtguvphlbnb(), var28);
      var28 = 854589802 ^ var28;
      String var11 = var10.replace(var19, var3);
      var28 = 1831092041 ^ var28;
      var0.sendMessage(var11);
      var28 = 1206229269 ^ var28;
      playMsgSound(var0);
      var28 = 78553487 ^ var28;
      if (var2 != null) {
         var28 = 2072498770 ^ var28;
         UUID var16 = var0.getUniqueId();
         rememberReply(var16, var2, var1);
         var28 = 188950361 ^ var28;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var28)) {
               case 9328908:
                  var28 = 1891955979 ^ var28;
                  return;
               case 973541118:
                  return;
               case 1223476782:
               default:
                  throw new IOException();
               case 1237365519:
            }
         }
      }
   }

   public static void deliverIncoming(UUID var0, String var1, UUID var2, String var3, String var4) {
      int var47 = 1817299989 ^ 1462115231 ^ 924920094;
      var47 = 1292656252 ^ var47;
      Object var5 = null;
      Player var8 = (Player)var5;
      var47 = 1197622973 ^ var47;
      if (var0 != null) {
         var47 = 136261595 ^ var47;
         Player var12 = Bukkit.getPlayer(var0);
         var8 = var12;
         var47 = 39718317 ^ var47;
      } else {
         label96:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var47)) {
               case 97866199:
                  var47 ^= 172040822;
                  break label96;
               case 635891943:
               default:
                  throw new IOException();
               case 775004533:
                  break;
               case 1038537870:
                  break label96;
            }
         }
      }

      label86: {
         if (var8 != null) {
            var47 = 335603543 ^ var47;
            byte var15 = var8.isOnline();
            if (var15 != (410592116 ^ var47)) {
               var47 = 1052515465 ^ var47;
               break label86;
            }

            var47 = 164342836 ^ var47;
         } else {
            label84:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var47)) {
                  case 2581745:
                     break;
                  case 21232680:
                     break label84;
                  case 137093242:
                     var47 ^= 499862371;
                     break label84;
                  case 843985070:
                  default:
                     throw new IOException();
               }
            }
         }

         if (var1 != null) {
            var47 ^= 211200962;
            byte var18 = var1.isEmpty();
            if (var18 == (488907906 ^ var47)) {
               var47 = 586383398 ^ var47;
               Player var20 = Bukkit.getPlayerExact(var1);
               var8 = var20;
               var47 = 420649817 ^ var47;
            } else {
               label61:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var47)) {
                     case 141958047:
                        var47 ^= 1004608383;
                        break label61;
                     case 891182921:
                        break;
                     case 1131322415:
                     default:
                        throw new IOException();
                     case 1260701332:
                        break label61;
                  }
               }
            }
         } else {
            label71:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var47)) {
                  case 6439280:
                     break label71;
                  case 38396990:
                     var47 ^= 930590909;
                     break label71;
                  case 532713787:
                  default:
                     throw new IOException();
                  case 1242306834:
               }
            }
         }
      }

      if (var8 != null) {
         var47 = 1522898338 ^ var47;
         byte var23 = var8.isOnline();
         if (var23 != (2080418399 ^ var47)) {
            var47 = 65098682 ^ var47;
            byte var25 = isPrivateMessagesDisabled(var8);
            if (var25 != (2145516005 ^ var47)) {
               var47 = 785698772 ^ var47;
            } else {
               var47 = kxmsbxokyxrnkomp(var47, 974553573);
               String var26 = qrqxrwajgl(saygdompdqywprl(), rrgmbtguvphlbnb(), var47);
               String var6 = qrqxrwajgl(uszhrrofihikejy(), rrgmbtguvphlbnb(), var47);
               String var27 = get(var26, var6);
               String var36 = qrqxrwajgl(dhcoizgwjlxpmri(), rrgmbtguvphlbnb(), var47);
               var47 = 1930976941 ^ var47;
               String var28 = var27.replace(var36, var3);
               String var37 = qrqxrwajgl(qxcefvcypwsbtmw(), rrgmbtguvphlbnb(), var47);
               var47 = 1004703754 ^ var47;
               String var42 = var8.getName();
               String var29 = var28.replace(var37, var42);
               String var38 = qrqxrwajgl(hbrqolbaeshoofn(), rrgmbtguvphlbnb(), var47);
               var47 = 701370099 ^ var47;
               String var30 = var29.replace(var38, var4);
               var47 = 2064761041 ^ var47;
               var8.sendMessage(var30);
               var47 = 1145538315 ^ var47;
               playMsgSound(var8);
               var47 = 1156503570 ^ var47;
               if (var2 != null) {
                  var47 = 614773366 ^ var47;
                  UUID var35 = var8.getUniqueId();
                  rememberReply(var35, var2, var3);
                  var47 = 899307984 ^ var47;
               } else {
                  var47 = 289336230 ^ var47;
               }

            }
         } else {
            var47 = 1336637242 ^ var47;
         }
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var47)) {
               case 186518847:
                  var47 = 359588504 ^ var47;
                  return;
               case 543211117:
                  break;
               case 1424159931:
                  return;
               case 2030263728:
               default:
                  throw new IOException();
            }
         }
      }
   }

   private static void playMsgSound(Player var0) {
      int var8 = 527710886 ^ 1963785226 ^ 924920094;
      var8 = 1761881065 ^ var8;
      String var2 = qrqxrwajgl(uypdfomeigwktys(), rrgmbtguvphlbnb(), var8);
      Sound var3 = Sound.ENTITY_CHICKEN_EGG;
      float var4 = 1.0F;
      float var5 = 1.6F;
      KKo0KoOoOK.play(var0, var2, var3, var4, var5);
      var8 = 440501202 ^ var8;
   }

   private static void deliverLocal(Player var0, Player var1, String var2) {
      int var53 = 689401520 ^ 748246119 ^ 924920094;
      var53 = 377779313 ^ var53;
      String var3 = qrqxrwajgl(gsbkgfjksklzrhc(), rrgmbtguvphlbnb(), var53);
      String var4 = qrqxrwajgl(ilpwtoccyolrpao(), rrgmbtguvphlbnb(), var53);
      String var8 = get(var3, var4);
      String var25 = qrqxrwajgl(rlevfscdfqukwfz(), rrgmbtguvphlbnb(), var53);
      var53 = 1661093569 ^ var53;
      String var38 = var0.getName();
      String var9 = var8.replace(var25, var38);
      String var26 = qrqxrwajgl(ioaieycyepimulx(), rrgmbtguvphlbnb(), var53);
      var53 = 1367510776 ^ var53;
      String var40 = var1.getName();
      String var10 = var9.replace(var26, var40);
      String var27 = qrqxrwajgl(xthugidbcjtjnzx(), rrgmbtguvphlbnb(), var53);
      var53 = 1218906017 ^ var53;
      String var11 = var10.replace(var27, var2);
      var53 = 1361917502 ^ var53;
      String var12 = qrqxrwajgl(ncfgnbezwqrlonm(), rrgmbtguvphlbnb(), var53);
      String var28 = qrqxrwajgl(gftsxfvtmeaibtx(), rrgmbtguvphlbnb(), var53);
      String var13 = get(var12, var28);
      String var29 = qrqxrwajgl(gwllsnrpvedhjvu(), rrgmbtguvphlbnb(), var53);
      var53 = 1048532372 ^ var53;
      String var43 = var0.getName();
      String var14 = var13.replace(var29, var43);
      String var30 = qrqxrwajgl(ddoylqrfilphkgk(), rrgmbtguvphlbnb(), var53);
      var53 = 1707402788 ^ var53;
      String var45 = var1.getName();
      String var15 = var14.replace(var30, var45);
      String var31 = qrqxrwajgl(nqzjjdldybamtbz(), rrgmbtguvphlbnb(), var53);
      var53 = 615128187 ^ var53;
      String var16 = var15.replace(var31, var2);
      var53 = 237077838 ^ var53;
      var0.sendMessage(var11);
      var53 = 943396667 ^ var53;
      var1.sendMessage(var16);
      var53 = 590745374 ^ var53;
      playMsgSound(var0);
      var53 = 1892032421 ^ var53;
      playMsgSound(var1);
      var53 = 188217954 ^ var53;
      UUID var22 = var0.getUniqueId();
      UUID var35 = var1.getUniqueId();
      String var48 = var1.getName();
      rememberReply(var22, var35, var48);
      var53 = 445649288 ^ var53;
      UUID var24 = var1.getUniqueId();
      UUID var37 = var0.getUniqueId();
      String var50 = var0.getName();
      rememberReply(var24, var37, var50);
      var53 = 460513323 ^ var53;
   }

   public static void rememberReply(UUID var0, UUID var1, String var2) {
      int var16 = 1270565411 ^ 390211079 ^ 924920094;
      var16 = 2010260838 ^ var16;
      if (var0 != null) {
         var16 = 437213144 ^ var16;
         if (var1 != null) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
                  case 94691854:
                     var16 ^= 1551468868;
                  case 1849980629:
                     ConcurrentHashMap var7 = REPLY_UUID;
                     var7.put(var0, var1);
                     var16 = 2113328409 ^ var16;
                     if (var2 != null) {
                        var16 = 953242441 ^ var16;
                        ConcurrentHashMap var10 = REPLY_NAME;
                        var10.put(var0, var2);
                        var16 = 332325492 ^ var16;
                        return;
                     }

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
                           case 211556222:
                              var16 = 723497277 ^ var16;
                              return;
                           case 260425195:
                           default:
                              throw new IOException();
                           case 825429301:
                              break;
                           case 1628883683:
                              return;
                        }
                     }
                  case 319719944:
                     break;
                  case 2103673459:
                  default:
                     throw new IOException();
               }
            }
         }

         var16 = 916240089 ^ var16;
      } else {
         var16 = kxmsbxokyxrnkomp(var16, 747888897);
      }

   }

   public static UUID getReplyUuid(UUID var0) {
      int var8 = 1087191511 ^ 213497028 ^ 924920094;
      var8 = 57597602 ^ var8;
      UUID var5;
      if (var0 == null) {
         var8 = 1575599459 ^ var8;
         var5 = null;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var8)) {
               case 155731657:
                  var8 = 480298934 ^ var8;
                  return var5;
               case 235091651:
                  return var5;
               case 726535119:
               default:
                  throw new IOException();
               case 1091623338:
            }
         }
      } else {
         label34:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var8)) {
               case 150160776:
                  var8 ^= 776673490;
                  break label34;
               case 578448351:
                  break;
               case 1125181069:
               default:
                  throw new IOException();
               case 1714475785:
                  break label34;
            }
         }

         ConcurrentHashMap var3 = REPLY_UUID;
         Object var4 = var3.get(var0);
         var5 = (UUID)var4;
         var8 = 1862427143 ^ var8;
         return var5;
      }
   }

   public static String getReplyName(UUID var0) {
      int var8 = 105643448 ^ 1389186812 ^ 924920094;
      var8 = 416760218 ^ var8;
      String var5;
      if (var0 != null) {
         var8 = kxmsbxokyxrnkomp(var8, 2136792883);
         ConcurrentHashMap var3 = REPLY_NAME;
         Object var4 = var3.get(var0);
         var5 = (String)var4;
         var8 = 268513799 ^ var8;
         return var5;
      } else {
         var8 = 1605507636 ^ var8;
         var5 = null;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var8)) {
               case 121205514:
                  var8 = 821032704 ^ var8;
                  return var5;
               case 199418365:
                  return var5;
               case 362604191:
                  break;
               case 416875466:
               default:
                  throw new IOException();
            }
         }
      }
   }

   public static void clearReply(UUID var0) {
      int var10 = 1760539269 ^ 230179360 ^ 924920094;
      var10 = 1417712482 ^ var10;
      if (var0 == null) {
         var10 = 373539278 ^ var10;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var10)) {
               case 109502685:
                  var10 ^= 530447525;
               case 347656480:
                  ConcurrentHashMap var3 = REPLY_UUID;
                  var3.remove(var0);
                  var10 = 795372084 ^ var10;
                  ConcurrentHashMap var5 = REPLY_NAME;
                  var5.remove(var0);
                  var10 = 948754018 ^ var10;
                  return;
               case 160667097:
                  break;
               case 787895060:
               default:
                  throw new IllegalAccessException();
            }
         }
      }
   }

   private static boolean isPrivateMessagesDisabled(Player var0) {
      int var11 = 546428137 ^ 313905814 ^ 924920094;
      var11 = 1523751117 ^ var11;

      byte var8;
      label48: {
         label41: {
            try {
               oOo0o0oOo0oOK var1 = oOo0o0oOo0oOK.getInstance();
               byte var3 = (byte)(1607972781 ^ var11);
               byte var5 = var1.isEnabled(var0, var3);
               if (var5 == (1607972780 ^ var11)) {
                  var11 = 1216022200 ^ var11;
                  var8 = (byte)(397193493 ^ var11);
                  break label48;
               }
            } catch (Throwable var13) {
               boolean var10001 = false;
               break label41;
            }

            label40:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var11)) {
                  case 162638858:
                     var11 ^= 478923838;
                  case 1294022509:
                     try {
                        var8 = (byte)(1130134418 ^ var11);
                        var11 = 539760424 ^ var11;
                        return (boolean)var8;
                     } catch (Throwable var12) {
                        boolean var20 = false;
                        break label40;
                     }
                  case 1388441944:
                     break;
                  case 1451426840:
                  default:
                     throw new IOException();
               }
            }
         }

         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var11)) {
            case -1117419360 -> var11 = 1430357165 ^ var11;
            case -21119646 -> var11 = 490373653 ^ var11;
            case 451140754 -> var11 = 28397099 ^ var11;
            default -> throw new IOException("Error in hash");
         }

         var11 = 2127175034 ^ var11;
         byte var7 = (byte)(1009199299 ^ var11);
         return (boolean)var7;
      }

      var11 = 1960631726 ^ var11;
      return (boolean)var8;
   }

   private static String get(String var0, String var1) {
      int var11 = 1995802725 ^ 424991234 ^ 924920094;
      var11 = 1951351834 ^ var11;

      try {
         String var5 = KoOo0Ko0oOK.get(var0, var1);
         var11 = 2054468774 ^ var11;
         return var5;
      } catch (Throwable var12) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var11)) {
            case 1719270169:
               var11 = 472247404 ^ var11;
               var11 = 1608352974 ^ var11;
               String var8 = oOo0KKoOoOK.color(var1);
               return var8;
            default:
               throw new IOException("Error in hash");
         }
      }
   }

   public static boolean isPrivateMessageLine(String var0) {
      int var18 = 1980112717 ^ 870567125 ^ 924920094;
      var18 = 1235769092 ^ var18;
      if (var0 != null) {
         var18 = 701818464 ^ var18;
         byte var5 = var0.isEmpty();
         if (var5 == (314067938 ^ var18)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var18)) {
                  case 71631293:
                     var18 ^= 1858118353;
                     break;
                  case 154371544:
                  default:
                     throw new IOException();
                  case 1564023608:
                     break;
                  case 1574977235:
                     continue;
               }

               String var2 = qrqxrwajgl(kabzwjeohheywph(), rrgmbtguvphlbnb(), var18);
               String var3 = qrqxrwajgl(hairmoakjgmvwmy(), rrgmbtguvphlbnb(), var18);
               String var12 = get(var2, var3);
               byte var7 = matchesPmFormat(var0, var12);
               byte var10;
               if (var7 == (2088298803 ^ var18)) {
                  var18 = 743962019 ^ var18;
                  String var13 = qrqxrwajgl(ifmkoqoxnzomlru(), rrgmbtguvphlbnb(), var18);
                  String var15 = qrqxrwajgl(pdjvvdakbpkdwuv(), rrgmbtguvphlbnb(), var18);
                  var18 = 1266277585 ^ var18;
                  String var14 = get(var13, var15);
                  byte var9 = matchesPmFormat(var0, var14);
                  if (var9 == (458670145 ^ var18)) {
                     var18 = kxmsbxokyxrnkomp(var18, 1323605036);
                     var10 = (byte)(1437752429 ^ var18);
                     var18 = 299623507 ^ var18;
                     return (boolean)var10;
                  }

                  var18 = 47521327 ^ var18;
               } else {
                  var18 = kxmsbxokyxrnkomp(var18, 1710962525);
               }

               var10 = (byte)(428072559 ^ var18);

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var18)) {
                     case 24078198:
                        var18 = 1575642704 ^ var18;
                        return (boolean)var10;
                     case 545570660:
                     default:
                        throw new IOException();
                     case 1005302120:
                        break;
                     case 1622574275:
                        return (boolean)var10;
                  }
               }
            }
         }

         var18 = 1297514547 ^ var18;
      } else {
         var18 = kxmsbxokyxrnkomp(var18, 1686267475);
      }

      byte var11 = (byte)(1609485265 ^ var18);
      return (boolean)var11;
   }

   private static boolean matchesPmFormat(String var0, String var1) {
      int var47 = 884110891 ^ 321680780 ^ 924920094;
      var47 = 1380179793 ^ var47;
      String var14 = oOo0KKoOoOK.strip(var1);
      String var3 = qrqxrwajgl(ebnqjlrnziqoaai(), rrgmbtguvphlbnb(), var47);
      String var4 = qrqxrwajgl(pyqaqujhbgammxd(), rrgmbtguvphlbnb(), var47);
      String var15 = var14.replaceAll(var3, var4);
      var47 = 1100246527 ^ var47;
      String var37 = qrqxrwajgl(kmxxxmcfcadlrtp(), rrgmbtguvphlbnb(), var47);
      byte var43 = (byte)(-57186328 ^ var47);
      String[] var17 = var15.split(var37, var43);
      var47 = 131153898 ^ var47;
      byte var18 = (byte)(79276029 ^ var47);
      int var7 = var18;
      var47 = 771471273 ^ var47;
      byte var19 = (byte)(692195412 ^ var47);
      byte var8 = var19;
      var47 = 845663091 ^ var47;
      String[] var9 = var17;
      int var22 = var17.length;
      int var10 = var22;
      byte var23 = (byte)(455465767 ^ var47);
      int var11 = var23;

      for(var47 = 1918233411 ^ var47; var11 < var10; var47 = 1348102900 ^ var47) {
         var47 = 1714876149 ^ var47;
         String var27 = var9[var11];
         var47 = 1990674195 ^ var47;
         byte var29 = var27.isEmpty();
         if (var29 != (2044828034 ^ var47)) {
            var47 = 132554230 ^ var47;

            label40:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var47)) {
                  case 70117031:
                     var47 ^= 1194155748;
                  case 474010012:
                     break label40;
                  case 681852626:
                  default:
                     throw new IllegalAccessException();
                  case 863767830:
               }
            }
         } else {
            var47 = 663710894 ^ var47;
            int var31 = var0.indexOf(var27, var7);
            var47 = 661279351 ^ var47;
            if (var31 < (2030348123 ^ var47)) {
               var47 = 1818299341 ^ var47;
               byte var33 = (byte)(358984854 ^ var47);
               return (boolean)var33;
            }

            label29:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var47)) {
                  case 159642224:
                     break;
                  case 175734084:
                     var47 ^= 1173243363;
                     break label29;
                  case 229769223:
                  default:
                     throw new IllegalAccessException();
                  case 2000464001:
                     break label29;
               }
            }

            int var42 = var27.length();
            int var35 = var31 + var42;
            var7 = var35;
            var47 = 733371681 ^ var47;
            byte var36 = (byte)(391954328 ^ var47);
            var8 = var36;
            var47 = 779543817 ^ var47;
         }

         var11 += 959077009 ^ var47;
      }

      var47 = 1419892358 ^ var47;
      return (boolean)var8;
   }

   static {
      int var4 = 2036076695 ^ 416442679 ^ Integer.parseInt("1413132686");
      var4 = 1565909719 ^ var4;
      ConcurrentHashMap var0 = new ConcurrentHashMap();
      REPLY_UUID = var0;
      var4 = 858856360 ^ var4;
      ConcurrentHashMap var1 = new ConcurrentHashMap();
      REPLY_NAME = var1;
   }

   public static String qrqxrwajgl(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] rrgmbtguvphlbnb() {
      return new byte[]{32, 54, 105, 11, 3, 8, 112, 80, 67, 63, 37, 113, 9, 77, 54, 25, 100, 19, 89, 1, 53, 78, 89, 57, 89, 11, 41, 106, 21, 120, 4, 76, 33, 9, 93, 119, 40, 87, 2, 44, 108, 92, 118, 14, 4, 120, 86, 50, 80, 12, 34, 72, 77, 4, 34, 59};
   }

   private static byte[] tofluurnailncxg() {
      return new byte[]{-17, -16, 91, 80, 52, 72, 68, 6, 115, 32, 20, 56, 59, 23, 1, 75, 80, 91, 105, 85, 4, 5, 107, 34, 110, 86, 29, 52, 37, 61, 53, 88, 19, 89, 106, 43, 28, 19, 50, 115, 93, 1};
   }

   private static byte[] mniciilvtgzmllz() {
      return new byte[]{-17, -16, 91, 30, 52, 125, 68, 39, 115, 59, 20, 125, 59, 78, 1, 31, 80, 118, 105, 88, 4, 22, 107, 123, 110, 24, 29, 43, 37, 37, 53, 20, 19, 70, 106, 33, 28, 20, 50, 61, 93, 12, 68, 75, 51, 107, 98, 109, 96, 82, 19, 5, 127, 18, 21, 103, 20, 105, 89, 86, 50, 88, 66, 8, 116, 105, 17, 110};
   }

   private static byte[] obwmnelhvelvvtn() {
      return new byte[]{-20, -2, 89, 86, 49, 79, 65, 5, 112, 35, 18, 50, 57, 26, 2, 68, 86, 70, 107, 27, 5, 19, 107, 104, 104, 74, 26, 43, 34, 41, 52, 25, 21, 93};
   }

   private static byte[] xebucxpmjntynkf() {
      return new byte[]{-20, -2, 89, 24, 49, 122, 65, 36, 112, 56, 18, 116, 57, 74, 2, 29, 86, 121, 107, 89, 5, 11, 107, 45, 104, 90, 26, 57, 34, 38, 52, 89, 21, 76, 111, 100, 26, 13, 50, 121, 94, 27, 71, 79, 55, 43, 97, 101, 96, 91, 22, 89, 127, 78, 16, 99, 16, 115, 91, 77, 50, 73, 67, 7, 116, 99, 21, 37, 61, 82};
   }

   private static byte[] uufbpmwuievrhcz() {
      return new byte[]{-17, -4, 91, 85, 51, 75, 64, 3, 115, 38, 20, 52, 59, 18, 6, 72, 84, 94, 105, 83, 4, 9, 107, 39, 105, 85, 25, 49, 37, 59, 53, 84, 19, 92, 109, 40, 24, 22, 50, 117, 93, 13};
   }

   private static byte[] gnglrdtfycqgsgb() {
      return new byte[]{-17, -4, 91, 27, 51, 126, 64, 34, 115, 61, 20, 113, 59, 75, 6, 28, 84, 115, 105, 94, 4, 26, 107, 126, 105, 27, 25, 46, 37, 35, 53, 24, 19, 67, 109, 34, 24, 17, 50, 59, 93, 0, 68, 78, 52, 104, 102, 104, 96, 84, 19, 9, 127, 23, 18, 100, 16, 108, 89, 80, 50, 84, 66, 13, 115, 106, 21, 107};
   }

   private static byte[] abzbkmarsdmxmlm() {
      return new byte[]{-17, -16, 93, 31, 52, 75, 71, 6, 116, 122, 20, 47, 61, 25, 1, 90, 83, 1};
   }

   private static byte[] ckirkmrwolupyia() {
      return new byte[]{-17, -1, 91, 28, 53, 87, 71, 7, 115, 121, 20, 52, 59, 30, 0, 76, 83, 68, 105, 17};
   }

   private static byte[] exiukzkwbjdutcb() {
      return new byte[]{-19, -7, 94, 81, 54, 66, 64, 6, 119, 34, 21, 32, 62, 23, 15, 91, 85, 74, 106, 80, 2, 13, 108, 45, 105, 78, 29, 54, 37, 98, 51, 10, 24, 92, 108, 45, 27, 3, 53, 126, 89, 23};
   }

   private static byte[] mpdtlvdozandgbx() {
      return new byte[]{-19, -7, 94, 31, 54, 1, 64, 81, 119, 77, 21, 112, 62, 62, 15, 111, 85, 126, 106, 126, 2, 44, 108, 32, 105, 25, 29, 24, 37, 123, 51, 56, 24, 123, 108, 1, 27, 80, 53, 54, 89, 91, 70, 31, 48, 104, 102, 53, 103, 9, 27, 57, 124, 6, 17, 77, 23, 71, 92, 23, 51, 77, 68, 2, 115, 122, 18, 35, 48, 24, 7, 89, 87, 6, 110, 12, 0, 87, 105, 43, 109, 126, 25, 27, 34, 11, 61, 58, 16, 123, 110, 1, 31, 69, 55, 120, 92, 8, 66, 78, 52, 60, 97, 102, 105, 91, 19, 25, 126, 17};
   }

   private static byte[] cqttifwxfidiewn() {
      return new byte[]{-19, -7, 94, 25, 54, 66, 64, 4, 119, 98, 21, 34, 62, 29, 15, 91, 85, 2};
   }

   private static byte[] hbrqolbaeshoofn() {
      return new byte[]{-20, -8, 80, 30, 51, 87, 69, 6, 118, 126, 20, 59, 57, 28, 4, 75, 87, 67, 107, 21};
   }

   private static byte[] saygdompdqywprl() {
      return new byte[]{-17, -8, 94, 85, 59, 79, 70, 7, 114, 39, 20, 38, 62, 17, 14, 95, 82, 78, 104, 86, 4, 11, 110, 39, 97, 75, 31, 53, 36, 99, 53, 9, 22, 91, 101, 49, 30, 0, 51, 127, 93, 25};
   }

   private static byte[] uszhrrofihikejy() {
      return new byte[]{-17, -8, 94, 27, 59, 12, 70, 80, 114, 72, 20, 118, 62, 56, 14, 107, 82, 6, 104, 68, 4, 26, 110, 100, 97, 91, 31, 63, 36, 60, 53, 88, 22, 26, 101, 96, 30, 38, 51, 46, 93, 44, 65, 127, 60, 14, 96, 53, 97, 23, 19, 71, 122, 23, 26, 44, 22, 54, 88, 13, 50, 120, 71, 85, 123, 77, 19, 7, 56, 34, 7, 103, 83, 117, 97, 15, 3, 94, 104, 44, 104, 124, 30, 31, 45, 10, 50, 58, 16, 121, 108, 0, 31, 65, 58, 117, 90, 9, 71, 75, 53, 58, 97, 96, 104, 95, 20, 29, 124, 23};
   }

   private static byte[] dhcoizgwjlxpmri() {
      return new byte[]{-17, -8, 94, 29, 59, 79, 70, 5, 114, 103, 20, 36, 62, 27, 14, 95, 82, 6};
   }

   private static byte[] qxcefvcypwsbtmw() {
      return new byte[]{-25, -5, 88, 24, 55, 78, 70, 7, 122, 116, 23, 39, 63, 28, 4, 91, 82, 15};
   }

   private static byte[] uypdfomeigwktys() {
      return new byte[]{-26, -2, 81, 83, 53, 75, 67, 3, 116, 41, 18, 58, 60, 20, 6, 95, 80, 74, 97, 82};
   }

   private static byte[] gsbkgfjksklzrhc() {
      return new byte[]{-24, -7, 95, 94, 49, 79, 67, 0, 117, 39, 21, 33, 49, 16, 2, 88, 83, 72, 111, 80, 3, 2, 107, 32, 106, 72, 31, 51, 37, 99, 60, 13, 21, 95, 106, 47, 30, 3, 52, 113, 94, 26};
   }

   private static byte[] ilpwtoccyolrpao() {
      return new byte[]{-24, -7, 95, 16, 49, 12, 67, 87, 117, 72, 21, 113, 49, 57, 2, 108, 83, 124, 111, 126, 3, 35, 107, 45, 106, 31, 31, 29, 37, 122, 60, 63, 21, 120, 106, 3, 30, 80, 52, 57, 94, 86, 69, 25, 50, 109, 102, 52, 104, 14, 22, 58, 122, 4, 20, 77, 22, 72, 91, 26, 48, 75, 70, 7, 115, 123, 29, 36, 61, 27, 1, 91, 82, 6, 111, 3, 7, 90, 106, 45, 111, 123, 25, 26, 45, 12, 48, 57, 22, 121, 107, 1, 30, 74, 48, 117, 95, 14, 64, 75, 52, 61, 110, 97, 100, 88, 21, 27, 123, 17};
   }

   private static byte[] rlevfscdfqukwfz() {
      return new byte[]{-24, -7, 95, 22, 49, 79, 67, 2, 117, 103, 21, 35, 49, 26, 2, 88, 83, 0};
   }

   private static byte[] nqzjjdldybamtbz() {
      return new byte[]{-17, -3, 88, 23, 48, 92, 64, 6, 123, 126, 20, 54, 56, 21, 5, 71, 84, 69, 97, 22};
   }

   private static byte[] xthugidbcjtjnzx() {
      return new byte[]{-19, -15, 89, 29, 54, 85, 67, 6, 116, 127, 29, 50, 58, 25, 6, 77, 87, 65, 106, 28};
   }

   private static byte[] ddoylqrfilphkgk() {
      return new byte[]{-26, -5, 81, 28, 58, 74, 64, 6, 119, 117, 23, 46, 59, 17, 0, 93, 83, 2};
   }

   private static byte[] ioaieycyepimulx() {
      return new byte[]{-17, -8, 80, 29, 59, 75, 71, 9, 123, 124, 20, 39, 48, 27, 14, 90, 83, 14};
   }

   private static byte[] ncfgnbezwqrlonm() {
      return new byte[]{-20, -4, 90, 94, 53, 74, 68, 7, 117, 35, 16, 36, 49, 20, 7, 95, 84, 72, 107, 85, 6, 2, 111, 37, 109, 79, 31, 55, 32, 102, 60, 14, 16, 92, 109, 51, 26, 5, 49, 113, 90, 25};
   }

   private static byte[] gftsxfvtmeaibtx() {
      return new byte[]{-20, -4, 90, 16, 53, 9, 68, 80, 117, 76, 16, 116, 49, 61, 7, 107, 84, 0, 107, 71, 6, 19, 111, 102, 109, 95, 31, 61, 32, 57, 60, 95, 16, 29, 109, 98, 26, 35, 49, 32, 90, 44, 66, 124, 50, 8, 99, 54, 104, 23, 19, 66, 125, 18, 16, 45, 19, 62, 95, 10, 55, 121, 70, 84, 118, 74, 29, 1, 56, 32, 6, 96, 86, 115, 106, 3, 3, 95, 109, 42, 111, 127, 28, 31, 45, 8, 53, 62, 17, 121, 111, 4, 27, 74, 52, 112, 88, 9, 64, 79, 49, 56, 110, 101, 97, 95, 18, 27, 127, 20};
   }

   private static byte[] gwllsnrpvedhjvu() {
      return new byte[]{-20, -4, 90, 22, 53, 74, 68, 5, 117, 99, 16, 38, 49, 30, 7, 95, 84, 0};
   }

   private static byte[] ifmkoqoxnzomlru() {
      return new byte[]{-17, -6, 93, 83, 49, 77, 68, 0, 123, 37, 20, 36, 61, 23, 4, 93, 80, 73, 97, 84, 4, 9, 109, 33, 107, 73, 29, 50, 45, 97, 53, 11, 21, 93, 111, 51, 28, 7, 58, 125, 93, 27};
   }

   private static byte[] pdjvvdakbpkdwuv() {
      return new byte[]{-17, -6, 93, 29, 49, 14, 68, 87, 123, 74, 20, 116, 61, 62, 4, 105, 80, 1, 97, 70, 4, 24, 109, 98, 107, 89, 29, 56, 45, 62, 53, 90, 21, 28, 111, 98, 28, 33, 58, 44, 93, 46, 66, 121, 54, 12, 98, 50, 104, 21, 19, 69, 121, 17, 16, 46, 20, 49, 81, 15, 50, 122, 68, 83, 113, 79, 17, 0, 49, 32, 7, 101, 80, 115, 107, 13, 1, 89, 97, 46, 104, 126, 29, 25, 39, 8, 48, 61, 25, 123, 108, 2, 28, 71, 48, 119, 88, 14, 78, 73, 53, 56, 98, 102, 98, 93, 22, 26, 117, 21};
   }

   private static byte[] kabzwjeohheywph() {
      return new byte[]{-20, -7, 81, 94, 49, 66, 72, 15, 115, 34, 23, 39, 49, 26, 4, 82, 92, 70, 105, 83, 7, 10, 97, 44, 107, 70, 17, 61, 37, 102, 54, 15, 25, 84, 111, 32, 16, 11, 50, 122, 94, 30};
   }

   private static byte[] hairmoakjgmvwmy() {
      return new byte[]{-20, -7, 81, 16, 49, 1, 72, 88, 115, 77, 23, 119, 49, 51, 4, 102, 92, 114, 105, 125, 7, 43, 97, 33, 107, 17, 17, 19, 37, 127, 54, 61, 25, 115, 111, 12, 16, 88, 50, 50, 94, 82, 78, 22, 54, 98, 110, 58, 96, 15, 16, 57, 117, 10, 16, 68, 24, 72, 89, 29, 49, 76, 72, 9, 113, 116, 29, 46, 57, 27, 4, 93, 92, 14, 107, 2, 13, 86, 105, 41, 107, 125, 17, 20, 39, 7, 60, 50, 17, 124, 111, 1, 16, 74, 48, 120, 84, 1, 70, 78, 54, 59, 110, 107, 98, 82, 26, 21, 125, 18};
   }

   private static byte[] ebnqjlrnziqoaai() {
      return new byte[]{-17, -8, 91, 16, 59, 0, 68, 11, 123, 38, 20, 99, 59, 37, 14, 30, 80, 12, 97, 8, 4, 30, 107, 39, 97, 90, 29, 5, 45, 51, 53, 75, 19, 71};
   }

   private static byte[] pyqaqujhbgammxd() {
      return new byte[0];
   }

   private static byte[] kmxxxmcfcadlrtp() {
      return new byte[]{-21, -2, 88, 22, 53, 79, 66, 6, 118, 122, 20, 46, 63, 27, 4, 90, 81, 1, 104, 69, 3, 88, 107, 125, 108, 89, 24, 60, 35, 47, 54, 30, 20, 76, 108, 106, 30, 24, 48, 62, 89, 6, 71, 83, 50, 56, 100, 118, 101, 90, 19, 23, 123, 82, 16, 41};
   }

   private static byte[] mcfdsblbocaspib() {
      return new byte[]{-20, -7, 81, 87, 48, 75, 69, 7, 122, 35, 21, 57, 56, 18, 6, 77, 84, 83, 107, 84, 13, 13, 106, 36, 108, 85, 16, 55, 37, 52, 53, 82, 17, 90, 109, 33, 26, 18, 58, 115, 95, 8};
   }

   private static byte[] snftomnvurlwatm() {
      return new byte[]{-20, -7, 81, 25, 48, 126, 69, 38, 122, 56, 21, 124, 56, 75, 6, 25, 84, 126, 107, 89, 13, 30, 106, 125, 108, 27, 16, 40, 37, 44, 53, 30, 17, 69, 109, 43, 26, 21, 58, 61, 95, 5, 67, 77, 61, 106, 102, 100, 97, 80, 18, 9, 125, 29, 16, 100, 24, 105, 90, 87, 54, 81, 73, 12, 115, 98, 20, 108};
   }

   private static int kxmsbxokyxrnkomp(int var0, int var1) {
      return var0 ^ var1;
   }
}
