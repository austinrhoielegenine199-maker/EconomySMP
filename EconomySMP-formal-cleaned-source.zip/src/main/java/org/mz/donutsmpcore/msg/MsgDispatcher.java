package org.mz.donutsmpcore.msg;

import org.bukkit.entity.Player;

public interface MsgDispatcher {
   boolean dispatchCrossServer(Player var1, String var2, String var3);
}
