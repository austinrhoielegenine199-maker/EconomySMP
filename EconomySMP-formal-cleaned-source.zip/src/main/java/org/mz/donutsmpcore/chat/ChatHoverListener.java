package org.mz.donutsmpcore.chat;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.clip.placeholderapi.PlaceholderAPI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.HoverEvent.Action;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Statistic;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicesManager;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.KoOo0Ko0oOK;
import skido.oOo0KKoOoOK;
import skido.oOo0oOoOoOK;

public class ChatHoverListener implements Listener {
   private final Economy economy;
   private final DonutSMPCore plugin;
   private final boolean luckPerms;
   private final MiniMessage miniMessage;
   private final LegacyComponentSerializer legacySerializer;
   private static final Pattern GRADIENT_SHORTHAND;
   private static final Pattern LEGACY_HEX_PATTERN;
   private static final String VALID_CODE_CHARS = "0123456789AaBbCcDdEeFfKkLlMmNnOoRrXx";
   private static byte[] tulunpdvec;

   public ChatHoverListener() {
      DonutSMPCore var2 = DonutSMPCore.getInstance();
      this.plugin = var2;
      DonutSMPCore var15 = this.plugin;
      Economy var16 = var15.getEconomy();
      this.economy = var16;
      MiniMessage var17 = MiniMessage.miniMessage();
      this.miniMessage = var17;
      LegacyComponentSerializer.Builder var18 = LegacyComponentSerializer.builder();
      short var3 = 167;
      LegacyComponentSerializer.Builder var19 = var18.character((char)var3);
      LegacyComponentSerializer.Builder var20 = var19.hexColors();
      LegacyComponentSerializer.Builder var21 = var20.useUnusualXRepeatedCharacterHexFormat();
      LegacyComponentSerializer var22 = var21.build();
      this.legacySerializer = var22;
      boolean var23 = CoreComponent.present();
      this.luckPerms = var23;
      boolean var10 = this.luckPerms;
      if (var10) {
         DonutSMPCore var12 = this.plugin;
         Logger var13 = var12.getLogger();
         String var24 = "[Chat] LuckPerms hooked successfully!";
         var13.info(var24);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onChat(AsyncPlayerChatEvent var1) {
      int var157 = 352572072 ^ 1347706954 ^ 630852219;
      var157 = 1887154435 ^ var157;
      Player var22 = var1.getPlayer();
      Player var7 = var22;
      var157 = 1976468287 ^ var157;
      DonutSMPCore var24 = this.plugin;
      FileConfiguration var25 = var24.getConfig();
      var157 = 1781142537 ^ var157;
      String var3 = icyfhmszxl(povcipdbccuttqz(), var157);
      byte var4 = (byte)(257072812 ^ var157);
      byte var27 = var25.getBoolean(var3, (boolean)var4);
      var157 = 1260356023 ^ var157;
      if (var27 == (1145904923 ^ var157)) {
         var157 = 1238659371 ^ var157;
      } else {
         TextComponent var16;
         label124:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var157)) {
               case 72689673:
                  var157 ^= 1716332507;
               case 702399322:
                  break;
               case 715310014:
               default:
                  throw new IllegalAccessException();
               case 998132631:
                  continue;
            }

            String var30 = buildHoverText(var22);
            var157 = 1883702449 ^ var157;
            String var94 = icyfhmszxl(wskzeydnihfwlcn(), var157);
            String var124 = icyfhmszxl(ynlxibmahnahqrp(), var157);
            String var32 = var25.getString(var94, var124);
            var157 = 1760784574 ^ var157;
            String var34 = this.getPrefix(var22);
            var157 = 1015427938 ^ var157;
            String var36 = this.getSuffix(var22);
            var157 = 1147231415 ^ var157;
            String var97 = icyfhmszxl(lyohoywxknjsote(), var157);
            String var38 = var32.replace(var97, var34);
            var157 = 2045241025 ^ var157;
            String var98 = icyfhmszxl(oywqulzjykmzfvi(), var157);
            String var40 = var38.replace(var98, var36);
            var157 = 1030020788 ^ var157;
            String var99 = icyfhmszxl(elhbgoxocojvqon(), var157);
            String var128 = var22.getName();
            String var42 = var40.replace(var99, var128);
            String var145 = var42;
            var157 = 702696245 ^ var157;
            String var100 = icyfhmszxl(jomsxyxorrwksvp(), var157);
            byte var129 = (byte)(791826523 ^ var157);
            byte var44 = var25.getBoolean(var100, (boolean)var129);
            if (var44 != (791826522 ^ var157)) {
               var157 = 1174709567 ^ var157;
               PluginManager var45 = Bukkit.getPluginManager();
               String var101 = icyfhmszxl(nnewesjyskvuwar(), var157);
               byte var46 = var45.isPluginEnabled(var101);
               if (var46 != (1765209445 ^ var157)) {
                  label131: {
                     var157 = 2012028400 ^ var157;

                     try {
                        String var48 = PlaceholderAPI.setPlaceholders(var7, var145);
                        var157 = 926675069 ^ var157;
                        var145 = var48;
                        var157 = 1895177735 ^ var157;
                     } catch (Throwable var158) {
                        switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var157)) {
                           case -153140056 -> var157 = ubggpppgqtylclil(var157, 445984048);
                           case 1325451073 -> var157 = 766434637 ^ var157;
                           default -> throw new RuntimeException("Error in hash");
                        }

                        var157 = 439154185 ^ var157;
                        break label131;
                     }

                     var157 = 1198798147 ^ var157;
                  }
               } else {
                  var157 = ubggpppgqtylclil(var157, 2002044617);
               }
            } else {
               var157 = 827352054 ^ var157;
            }

            String var103 = icyfhmszxl(epvmsziuovlzpof(), var157);
            String var131 = var1.getMessage();
            String var50 = var145.replace(var103, var131);
            var157 = 83395242 ^ var157;
            String var52 = oOo0KKoOoOK.color(var50);
            var157 = 890911485 ^ var157;
            String var54 = var22.getName();
            var157 = 1960797480 ^ var157;
            int var56 = var52.indexOf(var54);
            var157 = 1911481582 ^ var157;
            byte var105 = (byte)(-716245566 ^ var157);
            if (var56 == var105) {
               var157 = 258484047 ^ var157;
               byte var121 = (byte)(634989939 ^ var157);
               var1.setCancelled((boolean)var121);
               var157 = 1914668633 ^ var157;
               BaseComponent[] var123 = TextComponent.fromLegacyText(var52);
               deliver(var1, var123);
               var157 = 1876691564 ^ var157;
               return;
            }

            label108:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var157)) {
                  case 45558119:
                     var157 ^= 1205358290;
                  case 412893645:
                     break label108;
                  case 727758581:
                  default:
                     throw new IllegalAccessException();
                  case 1374072967:
               }
            }

            byte var106 = (byte)(1835615471 ^ var157);
            String var59 = var52.substring(var106, var56);
            var157 = 1701666666 ^ var157;
            int var134 = var54.length();
            int var108 = var56 + var134;
            String var61 = var52.substring(var108);
            var157 = 384478666 ^ var157;
            TextComponent var62 = new TextComponent();
            var16 = var62;
            var157 = 1134569773 ^ var157;
            byte var64 = var59.isEmpty();
            if (var64 == (1565433698 ^ var157)) {
               var157 = 1988490290 ^ var157;
               BaseComponent[] var66 = TextComponent.fromLegacyText(var59);
               BaseComponent[] var17 = var66;
               int var68 = var66.length;
               int var18 = var68;
               byte var69 = (byte)(734751568 ^ var157);
               int var19 = var69;

               for(var157 = 102352080 ^ var157; var19 < var18; var157 = 1348048119 ^ var157) {
                  int var184 = 126072421 ^ var157;
                  BaseComponent var72 = var17[var19];
                  int var185 = 690456085 ^ var184;
                  var16.addExtra(var72);
                  var157 = 2130551943 ^ var185;
                  var19 += 2106276726 ^ var157;
               }

               label82:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var157)) {
                     case 147331546:
                        var157 ^= 45047581;
                        break label82;
                     case 181732991:
                        break;
                     case 1697444774:
                     default:
                        throw new IllegalAccessException();
                     case 1724054202:
                        break label82;
                  }
               }
            } else {
               label97:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var157)) {
                     case 8205948:
                        break;
                     case 80218499:
                        var157 ^= 1915973631;
                     case 377233381:
                        break label97;
                     case 1001190061:
                     default:
                        throw new IllegalAccessException();
                  }
               }
            }

            TextComponent var74 = new TextComponent(var54);
            var157 = 1952403027 ^ var157;
            HoverEvent.Action var5 = Action.SHOW_TEXT;
            String var138 = oOo0KKoOoOK.color(var30);
            BaseComponent[] var139 = TextComponent.fromLegacyText(var138);
            HoverEvent var112 = new HoverEvent(var5, var139);
            var74.setHoverEvent(var112);
            var157 = 19688085 ^ var157;
            ClickEvent.Action var136 = net.md_5.bungee.api.chat.ClickEvent.Action.SUGGEST_COMMAND;
            String var141 = "/msg " + var54;
            ClickEvent var113 = new ClickEvent(var136, var141);
            var74.setClickEvent(var113);
            var157 = 706009305 ^ var157;
            var16.addExtra(var74);
            var157 = 71538755 ^ var157;
            byte var79 = var61.isEmpty();
            if (var79 == (1952027841 ^ var157)) {
               var157 = 1347049356 ^ var157;
               BaseComponent[] var81 = TextComponent.fromLegacyText(var61);
               BaseComponent[] var152 = var81;
               int var83 = var81.length;
               int var153 = var83;
               byte var84 = (byte)(605274957 ^ var157);
               int var154 = var84;

               for(var157 = 761316439 ^ var157; var154 < var153; var157 = ubggpppgqtylclil(var157, 302001337)) {
                  int var193 = 1061716708 ^ var157;
                  BaseComponent var89 = var152[var154];
                  int var194 = 280943324 ^ var193;
                  var16.addExtra(var89);
                  var157 = 1039561857 ^ var194;
                  var154 += 460532642 ^ var157;
               }

               var157 = ubggpppgqtylclil(var157, 1722437767);
               break;
            }

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var157)) {
                  case 23979116:
                     var157 ^= 461423452;
                  case 469688640:
                     break label124;
                  case 545283852:
                  default:
                     throw new IllegalAccessException();
                  case 1052376783:
               }
            }
         }

         byte var116 = (byte)(1876514716 ^ var157);
         var1.setCancelled((boolean)var116);
         var157 = 82331093 ^ var157;
         byte var117 = (byte)(1798378057 ^ var157);
         BaseComponent[] var118 = new BaseComponent[var117];
         byte var137 = (byte)(1798378056 ^ var157);
         var118[var137] = var16;
         deliver(var1, var118);
         var157 = 925899326 ^ var157;
      }
   }

   private static void deliver(AsyncPlayerChatEvent var0, BaseComponent... var1) {
      int var30 = 143809935 ^ 351731207 ^ 1697254738;
      var30 = 1722235560 ^ var30;

      Object var4;
      label65: {
         try {
            Set var26 = var0.getRecipients();
            ArrayList var2 = new ArrayList(var26);
            var4 = var2;
            var30 = 135349168 ^ var30;
         } catch (Throwable var31) {
            switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var30)) {
               case -11754608:
                  var30 = 1658577942 ^ var30;
                  var30 = 1039606522 ^ var30;
                  Collection var20 = Bukkit.getOnlinePlayers();
                  var4 = var20;
                  var30 = 2139015130 ^ var30;
                  break label65;
               default:
                  throw new IOException("Error in hash");
            }
         }

         var30 = 675496582 ^ var30;
      }

      Iterator var8 = ((Collection)var4).iterator();
      Iterator var5 = var8;
      var30 = 1219310517 ^ var30;

      label59:
      while(true) {
         byte var10 = var5.hasNext();
         if (var10 != (1997973233 ^ var30)) {
            var30 = 667628499 ^ var30;
            Object var12 = var5.next();
            Player var13 = (Player)var12;
            var30 = 1129160362 ^ var30;
            Player var22 = var0.getPlayer();
            byte var15 = oOo0oOoOoOK.sees(var13, var22);
            if (var15 != (328207240 ^ var30)) {
               var30 = 2115594308 ^ var30;
               Player.Spigot var17 = var13.spigot();
               var17.sendMessage(var1);
               var30 = 731109024 ^ var30;
               var30 = 822875037 ^ var30;
               continue;
            }

            var30 = 1994370692 ^ var30;

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var30)) {
                  case 71969416:
                     var30 ^= 307823613;
                  case 364590383:
                     continue label59;
                  case 1612360389:
                     break;
                  case 2129385140:
                  default:
                     throw new RuntimeException();
               }
            }
         } else {
            label52:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var30)) {
                  case 112956516:
                     var30 ^= 951967518;
                     break label52;
                  case 912076381:
                  default:
                     throw new RuntimeException();
                  case 1404700744:
                     break;
                  case 1824116370:
                     break label52;
               }
            }
         }

         ConsoleCommandSender var18 = Bukkit.getConsoleSender();
         String var25 = BaseComponent.toLegacyText(var1);
         var18.sendMessage(var25);
         var30 = 339823219 ^ var30;
         return;
      }
   }

   private String convertGradientShorthand(String var1) {
      int var45 = 132022136 ^ 2096706849 ^ 630852219;
      var45 = 947236108 ^ var45;
      if (var1 == null) {
         var45 = 460110496 ^ var45;
         String var33 = icyfhmszxl(agipaabvpeaoyvy(), var45);
         return var33;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var45)) {
               case 119876929:
                  var45 ^= 671635325;
               case 1076334284:
                  Pattern var12 = GRADIENT_SHORTHAND;
                  Matcher var13 = var12.matcher(var1);
                  Matcher var5 = var13;
                  var45 = 294922842 ^ var45;
                  StringBuffer var14 = new StringBuffer();
                  StringBuffer var6 = var14;
                  var45 = 138607237 ^ var45;

                  while(true) {
                     byte var16 = var5.find();
                     if (var16 == (1461086860 ^ var45)) {
                        var45 = ubggpppgqtylclil(var45, 100127647);
                        StringBuffer var18 = var5.appendTail(var6);
                        var45 = 1753869974 ^ var45;
                        String var20 = var6.toString();
                        return var20;
                     }

                     var45 = 930442401 ^ var45;
                     byte var35 = (byte)(1617102380 ^ var45);
                     String var22 = var5.group(var35);
                     var45 = 395861339 ^ var45;
                     byte var36 = (byte)(2012961652 ^ var45);
                     String var24 = var5.group(var36);
                     var45 = 624855978 ^ var45;
                     byte var37 = (byte)(1388695775 ^ var45);
                     String var26 = var5.group(var37);
                     var45 = 1225550563 ^ var45;
                     String var28 = this.convertLegacyToMiniMessage(var24);
                     var45 = 1141001196 ^ var45;
                     String var30 = "<gradient:" + var22 + ":" + var26 + ">" + var28 + "</gradient>";
                     var45 = 934942591 ^ var45;
                     String var42 = Matcher.quoteReplacement(var30);
                     Matcher var32 = var5.appendReplacement(var6, var42);
                     var45 = 638246827 ^ var45;
                     var45 = ubggpppgqtylclil(var45, 426595211);
                  }
               case 953792748:
               default:
                  throw new IOException();
               case 1106720732:
            }
         }
      }
   }

   private String parseMiniMessage(String var1) {
      int var58 = 1246723461 ^ 472586933 ^ 630852219;
      var58 = 625751934 ^ var58;
      if (var1 != null) {
         var58 = 2049152507 ^ var58;
         byte var9 = var1.isEmpty();
         if (var9 == (747753422 ^ var58)) {
            var58 = 1625203261 ^ var58;

            Exception var10000;
            label82: {
               String var55;
               label105: {
                  String var5;
                  label106: {
                     String var6;
                     label79: {
                        label78: {
                           try {
                              String var11 = convertLegacyHexToMiniMessage(var1);
                              var5 = var11;
                              int var66 = 775762677 ^ var58;
                              String var13 = this.convertGradientShorthand(var11);
                              var6 = var13;
                              var58 = 953585162 ^ var66;
                              String var42 = icyfhmszxl(wekzcagauwtogqd(), var58);
                              byte var15 = var13.contains(var42);
                              if (var15 == (1520750860 ^ var58)) {
                                 var58 = 168268939 ^ var58;
                                 String var43 = icyfhmszxl(ajaqabpbcgdvftw(), var58);
                                 byte var17 = var13.contains(var43);
                                 if (var17 != (1352877447 ^ var58)) {
                                    break label78;
                                 }

                                 var58 = 567148439 ^ var58;
                                 String var44 = icyfhmszxl(gwgdcomotgomeam(), var58);
                                 byte var19 = var13.contains(var44);
                                 if (var19 == (1903082000 ^ var58)) {
                                    break label106;
                                 }

                                 var58 = 591241437 ^ var58;
                                 break label79;
                              }
                           } catch (Exception var62) {
                              var10000 = var62;
                              boolean var10001 = false;
                              break label82;
                           }

                           var58 = 150457281 ^ var58;
                           break label79;
                        }

                        var58 = ubggpppgqtylclil(var58, 49307466);
                     }

                     try {
                        String var34 = this.convertLegacyToMiniMessage(var6);
                        var58 = 1823838212 ^ var58;
                        MiniMessage var36 = this.miniMessage;
                        Component var37 = var36.deserialize(var34);
                        var58 = 292089348 ^ var58;
                        LegacyComponentSerializer var39 = this.legacySerializer;
                        String var40 = var39.serialize(var37);
                        var55 = var40;
                        var58 = 647499174 ^ var58;
                     } catch (Exception var60) {
                        var10000 = var60;
                        boolean var78 = false;
                        break label82;
                     }

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var58)) {
                           case 26961193:
                              var58 ^= 1213471252;
                              break label105;
                           case 377691771:
                              break;
                           case 1679132081:
                              break label105;
                           case 2054747669:
                           default:
                              throw new IOException();
                        }
                     }
                  }

                  var58 = ubggpppgqtylclil(var58, 2066771491);

                  try {
                     String var21 = oOo0KKoOoOK.color(var5);
                     var55 = var21;
                     var58 ^= 1260169036;
                  } catch (Exception var61) {
                     var10000 = var61;
                     boolean var77 = false;
                     break label82;
                  }
               }

               try {
                  byte var22 = (byte)(1094873945 ^ var58);
                  String var23 = ChatColor.translateAlternateColorCodes((char)var22, var55);
                  var58 = 1832084923 ^ var58;
                  String var25 = stripOrphanAmpersands(var23);
                  var58 = 2035695757 ^ var58;
                  return var25;
               } catch (Exception var59) {
                  var10000 = var59;
                  boolean var79 = false;
               }
            }

            switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var58)) {
               case -2061882310 -> var58 = ubggpppgqtylclil(var58, 520531907);
               case -1955213181 -> var58 = 1053511764 ^ var58;
               case -1835477398 -> var58 = 502722697 ^ var58;
               case -718895006 -> var58 = ubggpppgqtylclil(var58, 352402248);
               case -147564983 -> var58 = ubggpppgqtylclil(var58, 1900241037);
               case 169057274 -> var58 = ubggpppgqtylclil(var58, 250059067);
               case 328398899 -> var58 = 769111362 ^ var58;
               case 1219709784 -> var58 = ubggpppgqtylclil(var58, 1186169647);
               case 1391894936 -> var58 = 1174093431 ^ var58;
               case 1652256666 -> var58 = 65701815 ^ var58;
               case 1669903905 -> var58 = ubggpppgqtylclil(var58, 1674902656);
               case 2087921257 -> var58 = 1613467273 ^ var58;
               default -> throw new IOException("Error in hash");
            }

            Exception var26 = var10000;
            var58 = 205249988 ^ var58;
            DonutSMPCore var28 = this.plugin;
            Logger var29 = var28.getLogger();
            String var51 = var26.getMessage();
            String var47 = "[Chat] Failed to parse MiniMessage: " + var1 + " - " + var51;
            var29.warning(var47);
            var58 = 1204446560 ^ var58;
            String var31 = oOo0KKoOoOK.color(var1);
            String var32 = stripOrphanAmpersands(var31);
            return var32;
         }

         var58 = 341337974 ^ var58;
      } else {
         label98:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var58)) {
               case 133814388:
                  var58 ^= 1853616781;
               case 767907820:
                  break label98;
               case 2037104861:
                  break;
               case 2068234632:
               default:
                  throw new IOException();
            }
         }
      }

      String var41 = icyfhmszxl(hlyoqbyjdhahpyr(), var58);
      return var41;
   }

   private static String convertLegacyHexToMiniMessage(String var0) {
      int var59 = 395787119 ^ 966214372 ^ 1697254738;
      var59 = 516089345 ^ var59;
      if (var0 != null) {
         var59 = 1994202932 ^ var59;
         byte var10 = var0.isEmpty();
         if (var10 == (590712300 ^ var59)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var59)) {
                  case 70771148:
                     var59 ^= 1095757911;
                  case 1368378665:
                     byte var2 = (byte)(1652194755 ^ var59);
                     int var12 = var0.indexOf(var2);
                     if (var12 < (1652194747 ^ var59)) {
                        var59 = 177034868 ^ var59;
                        byte var42 = (byte)(1761029015 ^ var59);
                        int var14 = var0.indexOf(var42);
                        if (var14 < (1761029071 ^ var59)) {
                           var59 = 1333336673 ^ var59;
                           return var0;
                        }

                        var59 = ubggpppgqtylclil(var59, 2029311913);
                     } else {
                        label77:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var59)) {
                              case 248328672:
                                 var59 ^= 1920565725;
                                 break label77;
                              case 555702122:
                                 break;
                              case 746279799:
                              default:
                                 throw new IOException();
                              case 1712187112:
                                 break label77;
                           }
                        }
                     }

                     Pattern var16 = LEGACY_HEX_PATTERN;
                     Matcher var17 = var16.matcher(var0);
                     Matcher var4 = var17;
                     var59 = 383522109 ^ var59;
                     byte var19 = var17.find();
                     if (var19 == (115337563 ^ var59)) {
                        var59 = 318348172 ^ var59;
                        return var0;
                     }

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var59)) {
                           case 108129306:
                              var59 ^= 186712977;
                           case 2128242968:
                              Matcher var21 = var17.reset();
                              var59 = 770214190 ^ var59;
                              int var51 = var0.length();
                              StringBuffer var22 = new StringBuffer(var51);
                              StringBuffer var5 = var22;
                              var59 = 771660472 ^ var59;

                              while(true) {
                                 byte var24 = var4.find();
                                 if (var24 == (233371996 ^ var59)) {
                                    var59 = ubggpppgqtylclil(var59, 716556453);
                                    StringBuffer var26 = var4.appendTail(var5);
                                    var59 = 986678595 ^ var59;
                                    String var28 = var5.toString();
                                    return var28;
                                 }

                                 var59 = 564322062 ^ var59;
                                 String var30 = var4.group();
                                 String var6 = var30;
                                 var59 = 76439675 ^ var59;
                                 String var52 = icyfhmszxl(wsuucldadfwsuqj(), var59);
                                 StringBuilder var31 = new StringBuilder(var52);
                                 StringBuilder var7 = var31;
                                 var59 = 635064507 ^ var59;
                                 byte var32 = (byte)(220075665 ^ var59);
                                 int var8 = var32;
                                 var59 = 943081170 ^ var59;

                                 label55:
                                 while(true) {
                                    int var46 = var6.length();
                                    if (var8 >= var46) {
                                       var59 = 188917153 ^ var59;
                                       byte var47 = (byte)(1047197151 ^ var59);
                                       StringBuilder var35 = var7.append((char)var47);
                                       var59 = 1653501260 ^ var59;
                                       String var54 = var7.toString();
                                       String var55 = Matcher.quoteReplacement(var54);
                                       Matcher var37 = var4.appendReplacement(var5, var55);
                                       var59 = 303114337 ^ var59;
                                       var59 = ubggpppgqtylclil(var59, 1125992848);
                                       break;
                                    }

                                    int var72 = 227965049 ^ var59;
                                    char var50 = var6.charAt(var8);
                                    StringBuilder var39 = var7.append(var50);
                                    var59 = 1544380677 ^ var72;
                                    var8 += 1689471294 ^ var59;

                                    while(true) {
                                       switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var59)) {
                                          case 52115799:
                                             var59 ^= 1369119100;
                                          case 734533926:
                                             continue label55;
                                          case 734565755:
                                          default:
                                             throw new IOException();
                                          case 1252629876:
                                       }
                                    }
                                 }
                              }
                           case 858758789:
                              break;
                           case 1257391733:
                           default:
                              throw new IOException();
                        }
                     }
                  case 879324506:
                  default:
                     throw new IOException();
                  case 1220330857:
               }
            }
         }

         var59 = 403732989 ^ var59;
      } else {
         var59 = ubggpppgqtylclil(var59, 1858954953);
      }

      return var0;
   }

   private static String stripOrphanAmpersands(String var0) {
      int var46 = 2081904444 ^ 129033252 ^ 1697254738;
      var46 = 2133151653 ^ var46;
      if (var0 != null) {
         var46 = 1168935469 ^ var46;
         byte var10 = var0.isEmpty();
         if (var10 == (604273602 ^ var46)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var46)) {
                  case 97029059:
                     var46 ^= 1982807499;
                  case 47686963:
                     byte var2 = (byte)(1378567727 ^ var46);
                     int var12 = var0.indexOf(var2);
                     if (var12 < (1378567689 ^ var46)) {
                        var46 = 1358274882 ^ var46;
                        return var0;
                     }

                     var46 = 1807630083 ^ var46;
                     int var14 = var0.length();
                     int var5 = var14;
                     var46 = 750302525 ^ var46;
                     StringBuilder var15 = new StringBuilder(var14);
                     StringBuilder var6 = var15;
                     var46 = 2072303298 ^ var46;
                     byte var16 = (byte)(1856576245 ^ var46);
                     int var7 = var16;
                     var46 = 1195801972 ^ var46;

                     label95:
                     while(var7 < var5) {
                        var46 = 1115821658 ^ var46;
                        char var19 = var0.charAt(var7);
                        var46 = 1516870339 ^ var46;
                        byte var35 = (byte)(822405950 ^ var46);
                        if (var19 == var35) {
                           var46 = 1038089756 ^ var46;
                           byte var36 = (byte)(215684357 ^ var46);
                           int var22 = var7 + var36;
                           if (var22 < var5) {
                              var46 = 630073674 ^ var46;
                              String var23 = icyfhmszxl(itkgotulhvomwce(), var46);
                              byte var4 = (byte)(693451855 ^ var46);
                              int var43 = var7 + var4;
                              char var39 = var0.charAt(var43);
                              int var24 = var23.indexOf(var39);
                              if (var24 < (693451854 ^ var46)) {
                                 var46 = ubggpppgqtylclil(var46, 1190723013);
                              } else {
                                 var46 = 278648063 ^ var46;
                                 var6.append(var19);

                                 label49:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var46)) {
                                       case 56088:
                                          var46 ^= 1449339194;
                                          break label49;
                                       case 330338018:
                                       default:
                                          throw new RuntimeException();
                                       case 530871887:
                                          break label49;
                                       case 1076685921:
                                    }
                                 }
                              }
                           } else {
                              label63:
                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var46)) {
                                    case 149451884:
                                       var46 ^= 1668732047;
                                       break label63;
                                    case 557760653:
                                       break;
                                    case 1014314664:
                                       break label63;
                                    case 1899473059:
                                    default:
                                       throw new RuntimeException();
                                 }
                              }
                           }
                        } else {
                           label76:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var46)) {
                                 case 251246202:
                                    var46 ^= 2056857587;
                                    break label76;
                                 case 1021282860:
                                    break;
                                 case 1148511415:
                                 default:
                                    throw new RuntimeException();
                                 case 1812720672:
                                    break label76;
                              }
                           }

                           var6.append(var19);
                           var46 = 607128928 ^ var46;
                        }

                        var7 += 1873658250 ^ var46;

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var46)) {
                              case 140560720:
                                 var46 ^= 1178773002;
                                 continue label95;
                              case 1606910236:
                              default:
                                 throw new RuntimeException();
                              case 1766239087:
                                 break;
                              case 2092350448:
                                 continue label95;
                           }
                        }
                     }

                     var46 = 974877564 ^ var46;
                     String var30 = var6.toString();
                     return var30;
                  case 1090772804:
                     break;
                  case 1874627281:
                  default:
                     throw new RuntimeException();
               }
            }
         }

         var46 = 820048179 ^ var46;
      } else {
         var46 = ubggpppgqtylclil(var46, 1967946526);
      }

      return var0;
   }

   private String convertLegacyToMiniMessage(String var1) {
      int var177 = 1577635309 ^ 147969649 ^ 630852219;
      var177 = 1679462461 ^ var177;
      if (var1 == null) {
         var177 = 386331589 ^ var177;
         String var74 = icyfhmszxl(tdmfjiygincimuo(), var177);
         return var74;
      } else {
         var177 = ubggpppgqtylclil(var177, 1393734677);
         String var3 = icyfhmszxl(ugrptqsttooxhwk(), var177);
         String var4 = icyfhmszxl(eihgdviiqxuiwsc(), var177);
         String var6 = var1.replace(var3, var4);
         var177 = 1643211473 ^ var177;
         String var75 = icyfhmszxl(rpvtosbtijfaaav(), var177);
         String var108 = icyfhmszxl(diabidrkmlbcogf(), var177);
         String var8 = var6.replace(var75, var108);
         var177 = 1431466002 ^ var177;
         String var76 = icyfhmszxl(nsozapbvbmsciew(), var177);
         String var109 = icyfhmszxl(mxdnymreiyucmdz(), var177);
         String var10 = var8.replace(var76, var109);
         var177 = 1389766380 ^ var177;
         String var77 = icyfhmszxl(lrlzoyxwddszdsp(), var177);
         String var110 = icyfhmszxl(bybyvbxgjtzeqkd(), var177);
         String var12 = var10.replace(var77, var110);
         var177 = 1154869251 ^ var177;
         String var78 = icyfhmszxl(treotkknijeodrz(), var177);
         String var111 = icyfhmszxl(aqllbgynfajuonb(), var177);
         String var14 = var12.replace(var78, var111);
         var177 = 1683972440 ^ var177;
         String var79 = icyfhmszxl(xungqezcklqtizn(), var177);
         String var112 = icyfhmszxl(zusflayrnhpplum(), var177);
         String var16 = var14.replace(var79, var112);
         var177 = 832930487 ^ var177;
         String var80 = icyfhmszxl(ubfxkmcdbrofxqe(), var177);
         String var113 = icyfhmszxl(mvbeeexkzuazhzu(), var177);
         String var18 = var16.replace(var80, var113);
         var177 = 695806324 ^ var177;
         String var81 = icyfhmszxl(wykzexlzldwxuue(), var177);
         String var114 = icyfhmszxl(mftwhuaeutsueij(), var177);
         String var20 = var18.replace(var81, var114);
         var177 = 418421452 ^ var177;
         String var82 = icyfhmszxl(ffbcilvytuhlgpp(), var177);
         String var115 = icyfhmszxl(kgmwltghkjpurcn(), var177);
         String var22 = var20.replace(var82, var115);
         var177 = 469980629 ^ var177;
         String var83 = icyfhmszxl(aoinctdywxvxxot(), var177);
         String var116 = icyfhmszxl(vwbnvnyyvcmzhfh(), var177);
         String var24 = var22.replace(var83, var116);
         var177 = 2034073187 ^ var177;
         String var84 = icyfhmszxl(zpdjzuivhxibhgv(), var177);
         String var117 = icyfhmszxl(yymofpkdvjjwtzn(), var177);
         String var26 = var24.replace(var84, var117);
         var177 = 1538786594 ^ var177;
         String var85 = icyfhmszxl(jtmawjudiuyeocc(), var177);
         String var118 = icyfhmszxl(xoqcrtwiawyceyk(), var177);
         String var28 = var26.replace(var85, var118);
         var177 = 85022360 ^ var177;
         String var86 = icyfhmszxl(utgexkhmaiqycyx(), var177);
         String var119 = icyfhmszxl(ewvzbtshanadmfa(), var177);
         String var30 = var28.replace(var86, var119);
         var177 = 274609834 ^ var177;
         String var87 = icyfhmszxl(zaurpzewbtvxaww(), var177);
         String var120 = icyfhmszxl(veqbdfitwtzrpmz(), var177);
         String var32 = var30.replace(var87, var120);
         var177 = 917384602 ^ var177;
         String var88 = icyfhmszxl(ybuwvdctdcicmjt(), var177);
         String var121 = icyfhmszxl(ixijuhlohzppwme(), var177);
         String var34 = var32.replace(var88, var121);
         var177 = 1698121831 ^ var177;
         String var89 = icyfhmszxl(tbzhaowprbequnc(), var177);
         String var122 = icyfhmszxl(ebxzhwqcvfsksby(), var177);
         String var36 = var34.replace(var89, var122);
         var177 = 393055925 ^ var177;
         String var90 = icyfhmszxl(jutrzezhvvahfri(), var177);
         String var123 = icyfhmszxl(ealryrvngezuruf(), var177);
         String var38 = var36.replace(var90, var123);
         var177 = 1427872486 ^ var177;
         String var91 = icyfhmszxl(lfkbifqyihtuvar(), var177);
         String var124 = icyfhmszxl(glymlemvrgnvoex(), var177);
         String var40 = var38.replace(var91, var124);
         var177 = 2057095351 ^ var177;
         String var92 = icyfhmszxl(ridpwxjknzuuclv(), var177);
         String var125 = icyfhmszxl(brnhpiraojpwbob(), var177);
         String var42 = var40.replace(var92, var125);
         var177 = 305981343 ^ var177;
         String var93 = icyfhmszxl(zbxlkstciqoncen(), var177);
         String var126 = icyfhmszxl(swreaxxitwiswxh(), var177);
         String var44 = var42.replace(var93, var126);
         var177 = 1348620022 ^ var177;
         String var94 = icyfhmszxl(obortdndqjmeykm(), var177);
         String var127 = icyfhmszxl(cwcibshtirefkzh(), var177);
         String var46 = var44.replace(var94, var127);
         var177 = 1103391926 ^ var177;
         String var95 = icyfhmszxl(xuxmgceukahlyqw(), var177);
         String var128 = icyfhmszxl(dsoavlbkrajoltj(), var177);
         String var48 = var46.replace(var95, var128);
         var177 = 1692644166 ^ var177;
         String var96 = icyfhmszxl(wrsiznjebvlxgcv(), var177);
         String var129 = icyfhmszxl(ltkelqhknjvqbbw(), var177);
         String var50 = var48.replace(var96, var129);
         var177 = 67886460 ^ var177;
         String var97 = icyfhmszxl(gvrxdqbevyukkrn(), var177);
         String var130 = icyfhmszxl(fhlecjqfufcdtxj(), var177);
         String var52 = var50.replace(var97, var130);
         var177 = 59372334 ^ var177;
         String var98 = icyfhmszxl(urtneejjpfwnbot(), var177);
         String var131 = icyfhmszxl(hscukcfutpnvyud(), var177);
         String var54 = var52.replace(var98, var131);
         var177 = 1755283968 ^ var177;
         String var99 = icyfhmszxl(bzpemaumezkxwfx(), var177);
         String var132 = icyfhmszxl(owotfyuyipurzey(), var177);
         String var56 = var54.replace(var99, var132);
         var177 = 196337739 ^ var177;
         String var100 = icyfhmszxl(xmvphqakiesicis(), var177);
         String var133 = icyfhmszxl(hjhsyzegeavwpsf(), var177);
         String var58 = var56.replace(var100, var133);
         var177 = 1661326654 ^ var177;
         String var101 = icyfhmszxl(fmnbuinouiikhqt(), var177);
         String var134 = icyfhmszxl(otganhaggqrqwxv(), var177);
         String var60 = var58.replace(var101, var134);
         var177 = 1346527178 ^ var177;
         String var102 = icyfhmszxl(rhmixijohjotddm(), var177);
         String var135 = icyfhmszxl(grboaglfbwfdkxe(), var177);
         String var62 = var60.replace(var102, var135);
         var177 = 991645439 ^ var177;
         String var103 = icyfhmszxl(gzoasducdxhdxkk(), var177);
         String var136 = icyfhmszxl(zyqdkqdeiyhxdel(), var177);
         String var64 = var62.replace(var103, var136);
         var177 = 2127841048 ^ var177;
         String var104 = icyfhmszxl(nhlxxnojacipehc(), var177);
         String var137 = icyfhmszxl(lthocsstotrawuj(), var177);
         String var66 = var64.replace(var104, var137);
         var177 = 22130218 ^ var177;
         String var105 = icyfhmszxl(fcbcmivzqvbrbwe(), var177);
         String var138 = icyfhmszxl(fzygzykcdtcjkxy(), var177);
         String var68 = var66.replace(var105, var138);
         var177 = 1454680579 ^ var177;
         String var106 = icyfhmszxl(aslufqzyjzjgfep(), var177);
         String var139 = icyfhmszxl(cbdpqjymxlmgoel(), var177);
         String var70 = var68.replace(var106, var139);
         var177 = 160264156 ^ var177;
         String var107 = icyfhmszxl(nwhrasxiygwjmut(), var177);
         String var140 = icyfhmszxl(mstfvzbiuijhgww(), var177);
         String var72 = var70.replace(var107, var140);
         var177 = 1812598253 ^ var177;
         return var72;
      }
   }

   private String getPrefix(Player var1) {
      int var15 = 208790484 ^ 1499115445 ^ 630852219;
      var15 = 1071491113 ^ var15;
      byte var5 = this.luckPerms;
      if (var5 == (1332538931 ^ var15)) {
         var15 = 2121609 ^ var15;
         String var6 = icyfhmszxl(werqgukrwvolanp(), var15);
         return var6;
      } else {
         var15 = ubggpppgqtylclil(var15, 446884106);
         String var8 = CoreComponent.prefix(var1);
         var15 = 1496877941 ^ var15;
         byte var10 = var8.isEmpty();
         String var12;
         if (var10 != (217484364 ^ var15)) {
            var15 = 1929183142 ^ var15;
            var12 = icyfhmszxl(kcmplujsrhtcvzz(), var15);
            var15 = 309338222 ^ var15;
         } else {
            var15 = 1864010141 ^ var15;
            var12 = this.parseMiniMessage(var8);
            var15 = 261510741 ^ var15;
         }

         return var12;
      }
   }

   private String getSuffix(Player var1) {
      int var15 = 784343810 ^ 230882227 ^ 630852219;
      var15 = 408349196 ^ var15;
      byte var5 = this.luckPerms;
      if (var5 == (516831430 ^ var15)) {
         var15 = 179571323 ^ var15;
         String var12 = icyfhmszxl(eahksuztzeoujhk(), var15);
         return var12;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var15)) {
               case 196055857:
                  var15 ^= 426321496;
               case 1260897180:
                  String var7 = CoreComponent.suffix(var1);
                  var15 = 194411336 ^ var15;
                  byte var9 = var7.isEmpty();
                  String var11;
                  if (var9 != (204563926 ^ var15)) {
                     var15 = 1742913238 ^ var15;
                     var11 = icyfhmszxl(mcettjbvqjgqxxt(), var15);
                     var15 = 196497296 ^ var15;
                  } else {
                     var15 = 1507890190 ^ var15;
                     var11 = this.parseMiniMessage(var7);
                     var15 = 901014856 ^ var15;
                  }

                  return var11;
               case 464228572:
               default:
                  throw new RuntimeException();
               case 1238732133:
            }
         }
      }
   }

   private String getPrimaryGroup(Player var1) {
      int var8 = 1931974010 ^ 761861086 ^ 630852219;
      var8 = 1024982801 ^ var8;
      byte var3 = this.luckPerms;
      String var5;
      if (var3 != (1187214286 ^ var8)) {
         var8 = 660015518 ^ var8;
         var5 = CoreComponent.primaryGroup(var1);
         var8 = ubggpppgqtylclil(var8, 1894708190);
      } else {
         var8 = ubggpppgqtylclil(var8, 135810891);
         var5 = icyfhmszxl(lrnokkktqygtfyh(), var8);
         var8 = 1604433163 ^ var8;
      }

      return var5;
   }

   public static String buildHoverText(Player var0) {
      int var102 = 1150704681 ^ 179328749 ^ 1697254738;
      var102 = 1585470531 ^ var102;
      Object var1 = null;
      Economy var4 = (Economy)var1;
      var102 = 876077884 ^ var102;

      label102: {
         label101: {
            try {
               ServicesManager var15 = Bukkit.getServicesManager();
               Class var2 = Economy.class;
               RegisteredServiceProvider var16 = var15.getRegistration(var2);
               var102 = 967356053 ^ var102;
               if (var16 != null) {
                  var102 = 1952067759 ^ var102;
                  Object var19 = var16.getProvider();
                  Economy var20 = (Economy)var19;
                  var102 = 572470875 ^ var102;
                  var4 = var20;
                  var102 = 918812721 ^ var102;
                  break label101;
               }
            } catch (Throwable var103) {
               switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var102)) {
                  case -1063734301 -> var102 = 968870366 ^ var102;
                  case 232638282 -> var102 = 1533771 ^ var102;
                  case 1648965272 -> var102 = 1306917233 ^ var102;
                  case 1924170817 -> var102 = 1878708010 ^ var102;
                  default -> throw new IllegalAccessException("Error in hash");
               }

               var102 = 1296332062 ^ var102;
               break label102;
            }

            var102 = 1619459781 ^ var102;
         }

         var102 = ubggpppgqtylclil(var102, 343753221);
      }

      String var21 = icyfhmszxl(surbrplbfvgonpb(), var102);
      String var97 = var21;
      var102 = 1026616901 ^ var102;
      byte var22 = CoreComponent.present();
      if (var22 != (836257017 ^ var102)) {
         var102 = 1838965945 ^ var102;
         String var24 = CoreComponent.prefix(var0);
         String var25 = stripOrphanAmpersands(var24);
         var102 = 278647840 ^ var102;
         if (var25 != null) {
            var102 = 782688537 ^ var102;
            byte var28 = var25.isEmpty();
            if (var28 == (1652102521 ^ var102)) {
               var102 = 2087419537 ^ var102;
               String var30 = var25 + " ";
               var97 = var30;
               var102 = 757437837 ^ var102;
            } else {
               label86:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var102)) {
                     case 248183779:
                        var102 ^= 1364126492;
                     case 1103422945:
                        break label86;
                     case 1245929084:
                        break;
                     case 1608897653:
                     default:
                        throw new RuntimeException();
                  }
               }
            }
         } else {
            var102 = 2145913349 ^ var102;
         }
      } else {
         var102 = 49265308 ^ var102;
      }

      double var68;
      if (var4 != null) {
         var102 = 1100183534 ^ var102;
         var68 = var4.getBalance(var0);
         var102 = ubggpppgqtylclil(var102, 2054493812);
      } else {
         label73:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var102)) {
               case 54284244:
                  var102 ^= 811013526;
                  break label73;
               case 551373371:
                  break;
               case 1762809436:
               default:
                  throw new RuntimeException();
               case 2094388311:
                  break label73;
            }
         }

         var68 = (double)0.0F;
         var102 = 196178956 ^ var102;
      }

      String var32 = formatMoneyStatic(var68);
      String var99 = var32;
      var102 = 1322131014 ^ var102;
      Statistic var70 = Statistic.PLAYER_KILLS;
      int var34 = var0.getStatistic(var70);
      String var35 = String.valueOf(var34);
      String var7 = var35;
      var102 = 488406181 ^ var102;
      Statistic var71 = Statistic.PLAY_ONE_MINUTE;
      int var37 = var0.getStatistic(var71);
      String var38 = formatPlaytimeStatic(var37);
      String var8 = var38;
      var102 = 700930539 ^ var102;
      Statistic var72 = Statistic.DEATHS;
      int var40 = var0.getStatistic(var72);
      String var41 = String.valueOf(var40);
      String var9 = var41;
      var102 = 637082047 ^ var102;
      String var43 = getShardsStatic(var0);
      String var10 = var43;
      var102 = 1803873156 ^ var102;
      String var44 = icyfhmszxl(mugmlwdgahfreix(), var102);
      List var45 = KoOo0Ko0oOK.getList(var44);
      List var11 = var45;
      var102 = 933720725 ^ var102;
      StringBuilder var46 = new StringBuilder();
      StringBuilder var12 = var46;
      var102 = 620949052 ^ var102;
      byte var47 = (byte)(773638757 ^ var102);
      int var13 = var47;
      var102 = 1263274175 ^ var102;

      while(true) {
         int var74 = var11.size();
         if (var13 >= var74) {
            var102 = 1069864832 ^ var102;
            String var50 = var12.toString();
            return var50;
         }

         var102 = 450581143 ^ var102;
         Object var52 = var11.get(var13);
         String var53 = (String)var52;
         String var76 = icyfhmszxl(kozjjmkbvxmfwjk(), var102);
         var102 = 1866033774 ^ var102;
         String var54 = var53.replace(var76, var97);
         String var77 = icyfhmszxl(joafpkbujqaqqdw(), var102);
         var102 = 1775321655 ^ var102;
         String var90 = var0.getName();
         String var55 = var54.replace(var77, var90);
         String var78 = icyfhmszxl(eqkrgksopwwyjad(), var102);
         var102 = 848464964 ^ var102;
         String var56 = var55.replace(var78, var99);
         String var79 = icyfhmszxl(qsnobmbvndrgnrh(), var102);
         var102 = 2137427838 ^ var102;
         String var57 = var56.replace(var79, var7);
         String var80 = icyfhmszxl(ufabmjtfkivmmwl(), var102);
         var102 = 1720073040 ^ var102;
         String var58 = var57.replace(var80, var8);
         String var81 = icyfhmszxl(khwvubzwfnbywru(), var102);
         var102 = 1984433482 ^ var102;
         String var59 = var58.replace(var81, var9);
         String var82 = icyfhmszxl(ziuecselinexbxr(), var102);
         var102 = 1995676436 ^ var102;
         String var60 = var59.replace(var82, var10);
         var102 = 673853437 ^ var102;
         var12.append(var60);
         var102 = 1363920556 ^ var102;
         int var85 = var11.size();
         byte var96 = (byte)(734789488 ^ var102);
         int var86 = var85 - var96;
         if (var13 < var86) {
            var102 = 1657464131 ^ var102;
            String var87 = icyfhmszxl(pynvuaksslazgwg(), var102);
            StringBuilder var65 = var12.append(var87);
            var102 = 15847996 ^ var102;
         } else {
            label58:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var102)) {
                  case 81466657:
                     var102 ^= 1648047999;
                     break label58;
                  case 336350556:
                  default:
                     throw new RuntimeException();
                  case 865995628:
                     break;
                  case 1218621744:
                     break label58;
               }
            }
         }

         var13 += 1240516623 ^ var102;
         var102 = 748686036 ^ var102;
      }
   }

   private static String formatMoneyStatic(double var0) {
      int var11 = 1731305665 ^ 481243343 ^ 1697254738;
      var11 = 631036331 ^ var11;
      String var6 = oOo0KKoOoOK.formatPrice(var0);
      String var4 = icyfhmszxl(ptoxnntxmvhhgnx(), var11);
      String var5 = icyfhmszxl(axnsjcqoupywumm(), var11);
      String var7 = var6.replace(var4, var5);
      String var8 = var7.trim();
      return var8;
   }

   private static String formatPlaytimeStatic(int var0) {
   }

   private static String getShardsStatic(Player var0) {
      int var9 = 351120942 ^ 2135848113 ^ 1697254738;
      var9 = 1692222051 ^ var9;
      PluginManager var1 = Bukkit.getPluginManager();
      String var2 = icyfhmszxl(cghitdslelvjuzl(), var9);
      byte var3 = var1.isPluginEnabled(var2);
      String var5;
      if (var3 != (1783928238 ^ var9)) {
         var9 = 899573946 ^ var9;
         String var6 = icyfhmszxl(yzuwaseaefcfhae(), var9);
         var5 = PlaceholderAPI.setPlaceholders(var0, var6);
         var9 = ubggpppgqtylclil(var9, 385940567);
         return var5;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var9)) {
               case 235112533:
                  var9 ^= 306518383;
               case 1468355256:
                  var5 = icyfhmszxl(dbldoxorwmyykrf(), var9);
                  var9 = 819694978 ^ var9;
                  return var5;
               case 538888864:
               default:
                  throw new RuntimeException();
               case 1309176719:
            }
         }
      }
   }

   private String formatMoney(double var1) {
      int var12 = 1829048743 ^ 2027903074 ^ 630852219;
      var12 = 1160352999 ^ var12;
      String var7 = oOo0KKoOoOK.formatPrice(var1);
      String var5 = icyfhmszxl(jrlduolcgjdveqi(), var12);
      String var6 = icyfhmszxl(dtdpiwiydfckgzi(), var12);
      String var8 = var7.replace(var5, var6);
      String var9 = var8.trim();
      return var9;
   }

   private String formatPlaytime(int var1) {
   }

   private String getShards(Player var1) {
      int var10 = 921710033 ^ 1481647116 ^ 630852219;
      var10 = 336375469 ^ var10;
      PluginManager var2 = Bukkit.getPluginManager();
      String var3 = icyfhmszxl(nrlrfzwbmblrydr(), var10);
      byte var4 = var2.isPluginEnabled(var3);
      String var6;
      if (var4 != (1597418763 ^ var10)) {
         var10 = 1833297493 ^ var10;
         String var7 = icyfhmszxl(afyjvnqqsfgwqst(), var10);
         var6 = PlaceholderAPI.setPlaceholders(var1, var7);
         var10 = ubggpppgqtylclil(var10, 985000097);
      } else {
         var10 = ubggpppgqtylclil(var10, 704676537);
         var6 = icyfhmszxl(tfogfmyrylvgmuu(), var10);
         var10 = 2112916557 ^ var10;
      }

      return var6;
   }

   static {
      int var6 = 1734322004 ^ 1597922788 ^ Integer.parseInt("717744226");
      tulunpdvec = uriezbhglagszzu();
      var6 = 1327630896 ^ var6;
      String var0 = icyfhmszxl(uovathmwvchftqf(), var6);
      Pattern var1 = Pattern.compile(var0);
      GRADIENT_SHORTHAND = var1;
      var6 = 806382513 ^ var6;
      String var2 = icyfhmszxl(itjkpsekfknvgdy(), var6);
      var6 = 1578119141 ^ var6;
      Pattern var3 = Pattern.compile(var2);
      LEGACY_HEX_PATTERN = var3;
      var6 = 669378418 ^ var6;
   }

   public static String icyfhmszxl(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = tulunpdvec;
         byte[] var34 = tulunpdvec;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   private static byte[] uriezbhglagszzu() {
      return new byte[]{77, 107, 55, 123, 119, 31, 94, 45, 123, 11, 41, 16, 27, 18, 41, 37, 81, 30, 59, 59, 35, 90, 7, 105, 92, 1, 55, 24, 41, 87, 36, 40, 71, 64, 62, 23, 109, 112};
   }

   private static byte[] uovathmwvchftqf() {
      return new byte[]{-126, -95, 1, 127, 78, 4, 102, 60, 74, 96, 24, 100, 45, 7, 16, 80, 105, 77, 10, 38, 18, 9, 49, 97, 101, 31, 15, 19, 24, 58, 21, 102, 113, 78, 7, 89, 85, 107, 124, 101, 6, 102, 65, 9, 103, 52, 67, 6, 24, 9, 42, 27, 31, 50, 104, 5, 3, 42, 18, 49, 54, 29, 106, 20, 14, 109, 17, 4, 21, 53, 118, 19, 8, 31, 84, 110, 117, 96, 6, 22, 70, 81, 104, 35, 66, 69, 17, 11, 42, 28};
   }

   private static byte[] itjkpsekfknvgdy() {
      return new byte[]{-126, -84, 4, 24, 67, 13, 107, -71, 66, 99, 24, 80, 40, 2, 29, 46, 100, 23, 2, 85, 18, 68, 52, -10, 104, 104, 2, 112, 16, 82, 21, 61, 116, 65, 10, 98, 88, 110, 116, 24, 6, 34, 68, 10, 106, 127, 78, 101, 16, 12, 42, 81, 26, 43, 101, 87};
   }

   private static byte[] wsuucldadfwsuqj() {
      return new byte[]{-123, -84, 4, 126, 66, 13};
   }

   private static byte[] itkgotulhvomwce() {
      return new byte[]{-123, -83, 4, 127, 66, 31, 102, 42, 79, 14, 16, 23, 47, 18, 24, 43, 100, 29, 13, 58, 16, 87, 50, 25, 100, 85, 3, 108, 16, 6, 16, 94, 118, 27, 11, 103, 91, 45, 126, 26, 2, 47, 79, 108, 106, 125, 66, 115, 29, 78, 42, 102, 28, 125, 103, 106, 8, 98, 22, 37, 63, 50, 104, 120, 14, 68, 29, 48, 21, 98, 114, 44, 8, 86};
   }

   private static byte[] kozjjmkbvxmfwjk() {
      return new byte[]{-127, -91, 4, 103, 79, 90, 108, 103, 76, 89, 27, 71, 40, 66, 17, 104, 99, 3};
   }

   private static byte[] qsnobmbvndrgnrh() {
      return new byte[]{-126, -90, 0, 106, 71, 77, 102, 115, 77, 95, 24, 78, 44, 85, 25, 57};
   }

   private static byte[] joafpkbujqaqqdw() {
      return new byte[]{-127, -84, 7, 111, 65, 91, 102, 120, 66, 88, 17, 89, 42, 65, 29, 111, 104, 2};
   }

   private static byte[] ufabmjtfkivmmwl() {
      return new byte[]{-117, -84, 5, 109, 66, 86, 110, 121, 77, 82, 17, 91, 40, 83, 16, 124, 105, 69, 3, 102, 17, 76};
   }

   private static byte[] khwvubzwfnbywru() {
      return new byte[]{-126, -89, 0, 104, 79, 76, 102, 127, 74, 82, 24, 87, 44, 76, 17, 97, 105, 12};
   }

   private static byte[] surbrplbfvgonpb() {
      return new byte[0];
   }

   private static byte[] pynvuaksslazgwg() {
      return new byte[]{-126, -90, 5, 69};
   }

   private static byte[] mugmlwdgahfreix() {
      return new byte[]{-126, -92, 6, 32, 64, 64, 103, 127, 79, 79, 24, 14, 42, 66, 30, 125, 104, 91, 15, 110, 18, 24};
   }

   private static byte[] eqkrgksopwwyjad() {
      return new byte[]{-127, -92, 4, 104, 66, 69, 102, 113, 73, 81, 27, 69, 40, 93, 28, 55};
   }

   private static byte[] ziuecselinexbxr() {
      return new byte[]{-123, -92, 14, 102, 67, 84, 104, 119, 67, 92, 25, 91, 35, 66, 17, 96, 99, 3};
   }

   private static byte[] ptoxnntxmvhhgnx() {
      return new byte[]{-118, -83, 5, 107};
   }

   private static byte[] axnsjcqoupywumm() {
      return new byte[0];
   }

   private static byte[] cghitdslelvjuzl() {
      return new byte[]{-126, -93, 15, 24, 78, 65, 102, 126, 72, 80, 24, 66, 35, 73, 16, 120, 105, 64, 8, 103, 18, 8, 63, 40, 101, 114, 15, 122, 26, 38};
   }

   private static byte[] dbldoxorwmyykrf() {
      return new byte[]{-127, -92, 6, 127};
   }

   private static byte[] yzuwaseaefcfhae() {
      return new byte[]{-126, -94, 7, 105, 70, 72, 102, 119, 67, 85, 24, 83, 43, 81, 24, 101, 105, 70, 3, 123, 18, 15, 55, 49, 109, 64, 15, 72, 17, 56, 21, 109, 119, 31, 15, 69, 85, 55, 117, 63, 6, 62, 71, 13};
   }

   private static byte[] povcipdbccuttqz() {
      return new byte[]{-127, -95, 0, 40, 64, 69, 102, 125, 73, 77, 28, 9, 43, 70, 27, 104, 96, 95, 9, 122, 20, 5, 48, 54, 100, 29, 5, 76, 28, 15, 20, 109, 117, 21, 15, 68, 95, 49, 122, 117, 0, 44, 79, 64, 108, 126, 78, 94, 25, 75, 41, 79, 24, 115};
   }

   private static byte[] epvmsziuovlzpof() {
      return new byte[]{-122, -92, 14, 105, 66, 64, 108, 123, 77, 77, 25, 90, 44, 70, 27, 112, 98, 77, 14, 46};
   }

   private static byte[] jomsxyxorrwksvp() {
      return new byte[]{-124, -83, 6, 32, 69, 65, 107, 126, 73, 72, 16, 15, 35, 67, 31, 101, 99, 95, 12, 118, 18, 13, 53, 50, 105, 30, 5, 73, 16, 9, 28, 104, 113, 24, 12, 68, 90, 61, 124, 125, 5, 61, 66, 65, 108, 123, 66, 89, 17, 71, 45, 79, 27, 120, 102, 75, 10, 103, 17, 9, 50, 41, 110, 87, 14, 89, 17, 12};
   }

   private static byte[] lyohoywxknjsote() {
      return new byte[]{-126, -91, 6, 108, 64, 91, 106, 104, 72, 94, 24, 71, 42, 73, 30, 105, 101, 12};
   }

   private static byte[] wskzeydnihfwlcn() {
      return new byte[]{-126, -89, 15, 40, 67, 71, 110, 126, 79, 78, 24, 13, 35, 65, 29, 96, 97, 95, 15, 126, 18, 6, 63, 52, 104, 28, 7, 76, 29, 9, 21, 105, 127, 29, 10, 70, 93, 54, 121, 116, 6, 46, 79, 64, 106, 111, 75, 84, 29, 64, 42, 85};
   }

   private static byte[] ynlxibmahnahqrp() {
      return new byte[]{-126, -89, 15, 110, 67, 95, 110, 109, 79, 95, 24, 69, 35, 75, 29, 109, 97, 9, 15, 44, 18, 15, 63, 124, 104, 65, 7, 70, 29, 7, 21, 98, 127, 21, 10, 85, 93, 103, 121, 127, 6, 59, 79, 90, 106, 123, 75, 95, 29, 72, 42, 89, 17, 48, 101, 14, 11, 47, 23, 83, 54, -31, 100, 17, 3, 14, 25, 3, 16, 60, 118, 30, 6, 66, 89, 51, 125, 42, 3, 43, 70, 75, 102, 120, 79, 30};
   }

   private static byte[] nnewesjyskvuwar() {
      return new byte[]{-126, -93, 1, 30, 69, 67, 103, 120, 79, 93, 24, 66, 45, 79, 27, 122, 104, 70, 15, 106, 18, 8, 49, 46, 110, 112, 14, 124, 29, 43};
   }

   private static byte[] elhbgoxocojvqon() {
      return new byte[]{-126, -91, 3, 109, 71, 94, 102, 113, 76, 91, 24, 93, 40, 71, 24, 111, 97, 12};
   }

   private static byte[] oywqulzjykmzfvi() {
      return new byte[]{-126, -92, 7, 111, 64, 92, 108, 96, 76, 88, 24, 70, 43, 74, 30, 109, 99, 3};
   }

   private static byte[] agipaabvpeaoyvy() {
      return new byte[0];
   }

   private static byte[] gwgdcomotgomeam() {
      return new byte[]{-126, -83, 7, 116, 71, 4};
   }

   private static byte[] ajaqabpbcgdvftw() {
      return new byte[]{-126, -89, 2, 117, 79, 90, 105, 120, 79, 85, 24, 77, 46, 66, 17, 125, 102, 93};
   }

   private static byte[] hlyoqbyjdhahpyr() {
      return new byte[0];
   }

   private static byte[] wekzcagauwtogqd() {
      return new byte[]{-126, -95, 5, 119, 64, 77, 110, 103, 77, 90, 24, 65, 41, 75, 30, 117, 97, 72, 13, 127};
   }

   private static byte[] ybuwvdctdcicmjt() {
      return new byte[]{-122, -89, 1, 101, 66, 69};
   }

   private static byte[] ixijuhlohzppwme() {
      return new byte[]{-122, -89, 1, 127, 66, 84, 108, 127, 73, 90, 26, 24};
   }

   private static byte[] aoinctdywxvxxot() {
      return new byte[]{-122, -91, 4, 104, 68, 21};
   }

   private static byte[] vwbnvnyyvcmzhfh() {
      return new byte[]{-122, -91, 4, 114, 68, 78, 110, 115, 78, 75, 24, 70, 46, 31};
   }

   private static byte[] nwhrasxiygwjmut() {
      return new byte[]{-126, -93, 1, 110, 71, 127};
   }

   private static byte[] mstfvzbiuijhgww() {
      return new byte[]{-126, -93, 1, 116, 71, 95, 111, 113, 72, 75, 24, 66, 45, 85, 25, 41};
   }

   private static byte[] xungqezcklqtizn() {
      return new byte[]{-121, -95, 4, 101, 68, 18};
   }

   private static byte[] zusflayrnhpplum() {
      return new byte[]{-121, -95, 4, 127, 68, 67, 104, 123, 79, 76, 26, 67, 40, 117, 31, 98, 101, 94, 8, 113, 16, 18, 49, 50, 104, 81, 4, 30};
   }

   private static byte[] nsozapbvbmsciew() {
      return new byte[]{-126, -84, 14, 105, 69, 27};
   }

   private static byte[] mxdnymreiyucmdz() {
      return new byte[]{-126, -84, 14, 115, 69, 77, 106, 121, 67, 65, 24, 67, 34, 121, 27, 116, 101, 89, 3, 102, 18, 7, 62, 51, 110, 9};
   }

   private static byte[] wykzexlzldwxuue() {
      return new byte[]{-121, -96, 4, 109, 68, 28};
   }

   private static byte[] mftwhuaeutsueij() {
      return new byte[]{-121, -96, 4, 119, 68, 76, 106, 103, 67, 94, 29, 90, 43, 31};
   }

   private static byte[] jtmawjudiuyeocc() {
      return new byte[]{-126, -92, 7, 101, 65, 109};
   }

   private static byte[] xoqcrtwiawyceyk() {
      return new byte[]{-126, -92, 7, 127, 65, 75, 103, 104, 76, 88, 24, 69, 43, 68, 31, 40};
   }

   private static byte[] tbzhaowprbequnc() {
      return new byte[]{-127, -92, 2, 100, 78, 106};
   }

   private static byte[] ebxzhwqcvfsksby() {
      return new byte[]{-127, -92, 2, 126, 78, 91, 105, 122, 74, 90, 27, 30};
   }

   private static byte[] rpvtosbtijfaaav() {
      return new byte[]{-123, -89, 5, 100, 64, 31};
   }

   private static byte[] diabidrkmlbcogf() {
      return new byte[]{-123, -89, 5, 126, 64, 74, 110, 127, 67, 79, 26, 73, 34, 122, 24, 119, 98, 74, 13, 125, 17, 6, 48, 102};
   }

   private static byte[] urtneejjpfwnbot() {
      return new byte[]{-122, -84, 3, 107, 66, 70};
   }

   private static byte[] hscukcfutpnvyud() {
      return new byte[]{-122, -84, 3, 113, 66, 88, 107, 107, 67, 76, 17, 77, 45, 76, 29, 117, 99, 82, 14, 107, 23, 30, 50, 50, 105, 70, 15, 74, 17, 11, 18, 35};
   }

   private static byte[] xmvphqakiesicis() {
      return new byte[]{-126, -91, 7, 107, 65, 65};
   }

   private static byte[] hjhsyzegeavwpsf() {
      return new byte[]{-126, -91, 7, 113, 65, 90, 105, 113, 79, 92, 24, 68, 43, 86, 31, 121, 102, 69, 15, 102, 18, 14, 55, 59, 106, 15};
   }

   private static byte[] lrlzoyxwddszdsp() {
      return new byte[]{-122, -93, 3, 105, 78, 29};
   }

   private static byte[] bybyvbxgjtzeqkd() {
      return new byte[]{-122, -93, 3, 115, 78, 74, 111, 124, 79, 76, 30, 79, 47, 116, 24, 117, 97, 91, 14, 121, 23, 15, 62, 102};
   }

   private static byte[] wrsiznjebvlxgcv() {
      return new byte[]{-123, -90, 1, 106, 68, 64};
   }

   private static byte[] ltkelqhknjvqbbw() {
      return new byte[]{-123, -90, 1, 112, 68, 78, 108, 114, 73, 81, 27, 66, 44, 31};
   }

   private static byte[] ridpwxjknzuuclv() {
      return new byte[]{-126, -91, 7, 100, 66, 78};
   }

   private static byte[] brnhpiraojpwbob() {
      return new byte[]{-126, -91, 7, 126, 66, 82, 108, 124, 74, 86, 24, 77, 43, 68, 28, 102, 99, 20};
   }

   private static byte[] nhlxxnojacipehc() {
      return new byte[]{-118, -89, 6, 109, 71, 64};
   }

   private static byte[] lthocsstotrawuj() {
      return new byte[]{-118, -89, 6, 119, 71, 68, 109, 126, 73, 84, 26, 84, 43, 81, 29, 117, 96, 77, 2, 124, 18, 15, 55, 57, 111, 14};
   }

   private static byte[] xuxmgceukahlyqw() {
      return new byte[]{-126, -91, 7, 111, 65, 104};
   }

   private static byte[] dsoavlbkrajoltj() {
      return new byte[]{-126, -91, 7, 117, 65, 89, 111, 113, 74, 80, 24, 85, 43, 69, 31, 42};
   }

   private static byte[] tdmfjiygincimuo() {
      return new byte[0];
   }

   private static byte[] ubfxkmcdbrofxqe() {
      return new byte[]{-117, -95, 1, 106, 66, 27};
   }

   private static byte[] mvbeeexkzuazhzu() {
      return new byte[]{-117, -95, 1, 112, 66, 74, 104, 119, 73, 95, 28, 66, 44, 25};
   }

   private static byte[] ffbcilvytuhlgpp() {
      return new byte[]{-121, -89, 2, 107, 70, 20};
   }

   private static byte[] kgmwltghkjpurcn() {
      return new byte[]{-121, -89, 2, 113, 70, 72, 103, 122, 79, 74, 28, 77, 42, 126, 16, 116, 101, 95, 14, 108, 18, 16, 62, 97};
   }

   private static byte[] utgexkhmaiqycyx() {
      return new byte[]{-118, -95, 0, 110, 68, 72};
   }

   private static byte[] ewvzbtshanadmfa() {
      return new byte[]{-118, -95, 0, 116, 68, 75, 103, 101, 73, 71, 28, 70, 40, 31};
   }

   private static byte[] ugrptqsttooxhwk() {
      return new byte[]{-126, -91, 3, 104, 64, 24};
   }

   private static byte[] eihgdviiqxuiwsc() {
      return new byte[]{-126, -91, 3, 114, 64, 74, 103, 119, 77, 89, 24, 66, 47, 76, 30, 44};
   }

   private static byte[] obortdndqjmeykm() {
      return new byte[]{-117, -91, 15, 106, 64, 77};
   }

   private static byte[] cwcibshtirefkzh() {
      return new byte[]{-117, -91, 15, 112, 64, 92, 104, 125, 74, 90, 30, 83, 47, 65, 17, 42};
   }

   private static byte[] rhmixijohjotddm() {
      return new byte[]{-126, -83, 5, 105, 68, 67};
   }

   private static byte[] grboaglfbwfdkxe() {
      return new byte[]{-126, -83, 5, 115, 68, 69, 111, 104, 72, 95, 24, 69, 41, 79, 26, 117, 96, 17};
   }

   private static byte[] fmnbuinouiikhqt() {
      return new byte[]{-122, -84, 1, 108, 78, 102};
   }

   private static byte[] otganhaggqrqwxv() {
      return new byte[]{-122, -84, 1, 118, 78, 93, 106, 113, 66, 90, 17, 67, 42, 89, 30, 125, 99, 78, 14, 109, 21, 14, 62, 58, 104, 13};
   }

   private static byte[] zpdjzuivhxibhgv() {
      return new byte[]{-126, -93, 4, 101, 78, 73};
   }

   private static byte[] yymofpkdvjjwtzn() {
      return new byte[]{-126, -93, 4, 127, 78, 79, 111, 105, 78, 94, 24, 66, 40, 68, 16, 44};
   }

   private static byte[] treotkknijeodrz() {
      return new byte[]{-126, -93, 5, 107, 64, 24};
   }

   private static byte[] aqllbgynfajuonb() {
      return new byte[]{-126, -93, 5, 113, 64, 72, 106, 116, 74, 64, 24, 76, 41, 123, 30, 100, 101, 67, 10, 102, 18, 83};
   }

   private static byte[] gvrxdqbevyukkrn() {
      return new byte[]{-122, -95, 15, 100, 66, 98};
   }

   private static byte[] fhlecjqfufcdtxj() {
      return new byte[]{-122, -95, 15, 126, 66, 76, 103, 115, 67, 82, 28, 76, 34, 25};
   }

   private static byte[] gzoasducdxhdxkk() {
      return new byte[]{-126, -90, 4, 104, 79, 101};
   }

   private static byte[] zyqdkqdeiyhxdel() {
      return new byte[]{-126, -90, 4, 114, 79, 67, 103, 108, 67, 94, 24, 78, 40, 78, 17, 115, 104, 21};
   }

   private static byte[] lfkbifqyihtuvar() {
      return new byte[]{-118, -95, 5, 109, 70, 105};
   }

   private static byte[] glymlemvrgnvoex() {
      return new byte[]{-118, -95, 5, 119, 70, 65, 106, 115, 77, 85, 28, 74, 43, 87, 27, 78, 102, 88, 2, 123, 17, 24, 54, 43, 104, 90, 1, 68, 28, 91};
   }

   private static byte[] zbxlkstciqoncen() {
      return new byte[]{-126, -89, 3, 105, 70, 98};
   }

   private static byte[] swreaxxitwiswxh() {
      return new byte[]{-126, -89, 3, 115, 70, 94, 106, 127, 73, 83, 24, 79, 47, 73, 24, 106, 101, 23};
   }

   private static byte[] bzpemaumezkxwfx() {
      return new byte[]{-126, -90, 3, 107, 70, 102};
   }

   private static byte[] owotfyuyipurzey() {
      return new byte[]{-126, -90, 3, 113, 70, 88, 111, 111, 72, 75, 24, 75, 47, 79, 24, 116, 96, 92, 8, 97, 18, 26, 51, 48, 109, 64, 6, 73, 26, 13, 21, 36};
   }

   private static byte[] aslufqzyjzjgfep() {
      return new byte[]{-126, -94, 5, 109, 65, 94};
   }

   private static byte[] cbdpqjymxlmgoel() {
      return new byte[]{-126, -94, 5, 119, 65, 94, 102, 126, 79, 73, 24, 67, 41, 86, 31, 40};
   }

   private static byte[] fcbcmivzqvbrbwe() {
      return new byte[]{-118, -92, 15, 101, 64, 96};
   }

   private static byte[] fzygzykcdtcjkxy() {
      return new byte[]{-118, -92, 15, 127, 64, 68, 111, 121, 73, 84, 25, 93, 35, 86, 29, 119, 103, 77, 2, 127, 27, 7, 48, 57, 109, 9};
   }

   private static byte[] jutrzezhvvahfri() {
      return new byte[]{-126, -84, 4, 100, 66, 72};
   }

   private static byte[] ealryrvngezuruf() {
      return new byte[]{-126, -84, 4, 126, 66, 64, 107, 117, 66, 88, 24, 64, 40, 95, 28, 73, 100, 95, 2, 122, 18, 16, 52, 32, 105, 94, 2, 76, 16, 93};
   }

   private static byte[] zaurpzewbtvxaww() {
      return new byte[]{-123, -83, 4, 111, 68, 100};
   }

   private static byte[] veqbdfitwtzrpmz() {
      return new byte[]{-123, -83, 4, 117, 68, 71, 107, 107, 75, 72, 16, 66, 41, 31};
   }

   private static byte[] werqgukrwvolanp() {
      return new byte[0];
   }

   private static byte[] kcmplujsrhtcvzz() {
      return new byte[0];
   }

   private static byte[] mcettjbvqjgqxxt() {
      return new byte[0];
   }

   private static byte[] eahksuztzeoujhk() {
      return new byte[0];
   }

   private static byte[] lrnokkktqygtfyh() {
      return new byte[0];
   }

   private static byte[] jrlduolcgjdveqi() {
      return new byte[]{-126, -83, 1, 102};
   }

   private static byte[] dtdpiwiydfckgzi() {
      return new byte[0];
   }

   private static byte[] afyjvnqqsfgwqst() {
      return new byte[]{-117, -96, 1, 106, 70, 77, 105, 113, 79, 93, 29, 83, 47, 87, 31, 97, 98, 71, 3, 127, 21, 13, 54, 48, 107, 64, 3, 69, 29, 62, 16, 106, 113, 31, 13, 66, 85, 54, 123, 59, 6, 62, 64, 9};
   }

   private static byte[] tfogfmyrylvgmuu() {
      return new byte[]{-126, -83, 1, 125};
   }

   private static byte[] nrlrfzwbmblrydr() {
      return new byte[]{-126, -95, 14, 28, 67, 66, 102, 123, 77, 91, 24, 64, 34, 77, 29, 123, 105, 69, 13, 108, 18, 10, 62, 44, 104, 113, 15, 127, 31, 45};
   }

   private static int ubggpppgqtylclil(int var0, int var1) {
      return var1 ^ var0;
   }
}
