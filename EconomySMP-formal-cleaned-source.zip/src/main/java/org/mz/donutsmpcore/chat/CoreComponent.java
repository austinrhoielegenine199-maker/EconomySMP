package org.mz.donutsmpcore.chat;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.cacheddata.CachedDataManager;
import net.luckperms.api.cacheddata.CachedMetaData;
import net.luckperms.api.model.user.User;
import net.luckperms.api.model.user.UserManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicesManager;

public final class CoreComponent {

   private CoreComponent() {
   }

   public static boolean present() {
      int var5 = 4710280 ^ 104513237 ^ 1874920089;
      var5 = 2135104112 ^ var5;
      PluginManager var0 = Bukkit.getPluginManager();
      String var1 = yuybewcjgi(eastdndzqxtlqlt(), mwftatxadqdakng(), var5);
      boolean var2 = var0.isPluginEnabled(var1);
      return var2;
   }

   public static String prefix(Player var0) {
      int var17 = 1800418968 ^ 669698706 ^ 1874920089;
      var17 = 312688750 ^ var17;

      label104: {
         String var6;
         label81: {
            label87: {
               User var2;
               try {
                  User var4 = user(var0);
                  var2 = var4;
                  var17 = 1410029249 ^ var17;
                  if (var4 == null) {
                     var17 = 1365421927 ^ var17;
                     var6 = null;
                     break label87;
                  }
               } catch (Throwable var21) {
                  boolean var10001 = false;
                  break label104;
               }

               var17 = 2088885237 ^ var17;

               try {
                  CachedDataManager var12 = var2.getCachedData();
                  CachedMetaData var13 = var12.getMetaData();
                  var6 = var13.getPrefix();
                  var17 ^= 1836072917;
                  break label81;
               } catch (Throwable var20) {
                  boolean var30 = false;
                  break label104;
               }
            }

            var17 = 1083394887 ^ var17;
         }

         String var10;
         label88: {
            String var3;
            try {
               var3 = var6;
               var17 ^= 1450955321;
               if (var6 == null) {
                  var17 = 1023997296 ^ var17;
                  var10 = yuybewcjgi(mbilqfunojezvxt(), mwftatxadqdakng(), var17);
                  break label88;
               }
            } catch (Throwable var19) {
               boolean var31 = false;
               break label104;
            }

            label60:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var17)) {
                  case 42875966:
                     var17 ^= 575890382;
                     break label60;
                  case 798708649:
                     break;
                  case 1022326312:
                     break label60;
                  case 1484837785:
                  default:
                     throw new RuntimeException();
               }
            }

            try {
               var10 = var3;
               var17 = 910540352 ^ var17;
               return var10;
            } catch (Throwable var18) {
               boolean var32 = false;
               break label104;
            }
         }

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var17)) {
               case 212688037:
                  var17 = 689842430 ^ var17;
                  return var10;
               case 632914238:
                  break;
               case 1513884565:
                  return var10;
               case 1924225422:
               default:
                  throw new RuntimeException();
            }
         }
      }

      switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var17)) {
         case -1899628567 -> var17 = 237176928 ^ var17;
         case -1592762141 -> var17 = kavgwbjvfwebjdlx(var17, 1272560257);
         case -1517667623 -> var17 = 189460934 ^ var17;
         case -896426424 -> var17 = 648643924 ^ var17;
         case -91661656 -> var17 = 548052424 ^ var17;
         case 5631832 -> var17 = 1072761718 ^ var17;
         case 315552041 -> var17 = 497182904 ^ var17;
         case 782189027 -> var17 = kavgwbjvfwebjdlx(var17, 1512595105);
         default -> throw new RuntimeException("Error in hash");
      }

      var17 = 2021303087 ^ var17;
      String var9 = yuybewcjgi(cqhfhbvzufzcepp(), mwftatxadqdakng(), var17);
      return var9;
   }

   public static String suffix(Player var0) {
      int var17 = 403375204 ^ 1120708740 ^ 1874920089;
      var17 = 288683291 ^ var17;

      String var13;
      label63: {
         label64: {
            String var6;
            label56: {
               label65: {
                  User var2;
                  try {
                     User var4 = user(var0);
                     var2 = var4;
                     var17 = 1827818917 ^ var17;
                     if (var4 == null) {
                        var17 = 1636243377 ^ var17;
                        var6 = null;
                        break label65;
                     }
                  } catch (Throwable var21) {
                     boolean var10001 = false;
                     break label64;
                  }

                  var17 = 1270458803 ^ var17;

                  try {
                     CachedDataManager var11 = var2.getCachedData();
                     CachedMetaData var12 = var11.getMetaData();
                     var6 = var12.getSuffix();
                     var17 ^= 377239609;
                     break label56;
                  } catch (Throwable var19) {
                     boolean var31 = false;
                     break label64;
                  }
               }

               var17 = 1010992699 ^ var17;
            }

            String var3;
            try {
               var3 = var6;
               var17 = 411175967 ^ var17;
               if (var6 == null) {
                  var17 = 1519210398 ^ var17;
                  var13 = yuybewcjgi(dujxekfadyimcer(), mwftatxadqdakng(), var17);
                  break label63;
               }
            } catch (Throwable var20) {
               boolean var32 = false;
               break label64;
            }

            var17 = 1236447941 ^ var17;

            try {
               var13 = var3;
               var17 = 1295490862 ^ var17;
               return var13;
            } catch (Throwable var18) {
               boolean var33 = false;
            }
         }

         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var17)) {
            case -1473496472 -> var17 = 440487596 ^ var17;
            case -1202313630 -> var17 = 1481510189 ^ var17;
            case 466484128 -> var17 = 205354645 ^ var17;
            case 563272465 -> var17 = 729191043 ^ var17;
            case 564776122 -> var17 = 1265758326 ^ var17;
            case 1174451770 -> var17 = 1199890214 ^ var17;
            case 1245186993 -> var17 = 637782167 ^ var17;
            case 1815894672 -> var17 = kavgwbjvfwebjdlx(var17, 46351027);
            default -> throw new RuntimeException("Error in hash");
         }

         var17 = 1033363599 ^ var17;
         String var9 = yuybewcjgi(wbnjmxisdziwhcq(), mwftatxadqdakng(), var17);
         return var9;
      }

      var17 = kavgwbjvfwebjdlx(var17, 1577607797);
      return var13;
   }

   public static String primaryGroup(Player var0) {
      int var12 = 318589978 ^ 302326371 ^ 1874920089;
      var12 = 53104906 ^ var12;

      String var8;
      label40: {
         label41: {
            User var2;
            try {
               User var3 = user(var0);
               var2 = var3;
               var12 = 1799025273 ^ var12;
               if (var3 == null) {
                  var12 = 1082692669 ^ var12;
                  var8 = yuybewcjgi(adacmzknsinfbgg(), mwftatxadqdakng(), var12);
                  break label40;
               }
            } catch (Throwable var14) {
               boolean var10001 = false;
               break label41;
            }

            var12 = 971394890 ^ var12;

            try {
               var8 = var2.getPrimaryGroup();
               var12 = 1925339005 ^ var12;
               return var8;
            } catch (Throwable var13) {
               boolean var22 = false;
            }
         }

         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var12)) {
            case -159643959 -> var12 = 2011897205 ^ var12;
            case 961445016 -> var12 = kavgwbjvfwebjdlx(var12, 1309495871);
            case 1024122226 -> var12 = 243648002 ^ var12;
            case 1620701011 -> var12 = 624402502 ^ var12;
            default -> throw new IllegalAccessException("Error in hash");
         }

         var12 = 315851323 ^ var12;
         String var6 = yuybewcjgi(xfowutmiwlikcjr(), mwftatxadqdakng(), var12);
         return var6;
      }

      var12 = 195857418 ^ var12;
      return var8;
   }

   private static User user(Player var0) {
      int var15 = 1313743747 ^ 1284357750 ^ 1874920089;
      var15 = 1474096102 ^ var15;
      ServicesManager var1 = Bukkit.getServicesManager();
      Class var2 = LuckPerms.class;
      RegisteredServiceProvider var4 = var1.getRegistration(var2);
      var15 = 1347080515 ^ var15;
      User var10;
      if (var4 != null) {
         var15 = kavgwbjvfwebjdlx(var15, 1037645065);
         Object var7 = var4.getProvider();
         LuckPerms var8 = (LuckPerms)var7;
         UserManager var9 = var8.getUserManager();
         UUID var12 = var0.getUniqueId();
         var10 = var9.getUser(var12);
         var15 = 1093159587 ^ var15;
         return var10;
      } else {
         var15 = 981667428 ^ var15;
         var10 = null;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var15)) {
               case 187534472:
                  var15 = 1181905358 ^ var15;
                  return var10;
               case 288424287:
               default:
                  throw new RuntimeException();
               case 400559613:
                  return var10;
               case 1178736913:
            }
         }
      }
   }

   public static String yuybewcjgi(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] mwftatxadqdakng() {
      return new byte[]{122, 88, 73, 73, 57, 97, 18, 95, 93, 29};
   }

   private static byte[] eastdndzqxtlqlt() {
      return new byte[]{-73, -97, 124, 61, 13, 37, 39, 4, 101, 69, 66, 61, 113, 24, 8, 38, 42, 10, 110, 86};
   }

   private static byte[] mbilqfunojezvxt() {
      return new byte[0];
   }

   private static byte[] cqhfhbvzufzcepp() {
      return new byte[0];
   }

   private static byte[] wbnjmxisdziwhcq() {
      return new byte[0];
   }

   private static byte[] dujxekfadyimcer() {
      return new byte[0];
   }

   private static byte[] adacmzknsinfbgg() {
      return new byte[0];
   }

   private static byte[] xfowutmiwlikcjr() {
      return new byte[0];
   }

   private static int kavgwbjvfwebjdlx(int var0, int var1) {
      return var1 ^ var0;
   }

   static {
   }
}
