package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.mz.donutsmpcore.crossserver.CrossServerRedisBridge;
import skido.KKo0KoOoOK;
import skido.KKoOoOo0oOK;
import skido.KoOo0Ko0oOK;
import skido.KoOoOKKoOK;
import skido.oOo0KKoOoOK;
import skido.oOo0o0oOo0oOK;

public class TeamCommand implements CommandExecutor, TabCompleter {
   private static final int TEAM_INVITES_SLOT = 30;

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      int var682 = 1447969444 ^ 280650575 ^ 1463372668;
      var682 = 214754365 ^ var682;
      byte var17 = var1 instanceof Player;
      if (var17 == (486641322 ^ var682)) {
         var682 = 1601426431 ^ var682;
         byte var18 = (byte)(1114791252 ^ var682);
         return (boolean)var18;
      } else {
         Player var20;
         TeamService2 var21;
         TeamService var55;
         label710: {
            label709: {
               TeamService var355;
               OfflinePlayer var363;
               label708: {
                  TeamService var157;
                  label707: {
                     label706: {
                        String var177;
                        label754: {
                           label703: {
                              String var244;
                              label702: {
                                 label701: {
                                    TeamService var285;
                                    label700: {
                                       TeamService var126;
                                       label845: {
                                          var682 = wpfsmmvipvqijiso(var682, 539687858);
                                          var20 = (Player)var1;
                                          Player var10 = var20;
                                          var682 = 1883006208 ^ var682;
                                          var21 = TeamService2.getInstance();
                                          var682 = 765144742 ^ var682;
                                          int var23 = var4.length;
                                          byte var6 = (byte)(1619803836 ^ var682);
                                          if (var23 == var6) {
                                             var682 = 1589681105 ^ var682;
                                             byte var374 = (byte)(1045210479 ^ var682);
                                             String var25 = var4[var374];
                                             String var375 = mllziabcns(inloymycgdxlctj(), gwkchkizhlvynzp(), var682);
                                             byte var26 = var25.equalsIgnoreCase(var375);
                                             if (var26 != (1045210479 ^ var682)) {
                                                var682 = 1250911919 ^ var682;
                                                byte var376 = (byte)(1958986689 ^ var682);
                                                String var28 = var4[var376];
                                                OfflinePlayer var29 = Bukkit.getOfflinePlayer(var28);
                                                var682 = 698252668 ^ var682;
                                                UUID var378 = var29.getUniqueId();
                                                TeamService var31 = var21.getTeamByPlayer(var378);
                                                var682 = 986977213 ^ var682;
                                                if (var31 == null) {
                                                   var682 = 1099036201 ^ var682;
                                                   String var379 = mllziabcns(acetkfjgadpnrgi(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var379);
                                                   var682 = 1217342031 ^ var682;
                                                   byte var36 = (byte)(1854370150 ^ var682);
                                                   return (boolean)var36;
                                                }

                                                var682 = 2066179449 ^ var682;
                                                TeamManagementGUI var33 = new TeamManagementGUI(var20, var31);
                                                var33.open();
                                                var682 = 1157043722 ^ var682;
                                                byte var34 = (byte)(1482284659 ^ var682);
                                                return (boolean)var34;
                                             }

                                             var682 = 1559925223 ^ var682;
                                          } else {
                                             label696:
                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                   case 185587996:
                                                      var682 ^= 37358134;
                                                      break label696;
                                                   case 224144500:
                                                      break;
                                                   case 1643913786:
                                                      break label696;
                                                   case 2110663560:
                                                   default:
                                                      throw new RuntimeException();
                                                }
                                             }
                                          }

                                          int var38 = var4.length;
                                          if (var38 == (1656108168 ^ var682)) {
                                             var682 = 609658903 ^ var682;
                                             UUID var381 = var20.getUniqueId();
                                             byte var40 = var21.isInTeam(var381);
                                             if (var40 == (1189125279 ^ var682)) {
                                                var682 = 2082278863 ^ var682;
                                                String var382 = mllziabcns(gftxpqywssbvgkv(), gwkchkizhlvynzp(), var682);
                                                oOo0KKoOoOK.sendActionBarAndChat(var20, var382);
                                                var682 = 631090513 ^ var682;
                                                byte var42 = (byte)(526400512 ^ var682);
                                                return (boolean)var42;
                                             }

                                             var682 = wpfsmmvipvqijiso(var682, 1646953343);
                                             TeamMenu var43 = new TeamMenu(var20);
                                             var43.open();
                                             var682 = 187595117 ^ var682;
                                             byte var44 = (byte)(803497612 ^ var682);
                                             return (boolean)var44;
                                          }

                                          var682 = wpfsmmvipvqijiso(var682, 2130625882);
                                          byte var383 = (byte)(474542546 ^ var682);
                                          String var46 = var4[var383];
                                          String var384 = mllziabcns(eximrpwgafyopvc(), gwkchkizhlvynzp(), var682);
                                          byte var47 = var46.equalsIgnoreCase(var384);
                                          if (var47 != (474542546 ^ var682)) {
                                             var682 = 331414415 ^ var682;
                                             int var49 = var4.length;
                                             byte var385 = (byte)(260573788 ^ var682);
                                             if (var49 == var385) {
                                                var682 = 2085494223 ^ var682;
                                                UUID var387 = var20.getUniqueId();
                                                byte var51 = var21.isInTeam(var387);
                                                if (var51 == (1942362002 ^ var682)) {
                                                   var682 = 354420722 ^ var682;
                                                   String var388 = mllziabcns(pyktflqbhirtnhg(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var388);
                                                   var682 = 21798439 ^ var682;
                                                   byte var53 = (byte)(1739230790 ^ var682);
                                                   return (boolean)var53;
                                                }

                                                var682 = 2036327570 ^ var682;
                                                UUID var390 = var20.getUniqueId();
                                                var55 = var21.getTeamByPlayer(var390);
                                                var682 = 2095323595 ^ var682;
                                                UUID var392 = var20.getUniqueId();
                                                byte var57 = var55.canSetHome(var392);
                                                if (var57 == (1987963595 ^ var682)) {
                                                   var682 = 1561772797 ^ var682;
                                                   String var393 = mllziabcns(zsdxtdryhagwmpy(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var393);
                                                   var682 = 785621583 ^ var682;
                                                   String var394 = mllziabcns(iwvqnpkwowbmrzw(), gwkchkizhlvynzp(), var682);
                                                   Sound var580 = Sound.ENTITY_VILLAGER_NO;
                                                   float var619 = 1.0F;
                                                   float var9 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var394, var580, var619, var9);
                                                   var682 = 873901635 ^ var682;
                                                   byte var60 = (byte)(833496123 ^ var682);
                                                   return (boolean)var60;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 173898958);
                                                byte var62 = KoOoOKKoOK.isWorldBlocked(var20);
                                                if (var62 != (2082510341 ^ var682)) {
                                                   var682 = 1929523593 ^ var682;
                                                   String var401 = mllziabcns(xeeuwhjewpypxpu(), gwkchkizhlvynzp(), var682);
                                                   String var582 = mllziabcns(zkityjyjwifmbhg(), gwkchkizhlvynzp(), var682);
                                                   String var402 = KoOo0Ko0oOK.get(var401, var582);
                                                   var20.sendMessage(var402);
                                                   var682 = 574367195 ^ var682;
                                                   byte var69 = (byte)(756974166 ^ var682);
                                                   return (boolean)var69;
                                                }

                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 8347273:
                                                         var682 ^= 991996749;
                                                         break label710;
                                                      case 651273858:
                                                      default:
                                                         throw new RuntimeException();
                                                      case 827175770:
                                                         break label710;
                                                      case 1004865130:
                                                   }
                                                }
                                             }

                                             var682 = wpfsmmvipvqijiso(var682, 1544510106);
                                          } else {
                                             label684:
                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                   case 100968744:
                                                   default:
                                                      throw new RuntimeException();
                                                   case 114116814:
                                                      var682 ^= 1339007253;
                                                   case 672889193:
                                                      break label684;
                                                   case 2090475443:
                                                }
                                             }
                                          }

                                          byte var403 = (byte)(1401376967 ^ var682);
                                          String var71 = var4[var403];
                                          String var404 = mllziabcns(smirakgrkzlpewo(), gwkchkizhlvynzp(), var682);
                                          byte var72 = var71.equalsIgnoreCase(var404);
                                          if (var72 != (1401376967 ^ var682)) {
                                             var682 = 1699310478 ^ var682;
                                             int var74 = var4.length;
                                             byte var405 = (byte)(919485256 ^ var682);
                                             if (var74 == var405) {
                                                var682 = 898284225 ^ var682;
                                                UUID var407 = var20.getUniqueId();
                                                byte var76 = var21.isInTeam(var407);
                                                if (var76 == (54821256 ^ var682)) {
                                                   var682 = 2059258443 ^ var682;
                                                   String var408 = mllziabcns(buyldpkbbnazccf(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var408);
                                                   var682 = 710817672 ^ var682;
                                                   byte var78 = (byte)(1403485258 ^ var682);
                                                   return (boolean)var78;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 1456999149);
                                                UUID var410 = var20.getUniqueId();
                                                TeamService var80 = var21.getTeamByPlayer(var410);
                                                var682 = 456825498 ^ var682;
                                                UUID var412 = var20.getUniqueId();
                                                var80.toggleTeamChat(var412);
                                                var682 = 910267804 ^ var682;
                                                UUID var584 = var20.getUniqueId();
                                                var21.savePermissions(var80, var584);
                                                var682 = 483031961 ^ var682;
                                                UUID var415 = var20.getUniqueId();
                                                byte var84 = var80.isTeamChatEnabled(var415);
                                                if (var84 != (1680736250 ^ var682)) {
                                                   var682 = 497246928 ^ var682;
                                                   String var417 = mllziabcns(ehbfrgzddvxfogc(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var417);

                                                   while(true) {
                                                      switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                         case 193210639:
                                                            var682 ^= 2100993219;
                                                         case 326029465:
                                                            break label709;
                                                         case 887638166:
                                                            break;
                                                         case 1628600659:
                                                         default:
                                                            throw new RuntimeException();
                                                      }
                                                   }
                                                }

                                                label331:
                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 35224537:
                                                         var682 ^= 2042729115;
                                                      case 487885969:
                                                         break label331;
                                                      case 537189069:
                                                         break;
                                                      case 687694261:
                                                      default:
                                                         throw new RuntimeException();
                                                   }
                                                }

                                                String var416 = mllziabcns(ocfekldnqbknidw(), gwkchkizhlvynzp(), var682);
                                                oOo0KKoOoOK.sendActionBarAndChat(var20, var416);
                                                var682 = 425225352 ^ var682;
                                                break label709;
                                             }

                                             var682 = wpfsmmvipvqijiso(var682, 696285881);
                                          } else {
                                             var682 = 1288245559 ^ var682;
                                          }

                                          byte var418 = (byte)(525222384 ^ var682);
                                          String var89 = var4[var418];
                                          String var419 = mllziabcns(kiixzwvwwprhuot(), gwkchkizhlvynzp(), var682);
                                          byte var90 = var89.equalsIgnoreCase(var419);
                                          if (var90 != (525222384 ^ var682)) {
                                             var682 = 1248758105 ^ var682;
                                             int var92 = var4.length;
                                             byte var420 = (byte)(1428211880 ^ var682);
                                             if (var92 == var420) {
                                                var682 = 1442020674 ^ var682;
                                                UUID var422 = var20.getUniqueId();
                                                byte var94 = var21.isInTeam(var422);
                                                if (var94 == (13874667 ^ var682)) {
                                                   var682 = 1834807425 ^ var682;
                                                   String var436 = mllziabcns(naxpagxuegjnduh(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var436);
                                                   var682 = 1849137382 ^ var682;
                                                   byte var115 = (byte)(62446989 ^ var682);
                                                   return (boolean)var115;
                                                }

                                                label367:
                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 13007455:
                                                         var682 ^= 1691664576;
                                                         break label367;
                                                      case 119336376:
                                                         break;
                                                      case 1341696524:
                                                         break label367;
                                                      case 1665802116:
                                                      default:
                                                         throw new RuntimeException();
                                                   }
                                                }

                                                UUID var424 = var20.getUniqueId();
                                                TeamService var96 = var21.getTeamByPlayer(var424);
                                                var682 = 262798814 ^ var682;
                                                byte var98 = var96.hasTeamHome();
                                                if (var98 == (1806600437 ^ var682)) {
                                                   var682 = 1456301254 ^ var682;
                                                   String var434 = mllziabcns(lliekthhcxeysmt(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var434);
                                                   var682 = 735513283 ^ var682;
                                                   String var435 = mllziabcns(nvpguvyyxiqfnil(), gwkchkizhlvynzp(), var682);
                                                   Sound var587 = Sound.ENTITY_VILLAGER_NO;
                                                   float var622 = 1.0F;
                                                   float var642 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var435, var587, var622, var642);
                                                   var682 = 1229378432 ^ var682;
                                                   byte var113 = (byte)(1609708913 ^ var682);
                                                   return (boolean)var113;
                                                }

                                                label356:
                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 10633972:
                                                         var682 ^= 1098169147;
                                                         break label356;
                                                      case 311434934:
                                                      default:
                                                         throw new RuntimeException();
                                                      case 945555675:
                                                         break label356;
                                                      case 1309561318:
                                                   }
                                                }

                                                UUID var426 = var20.getUniqueId();
                                                byte var100 = var96.canSetHome(var426);
                                                if (var100 == (718943182 ^ var682)) {
                                                   var682 = 453059414 ^ var682;
                                                   String var427 = mllziabcns(zmkefwinidefkll(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var427);
                                                   var682 = 512629896 ^ var682;
                                                   String var428 = mllziabcns(elkfajgzqvvjsgx(), gwkchkizhlvynzp(), var682);
                                                   Sound var585 = Sound.ENTITY_VILLAGER_NO;
                                                   float var620 = 1.0F;
                                                   float var640 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var428, var585, var620, var640);
                                                   var682 = 598094511 ^ var682;
                                                   byte var103 = (byte)(217267902 ^ var682);
                                                   return (boolean)var103;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 109968903);
                                                UUID var430 = var20.getUniqueId();
                                                byte var105 = var96.canVisitHome(var430);
                                                if (var105 == (743951817 ^ var682)) {
                                                   var682 = 758854103 ^ var682;
                                                   String var431 = mllziabcns(ynroudnfvnolbtk(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var431);
                                                   var682 = 1279046888 ^ var682;
                                                   String var432 = mllziabcns(cbsluurmuznylah(), gwkchkizhlvynzp(), var682);
                                                   Sound var586 = Sound.ENTITY_VILLAGER_NO;
                                                   float var621 = 1.0F;
                                                   float var641 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var432, var586, var621, var641);
                                                   var682 = 1209810727 ^ var682;
                                                   byte var108 = (byte)(88897488 ^ var682);
                                                   return (boolean)var108;
                                                }

                                                label345:
                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 99234530:
                                                         var682 ^= 1609637847;
                                                      case 196254235:
                                                         break label345;
                                                      case 857481700:
                                                         break;
                                                      case 1234159119:
                                                      default:
                                                         throw new RuntimeException();
                                                   }
                                                }

                                                TeamComponent.run(var20, var96);
                                                var682 = 1057674073 ^ var682;
                                                byte var110 = (byte)(1286340934 ^ var682);
                                                return (boolean)var110;
                                             }

                                             label671:
                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                   case 82825703:
                                                      var682 ^= 1249910435;
                                                      break label671;
                                                   case 263117972:
                                                   default:
                                                      throw new RuntimeException();
                                                   case 684139198:
                                                      break;
                                                   case 1027115637:
                                                      break label671;
                                                }
                                             }
                                          } else {
                                             var682 = 15636474 ^ var682;
                                          }

                                          byte var437 = (byte)(530634250 ^ var682);
                                          String var117 = var4[var437];
                                          String var438 = mllziabcns(eiysmixvynjyvmp(), gwkchkizhlvynzp(), var682);
                                          byte var118 = var117.equalsIgnoreCase(var438);
                                          if (var118 != (530634250 ^ var682)) {
                                             var682 = 1009256327 ^ var682;
                                             int var120 = var4.length;
                                             byte var439 = (byte)(596169100 ^ var682);
                                             if (var120 == var439) {
                                                var682 = 291638125 ^ var682;
                                                UUID var441 = var20.getUniqueId();
                                                byte var122 = var21.isInTeam(var441);
                                                if (var122 == (854252256 ^ var682)) {
                                                   var682 = 595925504 ^ var682;
                                                   String var442 = mllziabcns(retwytnjkznmuxe(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var442);
                                                   var682 = 1583337264 ^ var682;
                                                   byte var124 = (byte)(1328549841 ^ var682);
                                                   return (boolean)var124;
                                                }

                                                var682 = 1101015413 ^ var682;
                                                UUID var444 = var20.getUniqueId();
                                                var126 = var21.getTeamByPlayer(var444);
                                                var682 = 1580558043 ^ var682;
                                                UUID var446 = var20.getUniqueId();
                                                byte var128 = var126.isLeader(var446);
                                                if (var128 == (763336014 ^ var682)) {
                                                   var682 = 441496321 ^ var682;
                                                   String var447 = mllziabcns(terwnypovzhwdiu(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var447);
                                                   var682 = 1508126752 ^ var682;
                                                   String var448 = mllziabcns(meujqlkrarhnvso(), gwkchkizhlvynzp(), var682);
                                                   Sound var588 = Sound.ENTITY_VILLAGER_NO;
                                                   float var623 = 1.0F;
                                                   float var643 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var448, var588, var623, var643);
                                                   var682 = 1806763506 ^ var682;
                                                   byte var131 = (byte)(91886492 ^ var682);
                                                   return (boolean)var131;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 1088208219);
                                                byte var133 = var126.hasTeamHome();
                                                if (var133 == (1839409173 ^ var682)) {
                                                   var682 = 466767690 ^ var682;
                                                   String var454 = mllziabcns(eagwmcqmnoizzos(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var454);
                                                   var682 = 405350050 ^ var682;
                                                   String var455 = mllziabcns(ruzydsanqoonrii(), gwkchkizhlvynzp(), var682);
                                                   Sound var590 = Sound.ENTITY_VILLAGER_NO;
                                                   float var624 = 1.0F;
                                                   float var644 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var455, var590, var624, var644);
                                                   var682 = 816161341 ^ var682;
                                                   byte var141 = (byte)(1593697217 ^ var682);
                                                   return (boolean)var141;
                                                }

                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 74215435:
                                                         var682 ^= 512773507;
                                                         break label845;
                                                      case 125681534:
                                                      default:
                                                         throw new RuntimeException();
                                                      case 1378430477:
                                                         break label845;
                                                      case 2092968364:
                                                   }
                                                }
                                             }

                                             label659:
                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                   case 81343881:
                                                      var682 ^= 1132203712;
                                                      break label659;
                                                   case 911509142:
                                                      break;
                                                   case 1698662342:
                                                      break label659;
                                                   case 1901239275:
                                                   default:
                                                      throw new RuntimeException();
                                                }
                                             }
                                          } else {
                                             var682 = wpfsmmvipvqijiso(var682, 2136213831);
                                          }

                                          byte var456 = (byte)(1626660685 ^ var682);
                                          String var143 = var4[var456];
                                          String var457 = mllziabcns(ckoevymwnnvdpdf(), gwkchkizhlvynzp(), var682);
                                          byte var144 = var143.equalsIgnoreCase(var457);
                                          if (var144 != (1626660685 ^ var682)) {
                                             var682 ^= 2052701832;
                                             int var146 = var4.length;
                                             byte var458 = (byte)(447570375 ^ var682);
                                             if (var146 == var458) {
                                                var682 = 521569770 ^ var682;
                                                UUID var561 = var20.getUniqueId();
                                                byte var350 = var21.isInTeam(var561);
                                                if (var350 == (96199727 ^ var682)) {
                                                   var682 = 1584376452 ^ var682;
                                                   String var562 = mllziabcns(nughnmoytnzfbjh(), gwkchkizhlvynzp(), var682);
                                                   Sound var616 = Sound.ENTITY_VILLAGER_NO;
                                                   float var636 = 1.0F;
                                                   float var651 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var562, var616, var636, var651);
                                                   var682 = 356760988 ^ var682;
                                                   String var563 = mllziabcns(xynqeerpdrvjqov(), gwkchkizhlvynzp(), var682);
                                                   String var564 = KoOo0Ko0oOK.get(var563);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var564);
                                                   var682 = 1536782986 ^ var682;
                                                   byte var353 = (byte)(353272252 ^ var682);
                                                   return (boolean)var353;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 701657880);
                                                UUID var566 = var20.getUniqueId();
                                                var355 = var21.getTeamByPlayer(var566);
                                                var682 = 18373302 ^ var682;
                                                UUID var568 = var20.getUniqueId();
                                                byte var357 = var355.canKick(var568);
                                                if (var357 == (762432897 ^ var682)) {
                                                   var682 = 366285176 ^ var682;
                                                   String var569 = mllziabcns(ajgllcpiiecloeh(), gwkchkizhlvynzp(), var682);
                                                   Sound var617 = Sound.ENTITY_VILLAGER_NO;
                                                   float var637 = 1.0F;
                                                   float var652 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var569, var617, var637, var652);
                                                   var682 = 1403899256 ^ var682;
                                                   String var570 = mllziabcns(oybezjorlfgvmbi(), gwkchkizhlvynzp(), var682);
                                                   String var571 = KoOo0Ko0oOK.get(var570);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var571);
                                                   var682 = 1599344164 ^ var682;
                                                   byte var360 = (byte)(878518180 ^ var682);
                                                   return (boolean)var360;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 1131893830);
                                                byte var572 = (byte)(1845926342 ^ var682);
                                                String var362 = var4[var572];
                                                var363 = Bukkit.getOfflinePlayer(var362);
                                                var682 = 532283972 ^ var682;
                                                UUID var574 = var363.getUniqueId();
                                                byte var365 = var355.isMember(var574);
                                                if (var365 == (1908185987 ^ var682)) {
                                                   var682 = 1498869637 ^ var682;
                                                   String var578 = mllziabcns(ygiczywrdjcqpsm(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var578);
                                                   var682 = 1864942141 ^ var682;
                                                   byte var373 = (byte)(1203942970 ^ var682);
                                                   return (boolean)var373;
                                                }

                                                var682 = 1433977131 ^ var682;
                                                UUID var576 = var363.getUniqueId();
                                                byte var367 = var355.isLeader(var576);
                                                if (var367 != (616848040 ^ var682)) {
                                                   var682 = 1284946067 ^ var682;
                                                   String var577 = mllziabcns(glpgebdfifqeeds(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var577);
                                                   var682 = 1826015619 ^ var682;
                                                   byte var371 = (byte)(75770809 ^ var682);
                                                   return (boolean)var371;
                                                }

                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 121391969:
                                                         var682 ^= 1114693450;
                                                      case 345085400:
                                                         break label708;
                                                      case 897196756:
                                                         break;
                                                      case 1951521783:
                                                      default:
                                                         throw new RuntimeException();
                                                   }
                                                }
                                             }

                                             label647:
                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                   case 21575032:
                                                   default:
                                                      throw new RuntimeException();
                                                   case 61863872:
                                                      var682 ^= 1613394589;
                                                      break label647;
                                                   case 409724575:
                                                      break;
                                                   case 1530306816:
                                                      break label647;
                                                }
                                             }
                                          } else {
                                             label638:
                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                   case 198840401:
                                                      var682 ^= 443796501;
                                                   case 1058938473:
                                                      break label638;
                                                   case 1765215560:
                                                   default:
                                                      throw new RuntimeException();
                                                   case 2114965365:
                                                }
                                             }
                                          }

                                          byte var459 = (byte)(2055672664 ^ var682);
                                          String var148 = var4[var459];
                                          String var460 = mllziabcns(qmuxhivowmxefby(), gwkchkizhlvynzp(), var682);
                                          byte var149 = var148.equalsIgnoreCase(var460);
                                          if (var149 != (2055672664 ^ var682)) {
                                             var682 = 1860630816 ^ var682;
                                             int var151 = var4.length;
                                             byte var461 = (byte)(341961337 ^ var682);
                                             if (var151 == var461) {
                                                var682 = 1177798727 ^ var682;
                                                UUID var463 = var20.getUniqueId();
                                                byte var153 = var21.isInTeam(var463);
                                                if (var153 == (1381114431 ^ var682)) {
                                                   var682 = 1238921065 ^ var682;
                                                   String var464 = mllziabcns(wirtsqdknguqqef(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var464);
                                                   var682 = 1626666761 ^ var682;
                                                   byte var155 = (byte)(2071902814 ^ var682);
                                                   return (boolean)var155;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 281682436);
                                                UUID var466 = var20.getUniqueId();
                                                var157 = var21.getTeamByPlayer(var466);
                                                var682 = 1386706847 ^ var682;
                                                UUID var468 = var20.getUniqueId();
                                                byte var159 = var157.isLeader(var468);
                                                if (var159 != (272594852 ^ var682)) {
                                                   var682 = 1560718209 ^ var682;
                                                   String var469 = mllziabcns(pmsdevxoogqeylc(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var469);
                                                   var682 = 322773835 ^ var682;
                                                   byte var161 = (byte)(1577385839 ^ var682);
                                                   return (boolean)var161;
                                                }

                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 259713010:
                                                         var682 ^= 1100660093;
                                                      case 339438756:
                                                         break label707;
                                                      case 737490693:
                                                      default:
                                                         throw new RuntimeException();
                                                      case 1851667445:
                                                   }
                                                }
                                             }

                                             label626:
                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                   case 125674025:
                                                      var682 ^= 892938788;
                                                      break label626;
                                                   case 1590309353:
                                                      break;
                                                   case 1634544507:
                                                      break label626;
                                                   case 1803359909:
                                                   default:
                                                      throw new RuntimeException();
                                                }
                                             }
                                          } else {
                                             var682 = 1541395204 ^ var682;
                                          }

                                          byte var470 = (byte)(559464540 ^ var682);
                                          String var165 = var4[var470];
                                          String var471 = mllziabcns(ddxtmabufbupxgg(), gwkchkizhlvynzp(), var682);
                                          byte var166 = var165.equalsIgnoreCase(var471);
                                          if (var166 != (559464540 ^ var682)) {
                                             var682 = 923437133 ^ var682;
                                             int var168 = var4.length;
                                             byte var472 = (byte)(374491155 ^ var682);
                                             if (var168 >= var472) {
                                                var682 = 1569830838 ^ var682;
                                                UUID var474 = var20.getUniqueId();
                                                byte var170 = var21.isInTeam(var474);
                                                if (var170 != (1271136167 ^ var682)) {
                                                   var682 = 181495218 ^ var682;
                                                   String var475 = mllziabcns(sitthuytzpqflqc(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var475);
                                                   var682 = 2138092294 ^ var682;
                                                   byte var172 = (byte)(1046620434 ^ var682);
                                                   return (boolean)var172;
                                                }

                                                label483:
                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 46920848:
                                                         var682 ^= 1554527078;
                                                      case 523491871:
                                                         break label483;
                                                      case 1028714257:
                                                         break;
                                                      case 1313927173:
                                                      default:
                                                         throw new RuntimeException();
                                                   }
                                                }

                                                StringBuilder var173 = new StringBuilder();
                                                StringBuilder var659 = var173;
                                                var682 = 559122481 ^ var682;
                                                byte var174 = (byte)(909657329 ^ var682);
                                                int var664 = var174;
                                                var682 = 547357288 ^ var682;

                                                label473:
                                                while(true) {
                                                   int var477 = var4.length;
                                                   if (var664 >= var477) {
                                                      int var788 = wpfsmmvipvqijiso(var682, 196997748);
                                                      var177 = var659.toString();
                                                      int var789 = 83126805 ^ var788;
                                                      String var179 = oOo0KKoOoOK.color(var177);
                                                      String var180 = ChatColor.stripColor(var179);
                                                      String var181 = var180.toLowerCase();
                                                      String var478 = mllziabcns(jdfhneptmvsspwz(), gwkchkizhlvynzp(), var789);
                                                      String var592 = mllziabcns(gkbwnrhietmxruq(), gwkchkizhlvynzp(), var789);
                                                      String var182 = var181.replace(var478, var592);
                                                      var682 = 1275959610 ^ var789;
                                                      int var184 = var182.length();
                                                      byte var479 = (byte)(1440499648 ^ var682);
                                                      if (var184 >= var479) {
                                                         var682 = 1086721498 ^ var682;
                                                         int var186 = var182.length();
                                                         byte var480 = (byte)(354044425 ^ var682);
                                                         if (var186 > var480) {
                                                            var682 = 831413743 ^ var682;
                                                            break label706;
                                                         }

                                                         var682 = 1248734884 ^ var682;
                                                         String var481 = mllziabcns(nwprshrrbrpqxre(), gwkchkizhlvynzp(), var682);
                                                         byte var188 = var182.matches(var481);
                                                         if (var188 == (1601463485 ^ var682)) {
                                                            var682 = 2078307147 ^ var682;
                                                            break label706;
                                                         }

                                                         var682 = 1053527763 ^ var682;
                                                         TeamService var190 = var21.getTeam(var182);
                                                         if (var190 != null) {
                                                            var682 = 2140450933 ^ var682;
                                                            String var483 = mllziabcns(yoxqlebqllcuovt(), gwkchkizhlvynzp(), var682);
                                                            oOo0KKoOoOK.sendActionBarAndChat(var20, var483);
                                                            var682 = 39831316 ^ var682;
                                                            byte var192 = (byte)(477404430 ^ var682);
                                                            return (boolean)var192;
                                                         }

                                                         while(true) {
                                                            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                               case 224638858:
                                                                  var682 ^= 1712554696;
                                                                  break label754;
                                                               case 1221669340:
                                                                  break;
                                                               case 1643347454:
                                                                  break label754;
                                                               case 1647240257:
                                                               default:
                                                                  throw new RuntimeException();
                                                            }
                                                         }
                                                      }

                                                      while(true) {
                                                         switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                            case 4955518:
                                                               break label706;
                                                            case 106602197:
                                                               var682 ^= 1900564533;
                                                               break label706;
                                                            case 275581807:
                                                            default:
                                                               throw new RuntimeException();
                                                            case 515258566:
                                                         }
                                                      }
                                                   }

                                                   var682 = 1634329935 ^ var682;
                                                   byte var487 = (byte)(2012324822 ^ var682);
                                                   if (var664 > var487) {
                                                      var682 = 1026505373 ^ var682;
                                                      String var488 = mllziabcns(dctnklpqxnamtbc(), gwkchkizhlvynzp(), var682);
                                                      StringBuilder var201 = var659.append(var488);
                                                      var682 = 1714992354 ^ var682;
                                                   } else {
                                                      label454:
                                                      while(true) {
                                                         switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                            case 140794497:
                                                               var682 ^= 1528270463;
                                                            case 667168819:
                                                               break label454;
                                                            case 1395528463:
                                                               break;
                                                            case 2043862132:
                                                            default:
                                                               throw new RuntimeException();
                                                         }
                                                      }
                                                   }

                                                   String var490 = var4[var664];
                                                   StringBuilder var203 = var659.append(var490);
                                                   var682 = 1797438040 ^ var682;
                                                   var664 += 1204066289 ^ var682;

                                                   while(true) {
                                                      switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                         case 185377189:
                                                            var682 ^= 1365037416;
                                                            continue label473;
                                                         case 493664640:
                                                         default:
                                                            throw new RuntimeException();
                                                         case 959512799:
                                                            break;
                                                         case 1858084362:
                                                            continue label473;
                                                      }
                                                   }
                                                }
                                             }

                                             var682 = wpfsmmvipvqijiso(var682, 287008958);
                                          } else {
                                             var682 = wpfsmmvipvqijiso(var682, 638705907);
                                          }

                                          byte var491 = (byte)(122233007 ^ var682);
                                          String var205 = var4[var491];
                                          String var492 = mllziabcns(jgeqifxdmdbigzc(), gwkchkizhlvynzp(), var682);
                                          byte var206 = var205.equalsIgnoreCase(var492);
                                          if (var206 != (122233007 ^ var682)) {
                                             var682 = 1833246464 ^ var682;
                                             int var208 = var4.length;
                                             byte var493 = (byte)(1779187629 ^ var682);
                                             if (var208 == var493) {
                                                var682 = 678409817 ^ var682;
                                                UUID var495 = var20.getUniqueId();
                                                byte var210 = var21.isInTeam(var495);
                                                if (var210 == (1113819638 ^ var682)) {
                                                   var682 = 55607671 ^ var682;
                                                   String var496 = mllziabcns(fsqywjccmujjhdj(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var496);
                                                   var682 = 516146708 ^ var682;
                                                   byte var212 = (byte)(1609617044 ^ var682);
                                                   return (boolean)var212;
                                                }

                                                label526:
                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 10524975:
                                                         var682 ^= 1643273889;
                                                      case 1037471574:
                                                         break label526;
                                                      case 1493395533:
                                                         break;
                                                      case 1907214071:
                                                      default:
                                                         throw new RuntimeException();
                                                   }
                                                }

                                                UUID var498 = var20.getUniqueId();
                                                TeamService var214 = var21.getTeamByPlayer(var498);
                                                var682 = 341228563 ^ var682;
                                                UUID var500 = var20.getUniqueId();
                                                byte var216 = var214.canInvite(var500);
                                                if (var216 == (935816004 ^ var682)) {
                                                   var682 = 637315021 ^ var682;
                                                   String var528 = mllziabcns(kzyogdxbntfwfmd(), gwkchkizhlvynzp(), var682);
                                                   String var529 = KoOo0Ko0oOK.get(var528);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var529);
                                                   var682 = 1426307955 ^ var682;
                                                   byte var274 = (byte)(1194883067 ^ var682);
                                                   return (boolean)var274;
                                                }

                                                var682 = 300571610 ^ var682;
                                                byte var501 = (byte)(640495775 ^ var682);
                                                String var218 = var4[var501];
                                                Player var219 = Bukkit.getPlayer(var218);
                                                var682 = 1632132873 ^ var682;
                                                if (var219 == null) {
                                                   var682 = 740274663 ^ var682;
                                                   byte var596 = (byte)(1803214449 ^ var682);
                                                   String var503 = var4[var596];
                                                   String var598 = var214.getName();
                                                   byte var222 = TeamSyncBridge.tryDispatchInvite(var20, var503, var598);
                                                   if (var222 != (1803214448 ^ var682)) {
                                                      var682 = 882664292 ^ var682;
                                                      byte var504 = (byte)(1608957205 ^ var682);
                                                      String var224 = var4[var504];
                                                      String var225 = "#2399FF" + var224;
                                                      var682 = 2066051221 ^ var682;
                                                      String var506 = "&7You invited " + var225 + " &7to the team";
                                                      oOo0KKoOoOK.sendActionBarAndChat(var20, var506);
                                                      var682 = 1995863362 ^ var682;
                                                      String var507 = mllziabcns(ymtcxzrtoavueae(), gwkchkizhlvynzp(), var682);
                                                      Sound var599 = Sound.BLOCK_NOTE_BLOCK_PLING;
                                                      float var626 = 1.0F;
                                                      float var645 = 1.8F;
                                                      KKo0KoOoOK.play(var20, var507, var599, var626, var645);
                                                      var682 = 1261303420 ^ var682;
                                                      byte var228 = (byte)(421023422 ^ var682);
                                                      return (boolean)var228;
                                                   }

                                                   while(true) {
                                                      switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                         case 4089219:
                                                            var682 ^= 1693655757;
                                                            break label703;
                                                         case 612891709:
                                                         default:
                                                            throw new RuntimeException();
                                                         case 613633655:
                                                            break label703;
                                                         case 1786576015:
                                                      }
                                                   }
                                                }

                                                var682 = 1262023764 ^ var682;
                                                UUID var511 = var219.getUniqueId();
                                                byte var232 = var21.isInTeam(var511);
                                                if (var232 != (207461315 ^ var682)) {
                                                   var682 = 321032621 ^ var682;
                                                   String var527 = mllziabcns(bktbgycupsaewdi(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var527);
                                                   var682 = 824496021 ^ var682;
                                                   byte var272 = (byte)(777766394 ^ var682);
                                                   return (boolean)var272;
                                                }

                                                var682 = 1186142653 ^ var682;
                                                oOo0o0oOo0oOK var233 = oOo0o0oOo0oOK.getInstance();
                                                byte var600 = (byte)(1257144928 ^ var682);
                                                byte var234 = var233.isEnabled(var219, var600);
                                                if (var234 == (1257144958 ^ var682)) {
                                                   var682 = 1602805675 ^ var682;
                                                   String var265 = var219.getName();
                                                   String var266 = "#FF0000" + var265 + " has disabled team invites.";
                                                   var682 = 297862263 ^ var682;
                                                   String var524 = oOo0KKoOoOK.color(var266);
                                                   var20.sendMessage(var524);
                                                   var682 = 1013475052 ^ var682;
                                                   oOo0KKoOoOK.sendActionBar(var20, var266);
                                                   var682 = 445149446 ^ var682;
                                                   String var526 = mllziabcns(zhhegxyocgaicmm(), gwkchkizhlvynzp(), var682);
                                                   Sound var607 = Sound.ENTITY_VILLAGER_NO;
                                                   float var630 = 1.0F;
                                                   float var648 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var526, var607, var630, var648);
                                                   var682 = 302461618 ^ var682;
                                                   byte var270 = (byte)(809532667 ^ var682);
                                                   return (boolean)var270;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 1094409469);
                                                byte var236 = var214.isFull();
                                                if (var236 == (198565507 ^ var682)) {
                                                   var682 = wpfsmmvipvqijiso(var682, 1761375145);
                                                   UUID var246 = var219.getUniqueId();
                                                   byte var247 = TeamService3.hasInvite(var246);
                                                   if (var247 != (1663675690 ^ var682)) {
                                                      var682 = 1517593447 ^ var682;
                                                      String var516 = mllziabcns(pxrezndihaqstth(), gwkchkizhlvynzp(), var682);
                                                      oOo0KKoOoOK.sendActionBarAndChat(var20, var516);
                                                      var682 = 45611265 ^ var682;
                                                      byte var249 = (byte)(1005254477 ^ var682);
                                                      return (boolean)var249;
                                                   }

                                                   var682 = 1946262743 ^ var682;
                                                   TeamService3.addInvite(var219, var214);
                                                   var682 = 937464717 ^ var682;
                                                   String var252 = var219.getName();
                                                   String var253 = "#2399FF" + var252;
                                                   var682 = 1286220554 ^ var682;
                                                   String var255 = var214.getName();
                                                   String var256 = "#2399FF" + var255;
                                                   var682 = 1140508784 ^ var682;
                                                   String var602 = var20.getName();
                                                   String var603 = var602 + " &7invited you to the team " + var256 + " &8[CLICK TO ACCEPT]";
                                                   String var604 = oOo0KKoOoOK.color(var603);
                                                   BaseComponent[] var605 = TextComponent.fromLegacyText(var604);
                                                   TextComponent var257 = new TextComponent(var605);
                                                   var682 = 1282010001 ^ var682;
                                                   ClickEvent.Action var628 = Action.RUN_COMMAND;
                                                   String var646 = mllziabcns(yqpsphowsbojvly(), gwkchkizhlvynzp(), var682);
                                                   ClickEvent var518 = new ClickEvent(var628, var646);
                                                   var257.setClickEvent(var518);
                                                   var682 = 725009641 ^ var682;
                                                   Player.Spigot var260 = var219.spigot();
                                                   var260.sendMessage(var257);
                                                   var682 = 36458100 ^ var682;
                                                   String var521 = "&7You invited " + var253 + " &7to the team";
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var521);
                                                   var682 = 392936917 ^ var682;
                                                   String var522 = mllziabcns(xlzwwozxdeixsru(), gwkchkizhlvynzp(), var682);
                                                   Sound var606 = Sound.BLOCK_NOTE_BLOCK_PLING;
                                                   float var629 = 1.0F;
                                                   float var647 = 1.8F;
                                                   KKo0KoOoOK.play(var20, var522, var606, var629, var647);
                                                   var682 = 239807090 ^ var682;
                                                   byte var263 = (byte)(1405859744 ^ var682);
                                                   return (boolean)var263;
                                                }

                                                var682 = 269826136 ^ var682;
                                                int var237 = TeamService.getMaxPlayers();
                                                var682 = 950039497 ^ var682;
                                                if (var237 <= (593532178 ^ var682)) {
                                                   var682 = 489417251 ^ var682;
                                                   var244 = mllziabcns(ejhlrxwollqbbxq(), gwkchkizhlvynzp(), var682);
                                                   var682 = 489253291 ^ var682;
                                                   break label702;
                                                }

                                                var682 = 495923104 ^ var682;
                                                Set var242 = var214.getMembers();
                                                int var243 = var242.size();
                                                var244 = "(" + var243 + "/" + var237 + ")";

                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 157004059:
                                                      default:
                                                         throw new RuntimeException();
                                                      case 166741847:
                                                         var682 ^= 495823912;
                                                      case 935798612:
                                                         break label702;
                                                      case 1242483551:
                                                   }
                                                }
                                             }

                                             var682 = wpfsmmvipvqijiso(var682, 1553537515);
                                          } else {
                                             label614:
                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                   case 114592237:
                                                      var682 ^= 836503275;
                                                      break label614;
                                                   case 645390769:
                                                      break;
                                                   case 831002407:
                                                      break label614;
                                                   case 1795023172:
                                                   default:
                                                      throw new RuntimeException();
                                                }
                                             }
                                          }

                                          byte var530 = (byte)(915744324 ^ var682);
                                          String var276 = var4[var530];
                                          String var531 = mllziabcns(vcvseslkbwlsxif(), gwkchkizhlvynzp(), var682);
                                          byte var277 = var276.equalsIgnoreCase(var531);
                                          if (var277 != (915744324 ^ var682)) {
                                             var682 = 289249363 ^ var682;
                                             int var279 = var4.length;
                                             byte var532 = (byte)(665370134 ^ var682);
                                             if (var279 == var532) {
                                                var682 = 859753811 ^ var682;
                                                UUID var281 = var20.getUniqueId();
                                                byte var282 = TeamService3.hasInvite(var281);
                                                if (var282 == (345404228 ^ var682)) {
                                                   var682 = 1391782636 ^ var682;
                                                   String var547 = mllziabcns(wxutzvlvmdolcdc(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var547);
                                                   var682 = 954314877 ^ var682;
                                                   byte var329 = (byte)(2122525140 ^ var682);
                                                   return (boolean)var329;
                                                }

                                                label586:
                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                      case 132344773:
                                                         var682 ^= 489461306;
                                                         break label586;
                                                      case 988245246:
                                                      default:
                                                         throw new RuntimeException();
                                                      case 1623550339:
                                                         break;
                                                      case 1707082127:
                                                         break label586;
                                                   }
                                                }

                                                UUID var284 = var20.getUniqueId();
                                                var285 = TeamService3.getInvite(var284);
                                                var682 = 2141546962 ^ var682;
                                                byte var287 = var285.isFull();
                                                if (var287 != (1981779116 ^ var682)) {
                                                   var682 = 23695034 ^ var682;
                                                   UUID var289 = var20.getUniqueId();
                                                   TeamService3.removeInvite(var289);
                                                   var682 = 1324881557 ^ var682;
                                                   int var290 = TeamService.getMaxPlayers();
                                                   var682 = 669457974 ^ var682;
                                                   String var295;
                                                   if (var290 > (510200501 ^ var682)) {
                                                      var682 = 991666647 ^ var682;
                                                      Set var293 = var285.getMembers();
                                                      int var294 = var293.size();
                                                      var295 = "(" + var294 + "/" + var290 + ")";
                                                      var682 = 2023290104 ^ var682;
                                                   } else {
                                                      var682 = wpfsmmvipvqijiso(var682, 1614965970);
                                                      var295 = mllziabcns(qybighikqmxcgew(), gwkchkizhlvynzp(), var682);
                                                      var682 = 599865853 ^ var682;
                                                   }

                                                   var682 = 2129713772 ^ var682;
                                                   String var535 = "&cThis team is now full " + var295;
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var535);
                                                   var682 = 1585519940 ^ var682;
                                                   String var536 = mllziabcns(mefenxibolqvnim(), gwkchkizhlvynzp(), var682);
                                                   Sound var608 = Sound.ENTITY_VILLAGER_NO;
                                                   float var631 = 1.0F;
                                                   float var649 = 1.0F;
                                                   KKo0KoOoOK.play(var20, var536, var608, var631, var649);
                                                   var682 = 304543081 ^ var682;
                                                   byte var298 = (byte)(1874685402 ^ var682);
                                                   return (boolean)var298;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 1866243511);
                                                byte var299 = TeamGUI.isEnabled();
                                                if (var299 != (421728539 ^ var682)) {
                                                   var682 = 1525420119 ^ var682;
                                                   TeamGUI var300 = new TeamGUI(var20, var285);
                                                   var300.open();
                                                   var682 = 612177442 ^ var682;
                                                   byte var301 = (byte)(1739724655 ^ var682);
                                                   return (boolean)var301;
                                                }

                                                var682 = 1192437593 ^ var682;
                                                UUID var303 = var20.getUniqueId();
                                                TeamService3.removeInvite(var303);
                                                var682 = 486933012 ^ var682;
                                                UUID var538 = var20.getUniqueId();
                                                var21.joinTeam(var538, var285);
                                                var682 = 1354611592 ^ var682;
                                                String var306 = var285.getName();
                                                String var307 = "#2399FF" + var306;
                                                var682 = 2111671178 ^ var682;
                                                String var540 = "&7You joined the team " + var307;
                                                oOo0KKoOoOK.sendActionBarAndChat(var20, var540);
                                                var682 = 1562392940 ^ var682;
                                                String var541 = mllziabcns(sdihkjmuugwwoua(), gwkchkizhlvynzp(), var682);
                                                Sound var611 = Sound.ENTITY_PLAYER_LEVELUP;
                                                float var633 = 1.5F;
                                                float var650 = 1.2F;
                                                KKo0KoOoOK.play(var20, var541, var611, var633, var650);
                                                var682 = 313323883 ^ var682;
                                                Set var311 = var285.getMembers();
                                                Iterator var312 = var311.iterator();
                                                Iterator var675 = var312;
                                                var682 = 935309915 ^ var682;

                                                label576:
                                                while(true) {
                                                   byte var314 = var675.hasNext();
                                                   if (var314 == (375750152 ^ var682)) {
                                                      while(true) {
                                                         switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                            case 191148618:
                                                               var682 ^= 1899108838;
                                                               break label700;
                                                            case 309983438:
                                                            default:
                                                               throw new RuntimeException();
                                                            case 1230168686:
                                                               break label700;
                                                            case 2052627340:
                                                         }
                                                      }
                                                   }

                                                   var682 = 1577539014 ^ var682;
                                                   Object var316 = var675.next();
                                                   UUID var317 = (UUID)var316;
                                                   var682 = 1205726932 ^ var682;
                                                   UUID var543 = var10.getUniqueId();
                                                   byte var319 = var317.equals(var543);
                                                   if (var319 != (264226074 ^ var682)) {
                                                      var682 = 832886929 ^ var682;
                                                      var682 = 679371651 ^ var682;
                                                   } else {
                                                      var682 = 1774147964 ^ var682;
                                                      Player var321 = Bukkit.getPlayer(var317);
                                                      var682 = 1838754472 ^ var682;
                                                      if (var321 != null) {
                                                         var682 = 1806229587 ^ var682;
                                                         byte var324 = var321.isOnline();
                                                         if (var324 == (1613846173 ^ var682)) {
                                                            var682 = 825722993 ^ var682;
                                                            var682 = wpfsmmvipvqijiso(var682, 1197711588);
                                                         } else {
                                                            label556:
                                                            while(true) {
                                                               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                                  case 174061537:
                                                                     var682 ^= 826982087;
                                                                     break label556;
                                                                  case 463283396:
                                                                  default:
                                                                     throw new RuntimeException();
                                                                  case 631895356:
                                                                     break;
                                                                  case 1594166538:
                                                                     break label556;
                                                               }
                                                            }

                                                            KKoOoOo0oOK var325 = KKoOoOo0oOK.getInstance();
                                                            Runnable var613 = () -> {
                                                               int var8 = 464358553 ^ 1009483871 ^ 92513075;
                                                               var8 = 1681336313 ^ var8;
                                                               String var4 = var10.getName();
                                                               String var5 = "&7Player #2399FF" + var4 + " &7joined your team!";
                                                               oOo0KKoOoOK.sendActionBarAndChat(var321, var5);
                                                            };
                                                            var325.runAtEntity(var321, var613);
                                                            var682 = 1747469504 ^ var682;
                                                            var682 = 792122002 ^ var682;
                                                         }
                                                      } else {
                                                         while(true) {
                                                            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                               case 108648886:
                                                                  var682 ^= 503105734;
                                                                  continue label576;
                                                               case 326646741:
                                                                  break;
                                                               case 482001266:
                                                                  continue label576;
                                                               case 2127020247:
                                                               default:
                                                                  throw new RuntimeException();
                                                            }
                                                         }
                                                      }
                                                   }
                                                }
                                             }

                                             var682 = 451899559 ^ var682;
                                          } else {
                                             var682 = wpfsmmvipvqijiso(var682, 198371572);
                                          }

                                          byte var548 = (byte)(1028116144 ^ var682);
                                          String var331 = var4[var548];
                                          String var549 = mllziabcns(vulykguptawepyw(), gwkchkizhlvynzp(), var682);
                                          byte var332 = var331.equalsIgnoreCase(var549);
                                          if (var332 != (1028116144 ^ var682)) {
                                             var682 = 1600723520 ^ var682;
                                             int var334 = var4.length;
                                             byte var550 = (byte)(1647236337 ^ var682);
                                             if (var334 == var550) {
                                                var682 = 1954115092 ^ var682;
                                                UUID var553 = var20.getUniqueId();
                                                byte var338 = var21.isInTeam(var553);
                                                if (var338 == (374848228 ^ var682)) {
                                                   var682 = 522287845 ^ var682;
                                                   String var559 = mllziabcns(tdegseavkhoubao(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var559);
                                                   var682 = 418450727 ^ var682;
                                                   byte var348 = (byte)(294112551 ^ var682);
                                                   return (boolean)var348;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 910266070);
                                                UUID var555 = var20.getUniqueId();
                                                TeamService var340 = var21.getTeamByPlayer(var555);
                                                var682 = 1950879109 ^ var682;
                                                UUID var557 = var20.getUniqueId();
                                                byte var342 = var340.isLeader(var557);
                                                if (var342 == (1415461303 ^ var682)) {
                                                   var682 = 1596471835 ^ var682;
                                                   String var558 = mllziabcns(mtjdqwpdgjnklkt(), gwkchkizhlvynzp(), var682);
                                                   oOo0KKoOoOK.sendActionBarAndChat(var20, var558);
                                                   var682 = 367776918 ^ var682;
                                                   byte var344 = (byte)(513660731 ^ var682);
                                                   return (boolean)var344;
                                                }

                                                var682 = wpfsmmvipvqijiso(var682, 1192829237);
                                                TeamSettingsGUI var345 = new TeamSettingsGUI(var20, var340);
                                                var345.open();
                                                var682 = 515803739 ^ var682;
                                                byte var346 = (byte)(234459864 ^ var682);
                                                return (boolean)var346;
                                             }

                                             var682 = wpfsmmvipvqijiso(var682, 994110498);
                                             break label701;
                                          }

                                          while(true) {
                                             switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var682)) {
                                                case 112926002:
                                                   var682 ^= 1680471650;
                                                case 580392874:
                                                   break label701;
                                                case 756993022:
                                                default:
                                                   throw new RuntimeException();
                                                case 1589067298:
                                             }
                                          }
                                       }

                                       Object var449 = null;
                                       var126.setTeamHome((Location)var449);
                                       var682 = 1777238970 ^ var682;
                                       var21.saveTeamHome(var126);
                                       var682 = 1954002815 ^ var682;
                                       String var451 = mllziabcns(oiotsnuamqejutd(), gwkchkizhlvynzp(), var682);
                                       oOo0KKoOoOK.sendActionBarAndChat(var20, var451);
                                       var682 = 1455566657 ^ var682;
                                       KKoOoOo0oOK var137 = KKoOoOo0oOK.getInstance();
                                       Runnable var453 = () -> {
                                          int var6 = 616443761 ^ 1589320905 ^ 92513075;
                                          var6 = 408980923 ^ var6;
                                          var21.broadcastTeamUpdate(var126);
                                       };
                                       var137.runNextTick(var453);
                                       var682 = 588769180 ^ var682;
                                       byte var138 = (byte)(461347215 ^ var682);
                                       return (boolean)var138;
                                    }

                                    KKoOoOo0oOK var326 = KKoOoOo0oOK.getInstance();
                                    Runnable var546 = () -> {
                                       int var6 = 531771555 ^ 1165116619 ^ 92513075;
                                       var6 = 1417684532 ^ var6;
                                       var21.broadcastTeamUpdate(var285);
                                    };
                                    var326.runNextTick(var546);
                                    var682 = 681334330 ^ var682;
                                    byte var327 = (byte)(1338716629 ^ var682);
                                    return (boolean)var327;
                                 }

                                 String var551 = mllziabcns(nsaebacjhwsidnd(), gwkchkizhlvynzp(), var682);
                                 oOo0KKoOoOK.sendActionBarAndChat(var20, var551);
                                 var682 = 573679474 ^ var682;
                                 byte var336 = (byte)(2069864353 ^ var682);
                                 return (boolean)var336;
                              }

                              var682 = 1066009313 ^ var682;
                              String var514 = "&cTeam is full " + var244;
                              oOo0KKoOoOK.sendActionBarAndChat(var20, var514);
                              var682 = 1242402240 ^ var682;
                              byte var240 = (byte)(1457887674 ^ var682);
                              return (boolean)var240;
                           }

                           String var508 = mllziabcns(hxrjqstnrurvvet(), gwkchkizhlvynzp(), var682);
                           String var509 = KoOo0Ko0oOK.get(var508);
                           oOo0KKoOoOK.sendActionBarAndChat(var20, var509);
                           var682 = 992906720 ^ var682;
                           byte var230 = (byte)(883388764 ^ var682);
                           return (boolean)var230;
                        }

                        UUID var594 = var20.getUniqueId();
                        TeamService var194 = var21.createTeam(var177, var594);
                        var682 = 237161122 ^ var682;
                        String var485 = mllziabcns(zgrhpkmbnfvzueu(), gwkchkizhlvynzp(), var682);
                        oOo0KKoOoOK.sendActionBarAndChat(var20, var485);
                        var682 = 1413307733 ^ var682;
                        byte var196 = (byte)(1572077392 ^ var682);
                        return (boolean)var196;
                     }

                     String var486 = mllziabcns(fyoqyuugwclehsm(), gwkchkizhlvynzp(), var682);
                     oOo0KKoOoOK.sendActionBarAndChat(var20, var486);
                     var682 = 327979714 ^ var682;
                     byte var198 = (byte)(924353845 ^ var682);
                     return (boolean)var198;
                  }

                  TeamCreateGUI var162 = new TeamCreateGUI(var20, var157);
                  var162.open();
                  var682 = 729228040 ^ var682;
                  byte var163 = (byte)(2060642768 ^ var682);
                  return (boolean)var163;
               }

               UUID var639 = var363.getUniqueId();
               TeamInviteGUI var368 = new TeamInviteGUI(var20, var639, var355);
               var368.open();
               var682 = 1071423252 ^ var682;
               byte var369 = (byte)(1499994871 ^ var682);
               return (boolean)var369;
            }

            byte var86 = (byte)(78905832 ^ var682);
            return (boolean)var86;
         }

         Location var396 = var20.getLocation();
         var55.setTeamHome(var396);
         var682 = 1972166534 ^ var682;
         var21.saveTeamHome(var55);
         var682 = 529141236 ^ var682;
         String var398 = mllziabcns(ydcoidsmvzrrtgp(), gwkchkizhlvynzp(), var682);
         oOo0KKoOoOK.sendActionBarAndChat(var20, var398);
         var682 = 1485849402 ^ var682;
         KKoOoOo0oOK var66 = KKoOoOo0oOK.getInstance();
         Runnable var400 = () -> {
            int var6 = 1624380141 ^ 1330021837 ^ 92513075;
            var6 = 1301633877 ^ var6;
            var21.broadcastTeamUpdate(var55);
         };
         var66.runNextTick(var400);
         var682 = 730444489 ^ var682;
         byte var67 = (byte)(1579097800 ^ var682);
         return (boolean)var67;
      }
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      int var141 = 541535861 ^ 1483453603 ^ 1463372668;
      var141 = 410146905 ^ var141;
      byte var12 = var1 instanceof Player;
      if (var12 == (929532403 ^ var141)) {
         var141 = 1175959305 ^ var141;
         List var91 = Collections.emptyList();
         return var91;
      } else {
         label204: {
            var141 = 1038132214 ^ var141;
            Player var14 = (Player)var1;
            var141 = 224314005 ^ var141;
            TeamService2 var15 = TeamService2.getInstance();
            var141 = 243577371 ^ var141;
            UUID var92 = var14.getUniqueId();
            TeamService var17 = var15.getTeamByPlayer(var92);
            var141 = 1588522282 ^ var141;
            int var19 = var4.length;
            byte var93 = (byte)(1475590048 ^ var141);
            ArrayList var52;
            if (var19 != var93) {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var141)) {
                     case 174613556:
                        var141 ^= 163066018;
                     case 443461473:
                        int var21 = var4.length;
                        byte var94 = (byte)(1582008065 ^ var141);
                        if (var21 == var94) {
                           var141 = 765358227 ^ var141;
                           byte var95 = (byte)(1943402384 ^ var141);
                           String var23 = var4[var95];
                           String var96 = mllziabcns(guerupitfrrcyra(), gwkchkizhlvynzp(), var141);
                           byte var24 = var23.equalsIgnoreCase(var96);
                           if (var24 != (1943402384 ^ var141)) {
                              var141 = 1042342564 ^ var141;
                              String var25 = mllziabcns(wfhfsukougrarkx(), gwkchkizhlvynzp(), var141);
                              List var26 = List.of(var25);
                              return var26;
                           }

                           var141 = 330308348 ^ var141;
                        } else {
                           label118:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var141)) {
                                 case 112331742:
                                    var141 ^= 1043229295;
                                    break label118;
                                 case 337009818:
                                    break;
                                 case 1029911912:
                                    break label118;
                                 case 1384636175:
                                 default:
                                    throw new IOException();
                              }
                           }
                        }

                        int var28 = var4.length;
                        byte var97 = (byte)(1617292654 ^ var141);
                        if (var28 == var97) {
                           var141 = 430937722 ^ var141;
                           byte var98 = (byte)(2043312918 ^ var141);
                           String var30 = var4[var98];
                           String var99 = mllziabcns(hxrsxmpjixvubao(), gwkchkizhlvynzp(), var141);
                           byte var31 = var30.equalsIgnoreCase(var99);
                           if (var31 != (2043312918 ^ var141)) {
                              var141 = 1389377740 ^ var141;
                              Object var32 = null;
                              return (List<String>)var32;
                           }

                           var141 = 1421488984 ^ var141;
                        } else {
                           var141 = 1293264162 ^ var141;
                        }

                        int var34 = var4.length;
                        byte var100 = (byte)(762333260 ^ var141);
                        if (var34 == var100) {
                           var141 ^= 1001933919;
                           String var35 = mllziabcns(bybnrpalsxdtulw(), gwkchkizhlvynzp(), var141);
                           byte var7 = (byte)(382206993 ^ var141);
                           String var102 = var4[var7];
                           byte var36 = var35.equalsIgnoreCase(var102);
                           if (var36 != (382206993 ^ var141)) {
                              var141 = 2102698263 ^ var141;
                              byte var137 = (byte)(1805427975 ^ var141);
                              String var104 = var4[var137];
                              List var38 = CrossServerRedisBridge.allOnlineNamesExcludingSender(var1, var104);
                              return var38;
                           }

                           label95:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var141)) {
                                 case 203657512:
                                    var141 ^= 2006966607;
                                    break label95;
                                 case 237597148:
                                    break;
                                 case 327647914:
                                    break label95;
                                 case 1771219379:
                                 default:
                                    throw new IOException();
                              }
                           }
                        } else {
                           label105:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var141)) {
                                 case 134848871:
                                    var141 ^= 1277668624;
                                    break label105;
                                 case 349569218:
                                 default:
                                    throw new IOException();
                                 case 1355767486:
                                    break;
                                 case 2106276224:
                                    break label105;
                              }
                           }
                        }

                        int var40 = var4.length;
                        byte var105 = (byte)(1633150300 ^ var141);
                        if (var40 != var105) {
                           var141 = wpfsmmvipvqijiso(var141, 116840846);
                           break label204;
                        }

                        var141 = 98782544 ^ var141;
                        String var41 = mllziabcns(ilmnsktenxtdbtb(), gwkchkizhlvynzp(), var141);
                        byte var138 = (byte)(1689561102 ^ var141);
                        String var107 = var4[var138];
                        byte var42 = var41.equalsIgnoreCase(var107);
                        if (var42 == (1689561102 ^ var141)) {
                           var141 = wpfsmmvipvqijiso(var141, 51746014);
                           break label204;
                        }

                        var141 = 890997724 ^ var141;
                        if (var17 != null) {
                           var141 = 36952941 ^ var141;
                           Set var45 = var17.getMembers();
                           Stream var46 = var45.stream();
                           Predicate var109 = (var1x) -> {
                              int var8 = 83070103 ^ 1624634524 ^ 92513075;
                              var8 = 698304835 ^ var8;
                              byte var4 = var17.isLeader(var1x);
                              byte var5;
                              if (var4 == (1211798139 ^ var8)) {
                                 var8 = 463733088 ^ var8;
                                 var5 = (byte)(1402901274 ^ var8);
                                 var8 = wpfsmmvipvqijiso(var8, 306595426);
                              } else {
                                 var8 = wpfsmmvipvqijiso(var8, 395993574);
                                 var5 = (byte)(1604383645 ^ var8);
                                 var8 = 511190756 ^ var8;
                              }

                              return (boolean)var5;
                           };
                           var141 = 2139574986 ^ var141;
                           Stream var47 = var46.filter(var109);
                           Function var110 = (var0) -> {
                              int var6 = 1805161329 ^ 691936063 ^ 92513075;
                              var6 = 1253567522 ^ var6;
                              OfflinePlayer var2 = Bukkit.getOfflinePlayer(var0);
                              String var3 = var2.getName();
                              return var3;
                           };
                           var141 = 1672371995 ^ var141;
                           Stream var48 = var47.map(var110);
                           Predicate var112 = (var1x) -> {
                              int var13 = 465387462 ^ 1165288733 ^ 92513075;
                              var13 = 1185067236 ^ var13;
                              byte var8;
                              if (var1x != null) {
                                 var13 = 6600033 ^ var13;
                                 String var6 = var1x.toLowerCase();
                                 byte var4x = (byte)(495746156 ^ var13);
                                 String var9 = var4[var4x];
                                 String var10 = var9.toLowerCase();
                                 byte var7 = var6.startsWith(var10);
                                 if (var7 != (495746157 ^ var13)) {
                                    var13 = 1707300496 ^ var13;
                                    var8 = (byte)(2018454268 ^ var13);
                                    var13 = 1827446474 ^ var13;
                                    return (boolean)var8;
                                 }

                                 label25:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var13)) {
                                       case 155200671:
                                          var13 ^= 1166110337;
                                          break label25;
                                       case 628992360:
                                          break;
                                       case 1667035753:
                                       default:
                                          throw new RuntimeException();
                                       case 1940904933:
                                          break label25;
                                    }
                                 }
                              } else {
                                 var13 = wpfsmmvipvqijiso(var13, 1172691936);
                              }

                              var8 = (byte)(1477251820 ^ var13);
                              var13 = 1286514395 ^ var13;
                              return (boolean)var8;
                           };
                           var141 = 741400659 ^ var141;
                           Stream var49 = var48.filter(var112);
                           var141 = 476790366 ^ var141;
                           List var50 = var49.toList();
                           var141 = 1420604212 ^ var141;
                           return var50;
                        }

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var141)) {
                              case 239273161:
                                 var141 = 906895106 ^ var141;
                                 break label204;
                              case 1385829664:
                                 break;
                              case 1461609655:
                              default:
                                 throw new IOException();
                              case 1639036685:
                                 break label204;
                           }
                        }
                     case 348442773:
                        break;
                     case 417925404:
                     default:
                        throw new IOException();
                  }
               }
            } else {
               var141 = 1659138239 ^ var141;
               var52 = new ArrayList();
               var141 = 1984365708 ^ var141;
               if (var17 == null) {
                  var141 = 1583490615 ^ var141;
                  String var135 = mllziabcns(mwbcbqhhppordgq(), gwkchkizhlvynzp(), var141);
                  var52.add(var135);
                  var141 = 1307552729 ^ var141;
                  String var136 = mllziabcns(gbtsmhrcgbadqip(), gwkchkizhlvynzp(), var141);
                  var52.add(var136);

                  label140:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var141)) {
                        case 83564378:
                           break label140;
                        case 212637901:
                           var141 = 167537056 ^ var141;
                           break label140;
                        case 1392124244:
                           break;
                        case 1446473070:
                        default:
                           throw new IOException();
                     }
                  }
               } else {
                  label167: {
                     var141 = 90303183 ^ var141;
                     String var113 = mllziabcns(iizuuotrbdfoffa(), gwkchkizhlvynzp(), var141);
                     var52.add(var113);
                     var141 = 489485103 ^ var141;
                     String var114 = mllziabcns(zzbwylsornlbgcw(), gwkchkizhlvynzp(), var141);
                     var52.add(var114);
                     var141 = 1171433843 ^ var141;
                     String var115 = mllziabcns(daprtjfffndjcma(), gwkchkizhlvynzp(), var141);
                     var52.add(var115);
                     var141 = 1602336295 ^ var141;
                     String var116 = mllziabcns(muehhkqebwalodq(), gwkchkizhlvynzp(), var141);
                     var52.add(var116);
                     var141 = 214319055 ^ var141;
                     String var117 = mllziabcns(qzmzafasoehusrd(), gwkchkizhlvynzp(), var141);
                     var52.add(var117);
                     var141 = 1710954617 ^ var141;
                     UUID var119 = var14.getUniqueId();
                     byte var65 = var17.isLeader(var119);
                     if (var65 == (678683280 ^ var141)) {
                        var141 = 627489611 ^ var141;
                        UUID var121 = var14.getUniqueId();
                        byte var67 = var17.canInvite(var121);
                        if (var67 == (219503067 ^ var141)) {
                           var141 = 932899728 ^ var141;
                           break label167;
                        }

                        var141 = 1252551034 ^ var141;
                     } else {
                        var141 = 1875825201 ^ var141;
                     }

                     String var122 = mllziabcns(hzictuskxsgwfim(), gwkchkizhlvynzp(), var141);
                     boolean var69 = var52.add(var122);
                     var141 = 2100462314 ^ var141;
                  }

                  label161: {
                     UUID var124 = var14.getUniqueId();
                     byte var71 = var17.isLeader(var124);
                     if (var71 == (982495819 ^ var141)) {
                        var141 = 945085610 ^ var141;
                        UUID var126 = var14.getUniqueId();
                        byte var73 = var17.canKick(var126);
                        if (var73 == (47935201 ^ var141)) {
                           var141 = 470431613 ^ var141;
                           break label161;
                        }

                        var141 = 1806535857 ^ var141;
                     } else {
                        var141 = 1408847899 ^ var141;
                     }

                     String var127 = mllziabcns(jztsdqnudawiubd(), gwkchkizhlvynzp(), var141);
                     boolean var75 = var52.add(var127);
                     var141 = 2007481292 ^ var141;
                  }

                  UUID var129 = var14.getUniqueId();
                  byte var77 = var17.isLeader(var129);
                  if (var77 != (517036444 ^ var141)) {
                     var141 = 3430260 ^ var141;
                     String var130 = mllziabcns(dtawvsvlcqewopb(), gwkchkizhlvynzp(), var141);
                     var52.add(var130);
                     var141 = 563135494 ^ var141;
                     String var131 = mllziabcns(ssqnbqdsbcsgtib(), gwkchkizhlvynzp(), var141);
                     var52.add(var131);
                     var141 = 1716841778 ^ var141;
                  } else {
                     label154:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var141)) {
                           case 56190841:
                           default:
                              throw new IOException();
                           case 196445007:
                              var141 = 1206943296 ^ var141;
                           case 517334934:
                              break label154;
                           case 1564504115:
                        }
                     }
                  }
               }
            }

            Stream var83 = var52.stream();
            Predicate var133 = (var1x) -> {
               int var11 = 2095829496 ^ 1464023384 ^ 92513075;
               var11 = 12315182 ^ var11;
               String var5 = var1x.toLowerCase();
               byte var4x = (byte)(781230525 ^ var11);
               String var7 = var4[var4x];
               String var8 = var7.toLowerCase();
               boolean var6 = var5.startsWith(var8);
               return var6;
            };
            Stream var84 = var83.filter(var133);
            Comparator var134 = String.CASE_INSENSITIVE_ORDER;
            Stream var85 = var84.sorted(var134);
            List var86 = var85.toList();
            return var86;
         }

         List var51 = Collections.emptyList();
         return var51;
      }
   }

   public static String mllziabcns(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] gwkchkizhlvynzp() {
      return new byte[]{87, 75, 67, 65, 116, 66, 105, 33, 9, 107, 25, 26, 83, 56, 99, 116, 103, 66, 68, 66, 87, 23, 16, 47, 62, 99, 51, 31, 14, 65, 48, 36, 104, 12, 56, 20, 119, 81, 25, 116, 58, 33, 61, 116, 60, 64, 48, 113, 28, 39, 30, 97, 74, 66, 37, 108, 97, 59, 50, 120, 104, 82, 101, 116, 38, 25, 1, 26, 122, 109, 106, 95, 16, 117, 13, 107, 74};
   }

   private static byte[] inloymycgdxlctj() {
      return new byte[]{-104, -124, 119, 29, 70, 29, 89, 115, 62, 61};
   }

   private static byte[] mefenxibolqvnim() {
      return new byte[]{-101, -123, 115, 2, 71, 19, 80, 113, 62, 54, 43, 88, 99, 33, 80, 52, 94, 22, 115, 19, 101, 75, 32, 123, 13, 56, 10, 67, 57, 28, 2, 116, 88, 85, 11, 68, 78, 78, 46, 32, 8, 117, 13, 45, 15, 13, 9, 113, 43, 39};
   }

   private static byte[] xlzwwozxdeixsru() {
      return new byte[]{-104, -127, 117, 13, 67, 22, 89, 112, 48, 63, 40, 92, 101, 46, 84, 49, 87, 23, 125, 26, 102, 79, 38, 116, 9, 61, 3, 66, 55, 21, 1, 112, 94, 90, 15, 65, 71, 79, 32, 35, 11, 123, 11, 56, 11, 24, 0, 39, 37, 103, 47, 102};
   }

   private static byte[] eximrpwgafyopvc() {
      return new byte[]{-99, -125, 119, 7, 64, 21, 92, 97, 63, 55, 46, 65, 102, 97, 81, 36};
   }

   private static byte[] pxrezndihaqstth() {
      return new byte[]{-112, -126, 113, 84, 77, 24, 81, 71, 56, 58, 47, 65, 96, 114, 90, 108, 85, 3, 125, 24, 101, 69, 41, 111, 6, 52, 2, 84, 56, 83, 3, 124, 81, 88, 10, 87, 78, 2, 43, 38, 3, 124, 5, 63, 13, 89, 6, 43, 47, 127, 39, 42, 120, 83, 28, 59, 83, 40, 11, 49, 80, 5, 84, 35, 16, 79, 50, 74, 67, 59, 88, 9, 41, 99, 63, 49, 115, 0, 115, 7, 112, 36, 116, 47, 18, 85};
   }

   private static byte[] oybezjorlfgvmbi() {
      return new byte[]{-104, -125, 122, 19, 67, 18, 95, 123, 56, 57, 40, 95, 106, 108, 84, 45, 81, 88, 117, 27, 102, 79, 41, 55, 9, 38, 5, 78, 63, 4, 1, 126, 81, 80, 15, 82, 65, 22, 40, 42, 11, 121, 4, 47};
   }

   private static byte[] terwnypovzhwdiu() {
      return new byte[]{-112, -122, 118, 95, 71, 23, 81, 89, 48, 60, 43, 67, 107, 114, 85, 108, 80, 15, 125, 24, 98, 74, 35, 57, 6, 56, 10, 67, 60, 21, 8, 115, 94, 81, 15, 95, 78, 67, 44, 47, 9, 118, 5, 45, 5, 89, 2, 32, 36, 113, 40, 53, 125, 30, 28, 42, 84, 102, 1, 110, 80, 17, 92, 37, 20, 73, 57, 9, 76, 33, 93, 3, 41, 38, 56, 62, 121, 65, 115, 28, 120, 34, 112, 49, 25, 95};
   }

   private static byte[] lliekthhcxeysmt() {
      return new byte[]{-104, -124, 113, 94, 77, 20, 81, 79, 57, 51, 40, 95, 97, 115, 90, 97, 95, 1, 116, 16, 102, 70, 34, 123, 7, 118, 11, 76, 62, 25, 1, 113, 90, 70, 1, 1, 79, 8, 41, 44, 11, 101, 15, 109, 5, 29, 8, 39, 44, 102, 47, 52, 120, 91, 28, 56, 89, 44, 2, 39, 89, 13, 87, 32, 31, 73, 57, 3};
   }

   private static byte[] ckoevymwnnvdpdf() {
      return new byte[]{-104, -126, 113, 28, 66, 29, 89, 116, 49, 53};
   }

   private static byte[] ddxtmabufbupxgg() {
      return new byte[]{-100, -127, 122, 22, 66, 4, 92, 112, 57, 63, 44, 87, 103, 107};
   }

   private static byte[] hxrjqstnrurvvet() {
      return new byte[]{-101, -126, 115, 17, 68, 22, 90, 120, 58, 60, 47, 88, 100, 105, 82, 43, 80, 95, 118, 29, 103, 78, 32, 104, 13, 53, 0, 65, 56, 24, 7, 112, 89, 18, 15, 87, 69, 11, 41, 34, 10, 105, 14, 38, 15, 0};
   }

   private static byte[] meujqlkrarhnvso() {
      return new byte[]{-104, -116, 118, 13, 76, 23, 90, 115, 56, 55, 40, 81, 102, 46, 91, 48, 84, 20, 117, 18, 102, 66, 37, 116, 6, 60, 0, 65, 63, 29, 1, 125, 93, 90, 0, 64, 68, 76, 40, 33, 11, 124, 8, 34, 4, 9, 3, 119};
   }

   private static byte[] elkfajgzqvvjsgx() {
      return new byte[]{-98, -115, 119, 4, 68, 21, 81, 112, 57, 49, 32, 93, 98, 38, 81, 56, 87, 23, 115, 26, 99, 75, 32, 126, 6, 60, 3, 69, 55, 24, 1, 117, 90, 90, 8, 64, 64, 70, 45, 33, 10, 118, 5, 42, 12, 14, 9, 118};
   }

   private static byte[] retwytnjkznmuxe() {
      return new byte[]{-101, -115, 113, 82, 71, 23, 92, 76, 61, 54, 32, 93, 102, 43, 85, 32, 83, 4, 118, 30, 101, 2, 35, 119, 11, 56, 7, 89, 55, 83, 5, 126, 94, 87, 12, 0, 69, 9, 43, 97, 9, 99, 8, 37, 8, 19, 9, 46};
   }

   private static byte[] nwprshrrbrpqxre() {
      return new byte[]{-104, -126, 115, 43, 64, 21, 90, 56, 49, 36, 40, 28, 99, 36, 87, 123, 84, 41, 124, 42, 102, 10};
   }

   private static byte[] pmsdevxoogqeylc() {
      return new byte[]{-104, -122, 122, 82, 66, 18, 94, 77, 61, 53, 40, 93, 106, 45, 85, 38, 80, 5, 112, 22, 102, 5, 41, 110, 8, 56, 4, 79, 58, 80, 1, 122, 81, 92, 14, 70, 64, 0, 45, 32, 11, 97, 4, 111, 10, 83, 7, 17, 40, 101, 47, 54, 115, 87, 19, 112, 86, 122, 6, 44, 89, 1, 92, 44, 16, 10, 54, 75, 78, 53, 91, 30, 41, 34, 59, 57, 125, 12, 127, 22, 112, 102, 123, 53, 23, 84, 92, 95, 46, 22, 9, 52, 77, 51, 116, 19, 117, 76};
   }

   private static byte[] zsdxtdryhagwmpy() {
      return new byte[]{-98, -122, 123, 83, 64, 19, 80, 75, 61, 51, 43, 87, 103, 44, 81, 41, 84, 25, 115, 80, 111, 77, 36, 114, 7, 36, 7, 8, 60, 17, 4, 113, 90, 67, 11, 69, 64, 67, 33, 48, 14, 118, 4, 53, 8, 26, 2, 32, 40, 96, 44, 43, 121, 31, 18, 49, 89, 97, 6, 106, 81, 21, 81, 44, 20, 1, 53, 93, 72, 49, 89, 31, 39, 103, 53, 43, 126, 13, 114, 21, 117, 99, 112, 37, 21, 88, 89, 65, 41, 10, 15, 113, 76, 59, 118, 25, 123, 9, 35, 66, 29, 40};
   }

   private static byte[] vulykguptawepyw() {
      return new byte[]{-104, -124, 113, 29, 69, 26, 95, 99, 61, 61, 40, 75, 97, 110, 82, 33};
   }

   private static byte[] kiixzwvwwprhuot() {
      return new byte[]{-100, -122, 118, 27, 70, 31, 90, 116, 61, 59};
   }

   private static byte[] cbsluurmuznylah() {
      return new byte[]{-104, -122, 122, 2, 69, 23, 94, 113, 48, 54, 40, 91, 106, 33, 82, 48, 80, 22, 125, 19, 102, 72, 41, 123, 15, 60, 4, 67, 55, 28, 1, 119, 81, 85, 9, 64, 64, 78, 32, 32, 11, 118, 4, 45, 13, 9, 7, 116};
   }

   private static byte[] eagwmcqmnoizzos() {
      return new byte[]{-104, -115, 123, 80, 69, 21, 90, 77, 56, 61, 40, 86, 107, 125, 82, 96, 84, 3, 117, 30, 102, 79, 40, 117, 15, 119, 0, 78, 63, 23, 1, 120, 80, 72, 9, 0, 68, 10, 40, 34, 11, 108, 5, 99, 13, 28, 3, 37, 45, 104, 47, 61, 114, 85, 20, 57, 82, 46, 3, 41, 89, 4, 93, 46, 23, 72, 50, 1};
   }

   private static byte[] naxpagxuegjnduh() {
      return new byte[]{-104, -116, 112, 95, 69, 17, 92, 65, 63, 54, 40, 87, 96, 32, 82, 37, 82, 9, 114, 21, 102, 15, 35, 121, 15, 60, 6, 82, 56, 83, 1, 117, 91, 90, 9, 4, 66, 9, 47, 102, 11, 109, 14, 41, 13, 17, 5, 37};
   }

   private static byte[] fyoqyuugwclehsm() {
      return new byte[]{-97, -123, 112, 81, 76, 20, 91, 92, 49, 60, 40, 68, 101, 101, 86, 102, 84, 23, 114, 6, 100, 82, 40, 110, 12, 112, 11, 75, 63, 23, 6, 60, 93, 13, 43, 63, 65, 81, 42, 116, 2, 52, 15, 36, 4, 30, 1, 35, 42, 109, 43, 32, 121, 90, 19, 117, 82, 97, 10, 40, 90, 21, 93, 54, 23, 79, 55, 80, 79, 44, 89, 75, 38, 100, 62, 51, 114, 23, 121, 29, 121, 32, 115, 63, 23, 67, 94, 88, 41, 71, 14, 114, 71, 14, 122, 88};
   }

   private static byte[] fsqywjccmujjhdj() {
      return new byte[]{-104, -124, 122, 84, 76, 23, 90, 77, 60, 55, 40, 95, 106, 43, 91, 38, 84, 24, 113, 31, 102, 83, 41, 60, 6, 61, 0, 75, 59, 4, 1, 113, 81, 31, 0, 67, 68, 68, 44, 51, 11, 116, 4, 38, 4, 27};
   }

   private static byte[] ehbfrgzddvxfogc() {
      return new byte[]{-101, -124, 112, 94, 71, 77, 80, 76, 49, 54, 43, 95, 96, 33, 80, 41, 94, 24, 124, 17, 101, 69, 35, 122, 13, 62, 10, 79, 54, 83, 2, 96, 91, 80, 11, 77, 78, 8, 33, 102, 8, 114, 14, 37, 15, 25, 9, 49, 36, 59};
   }

   private static byte[] jgeqifxdmdbigzc() {
      return new byte[]{-104, -122, 113, 26, 71, 31, 89, 103, 62, 51, 43, 92, 97, 110};
   }

   private static byte[] bktbgycupsaewdi() {
      return new byte[]{-100, -122, 123, 83, 69, 24, 93, 70, 49, 54, 43, 75, 103, 122, 90, 96, 84, 15, 113, 3, 111, 70, 33, 100, 10, 112, 11, 75, 60, 21, 4, 103, 81, 93, 11, 77, 66, 7, 33, 57, 11, 56, 9, 47, 4, 20, 2, 58, 40, 54, 39, 52, 121, 90, 16, 42, 89, 106, 3, 32, 92, 12};
   }

   private static byte[] qybighikqmxcgew() {
      return new byte[0];
   }

   private static byte[] sdihkjmuugwwoua() {
      return new byte[]{-111, -126, 112, 6, 76, 17, 80, 115, 63, 62, 47, 90, 96, 46, 85, 57, 84, 17, 124, 21, 100, 73, 40, 122, 7, 63, 5, 74, 56, 31, 3, 125, 94, 91, 11, 70, 79, 73, 42, 52, 2, 98, 4, 36, 10, 27, 6, 39, 47, 108, 40, 43};
   }

   private static byte[] ynroudnfvnolbtk() {
      return new byte[]{-101, -121, 122, 86, 77, 23, 93, 78, 59, 55, 32, 94, 106, 46, 87, 38, 85, 30, 125, 83, 110, 79, 36, 118, 12, 36, 10, 14, 55, 31, 4, 115, 90, 73, 1, 64, 78, 71, 45, 50, 8, 119, 4, 55, 5, 27, 4, 46, 46, 103, 39, 35, 115, 29, 17, 53, 83, 102, 11, 105, 81, 16, 81, 45, 20, 10, 56, 76, 67, 52, 94, 73, 34, 50, 52, 53, 115, 65, 127, 1, 115, 47, 123, 61, 24, 31, 95, 91, 40, 5, 1, 51, 77, 60, 118, 82, 112, 12, 46, 78, 22, 101, 87, 96, 45, 19};
   }

   private static byte[] ajgllcpiiecloeh() {
      return new byte[]{-112, -127, 115, 6, 70, 31, 92, 118, 48, 63, 44, 89, 96, 36, 91, 53, 81, 30, 125, 22, 103, 73, 34, 116, 11, 58, 10, 75, 59, 28, 3, 119, 80, 87, 14, 73, 78, 74, 41, 35, 8, 124, 8, 44, 5, 0, 5, 121};
   }

   private static byte[] zhhegxyocgaicmm() {
      return new byte[]{-100, -125, 118, 5, 77, 31, 93, 116, 57, 51, 46, 92, 99, 47, 91, 52, 83, 23, 113, 20, 98, 74, 41, 116, 10, 56, 3, 71, 57, 25, 0, 124, 80, 86, 12, 64, 66, 72, 44, 32, 3, 124, 9, 46, 12, 12, 7, 125};
   }

   private static byte[] acetkfjgadpnrgi() {
      return new byte[]{-97, -121, 123, 87, 76, 16, 81, 70, 59, 53, 42, 67, 99, 116, 82, 108, 84, 0, 114, 29, 111, 70, 40, 103, 6, 53, 1, 91, 61, 89, 0, 117, 89, 71, 11, 6, 65, 12, 33, 43, 2, 100, 5, 103, 14, 31, 3, 39, 44, 63, 47, 56, 121, 80, 19, 43, 89, 110, 10, 40, 80, 12, 87, 108};
   }

   private static byte[] qmuxhivowmxefby() {
      return new byte[]{-101, -124, 118, 24, 66, 16, 91, 118, 63, 41, 43, 79};
   }

   private static byte[] xynqeerpdrvjqov() {
      return new byte[]{-104, -121, 114, 30, 65, 31, 88, 127, 61, 57, 40, 91, 98, 97, 86, 32, 86, 92, 112, 27, 102, 75, 33, 58, 11, 43, 2, 74, 58, 4, 1, 122, 89, 93, 13, 95, 70, 18, 45, 42, 11, 125, 12, 34};
   }

   private static byte[] buyldpkbbnazccf() {
      return new byte[]{-101, -124, 119, 81, 71, 25, 89, 65, 48, 49, 43, 95, 103, 46, 80, 45, 87, 9, 125, 18, 101, 7, 36, 119, 13, 52, 3, 82, 55, 84, 2, 125, 92, 84, 11, 12, 71, 9, 32, 97, 8, 101, 9, 39, 15, 25, 0, 37};
   }

   private static byte[] yqpsphowsbojvly() {
      return new byte[]{-104, -126, 116, 88, 67, 14, 91, 118, 58, 63, 40, 65, 100, 46, 84, 45, 85, 19, 119, 20, 102, 68, 39, 105, 9, 47};
   }

   private static byte[] ruzydsanqoonrii() {
      return new byte[]{-104, -116, 118, 4, 70, 16, 94, 120, 59, 55, 40, 81, 102, 39, 81, 55, 80, 31, 118, 18, 102, 66, 37, 125, 12, 59, 4, 74, 60, 29, 1, 125, 93, 83, 10, 71, 64, 71, 43, 33, 11, 124, 8, 43, 14, 14, 7, 127};
   }

   private static byte[] smirakgrkzlpewo() {
      return new byte[]{-104, -128, 115, 19, 71, 29, 95, 121, 63, 40};
   }

   private static byte[] iwvqnpkwowbmrzw() {
      return new byte[]{-112, -127, 122, 13, 68, 22, 92, 115, 48, 51, 32, 81, 99, 39, 86, 51, 94, 18, 125, 27, 103, 75, 37, 127, 7, 57, 10, 74, 62, 29, 5, 118, 81, 87, 1, 72, 71, 78, 44, 35, 3, 113, 4, 34, 12, 8};
   }

   private static byte[] ejhlrxwollqbbxq() {
      return new byte[0];
   }

   private static byte[] mtjdqwpdgjnklkt() {
      return new byte[]{-104, -115, 113, 85, 76, 18, 92, 88, 61, 52, 32, 68, 97, 121, 80, 97, 81, 2, 117, 19, 101, 64, 40, 60, 11, 57, 7, 75, 55, 18, 2, 120, 91, 92, 14, 82, 70, 72, 43, 37, 2, 115, 8, 44, 8, 81, 9, 39, 46, 118, 45, 39, 124, 20, 20, 52, 83, 103, 10, 47, 93, 68, 81, 49, 31, 67, 51, 71, 73, 120, 92, 31, 33, 41, 63, 56, 114, 9};
   }

   private static byte[] dctnklpqxnamtbc() {
      return new byte[]{-104, -122, 118, 87};
   }

   private static byte[] eiysmixvynjyvmp() {
      return new byte[]{-100, -121, 115, 19, 71, 19, 91, 120, 57, 54, 42, 69, 101, 102, 87, 35};
   }

   private static byte[] kzyogdxbntfwfmd() {
      return new byte[]{-102, -124, 118, 31, 68, 31, 81, 120, 58, 61, 41, 93, 106, 105, 91, 32, 80, 95, 119, 28, 98, 65, 32, 58, 6, 36, 0, 73, 62, 6, 9, 121, 80, 93, 15, 84, 68, 18, 44, 36, 10, 118, 5, 45};
   }

   private static byte[] ygiczywrdjcqpsm() {
      return new byte[]{-97, -116, 117, 83, 65, 18, 94, 67, 63, 53, 33, 77, 103, 121, 80, 99, 81, 4, 114, 22, 97, 66, 37, 101, 9, 48, 5, 91, 54, 87, 4, 120, 91, 72, 14, 2, 65, 7, 47, 47, 15, 102, 10, 98, 10, 31, 8, 41, 40, 50, 45, 47, 124, 27, 19, 33, 87, 125, 7, 107, 95, 16, 83, 39, 30, 78, 53, 66, 73, 116};
   }

   private static byte[] pyktflqbhirtnhg() {
      return new byte[]{-104, -125, 113, 81, 71, 20, 90, 77, 57, 48, 40, 88, 97, 46, 80, 32, 84, 5, 116, 19, 102, 0, 34, 119, 13, 57, 0, 94, 62, 85, 1, 122, 90, 84, 11, 1, 68, 5, 41, 96, 11, 98, 15, 39, 15, 20, 3, 41};
   }

   private static byte[] sitthuytzpqflqc() {
      return new byte[]{-104, -124, 122, 86, 67, 18, 81, 73, 58, 55, 40, 95, 106, 41, 84, 38, 95, 31, 119, 3, 102, 66, 41, 127, 9, 52, 11, 87, 61, 82, 1, 124, 81, 92, 15, 81, 79, 5, 42, 103, 11, 112, 4, 101, 11, 7, 8, 37, 47, 117, 47, 60};
   }

   private static byte[] vcvseslkbwlsxif() {
      return new byte[]{-112, -123, 118, 23, 64, 21, 90, 112, 61, 55, 40, 95, 100, 120};
   }

   private static byte[] nughnmoytnzfbjh() {
      return new byte[]{-104, -127, 119, 5, 66, 19, 89, 116, 59, 49, 40, 92, 103, 38, 85, 52, 87, 19, 118, 20, 102, 79, 36, 124, 8, 56, 3, 70, 60, 27, 1, 112, 92, 82, 14, 68, 71, 75, 43, 39, 11, 113, 9, 42, 10, 13, 0, 114};
   }

   private static byte[] wxutzvlvmdolcdc() {
      return new byte[]{-104, -123, 123, 87, 76, 23, 95, 65, 49, 48, 40, 94, 107, 40, 91, 42, 81, 26, 124, 0, 102, 67, 40, 63, 6, 59, 5, 73, 54, 85, 1, 101, 80, 89, 0, 76, 65, 12, 33, 41, 11, 126, 5, 35, 4, 86, 6, 60, 36, 118, 47, 49, 114, 31, 29, 122, 87, 107, 10, 34, 89, 21, 93, 45, 30, 91, 55, 70};
   }

   private static byte[] glpgebdfifqeeds() {
      return new byte[]{-104, -125, 118, 87, 70, 23, 91, 75, 58, 53, 40, 88, 102, 40, 81, 33, 85, 16, 119, 29, 102, 78, 37, 112, 12, 33, 1, 12, 61, 27, 1, 122, 93, 95, 10, 73, 69, 66, 42, 49, 11, 126, 8, 33, 14, 86, 2, 54, 47, 115, 47, 55, 127, 31, 23, 122, 83, 100, 1, 44, 89, 4, 80, 32, 20, 74, 51, 91, 73, 114};
   }

   private static byte[] tdegseavkhoubao() {
      return new byte[]{-104, -127, 123, 80, 67, 22, 90, 76, 60, 53, 44, 87, 100, 47, 84, 35, 83, 24, 117, 25, 111, 84, 39, 56, 13, 63, 6, 79, 59, 15, 7, 118, 95, 31, 12, 64, 70, 68, 33, 55, 13, 115, 14, 33, 9, 28};
   }

   private static byte[] ydcoidsmvzrrtgp() {
      return new byte[]{-98, -127, 118, 83, 70, 76, 88, 66, 49, 57, 44, 78, 103, 103, 90, 101, 80, 18, 115, 24, 98, 78, 34, 115, 15, 116, 11, 91, 59, 17, 4, 98};
   }

   private static byte[] ymtcxzrtoavueae() {
      return new byte[]{-104, -121, 116, 12, 70, 18, 91, 116, 56, 63, 40, 90, 100, 47, 81, 53, 85, 19, 117, 26, 102, 73, 39, 117, 12, 57, 1, 70, 63, 21, 1, 118, 95, 91, 10, 69, 69, 75, 40, 35, 11, 125, 10, 57, 14, 28, 2, 35, 45, 103};
   }

   private static byte[] yoxqlebqllcuovt() {
      return new byte[]{-100, -124, 117, 86, 65, 22, 92, 76, 60, 59, 41, 77, 98, 96, 84, 97, 94, 25, 113, 19, 97, 75, 37, 125, 11, 122, 6, 75, 62, 27, 1, 99, 95, 92, 1, 64, 66, 5, 47, 60, 15, 54, 8, 57, 9, 20, 0, 44, 45, 119, 41, 58};
   }

   private static byte[] ocfekldnqbknidw() {
      return new byte[]{-100, -124, 113, 87, 71, 70, 94, 78, 56, 49, 41, 93, 99, 43, 80, 39, 81, 26, 113, 1, 101, 70, 35, 126, 9, 57, 2, 79, 62, 23, 0, 55, 91, 79, 14, 64, 66, 0, 43, 41, 9, 50, 10, 33, 13, 29, 0, 34, 44, 96, 45, 120};
   }

   private static byte[] oiotsnuamqejutd() {
      return new byte[]{-104, -116, 118, 81, 66, 64, 92, 67, 48, 55, 40, 67, 102, 99, 85, 97, 82, 28, 125, 20, 102, 66, 37, 124, 8, 118, 6, 77, 55, 29, 1, 112, 93, 95, 14, 85, 66, 2, 32, 41};
   }

   private static byte[] gftxpqywssbvgkv() {
      return new byte[]{-112, -116, 122, 81, 77, 23, 90, 75, 63, 61, 33, 86, 101, 33, 85, 35, 84, 27, 125, 20, 110, 6, 41, 109, 13, 112, 5, 78, 54, 25, 6, 107, 94, 90, 11, 2, 78, 8, 32, 98, 3, 99, 14, 34, 10, 24, 8, 37, 42, 48, 40, 114, 121, 32, 28, 45, 88, 125, 11, 43, 91, 65, 83, 98, 30, 84, 55, 70, 76, 63, 89, 4, 41, 109, 52, 62, 115, 19, 120, 21, 119, 44, 122, 36, 23, 85, 93, 10, 41, 77, 1, 53, 77, 48, 123, 31, 113, 1, 33, 0, 23, 39, 85, 126, 41, 82, 114, 38, 29, 51, 53, 124, 45, 36, 98, 75, 66, 119, 25, 97, 66, 37, 118, 98, 66, 10, 30, 82, 88, 25, 123, 114, 95, 63, 13, 37};
   }

   private static byte[] wirtsqdknguqqef() {
      return new byte[]{-99, -126, 113, 87, 64, 25, 92, 65, 49, 48, 47, 93, 99, 44, 91, 32, 94, 8, 112, 17, 101, 7, 36, 121, 11, 53, 11, 95, 56, 83, 0, 121, 80, 87, 1, 12, 67, 6, 43, 100, 14, 109, 8, 40, 4, 21, 6, 46};
   }

   private static byte[] zgrhpkmbnfvzueu() {
      return new byte[]{-104, -126, 115, 81, 64, 67, 92, 83, 59, 28, 47, 108, 96, 60, 81, 113, 84, 36, 117, 17, 103, 69, 36, 112, 11, 112, 1, 77, 56, 3, 3, 117, 90, 88, 11, 82, 70, 2, 41, 35, 14, 61};
   }

   private static byte[] zmkefwinidefkll() {
      return new byte[]{-111, -121, 117, 83, 64, 17, 91, 73, 63, 60, 42, 89, 103, 44, 83, 34, 86, 27, 124, 81, 97, 77, 36, 112, 12, 38, 5, 7, 61, 31, 4, 113, 88, 72, 9, 71, 79, 66, 47, 48, 14, 116, 15, 55, 10, 21, 3, 46, 40, 96, 46, 32, 123, 29, 29, 48, 87, 97, 6, 104, 90, 23, 83, 35, 21, 15, 53, 73, 74, 48, 91, 73, 40, 50, 59, 48, 126, 71, 121, 6, 119, 36, 113, 58, 21, 29, 91, 95, 43, 0, 0, 49, 66, 62, 118, 84, 112, 14, 33, 71, 28, 101, 87, 98, 47, 18};
   }

   private static byte[] nvpguvyyxiqfnil() {
      return new byte[]{-102, -116, 115, 12, 65, 19, 90, 117, 59, 53, 33, 89, 106, 35, 87, 51, 82, 21, 119, 27, 103, 67, 37, 120, 13, 57, 1, 65, 54, 28, 9, 112, 92, 81, 13, 66, 68, 71, 41, 41, 15, 112, 14, 47, 14, 10, 8, 115};
   }

   private static byte[] xeeuwhjewpypxpu() {
      return new byte[]{-101, -127, 112, 16, 70, 20, 90, 121, 63, 60, 44, 90, 106, 36, 90, 48, 82, 27, 118, 5, 100, 66, 34, 114, 13, 123, 5, 79, 59, 30, 9, 119, 81, 92, 13, 73, 69, 8, 42, 36, 8, 107, 14, 53, 10, 23, 5, 38};
   }

   private static byte[] zkityjyjwifmbhg() {
      return new byte[]{-101, -127, 112, 94, 70, 24, 90, 77, 63, 54, 44, 92, 106, 42, 90, 36, 82, 21, 118, 25, 100, 9, 34, 98, 13, 118, 5, 94, 59, 23, 9, 98, 81, 31, 13, 67, 69, 68, 42, 37, 8, 119, 14, 44, 10, 23, 5, 98, 37, 124, 39, 60, 127, 84, 23, 45, 82, 106, 0, 40, 91, 20, 83, 102, 19, 93, 56, 71, 67, 44, 95, 5, 34, 36, 62, 124};
   }

   private static byte[] nsaebacjhwsidnd() {
      return new byte[]{-104, -127, 115, 87, 71, 24, 92, 67, 58, 40, 40, 78, 99, 111, 80, 40, 82, 79, 119, 82, 102, 13, 32, 107, 13, 63, 6, 73, 61, 28, 1, 49, 88, 95, 11, 95, 66, 3, 42, 37, 11, 96, 13, 33, 15, 89, 5, 110, 47, 121, 47, 53, 122, 31, 22, 48, 84, 37, 1, 104, 89, 27, 85, 100, 21, 15, 52, 89, 73, 56, 91, 11, 32, 40, 62, 114, 127, 9, 120, 29, 112, 55, 114, 48, 18, 68, 94, 75, 41, 67, 9, 126, 68, 39, 113, 17, 119, 1, 36, 89, 30, 110, 83, 113, 44, 30};
   }

   private static byte[] jdfhneptmvsspwz() {
      return new byte[]{-99, -121, 112, 80};
   }

   private static byte[] gkbwnrhietmxruq() {
      return new byte[]{-99, -121, 112, 47};
   }

   private static byte[] hxrsxmpjixvubao() {
      return new byte[]{-101, -124, 119, 27, 71, 29, 91, 126, 56, 60};
   }

   private static byte[] guerupitfrrcyra() {
      return new byte[]{-104, -115, 119, 17, 64, 0, 91, 119, 49, 62, 40, 87, 103, 110};
   }

   private static byte[] mwbcbqhhppordgq() {
      return new byte[]{-99, -116, 122, 26, 67, 4, 81, 113, 58, 62, 33, 87, 107, 106};
   }

   private static byte[] ilmnsktenxtdbtb() {
      return new byte[]{-104, -126, 123, 19, 65, 29, 88, 115, 57, 50};
   }

   private static byte[] muehhkqebwalodq() {
      return new byte[]{-104, -124, 122, 24, 66, 31, 88, 115, 56, 37, 40, 79};
   }

   private static byte[] dtawvsvlcqewopb() {
      return new byte[]{-100, -123, 123, 22, 70, 19, 89, 102, 57, 60, 40, 67, 96, 100, 91, 32};
   }

   private static byte[] ssqnbqdsbcsgtib() {
      return new byte[]{-104, -124, 117, 17, 66, 31, 93, 127, 62, 51, 40, 69, 101, 97, 85, 41};
   }

   private static byte[] zzbwylsornlbgcw() {
      return new byte[]{-104, -127, 113, 10, 66, 31, 90, 100, 59, 49, 40, 64, 97, 109, 85, 41};
   }

   private static byte[] jztsdqnudawiubd() {
      return new byte[]{-104, -125, 117, 19, 71, 18, 81, 122, 63, 52};
   }

   private static byte[] daprtjfffndjcma() {
      return new byte[]{-100, -123, 117, 27, 69, 27, 81, 119, 58, 42};
   }

   private static byte[] hzictuskxsgwfim() {
      return new byte[]{-104, -122, 115, 27, 65, 20, 88, 103, 49, 59, 40, 92, 99, 110};
   }

   private static byte[] qzmzafasoehusrd() {
      return new byte[]{-104, -121, 115, 24, 76, 30, 91, 112, 63, 53};
   }

   private static byte[] wfhfsukougrarkx() {
      return new byte[]{-104, -121, 115, 94, 77, 28, 94, 115, 49, 54, 40, 76, 99, 38};
   }

   private static byte[] gbtsmhrcgbadqip() {
      return new byte[]{-104, -121, 118, 22, 66, 25, 89, 122, 59, 54, 40, 89, 102, 122};
   }

   private static byte[] iizuuotrbdfoffa() {
      return new byte[]{-104, -123, 116, 30, 66, 31, 95, 117, 62, 61};
   }

   private static byte[] bybnrpalsxdtulw() {
      return new byte[]{-102, -116, 113, 26, 68, 26, 80, 110, 58, 49, 33, 92, 97, 109};
   }

   private static int wpfsmmvipvqijiso(int var0, int var1) {
      return var1 ^ var0;
   }

   static {
   }
}
