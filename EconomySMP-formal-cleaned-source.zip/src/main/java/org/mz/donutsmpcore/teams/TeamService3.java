package org.mz.donutsmpcore.teams;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

public class TeamService3 {
   private static final Map<UUID, TeamService> pendingInvites;
   private static byte[] qbrwfiuanl;

   public static void addInvite(Player var0, TeamService var1) {
      int var9 = 1740132818 ^ 1468791569 ^ 897249304;
      var9 = 34095748 ^ var9;
      Map var2 = pendingInvites;
      UUID var6 = var0.getUniqueId();
      var2.put(var6, var1);
      var9 = 1002499610 ^ var9;
   }

   public static TeamService getInvite(UUID var0) {
      int var7 = 1923686353 ^ 432001267 ^ 897249304;
      var7 = 897875910 ^ var7;
      Map var1 = pendingInvites;
      Object var3 = var1.get(var0);
      TeamService var4 = (TeamService)var3;
      return var4;
   }

   public static void removeInvite(UUID var0) {
      int var6 = 1567511626 ^ 1117331830 ^ 897249304;
      var6 = 1655481195 ^ var6;
      Map var1 = pendingInvites;
      var1.remove(var0);
      var6 = 1072635418 ^ var6;
   }

   public static boolean hasInvite(UUID var0) {
      int var6 = 1093976023 ^ 1115844655 ^ 897249304;
      var6 = 117876512 ^ var6;
      Map var1 = pendingInvites;
      boolean var3 = var1.containsKey(var0);
      return var3;
   }

   static {
      int var3 = 1232903217 ^ 1662491294 ^ Integer.parseInt("493719149");
      qbrwfiuanl = erjkcavqjwbnugc();
      var3 = 1831141925 ^ var3;
      ConcurrentHashMap var0 = new ConcurrentHashMap();
      pendingInvites = var0;
      var3 = 110360323 ^ var3;
   }

   public static String ntqqnhshwo(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = qbrwfiuanl;
         byte[] var34 = qbrwfiuanl;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] erjkcavqjwbnugc() {
      return new byte[]{83, 1, 95, 5, 78, 24, 96, 59, 26, 31, 121, 54, 104, 70, 9, 45, 29, 42, 25, 37, 109, 45, 14, 123, 27};
   }
}
