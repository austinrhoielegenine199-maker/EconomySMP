package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.KKoOoOo0oOK;
import skido.o0KoOo0o0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;

public class TeamGUI implements KKoOK {
   private final Player player;
   private final TeamService team;
   private Inventory inv;
   private int cancelSlot;
   private int confirmSlot;
   private static final o0KoOo0o0oOK GUI;
   private static String xtpihdlkjj;

   public TeamGUI(Player var1, TeamService var2) {
      byte var4 = -1;
      this.cancelSlot = var4;
      byte var9 = -1;
      this.confirmSlot = var9;
      this.player = var1;
      this.team = var2;
   }

   public static boolean isEnabled() {
      int var10 = 1407460188 ^ 1686632362 ^ 1191194309;
      var10 = 1069517872 ^ var10;

      try {
         DonutSMPCore var0 = DonutSMPCore.getInstance();
         FileConfiguration var4 = var0.getConfig();
         String var1 = jtzuepiaob(ghojxmmdjcfiubw(), var10);
         byte var2 = (byte)(1339848194 ^ var10);
         boolean var5 = var4.getBoolean(var1, (boolean)var2);
         var10 = 157428566 ^ var10;
         return var5;
      } catch (Throwable var11) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var10)) {
            case 2128850970:
               var10 = fosixquekhubfdac(var10, 2012637113);
               var10 = 618888577 ^ var10;
               byte var7 = (byte)(482962490 ^ var10);
               return (boolean)var7;
            default:
               throw new IllegalAccessException("Error in hash");
         }
      }
   }

   public Inventory createInventory() {
      int var25 = 1747165633 ^ 2089012179 ^ 811911316;
      var25 = 617306687 ^ var25;
      Object var2 = null;
      InventoryHolder var12 = (InventoryHolder)var2;
      o0KoOo0o0oOK var3 = GUI;
      byte var4 = (byte)(1046690 ^ var25);
      int var14 = var3.size(var4);
      o0KoOo0o0oOK var15 = GUI;
      String var5 = jtzuepiaob(ffzteazmiqoukll(), var25);
      byte var6 = (byte)(1046715 ^ var25);
      Object[] var17 = new Object[var6];
      byte var7 = (byte)(1046713 ^ var25);
      String var8 = jtzuepiaob(hzvlwrwosryjsfu(), var25);
      var17[var7] = var8;
      byte var18 = (byte)(1046712 ^ var25);
      TeamService var20 = this.team;
      var25 = 1603465809 ^ var25;
      String var21 = var20.getName();
      String var22 = String.valueOf(var21);
      var17[var18] = var22;
      String var16 = var15.title(var5, var17);
      var25 = 1416444206 ^ var25;
      Inventory var13 = Bukkit.createInventory(var12, var14, var16);
      this.inv = var13;
      var25 = 289662708 ^ var25;
      this.decorate();
      var25 = 886239204 ^ var25;
      Inventory var11 = this.inv;
      return var11;
   }

   public void decorate() {
      int var52 = 1242882958 ^ 283679294 ^ 811911316;
      var52 = 1873884621 ^ var52;
      TeamService var15 = this.team;
      String var16 = var15.getName();
      String var17 = String.valueOf(var16);
      var52 = 1463839684 ^ var52;
      o0KoOo0o0oOK var2 = GUI;
      Inventory var26 = this.inv;
      String var4 = jtzuepiaob(dczysoffrssruux(), var52);
      byte var5 = (byte)(1382674214 ^ var52);
      o0KoOo0o0oOK var6 = GUI;
      String var7 = jtzuepiaob(njtfiuztcrgifzh(), var52);
      Material var8 = Material.RED_STAINED_GLASS_PANE;
      String var9 = jtzuepiaob(zibogtxbklrnsql(), var52);
      String var10 = jtzuepiaob(blbhwvkjpvgfnpk(), var52);
      var52 = 1673307879 ^ var52;
      List var37 = List.of(var10);
      byte var11 = (byte)(836061640 ^ var52);
      Object[] var40 = new Object[var11];
      byte var12 = (byte)(836061642 ^ var52);
      String var13 = jtzuepiaob(fsuvauhurrqvbka(), var52);
      var40[var12] = var13;
      byte var44 = (byte)(836061643 ^ var52);
      var40[var44] = var17;
      ItemStack var31 = var6.item(var7, var8, var9, var37, var40);
      var52 = 1515836693 ^ var52;
      int var21 = var2.place(var26, var4, var5, var31);
      this.cancelSlot = var21;
      var52 = 101415739 ^ var52;
      o0KoOo0o0oOK var22 = GUI;
      Inventory var28 = this.inv;
      String var29 = jtzuepiaob(ubzbffpvjujvjip(), var52);
      byte var30 = (byte)(1837623275 ^ var52);
      o0KoOo0o0oOK var32 = GUI;
      String var34 = jtzuepiaob(wpnapbhbghyqzbw(), var52);
      Material var35 = Material.LIME_STAINED_GLASS_PANE;
      String var36 = jtzuepiaob(eqenykztmlvtlnh(), var52);
      String var38 = jtzuepiaob(yxwlwtyiawtpnjq(), var52);
      String var41 = jtzuepiaob(pqvvivhcwcaekpj(), var52);
      var52 = 517087065 ^ var52;
      List var39 = List.of(var38, var41);
      byte var42 = (byte)(1935014079 ^ var52);
      Object[] var43 = new Object[var42];
      byte var45 = (byte)(1935014077 ^ var52);
      String var48 = jtzuepiaob(jtndtlzmneztmhl(), var52);
      var43[var45] = var48;
      byte var46 = (byte)(1935014076 ^ var52);
      var43[var46] = var17;
      var52 = 526187753 ^ var52;
      ItemStack var33 = var32.item(var34, var35, var36, var39, var43);
      var52 = 137051294 ^ var52;
      int var23 = var22.place(var28, var29, var30, var33);
      this.confirmSlot = var23;
      var52 = 1327638099 ^ var52;
      o0KoOo0o0oOK var20 = GUI;
      Inventory var25 = this.inv;
      var20.fill(var25);
      var52 = 595208245 ^ var52;
   }

   public void onClick(InventoryClickEvent var1) {
      int var181 = 1835852665 ^ 180754697 ^ 811911316;
      var181 = 174006302 ^ var181;
      byte var3 = (byte)(1569788667 ^ var181);
      var1.setCancelled((boolean)var3);
      var181 = 731482708 ^ var181;
      int var15 = var1.getRawSlot();
      var181 = 863501830 ^ var181;
      if (var15 < (1165977256 ^ var181)) {
         var181 = fosixquekhubfdac(var181, 1183358338);
      } else {
         var181 = 1918995698 ^ var181;
         int var87 = this.cancelSlot;
         if (var15 != var87) {
            var181 = 1744578903 ^ var181;
            int var89 = this.confirmSlot;
            if (var15 != var89) {
               var181 = 1393899559 ^ var181;
               return;
            }

            label136:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var181)) {
                  case 213321995:
                     var181 ^= 386291645;
                     break label136;
                  case 752790606:
                     break;
                  case 832479120:
                  default:
                     throw new IOException();
                  case 1312039148:
                     break label136;
               }
            }
         } else {
            var181 = 1895464682 ^ var181;
         }

         Player var20 = this.player;
         KKo0KoOoOK.click(var20);
         var181 = 1052129601 ^ var181;
         int var91 = this.cancelSlot;
         if (var15 == var91) {
            var181 = 244262826 ^ var181;
            Player var83 = this.player;
            var83.closeInventory();
            var181 = 364606067 ^ var181;
            Player var85 = this.player;
            o0KoOo0o0oOK var117 = GUI;
            String var131 = jtzuepiaob(pvojavasvvmikxg(), var181);
            String var140 = jtzuepiaob(sopvoboglvvxiuc(), var181);
            byte var152 = (byte)(1650915370 ^ var181);
            Object[] var153 = new Object[var152];
            byte var159 = (byte)(1650915368 ^ var181);
            String var172 = jtzuepiaob(ephpyhykpqufjdm(), var181);
            var153[var159] = var172;
            byte var160 = (byte)(1650915369 ^ var181);
            TeamService var174 = this.team;
            String var175 = var174.getName();
            String var176 = String.valueOf(var175);
            var153[var160] = var176;
            String var118 = var117.msg(var131, var140, var153);
            oOo0KKoOoOK.sendActionBarAndChat(var85, var118);
            var181 = 939090282 ^ var181;
         } else {
            label125:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var181)) {
                  case 58099725:
                  default:
                     throw new IOException();
                  case 185616464:
                     var181 ^= 14643084;
                     break label125;
                  case 1015554487:
                     break;
                  case 1819338685:
                     break label125;
               }
            }

            Player var23 = this.player;
            var23.closeInventory();
            var181 = 588539570 ^ var181;
            TeamService2 var24 = TeamService2.getInstance();
            var181 = 1732316888 ^ var181;
            Player var93 = this.player;
            UUID var94 = var93.getUniqueId();
            byte var26 = var24.isInTeam(var94);
            if (var26 != (1037609495 ^ var181)) {
               var181 = 287557632 ^ var181;
               Player var28 = this.player;
               o0KoOo0o0oOK var95 = GUI;
               String var4 = jtzuepiaob(omodvakmzifhjhl(), var181);
               String var5 = jtzuepiaob(jcmaphemrpaozbs(), var181);
               byte var6 = (byte)(754672151 ^ var181);
               Object[] var141 = new Object[var6];
               String var96 = var95.msg(var4, var5, var141);
               oOo0KKoOoOK.sendActionBarAndChat(var28, var96);
               var181 = 464156075 ^ var181;
               Player var30 = this.player;
               String var97 = jtzuepiaob(adnffhtqjxfcnki(), var181);
               Sound var119 = Sound.ENTITY_VILLAGER_NO;
               float var132 = 1.0F;
               float var142 = 1.0F;
               KKo0KoOoOK.play(var30, var97, var119, var132, var142);
               var181 = 320729822 ^ var181;
            } else {
               var181 = fosixquekhubfdac(var181, 326780841);
               Player var32 = this.player;
               UUID var33 = var32.getUniqueId();
               byte var34 = TeamService3.hasInvite(var33);
               if (var34 == (782429630 ^ var181)) {
                  var181 = 1712244329 ^ var181;
                  Player var36 = this.player;
                  o0KoOo0o0oOK var98 = GUI;
                  String var120 = jtzuepiaob(fdytcrdjqdgxhju(), var181);
                  String var133 = jtzuepiaob(olqybxwhboqykju(), var181);
                  byte var143 = (byte)(1219242967 ^ var181);
                  Object[] var144 = new Object[var143];
                  String var99 = var98.msg(var120, var133, var144);
                  oOo0KKoOoOK.sendActionBarAndChat(var36, var99);
                  var181 = 1674350871 ^ var181;
                  Player var38 = this.player;
                  String var100 = jtzuepiaob(hzoyzazgdtjjequ(), var181);
                  Sound var121 = Sound.ENTITY_VILLAGER_NO;
                  float var134 = 1.0F;
                  float var145 = 1.0F;
                  KKo0KoOoOK.play(var38, var100, var121, var134, var145);
                  var181 = 503028609 ^ var181;
               } else {
                  var181 = fosixquekhubfdac(var181, 1033371348);
                  TeamService var40 = this.team;
                  byte var41 = var40.isFull();
                  if (var41 != (322245482 ^ var181)) {
                     var181 = 675416034 ^ var181;
                     Player var69 = this.player;
                     UUID var70 = var69.getUniqueId();
                     TeamService3.removeInvite(var70);
                     var181 = 225149791 ^ var181;
                     int var71 = TeamService.getMaxPlayers();
                     var181 = 1419410833 ^ var181;
                     String var81;
                     if (var71 > (1653008966 ^ var181)) {
                        var181 = 1181631822 ^ var181;
                        TeamService var74 = this.team;
                        Set var75 = var74.getMembers();
                        int var76 = var75.size();
                        var81 = "(" + var76 + "/" + var71 + ")";
                        var181 = 1402360625 ^ var181;
                     } else {
                        var181 = 2028936672 ^ var181;
                        var81 = jtzuepiaob(ptcrihxhlrpteqa(), var181);
                        var181 = 1830226847 ^ var181;
                     }

                     var181 = 1790394877 ^ var181;
                     Player var78 = this.player;
                     o0KoOo0o0oOK var114 = GUI;
                     String var129 = jtzuepiaob(noaazhmtkisehaa(), var181);
                     String var138 = jtzuepiaob(kjfysgmrvybbcmg(), var181);
                     byte var149 = (byte)(499760576 ^ var181);
                     Object[] var150 = new Object[var149];
                     byte var155 = (byte)(499760580 ^ var181);
                     String var165 = jtzuepiaob(azdhynmedgwssgf(), var181);
                     var150[var155] = var165;
                     byte var156 = (byte)(499760581 ^ var181);
                     var150[var156] = var81;
                     byte var157 = (byte)(499760582 ^ var181);
                     String var167 = jtzuepiaob(efljclosnkvmdeb(), var181);
                     var150[var157] = var167;
                     byte var158 = (byte)(499760583 ^ var181);
                     TeamService var169 = this.team;
                     String var170 = var169.getName();
                     String var171 = String.valueOf(var170);
                     var150[var158] = var171;
                     String var115 = var114.msg(var129, var138, var150);
                     oOo0KKoOoOK.sendActionBarAndChat(var78, var115);
                     var181 = 2089456036 ^ var181;
                     Player var80 = this.player;
                     String var116 = jtzuepiaob(pukvrtcesqecrwq(), var181);
                     Sound var130 = Sound.ENTITY_VILLAGER_NO;
                     float var139 = 1.0F;
                     float var151 = 1.0F;
                     KKo0KoOoOK.play(var80, var116, var130, var139, var151);
                     var181 = 1700860590 ^ var181;
                  } else {
                     label114:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var181)) {
                           case 87475880:
                              var181 ^= 604237427;
                              break label114;
                           case 103253057:
                              break;
                           case 880914151:
                           default:
                              throw new IOException();
                           case 1611463129:
                              break label114;
                        }
                     }

                     Player var43 = this.player;
                     UUID var44 = var43.getUniqueId();
                     TeamService3.removeInvite(var44);
                     var181 = 830017599 ^ var181;
                     Player var102 = this.player;
                     UUID var103 = var102.getUniqueId();
                     TeamService var123 = this.team;
                     var24.joinTeam(var103, var123);
                     var181 = 1107400510 ^ var181;
                     Player var47 = this.player;
                     o0KoOo0o0oOK var104 = GUI;
                     String var124 = jtzuepiaob(lnjtgmnfagcscmz(), var181);
                     String var135 = jtzuepiaob(beqgmxejaxiehwp(), var181);
                     byte var146 = (byte)(1145993754 ^ var181);
                     Object[] var147 = new Object[var146];
                     byte var7 = (byte)(1145993752 ^ var181);
                     String var8 = jtzuepiaob(vygibfprgwzyekm(), var181);
                     var147[var7] = var8;
                     byte var154 = (byte)(1145993753 ^ var181);
                     TeamService var162 = this.team;
                     String var163 = var162.getName();
                     String var164 = String.valueOf(var163);
                     var147[var154] = var164;
                     String var105 = var104.msg(var124, var135, var147);
                     oOo0KKoOoOK.sendActionBarAndChat(var47, var105);
                     var181 = 546690067 ^ var181;
                     Player var49 = this.player;
                     String var106 = jtzuepiaob(vkbqpdjhfexewqa(), var181);
                     Sound var125 = Sound.ENTITY_PLAYER_LEVELUP;
                     float var136 = 1.5F;
                     float var148 = 1.2F;
                     KKo0KoOoOK.play(var49, var106, var125, var136, var148);
                     var181 = 1316846162 ^ var181;
                     TeamService var51 = this.team;
                     Set var52 = var51.getMembers();
                     Iterator var53 = var52.iterator();
                     Iterator var11 = var53;
                     var181 = 775367376 ^ var181;

                     label104:
                     while(true) {
                        byte var55 = var11.hasNext();
                        if (var55 == (76676745 ^ var181)) {
                           label68:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var181)) {
                                 case 71883313:
                                    var181 ^= 343586982;
                                    break label68;
                                 case 1185459637:
                                 default:
                                    throw new IOException();
                                 case 1429264077:
                                    break;
                                 case 1945182550:
                                    break label68;
                              }
                           }

                           KKoOoOo0oOK var56 = KKoOoOo0oOK.getInstance();
                           Runnable var108 = () -> {
                              int var7 = 657740523 ^ 1437870999 ^ 811911316;
                              var7 = 134161954 ^ var7;
                              TeamService var4 = this.team;
                              var24.broadcastTeamUpdate(var4);
                           };
                           var56.runNextTick(var108);
                           var181 = 986890882 ^ var181;
                           return;
                        }

                        var181 = 1548872619 ^ var181;
                        Object var58 = var11.next();
                        UUID var59 = (UUID)var58;
                        var181 = 826331848 ^ var181;
                        Player var110 = this.player;
                        UUID var111 = var110.getUniqueId();
                        byte var61 = var59.equals(var111);
                        if (var61 != (1770047466 ^ var181)) {
                           var181 = 90410181 ^ var181;
                           var181 = 1752348070 ^ var181;
                        } else {
                           label99:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var181)) {
                                 case 91518929:
                                    break label99;
                                 case 208267989:
                                    var181 ^= 1103078782;
                                    break label99;
                                 case 1278080847:
                                 default:
                                    throw new IOException();
                                 case 1783210429:
                              }
                           }

                           Player var63 = Bukkit.getPlayer(var59);
                           var181 = 921372034 ^ var181;
                           if (var63 == null) {
                              var181 = fosixquekhubfdac(var181, 440768927);
                           } else {
                              var181 = 951603288 ^ var181;
                              byte var66 = var63.isOnline();
                              if (var66 != (644626254 ^ var181)) {
                                 var181 = fosixquekhubfdac(var181, 1311409091);
                                 KKoOoOo0oOK var67 = KKoOoOo0oOK.getInstance();
                                 Runnable var128 = () -> {
                                    int var17 = 1763515886 ^ 434041408 ^ 811911316;
                                    var17 = 2031243780 ^ var17;
                                    o0KoOo0o0oOK var3 = GUI;
                                    String var4 = jtzuepiaob(cutfwtwmwyxqebo(), var17);
                                    String var5 = jtzuepiaob(nxxfvplobnxiqpy(), var17);
                                    byte var6 = (byte)(968193340 ^ var17);
                                    Object[] var10 = new Object[var6];
                                    byte var7 = (byte)(968193342 ^ var17);
                                    String var8 = jtzuepiaob(suupuntoyuhemik(), var17);
                                    var10[var7] = var8;
                                    byte var11 = (byte)(968193343 ^ var17);
                                    Player var13 = this.player;
                                    var17 = 1185788476 ^ var17;
                                    String var14 = var13.getName();
                                    var10[var11] = var14;
                                    String var9 = var3.msg(var4, var5, var10);
                                    var17 = 983067940 ^ var17;
                                    oOo0KKoOoOK.sendActionBarAndChat(var63, var9);
                                 };
                                 var67.runAtEntity(var63, var128);
                                 var181 = 1421943408 ^ var181;
                                 var181 = 940992628 ^ var181;
                              } else {
                                 var181 = 1162262323 ^ var181;

                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var181)) {
                                       case 2243544:
                                          var181 ^= 1740340980;
                                          continue label104;
                                       case 172691823:
                                          break;
                                       case 607803195:
                                       default:
                                          throw new IOException();
                                       case 1710865403:
                                          continue label104;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public void open() {
      int var12 = 792306359 ^ 344967786 ^ 811911316;
      var12 = 2077844388 ^ var12;
      Player var4 = this.player;
      Inventory var7 = this.createInventory();
      var4.openInventory(var7);
      var12 = 2096840097 ^ var12;
      oOoOKo0o0K var6 = oOoOKo0o0K.getInstance();
      Inventory var9 = this.inv;
      var6.register(var9, this);
      var12 = 2021448768 ^ var12;
   }

   static {
      int var4 = 1809692703 ^ 1557723858 ^ Integer.parseInt("1316431976");
      xtpihdlkjj = ByteBuffer.wrap(dfdklqegtyyqvbg()).asCharBuffer().toString();
      var4 = 1604370686 ^ var4;
      String var0 = jtzuepiaob(nmssuaguyjaqywz(), var4);
      o0KoOo0o0oOK var1 = o0KoOo0o0oOK.of(var0);
      GUI = var1;
   }

   public static String jtzuepiaob(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = xtpihdlkjj;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] nmssuaguyjaqywz() {
      return new byte[]{0, 0, 0, 25, 0, 0, 0, 0};
   }

   private static byte[] ghojxmmdjcfiubw() {
      return new byte[]{0, 0, 0, 18, 0, 0, 0, 25};
   }

   private static byte[] cutfwtwmwyxqebo() {
      return new byte[]{0, 0, 0, 13, 0, 0, 0, 43};
   }

   private static byte[] nxxfvplobnxiqpy() {
      return new byte[]{0, 0, 0, 44, 0, 0, 0, 56};
   }

   private static byte[] suupuntoyuhemik() {
      return new byte[]{0, 0, 0, 8, 0, 0, 0, 100};
   }

   private static byte[] ffzteazmiqoukll() {
      return new byte[]{0, 0, 0, 20, 0, 0, 0, 108};
   }

   private static byte[] hzvlwrwosryjsfu() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -128};
   }

   private static byte[] fsuvauhurrqvbka() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -122};
   }

   private static byte[] ubzbffpvjujvjip() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, -116};
   }

   private static byte[] wpnapbhbghyqzbw() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, -109};
   }

   private static byte[] eqenykztmlvtlnh() {
      return new byte[]{0, 0, 0, 14, 0, 0, 0, -102};
   }

   private static byte[] yxwlwtyiawtpnjq() {
      return new byte[]{0, 0, 0, 15, 0, 0, 0, -88};
   }

   private static byte[] pqvvivhcwcaekpj() {
      return new byte[]{0, 0, 0, 24, 0, 0, 0, -73};
   }

   private static byte[] dczysoffrssruux() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -49};
   }

   private static byte[] njtfiuztcrgifzh() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -43};
   }

   private static byte[] zibogtxbklrnsql() {
      return new byte[]{0, 0, 0, 13, 0, 0, 0, -37};
   }

   private static byte[] blbhwvkjpvgfnpk() {
      return new byte[]{0, 0, 0, 17, 0, 0, 0, -24};
   }

   private static byte[] jtndtlzmneztmhl() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -7};
   }

   private static byte[] vkbqpdjhfexewqa() {
      return new byte[]{0, 0, 0, 28, 0, 0, 0, -1};
   }

   private static byte[] ptcrihxhlrpteqa() {
      return new byte[]{0, 0, 0, 0, 0, 0, 1, 27};
   }

   private static byte[] pukvrtcesqecrwq() {
      return new byte[]{0, 0, 0, 26, 0, 0, 1, 27};
   }

   private static byte[] pvojavasvvmikxg() {
      return new byte[]{0, 0, 0, 9, 0, 0, 1, 53};
   }

   private static byte[] sopvoboglvvxiuc() {
      return new byte[]{0, 0, 0, 43, 0, 0, 1, 62};
   }

   private static byte[] ephpyhykpqufjdm() {
      return new byte[]{0, 0, 0, 6, 0, 0, 1, 105};
   }

   private static byte[] omodvakmzifhjhl() {
      return new byte[]{0, 0, 0, 15, 0, 0, 1, 111};
   }

   private static byte[] jcmaphemrpaozbs() {
      return new byte[]{0, 0, 0, 28, 0, 0, 1, 126};
   }

   private static byte[] lnjtgmnfagcscmz() {
      return new byte[]{0, 0, 0, 6, 0, 0, 1, -102};
   }

   private static byte[] beqgmxejaxiehwp() {
      return new byte[]{0, 0, 0, 35, 0, 0, 1, -96};
   }

   private static byte[] vygibfprgwzyekm() {
      return new byte[]{0, 0, 0, 6, 0, 0, 1, -61};
   }

   private static byte[] hzoyzazgdtjjequ() {
      return new byte[]{0, 0, 0, 26, 0, 0, 1, -55};
   }

   private static byte[] fdytcrdjqdgxhju() {
      return new byte[]{0, 0, 0, 14, 0, 0, 1, -29};
   }

   private static byte[] olqybxwhboqykju() {
      return new byte[]{0, 0, 0, 33, 0, 0, 1, -15};
   }

   private static byte[] adnffhtqjxfcnki() {
      return new byte[]{0, 0, 0, 25, 0, 0, 2, 18};
   }

   private static byte[] noaazhmtkisehaa() {
      return new byte[]{0, 0, 0, 9, 0, 0, 2, 43};
   }

   private static byte[] kjfysgmrvybbcmg() {
      return new byte[]{0, 0, 0, 31, 0, 0, 2, 52};
   }

   private static byte[] azdhynmedgwssgf() {
      return new byte[]{0, 0, 0, 7, 0, 0, 2, 83};
   }

   private static byte[] efljclosnkvmdeb() {
      return new byte[]{0, 0, 0, 6, 0, 0, 2, 90};
   }

   private static byte[] dfdklqegtyyqvbg() {
      return new byte[]{54, 82, 49, 70, 52, 89, 51, 68, 57, 25, 53, 69, 51, 81, 48, 82, 55, 84, 54, 70, 49, 28, 52, 90, 51, 88, 57, 95, 53, 95, 51, 87, 48, 92, 55, 87, 54, 83, 49, 90, 52, 66, 51, 90, 57, 81, 53, 68, 51, 93, 49, 71, 51, 92, 56, 85, 56, 92, 57, 70, 49, 29, 51, 83, 56, 91, 56, 88, 57, 91, 49, 30, 51, 90, 56, 91, 56, 95, 57, 83, 49, 90, 51, 75, 56, 89, 57, 91, 56, 84, 57, 94, 51, 86, 50, 92, 54, 74, 49, 20, 51, 89, 52, 93, 57, 95, 56, 95, 57, 86, 51, 80, 57, 16, 56, 6, 57, 99, 51, 88, 50, 88, 54, 65, 49, 92, 51, 65, 52, 18, 57, 21, 56, 3, 57, 0, 51, 13, 50, 0, 54, 126, 49, 127, 51, 22, 52, 66, 57, 90, 56, 80, 57, 74, 51, 81, 50, 75, 54, 29, 49, 25, 51, 21, 52, 5, 57, 92, 56, 94, 57, 90, 51, 90, 50, 92, 54, 92, 49, 25, 51, 74, 52, 93, 57, 67, 56, 67, 57, 19, 51, 64, 50, 92, 54, 89, 49, 84, 51, 18, 57, 19, 56, 65, 57, 95, 51, 85, 50, 64, 54, 93, 49, 75, 51, 22, 44, 52, 41, 57, 53, 69, -108, 1, 50, 94, 52, -73, 44, 62, 49, 16, 41, 60, 42, 62, 49, 91, 50, 64, 52, 93, 51, 71, 44, 63, 52, 22, 42, 42, 46, 54, 45, 52, 43, 58, 49, 21, 52, 66, 55, 84, 51, 80, 48, 89, 54, 18, 56, 22, 54, 68, 54, 84, 54, 85, 50, 85, 51, 19, 49, 91, 51, 88, 54, 92, 51, 84, 54, 81, 49, 74, 51, 90, 49, 91, 51, 88, 54, 92, 51, 84, 54, 81, 49, 74, 51, 90, 49, 27, 51, 4, 54, 115, 51, 116, 54, 126, 49, 8, 51, 7, 43, 54, 46, 61, 52, 76, -106, 8, 49, 93, 52, -78, 46, 63, 49, 30, 51, 0, 54, 120, 51, 93, 54, 81, 49, 86, 51, 23, 54, 20, 51, 84, 54, 29, 49, 76, 51, 82, 54, 83, 51, 95, 54, 29, 49, 30, 51, 81, 54, 113, 51, 94, 54, 81, 49, 91, 51, 92, 54, 18, 51, 70, 54, 87, 49, 24, 51, 93, 54, 93, 51, 91, 54, 86, 49, 24, 51, 67, 54, 90, 51, 87, 54, 24, 49, 76, 51, 82, 54, 83, 51, 95, 49, 80, 56, 83, 54, 89, 52, 81, 50, 84, 49, 95, 49, 80, 56, 83, 54, 89, 52, 81, 50, 84, 49, 95, 49, 16, 56, 116, 54, 113, 52, 3, 50, 117, 49, 2, 56, 118, 43, 51, 41, 50, 48, 69, 44, 55, 37, 53, 52, -88, 49, 21, 56, 84, 54, 116, 52, 94, 50, 88, 49, 80, 56, 89, 54, 23, 52, 70, 50, 94, 49, 19, 56, 81, 54, 86, 52, 92, 50, 82, 49, 86, 56, 94, 49, 28, 51, 65, 48, 84, 52, 81, 55, 90, 49, 28, 49, 66, 57, 87, 49, 80, 56, 88, 51, 74, 49, 24, 57, 88, 49, 94, 56, 92, 51, 87, 49, 85, 57, 93, 49, 95, 56, 83, 51, 80, 49, 68, 57, 95, 49, 86, 56, 64, 51, 80, 49, 24, 57, 65, 49, 68, 56, 86, 51, 90, 49, 83, 57, 65, 49, 66, 49, 66, 51, 84, 55, 88, 50, 95, 50, 71, 49, 24, 51, 91, 55, 86, 50, 91, 50, 90, 49, 85, 51, 94, 55, 87, 50, 84, 50, 93, 49, 68, 51, 92, 55, 94, 50, 71, 50, 93, 49, 24, 51, 85, 55, 92, 50, 92, 50, 77, 49, 5, 49, 85, 53, 81, 57, 95, 53, 80, 54, 93, 49, 90, 53, 92, 57, 84, 53, 87, 49, 16, 53, 7, 57, 123, 53, 92, 54, 81, 49, 88, 53, 16, 57, 82, 53, 82, 54, 86, 49, 85, 53, 85, 57, 93, 53, 95, 54, 93, 49, 82, 53, 30, 57, 17, 53, 103, 54, 80, 49, 83, 53, 16, 57, 88, 53, 93, 54, 78, 49, 95, 53, 68, 57, 84, 53, 19, 54, 81, 49, 69, 53, 16, 57, 66, 53, 71, 54, 81, 49, 90, 53, 92, 57, 17, 53, 92, 54, 72, 49, 83, 53, 94, 57, 31, 49, 19, 53, 68, 57, 84, 53, 82, 54, 85, 49, 19, 55, 84, 52, 90, 55, 64, 49, 80, 49, 86, 53, 80, 54, 78, 50, 28, 53, 88, 55, 91, 52, 27, 55, 70, 49, 80, 49, 86, 53, 89, 55, 19, 52, 85, 55, 107, 49, 90, 49, 66, 53, 20, 54, 86, 50, 67, 53, 84, 55, 21, 52, 87, 55, 94, 49, 71, 49, 82, 53, 85, 54, 83, 50, 72, 53, 17, 55, 92, 52, 88, 55, 18, 49, 84, 49, 23, 53, 64, 54, 82, 50, 80, 53, 92, 55, 27, 49, 91, 52, 90, 57, 80, 51, 89, 53, 87, 49, 85, 49, 23, 52, 2, 57, 96, 51, 88, 53, 71, 49, 17, 52, 95, 57, 86, 51, 94, 53, 92, 49, 84, 52, 81, 57, 25, 51, 67, 53, 90, 49, 84, 52, 21, 57, 77, 51, 82, 53, 83, 49, 92, 52, 21, 57, 26, 51, 5, 53, 1, 49, 8, 52, 12, 57, 127, 51, 113, 53, 23, 49, 69, 52, 80, 57, 88, 51, 90, 53, 23, 49, 20, 52, 65, 57, 92, 51, 86, 53, 95, 49, 20, 55, 70, 55, 82, 53, 88, 53, 88, 50, 68, 50, 25, 55, 95, 57, 90, 53, 91, 55, 92, 55, 84, 53, 86, 53, 91, 50, 81, 50, 94, 55, 71, 57, 88, 53, 85, 55, 71, 55, 94, 53, 23, 53, 81, 50, 82, 50, 89, 55, 76, 57, 7, 49, 91, 49, 87, 50, 66, 50, 80, 54, 67, 49, 87, 49, 20, 50, 93, 50, 87, 54, 65, 49, 83, 49, 85, 50, 93, 50, 93, 49, 20, 49, 90, 50, 96, 50, 81, 54, 86, 49, 70, 49, 25, 50, 93, 50, 87, 54, 65, 49, 91, 49, 77, 50, 81, 50, 25, 54, 94, 49, 65, 49, 25, 50, 90, 50, 86, 54, 23, 49, 94, 49, 86, 50, 90, 50, 94, 54, 82, 49, 64, 49, 25, 50, 66, 50, 88, 54, 91, 49, 91, 49, 93, 50, 26, 57, 70, 56, 85, 54, 80, 51, 90, 50, 74, 50, 22, 48, 92, 49, 92, 55, 91, 57, 92, 56, 83, 54, 94, 51, 89, 50, 95, 50, 81, 48, 68, 49, 94, 55, 85, 57, 71, 56, 89, 54, 31, 51, 83, 50, 92, 50, 86, 48, 79, 52, 77, 57, 82, 54, 81, 53, 85, 48, 25, 57, 95, 55, 67, 48, 89, 56, 92, 52, 31, 57, 84, 54, 100, 53, 80, 48, 93, 57, 74, 55, 22, 48, 65, 56, 85, 52, 88, 57, 90, 54, 16, 53, 81, 48, 71, 57, 25, 55, 88, 48, 90, 56, 71, 52, 25, 57, 81, 54, 69, 53, 84, 48, 88, 57, 25, 55, 19, 48, 89, 56, 89, 52, 84, 57, 94, 54, 68, 53, 29, 52, 28, 57, 91, 54, 89, 53, 85, 48, 93, 57, 77, 55, 19, 52, 28, 57, 67, 54, 85, 53, 89, 48, 89, 57, 28};
   }

   private static int fosixquekhubfdac(int var0, int var1) {
      return var0 ^ var1;
   }
}
