package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.KKoOoOo0oOK;
import skido.o0KoOo0o0oOK;
import skido.o0oOKo0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;

public class TeamManagementGUI implements KKoOK {
   private final Player viewer;
   private final TeamService team;
   private final boolean isMember;
   private final int page;
   private final TeamMenu.K sortType;
   private Inventory inv;
   private static final o0KoOo0o0oOK GUI;
   private static final List<Integer> DEFAULT_CONTENT;
   private static String qxgrdcvybp;

   public TeamManagementGUI(Player var1, TeamService var2, int var3, TeamMenu.K var4) {
      this.viewer = var1;
      this.team = var2;
      UUID var19 = var1.getUniqueId();
      boolean var15 = var2.isMember(var19);
      this.isMember = var15;
      byte var16 = 1;
      int var17 = Math.max(var16, var3);
      this.page = var17;
      this.sortType = var4;
   }

   public TeamManagementGUI(Player var1, TeamService var2) {
      byte var6 = 1;
      TeamMenu.K var7 = TeamMenu.K.JOIN_DATE;
      this(var1, var2, var6, var7);
   }

   public Inventory createInventory() {
      int var30 = 525919877 ^ 1884098266 ^ 1017777565;
      var30 = 1092810308 ^ var30;
      Object var2 = null;
      InventoryHolder var12 = (InventoryHolder)var2;
      o0KoOo0o0oOK var3 = GUI;
      byte var4 = (byte)(312284080 ^ var30);
      int var14 = var3.size(var4);
      o0KoOo0o0oOK var15 = GUI;
      String var5 = vhpupplrfs(vhmysimmniscjrm(), var30);
      byte var6 = (byte)(312284034 ^ var30);
      Object[] var17 = new Object[var6];
      byte var7 = (byte)(312284038 ^ var30);
      String var8 = vhpupplrfs(qfxmjeeikgveogi(), var30);
      var17[var7] = var8;
      byte var18 = (byte)(312284039 ^ var30);
      TeamService var22 = this.team;
      String var23 = var22.getDisplayName();
      var17[var18] = var23;
      byte var19 = (byte)(312284036 ^ var30);
      String var24 = vhpupplrfs(jqlmlgtntpuwpbs(), var30);
      var17[var19] = var24;
      byte var20 = (byte)(312284037 ^ var30);
      int var26 = this.page;
      Integer var27 = var26;
      var17[var20] = var27;
      String var16 = var15.title(var5, var17);
      Inventory var13 = Bukkit.createInventory(var12, var14, var16);
      this.inv = var13;
      var30 = 1801062450 ^ var30;
      this.decorate();
      var30 = 777965237 ^ var30;
      Inventory var11 = this.inv;
      return var11;
   }

   public void decorate() {
      int var378 = 1794622597 ^ 472276791 ^ 1017777565;
      var378 = 1085255623 ^ var378;
      Inventory var29 = this.inv;
      int var30 = var29.getSize();
      var378 = 1216001398 ^ var378;
      o0KoOo0o0oOK var31 = GUI;
      String var2 = vhpupplrfs(lhkqwzhxdjckvct(), var378);
      List var3 = DEFAULT_CONTENT;
      List var32 = var31.slots(var2, var3);
      Stream var33 = var32.stream();
      Predicate var127 = (var1) -> {
         int var10 = 631495356 ^ 1488622443 ^ 1912941156;
         var10 = 822488747 ^ var10;
         int var4 = var1;
         byte var7;
         if (var4 >= (1041911064 ^ var10)) {
            var10 = 1388836669 ^ var10;
            int var6 = var1;
            if (var6 < var30) {
               var10 = 412386696 ^ var10;
               var7 = (byte)(1950957484 ^ var10);
               var10 = 616160548 ^ var10;
               return (boolean)var7;
            }

            var10 = 797852463 ^ var10;
         } else {
            var10 = doiknbyxvpnlzzvj(var10, 2101982226);
         }

         var7 = (byte)(1129576714 ^ var10);
         var10 = 329456515 ^ var10;
         return (boolean)var7;
      };
      Stream var34 = var33.filter(var127);
      List var35 = var34.toList();
      List var15 = var35;
      var378 = 862153413 ^ var378;
      Iterator var37 = var35.iterator();
      Iterator var16 = var37;
      var378 = 1631881314 ^ var378;

      o0KoOo0o0oOK var87;
      Inventory var152;
      String var187;
      byte var207;
      o0KoOo0o0oOK var221;
      String var230;
      Material var238;
      String var248;
      List var265;
      Object[] var280;
      byte var319;
      String var362;
      label272:
      while(true) {
         byte var39 = var16.hasNext();
         if (var39 != (277442105 ^ var378)) {
            var378 = 973230566 ^ var378;
            Object var41 = var16.next();
            Integer var42 = (Integer)var41;
            int var43 = var42;
            var378 = 1034215364 ^ var378;
            Inventory var45 = this.inv;
            Object var174 = null;
            ItemStack var175 = (ItemStack)var174;
            var45.setItem(var43, var175);
            var378 = 135140048 ^ var378;

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                  case 121125255:
                     continue label272;
                  case 206690632:
                     var378 ^= 262708466;
                     continue label272;
                  case 1098044833:
                  default:
                     throw new IllegalAccessException();
                  case 1840698222:
               }
            }
         } else {
            label266:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                  case 677127:
                     var378 ^= 717899138;
                     break label266;
                  case 343970946:
                  default:
                     throw new IllegalAccessException();
                  case 1025810239:
                     break;
                  case 1618233492:
                     break label266;
               }
            }

            List var47 = this.getSortedMembers();
            List var368 = var47;
            var378 = 233431465 ^ var378;
            int var49 = this.page;
            byte var129 = (byte)(933939731 ^ var378);
            int var50 = var49 - var129;
            int var131 = var35.size();
            int var51 = var50 * var131;
            int var369 = var51;
            var378 = 1106063323 ^ var378;
            int var53 = var47.size();
            int var18 = var53;
            var378 = 1138835448 ^ var378;
            o0KoOo0o0oOK var54 = GUI;
            String var132 = vhpupplrfs(ymczlznrlwajahd(), var378);
            byte var176 = (byte)(900127280 ^ var378);
            byte var55 = var54.bool(var132, (boolean)var176);
            byte var19 = var55;
            var378 = 1138704695 ^ var378;
            byte var56 = (byte)(1987681030 ^ var378);
            int var20 = var56;
            var378 = 55407282 ^ var378;

            label256:
            while(true) {
               int var134 = var15.size();
               if (var20 >= var134) {
                  label193:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                        case 51835384:
                           var378 ^= 1393270451;
                           break label193;
                        case 505358137:
                        default:
                           throw new IllegalAccessException();
                        case 566023115:
                           break;
                        case 1259041993:
                           break label193;
                     }
                  }

                  TeamService var59 = this.team;
                  String var60 = var59.getDisplayName();
                  var378 = 171272744 ^ var378;
                  o0KoOo0o0oOK var61 = GUI;
                  Inventory var136 = this.inv;
                  String var177 = vhpupplrfs(nerpijzwonvxotp(), var378);
                  byte var4 = (byte)(738860290 ^ var378);
                  o0KoOo0o0oOK var5 = GUI;
                  String var6 = vhpupplrfs(mjzhypxmcanxhac(), var378);
                  Material var7 = Material.OAK_SIGN;
                  String var8 = vhpupplrfs(godzwrikuwlkrln(), var378);
                  String var9 = vhpupplrfs(pgbylnikjtcovxf(), var378);
                  List var253 = List.of(var9);
                  byte var10 = (byte)(738860335 ^ var378);
                  Object[] var266 = new Object[var10];
                  ItemStack var210 = var5.item(var6, var7, var8, var253, var266);
                  var61.place(var136, var177, var4, var210);
                  var378 = 465166275 ^ var378;
                  o0KoOo0o0oOK var63 = GUI;
                  Inventory var138 = this.inv;
                  String var178 = vhpupplrfs(ltzbkrdprcvhppv(), var378);
                  byte var202 = (byte)(934527708 ^ var378);
                  o0KoOo0o0oOK var211 = GUI;
                  String var225 = vhpupplrfs(lzozodgzoqtssvm(), var378);
                  Material var233 = Material.ARROW;
                  String var243 = vhpupplrfs(rmperddpghxsyzz(), var378);
                  String var254 = vhpupplrfs(bmliizbugusikgd(), var378);
                  List var255 = List.of(var254);
                  byte var267 = (byte)(934527726 ^ var378);
                  Object[] var268 = new Object[var267];
                  byte var11 = (byte)(934527724 ^ var378);
                  String var12 = vhpupplrfs(xgpxywjgtgztxih(), var378);
                  var268[var11] = var12;
                  byte var296 = (byte)(934527725 ^ var378);
                  int var321 = this.page;
                  Integer var322 = var321;
                  var268[var296] = var322;
                  ItemStack var212 = var211.item(var225, var233, var243, var255, var268);
                  var63.place(var138, var178, var202, var212);
                  var378 = 146832886 ^ var378;
                  o0KoOo0o0oOK var65 = GUI;
                  Inventory var140 = this.inv;
                  String var179 = vhpupplrfs(tgvfwkoyurliuts(), var378);
                  byte var203 = (byte)(1064550184 ^ var378);
                  o0KoOo0o0oOK var213 = GUI;
                  String var226 = vhpupplrfs(xqxahdromlhlplr(), var378);
                  Material var234 = Material.ARROW;
                  String var244 = vhpupplrfs(hkhavldubtknwyv(), var378);
                  String var256 = vhpupplrfs(wsqdjajhekcvamo(), var378);
                  List var257 = List.of(var256);
                  byte var269 = (byte)(1064550168 ^ var378);
                  Object[] var270 = new Object[var269];
                  byte var297 = (byte)(1064550170 ^ var378);
                  String var323 = vhpupplrfs(wsmkkiciaorryqp(), var378);
                  var270[var297] = var323;
                  byte var298 = (byte)(1064550171 ^ var378);
                  int var325 = this.page;
                  Integer var326 = var325;
                  var270[var298] = var326;
                  ItemStack var214 = var213.item(var226, var234, var244, var257, var270);
                  var65.place(var140, var179, var203, var214);
                  var378 = 378220169 ^ var378;
                  TeamService var68 = this.team;
                  byte var69 = var68.isPvpEnabled();
                  String var125;
                  if (var69 != (704156051 ^ var378)) {
                     var378 = 737942125 ^ var378;
                     o0KoOo0o0oOK var91 = GUI;
                     String var156 = vhpupplrfs(yjfgdfkgixwqdbk(), var378);
                     String var189 = vhpupplrfs(ofdjlmueirautnh(), var378);
                     var125 = var91.raw(var156, var189);

                     label181:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                           case 31736122:
                              var378 ^= 178980139;
                              break label181;
                           case 380801393:
                           default:
                              throw new IllegalAccessException();
                           case 1331896758:
                              break label181;
                           case 1533847158:
                        }
                     }
                  } else {
                     var378 = doiknbyxvpnlzzvj(var378, 2123030596);
                     o0KoOo0o0oOK var70 = GUI;
                     String var141 = vhpupplrfs(cceycrzjtogslbn(), var378);
                     String var180 = vhpupplrfs(gvtxrxqesbartwm(), var378);
                     var125 = var70.raw(var141, var180);
                     var378 = 1608384258 ^ var378;
                  }

                  var378 = 876133427 ^ var378;
                  o0KoOo0o0oOK var71 = GUI;
                  Inventory var143 = this.inv;
                  String var181 = vhpupplrfs(sxqdutfvnjnwihm(), var378);
                  byte var204 = (byte)(1016541907 ^ var378);
                  o0KoOo0o0oOK var215 = GUI;
                  String var227 = vhpupplrfs(kbezhophhahdtew(), var378);
                  Material var235 = Material.IRON_SWORD;
                  String var245 = vhpupplrfs(josrmpgebxnegim(), var378);
                  String var258 = vhpupplrfs(krfuzerjdwcnjzw(), var378);
                  List var259 = List.of(var258);
                  byte var271 = (byte)(1016541924 ^ var378);
                  Object[] var272 = new Object[var271];
                  byte var299 = (byte)(1016541926 ^ var378);
                  String var327 = vhpupplrfs(rjrnyiukisiktls(), var378);
                  var272[var299] = var327;
                  byte var300 = (byte)(1016541927 ^ var378);
                  var272[var300] = var125;
                  ItemStack var216 = var215.item(var227, var235, var245, var259, var272);
                  var71.place(var143, var181, var204, var216);
                  var378 = 271371585 ^ var378;
                  int var73 = TeamService.getMaxPlayers();
                  var378 = 1007580935 ^ var378;
                  o0KoOo0o0oOK var74 = GUI;
                  Inventory var145 = this.inv;
                  String var182 = vhpupplrfs(wsdeuawmbxtzsyt(), var378);
                  byte var205 = (byte)(280332433 ^ var378);
                  o0KoOo0o0oOK var217 = GUI;
                  String var228 = vhpupplrfs(polwffqkjdyscwu(), var378);
                  Material var236 = Material.IRON_HELMET;
                  String var246 = vhpupplrfs(agcnftrlclajlqj(), var378);
                  String var260 = vhpupplrfs(zyuhvldoxvqmjci(), var378);
                  String var273 = vhpupplrfs(swxeazanhlfisdz(), var378);
                  var378 = 216939449 ^ var378;
                  List var261 = List.of(var260, var273);
                  byte var274 = (byte)(475771679 ^ var378);
                  Object[] var275 = new Object[var274];
                  byte var301 = (byte)(475771673 ^ var378);
                  String var329 = vhpupplrfs(gmxwhnglesguxmu(), var378);
                  var275[var301] = var329;
                  byte var302 = (byte)(475771672 ^ var378);
                  var275[var302] = var60;
                  byte var303 = (byte)(475771675 ^ var378);
                  String var331 = vhpupplrfs(rtzbmsuqxdqgehu(), var378);
                  var275[var303] = var331;
                  byte var304 = (byte)(475771674 ^ var378);
                  TeamService var333 = this.team;
                  var378 = 177299693 ^ var378;
                  Set var334 = var333.getMembers();
                  int var335 = var334.size();
                  Integer var336 = var335;
                  var275[var304] = var336;
                  byte var305 = (byte)(382391280 ^ var378);
                  String var337 = vhpupplrfs(pcvermwtjiimblb(), var378);
                  var275[var305] = var337;
                  byte var306 = (byte)(382391281 ^ var378);
                  String var340;
                  if (var73 > (382391284 ^ var378)) {
                     var378 = 1942345703 ^ var378;
                     var340 = String.valueOf(var73);
                     var378 = doiknbyxvpnlzzvj(var378, 943163649);
                  } else {
                     var378 = 2140407766 ^ var378;
                     var340 = vhpupplrfs(splauorgxvrdrjk(), var378);
                     var378 = 879122736 ^ var378;
                  }

                  var275[var306] = var340;
                  var378 = 1319587522 ^ var378;
                  ItemStack var218 = var217.item(var228, var236, var246, var261, var275);
                  var74.place(var145, var182, var205, var218);
                  var378 = 567076923 ^ var378;
                  TeamService var77 = this.team;
                  byte var78 = var77.hasTeamHome();
                  String var80;
                  if (var78 != (844311531 ^ var378)) {
                     var378 = 2093511568 ^ var378;
                     o0KoOo0o0oOK var90 = GUI;
                     String var155 = vhpupplrfs(opfkxuvwcsnmcur(), var378);
                     String var188 = vhpupplrfs(aqtonyqaczgpvvt(), var378);
                     var80 = var90.raw(var155, var188);

                     label168:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                           case 139245045:
                              var378 ^= 1593932440;
                              break label168;
                           case 408828444:
                              break;
                           case 489187434:
                              break label168;
                           case 1288731403:
                           default:
                              throw new IllegalAccessException();
                        }
                     }
                  } else {
                     var378 = 712699960 ^ var378;
                     o0KoOo0o0oOK var79 = GUI;
                     String var146 = vhpupplrfs(rybtjbgcrjgcqfq(), var378);
                     String var183 = vhpupplrfs(mlzmqmykwjsirgp(), var378);
                     var80 = var79.raw(var146, var183);
                     var378 = 162789680 ^ var378;
                  }

                  var378 = 1873588910 ^ var378;
                  o0KoOo0o0oOK var81 = GUI;
                  Inventory var148 = this.inv;
                  String var184 = vhpupplrfs(qamlozraiaefxex(), var378);
                  byte var206 = (byte)(2117505145 ^ var378);
                  o0KoOo0o0oOK var219 = GUI;
                  String var229 = vhpupplrfs(zmahprfbxysycqd(), var378);
                  Material var237 = Material.WHITE_BANNER;
                  String var247 = vhpupplrfs(edukfpgsykkixdd(), var378);
                  String var262 = vhpupplrfs(imthcmsuyrfqwfo(), var378);
                  List var263 = List.of(var262);
                  byte var276 = (byte)(2117505103 ^ var378);
                  Object[] var277 = new Object[var276];
                  byte var307 = (byte)(2117505101 ^ var378);
                  String var341 = vhpupplrfs(libwvhghorydrrg(), var378);
                  var277[var307] = var341;
                  byte var308 = (byte)(2117505100 ^ var378);
                  var277[var308] = var80;
                  ItemStack var220 = var219.item(var229, var237, var247, var263, var277);
                  var81.place(var148, var184, var206, var220);
                  var378 = 1202402890 ^ var378;
                  o0KoOo0o0oOK var83 = GUI;
                  String var149 = vhpupplrfs(qeypvndimzxzsit(), var378);
                  String var185 = vhpupplrfs(zearknbaifjaqie(), var378);
                  String var84 = var83.raw(var149, var185);
                  var378 = 179819047 ^ var378;
                  o0KoOo0o0oOK var85 = GUI;
                  String var150 = vhpupplrfs(hfrewhusdtjsgkc(), var378);
                  String var186 = vhpupplrfs(ambhhqwhcnffbea(), var378);
                  String var86 = var85.raw(var150, var186);
                  var378 = 51699940 ^ var378;
                  var87 = GUI;
                  var152 = this.inv;
                  var187 = vhpupplrfs(trtofqirgezpnmt(), var378);
                  var207 = (byte)(809407722 ^ var378);
                  var221 = GUI;
                  var230 = vhpupplrfs(bbxndtnhoivkxzx(), var378);
                  var238 = Material.HOPPER;
                  var248 = vhpupplrfs(gfbyojezwizfavz(), var378);
                  String var264 = vhpupplrfs(qpnaevsnrpfccls(), var378);
                  String var278 = vhpupplrfs(vdfzqsptqekyvty(), var378);
                  String var287 = vhpupplrfs(ndnhjsovkrepqvm(), var378);
                  String var309 = vhpupplrfs(paqsjvflbmafocu(), var378);
                  String var343 = vhpupplrfs(tlzqiosykocyaqj(), var378);
                  var378 = 872604305 ^ var378;
                  var265 = List.of(var264, var278, var287, var309, var343);
                  byte var279 = (byte)(71071327 ^ var378);
                  var280 = new Object[var279];
                  byte var310 = (byte)(71071317 ^ var378);
                  String var344 = vhpupplrfs(tzpviscbquqjsgz(), var378);
                  var280[var310] = var344;
                  byte var311 = (byte)(71071316 ^ var378);
                  var378 = 1022313192 ^ var378;
                  TeamMenu.K var346 = this.sortType;
                  TeamMenu.K var13 = TeamMenu.K.JOIN_DATE;
                  String var361;
                  if (var346 == var13) {
                     var378 = 1732272450 ^ var378;
                     var361 = var84;
                     var378 = doiknbyxvpnlzzvj(var378, 1352255031);
                  } else {
                     var378 = doiknbyxvpnlzzvj(var378, 1414788408);
                     var361 = var86;
                     var378 = 1670009421 ^ var378;
                  }

                  var280[var311] = var361;
                  byte var312 = (byte)(252351434 ^ var378);
                  String var347 = vhpupplrfs(cyagcrmkttxofzm(), var378);
                  var280[var312] = var347;
                  byte var313 = (byte)(252351435 ^ var378);
                  var378 = 134667970 ^ var378;
                  TeamMenu.K var349 = this.sortType;
                  TeamMenu.K var364 = TeamMenu.K.PERMISSIONS;
                  String var363;
                  if (var349 == var364) {
                     var378 = 219476399 ^ var378;
                     var363 = var84;
                     var378 = 1015179367 ^ var378;
                  } else {
                     label155:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                           case 110858037:
                              var378 ^= 1448400628;
                           case 529257922:
                              break label155;
                           case 880606389:
                           default:
                              throw new IllegalAccessException();
                           case 1093925466:
                        }
                     }

                     var363 = var86;
                     var378 = 1740787516 ^ var378;
                  }

                  var280[var313] = var363;
                  byte var314 = (byte)(916116678 ^ var378);
                  String var350 = vhpupplrfs(omkszfrwfsxqkxq(), var378);
                  var280[var314] = var350;
                  byte var315 = (byte)(916116679 ^ var378);
                  var378 = 104086139 ^ var378;
                  TeamMenu.K var352 = this.sortType;
                  TeamMenu.K var365 = TeamMenu.K.MONEY;
                  String var360;
                  if (var352 == var365) {
                     var378 = 148745236 ^ var378;
                     var360 = var84;

                     label143:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                           case 224356700:
                              var378 ^= 194691223;
                              break label143;
                           case 516054074:
                           default:
                              throw new IllegalAccessException();
                           case 592063741:
                              break label143;
                           case 1674434906:
                        }
                     }
                  } else {
                     label133:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                           case 240311848:
                              var378 ^= 1273508337;
                              break label133;
                           case 492002742:
                           default:
                              throw new IllegalAccessException();
                           case 1173582355:
                              break;
                           case 1388177083:
                              break label133;
                        }
                     }

                     var360 = var86;
                     var378 = 1219452274 ^ var378;
                  }

                  var280[var315] = var360;
                  byte var316 = (byte)(870941244 ^ var378);
                  String var353 = vhpupplrfs(ryecdmavcapfmsa(), var378);
                  var280[var316] = var353;
                  byte var317 = (byte)(870941245 ^ var378);
                  var378 = 430236982 ^ var378;
                  TeamMenu.K var355 = this.sortType;
                  TeamMenu.K var366 = TeamMenu.K.ALPHABETICAL;
                  String var359;
                  if (var355 == var366) {
                     var378 = 2024777034 ^ var378;
                     var359 = var84;
                     var378 = 990763844 ^ var378;
                  } else {
                     var378 = doiknbyxvpnlzzvj(var378, 1002478288);
                     var359 = var86;
                     var378 = 2019747038 ^ var378;
                  }

                  var280[var317] = var359;
                  byte var318 = (byte)(1777277194 ^ var378);
                  String var356 = vhpupplrfs(ogutmvyinhuvkgt(), var378);
                  var280[var318] = var356;
                  var319 = (byte)(1777277195 ^ var378);
                  var378 = 1265928813 ^ var378;
                  TeamMenu.K var358 = this.sortType;
                  TeamMenu.K var367 = TeamMenu.K.ONLINE_FIRST;
                  if (var358 != var367) {
                     var378 = doiknbyxvpnlzzvj(var378, 1521820508);
                     var362 = var86;
                     var378 = 908302650 ^ var378;
                     break label272;
                  }

                  var378 = 239541886 ^ var378;
                  var362 = var84;

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                        case 116096396:
                           var378 ^= 1657906200;
                           break label272;
                        case 337114490:
                           break;
                        case 650996681:
                           break label272;
                        case 2079228394:
                        default:
                           throw new IllegalAccessException();
                     }
                  }
               }

               var378 = 1853582490 ^ var378;
               int var93 = var369 + var20;
               var378 = 1451088642 ^ var378;
               if (var93 >= var18) {
                  var378 = doiknbyxvpnlzzvj(var378, 698343944);
                  if (var19 != (1689107492 ^ var378)) {
                     var378 = 1555243416 ^ var378;
                     Inventory var124 = this.inv;
                     Object var171 = var15.get(var20);
                     Integer var172 = (Integer)var171;
                     int var173 = var172;
                     o0KoOo0o0oOK var200 = GUI;
                     String var209 = vhpupplrfs(anfhpjnptfsxllz(), var378);
                     Material var224 = Material.GRAY_STAINED_GLASS_PANE;
                     String var232 = vhpupplrfs(qkvezvwuehtbkhv(), var378);
                     String var241 = vhpupplrfs(izpzrrpncncfirn(), var378);
                     List var242 = List.of(var241);
                     byte var251 = (byte)(941530556 ^ var378);
                     Object[] var252 = new Object[var251];
                     ItemStack var201 = var200.item(var209, var224, var232, var242, var252);
                     var124.setItem(var173, var201);
                     var378 = 1456726127 ^ var378;
                  } else {
                     var378 = doiknbyxvpnlzzvj(var378, 174113271);
                  }
               } else {
                  UUID var97;
                  OfflinePlayer var99;
                  byte var104;
                  label280: {
                     var378 = 808551352 ^ var378;
                     Object var96 = var368.get(var93);
                     var97 = (UUID)var96;
                     var378 = 1645379023 ^ var378;
                     var99 = Bukkit.getOfflinePlayer(var97);
                     var378 = 16550820 ^ var378;
                     byte var101 = var99.isOnline();
                     if (var101 == (535636991 ^ var378)) {
                        var378 = 1863173989 ^ var378;
                        Player var103 = Bukkit.getPlayer(var97);
                        if (var103 == null) {
                           var378 = 66165872 ^ var378;
                           var104 = (byte)(1930522858 ^ var378);
                           var378 = 1599068923 ^ var378;
                           break label280;
                        }

                        var378 = 1009417588 ^ var378;
                     } else {
                        var378 = 1395112465 ^ var378;
                     }

                     var104 = (byte)(1288344047 ^ var378);

                     label231:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                           case 80230007:
                              var378 ^= 1620327423;
                              break label231;
                           case 249235109:
                           default:
                              throw new IllegalAccessException();
                           case 649571002:
                              break label231;
                           case 1931752408:
                        }
                     }
                  }

                  var378 = 773133980 ^ var378;
                  Material var190 = Material.PLAYER_HEAD;
                  ItemStack var105 = new ItemStack(var190);
                  var378 = 360270615 ^ var378;
                  ItemMeta var107 = var105.getItemMeta();
                  SkullMeta var108 = (SkullMeta)var107;
                  var378 = 296511361 ^ var378;
                  o0oOKo0oOK var109 = o0oOKo0oOK.getInstance();
                  var109.apply(var108, var97);
                  var378 = 105347539 ^ var378;
                  var105.setItemMeta(var108);
                  var378 = 881801308 ^ var378;
                  String var114;
                  if (var104 != (878104980 ^ var378)) {
                     var378 = 1332826643 ^ var378;
                     o0KoOo0o0oOK var113 = GUI;
                     String var162 = vhpupplrfs(bbwxyjltapiqnsf(), var378);
                     String var192 = vhpupplrfs(nvwjglpcjcrptcv(), var378);
                     var114 = var113.raw(var162, var192);

                     label219:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                           case 167729953:
                              break label219;
                           case 245167602:
                              var378 ^= 526483611;
                              break label219;
                           case 458682831:
                              break;
                           case 1999365909:
                           default:
                              throw new IllegalAccessException();
                        }
                     }
                  } else {
                     var378 = doiknbyxvpnlzzvj(var378, 814505037);
                     o0KoOo0o0oOK var121 = GUI;
                     String var169 = vhpupplrfs(yzqfncdxdhoejix(), var378);
                     String var198 = vhpupplrfs(wiunqypeceocgmn(), var378);
                     var114 = var121.raw(var169, var198);
                     var378 = 1620872901 ^ var378;
                  }

                  var378 = 1461734476 ^ var378;
                  String var120;
                  if (var104 != (862342992 ^ var378)) {
                     var378 = 2084091163 ^ var378;
                     o0KoOo0o0oOK var116 = GUI;
                     String var163 = vhpupplrfs(fdhwnmteneypugk(), var378);
                     String var193 = vhpupplrfs(etnkjqsbakwffwz(), var378);
                     var120 = var116.raw(var163, var193);
                     var378 = 1894879569 ^ var378;
                  } else {
                     label207:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                           case 60164813:
                              var378 ^= 893874556;
                           case 143403672:
                              break label207;
                           case 1012947482:
                              break;
                           case 1080982496:
                           default:
                              throw new IllegalAccessException();
                        }
                     }

                     o0KoOo0o0oOK var119 = GUI;
                     String var168 = vhpupplrfs(kdlhljoqoogdpgf(), var378);
                     String var197 = vhpupplrfs(fabtncvrxqtexxq(), var378);
                     var120 = var119.raw(var168, var197);
                     var378 = 965629238 ^ var378;
                  }

                  var378 = 1278883143 ^ var378;
                  Inventory var118 = this.inv;
                  Object var165 = var15.get(var20);
                  Integer var166 = (Integer)var165;
                  int var167 = var166;
                  o0KoOo0o0oOK var195 = GUI;
                  String var223 = vhpupplrfs(jirtqujqnqvkxyb(), var378);
                  String var231 = vhpupplrfs(kiuhgavxgwhmbjv(), var378);
                  String var239 = vhpupplrfs(lptjbsbexiwzppx(), var378);
                  List var240 = List.of(var239);
                  byte var249 = (byte)(1939168859 ^ var378);
                  Object[] var250 = new Object[var249];
                  byte var281 = (byte)(1939168861 ^ var378);
                  String var288 = vhpupplrfs(ldadfmpyqgewshm(), var378);
                  var250[var281] = var288;
                  byte var282 = (byte)(1939168860 ^ var378);
                  var250[var282] = var114;
                  byte var283 = (byte)(1939168863 ^ var378);
                  String var290 = vhpupplrfs(urbxdkaejmlykob(), var378);
                  var250[var283] = var290;
                  byte var284 = (byte)(1939168862 ^ var378);
                  var250[var284] = var120;
                  byte var285 = (byte)(1939168857 ^ var378);
                  String var292 = vhpupplrfs(kghgzzczmhbovmd(), var378);
                  var250[var285] = var292;
                  byte var286 = (byte)(1939168856 ^ var378);
                  var378 = 1495765601 ^ var378;
                  String var294 = var99.getName();
                  String var295 = String.valueOf(var294);
                  var250[var286] = var295;
                  var378 = 1245415118 ^ var378;
                  ItemStack var196 = var195.apply(var105, var223, var231, var240, var250);
                  var118.setItem(var167, var196);
                  var378 = 162067885 ^ var378;
                  var378 = doiknbyxvpnlzzvj(var378, 132956812);
               }

               var20 += 1858960850 ^ var378;

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var378)) {
                     case 112086277:
                        var378 ^= 469341287;
                        continue label256;
                     case 350173872:
                        break;
                     case 1681771746:
                        continue label256;
                     case 2104026553:
                     default:
                        throw new IllegalAccessException();
                  }
               }
            }
         }
      }

      var280[var319] = var362;
      var378 = 1561289041 ^ var378;
      ItemStack var222 = var221.item(var230, var238, var248, var265, var280);
      var87.place(var152, var187, var207, var222);
      var378 = 1141123911 ^ var378;
      o0KoOo0o0oOK var89 = GUI;
      Inventory var154 = this.inv;
      var89.fill(var154);
      var378 = 1909505280 ^ var378;
   }

   private List<UUID> getSortedMembers() {
      int var11 = 1688859227 ^ 571031380 ^ 1017777565;
      var11 = 529401956 ^ var11;
      TeamService var3 = this.team;
      Set var4 = var3.getMembers();
      Stream var5 = var4.stream();
      Comparator var8 = (var1, var2) -> {
         double var46;
         double var48;
         int var74;
         label89: {
            OfflinePlayer var12;
            OfflinePlayer var14;
            var74 = 197513371 ^ 1354518165 ^ 1017777565;
            var74 = 236063249 ^ var74;
            var12 = Bukkit.getOfflinePlayer(var1);
            var74 = 857405054 ^ var74;
            var14 = Bukkit.getOfflinePlayer(var2);
            var74 = 1797390896 ^ var74;
            int[] var15 = null.$SwitchMap$org$mz$donutsmpcore$teams$TeamGUI$SortType;
            TeamMenu.K var50 = this.sortType;
            int var51 = var50.ordinal();
            int var16 = var15[var51];
            label53:
            switch (var16) {
               case 1:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var74)) {
                        case 13858114:
                           var74 = 515718523 ^ var74;
                        case 295218774:
                           break label53;
                        case 1122083251:
                           break;
                        case 1326387648:
                        default:
                           throw new IOException();
                     }
                  }
               case 2:
                  var74 = doiknbyxvpnlzzvj(var74, 291206114);
                  String var18 = var12.getName();
                  String var26;
                  if (var18 != null) {
                     var74 = 420667693 ^ var74;
                     var26 = var12.getName();
                     var74 = 1588694870 ^ var74;
                  } else {
                     var74 = doiknbyxvpnlzzvj(var74, 186715035);
                     var26 = vhpupplrfs(gauugmhirmpjmsy(), var74);
                     var74 = 1283614176 ^ var74;
                  }

                  var74 = 469055836 ^ var74;
                  String var20 = var14.getName();
                  String var24;
                  if (var20 != null) {
                     var74 = 714291820 ^ var74;
                     var24 = var14.getName();
                     var74 = doiknbyxvpnlzzvj(var74, 891788826);
                  } else {
                     var74 = doiknbyxvpnlzzvj(var74, 2036708949);
                     var24 = vhpupplrfs(nwlrjdazbyrebwb(), var74);
                     var74 = 1724977699 ^ var74;
                  }

                  var74 = 1448546419 ^ var74;
                  int var22 = var26.compareToIgnoreCase(var24);
                  return var22;
               case 3:
                  var74 = 489243526 ^ var74;
                  DonutSMPCore var35 = DonutSMPCore.getInstance();
                  Economy var36 = var35.getEconomy();
                  if (var36 != null) {
                     var74 = 962084522 ^ var74;
                     DonutSMPCore var37 = DonutSMPCore.getInstance();
                     Economy var38 = var37.getEconomy();
                     var48 = var38.getBalance(var12);
                     var74 = 1972404885 ^ var74;
                  } else {
                     var74 = 1409032775 ^ var74;
                     var48 = (double)0.0F;
                     var74 = 523542136 ^ var74;
                  }

                  var74 = 955292338 ^ var74;
                  DonutSMPCore var39 = DonutSMPCore.getInstance();
                  Economy var40 = var39.getEconomy();
                  if (var40 == null) {
                     var74 = doiknbyxvpnlzzvj(var74, 1475487048);
                     var46 = (double)0.0F;
                     var74 = 1410053475 ^ var74;
                     break label89;
                  }

                  var74 = 285186616 ^ var74;
                  DonutSMPCore var41 = DonutSMPCore.getInstance();
                  Economy var42 = var41.getEconomy();
                  var46 = var42.getBalance(var14);

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var74)) {
                        case 144860716:
                        default:
                           throw new IOException();
                        case 195945689:
                           var74 ^= 319162899;
                           break label89;
                        case 1775362146:
                           break;
                        case 2058075019:
                           break label89;
                     }
                  }
               case 4:
                  var74 = 1550666375 ^ var74;
                  byte var30 = (byte)(1838425931 ^ var74);
                  return var30;
               default:
                  var74 = 1122267884 ^ var74;
                  long var32 = var1.getMostSignificantBits();
                  long var57 = var2.getMostSignificantBits();
                  int var34 = Long.compare(var32, var57);
                  return var34;
            }

            boolean var28 = var14.isOnline();
            boolean var54 = var12.isOnline();
            int var29 = Boolean.compare(var28, var54);
            return var29;
         }

         var74 = 646576666 ^ var74;
         int var45 = Double.compare(var46, var48);
         return var45;
      };
      Stream var6 = var5.sorted(var8);
      var11 = 1128713406 ^ var11;
      List var7 = var6.toList();
      var11 = 1732144266 ^ var11;
      return var7;
   }

   public void onClick(InventoryClickEvent var1) {
      int var35 = 428996548 ^ 101243904 ^ 1017777565;
      var35 = 1594090981 ^ var35;
      byte var3 = (byte)(2083570621 ^ var35);
      var1.setCancelled((boolean)var3);
      var35 = 868620636 ^ var35;
      byte var10 = this.isMember;
      if (var10 != (1341577952 ^ var35)) {
         var35 = 1238358885 ^ var35;
         Player var16 = this.viewer;
         KKo0KoOoOK.click(var16);
         var35 = 1356621282 ^ var35;
         KKoOoOo0oOK var17 = KKoOoOo0oOK.getInstance();
         Player var22 = this.viewer;
         Runnable var25 = () -> {
            int var6 = 475960903 ^ 2140069652 ^ 1017777565;
            var6 = 2039541910 ^ var6;
            Player var3 = this.viewer;
            TeamMenu var1 = new TeamMenu(var3);
            var1.open();
         };
         var17.runAtEntity(var22, var25);
         var35 = 1595620801 ^ var35;
      } else {
         var35 = 467545709 ^ var35;
         Player var12 = this.viewer;
         o0KoOo0o0oOK var18 = GUI;
         String var4 = vhpupplrfs(vbezgxhcemqficf(), var35);
         String var5 = vhpupplrfs(cxmnfytwfjzyolt(), var35);
         byte var6 = (byte)(1411970191 ^ var35);
         Object[] var27 = new Object[var6];
         byte var7 = (byte)(1411970189 ^ var35);
         String var8 = vhpupplrfs(xebjfzwrvjmzyvy(), var35);
         var27[var7] = var8;
         byte var29 = (byte)(1411970188 ^ var35);
         TeamService var31 = this.team;
         String var32 = var31.getDisplayName();
         var27[var29] = var32;
         String var19 = var18.msg(var4, var5, var27);
         oOo0KKoOoOK.sendActionBarAndChat(var12, var19);
         var35 = 335174699 ^ var35;
         Player var14 = this.viewer;
         String var20 = vhpupplrfs(obxfceplmbfxszy(), var35);
         Sound var23 = Sound.ENTITY_VILLAGER_NO;
         float var26 = 1.0F;
         float var28 = 1.0F;
         KKo0KoOoOK.play(var14, var20, var23, var26, var28);
         var35 = 639210555 ^ var35;
      }
   }

   public void open() {
      int var12 = 511043361 ^ 1611484704 ^ 1017777565;
      var12 = 1315373247 ^ var12;
      Player var4 = this.viewer;
      Inventory var7 = this.createInventory();
      var4.openInventory(var7);
      var12 = 1010215065 ^ var12;
      oOoOKo0o0K var6 = oOoOKo0o0K.getInstance();
      Inventory var9 = this.inv;
      var6.register(var9, this);
      var12 = 896063052 ^ var12;
   }

   static {
      int var9 = 1895239860 ^ 1948165655 ^ Integer.parseInt("99165147");
      qxgrdcvybp = ByteBuffer.wrap(osyrfbxqlgjcekg()).asCharBuffer().toString();
      var9 = 1280020552 ^ var9;
      String var0 = vhpupplrfs(eeckqsqmvftnseo(), var9);
      o0KoOo0o0oOK var2 = o0KoOo0o0oOK.of(var0);
      GUI = var2;
      var9 = 867713070 ^ var9;
      byte var3 = (byte)(2129872158 ^ var9);
      byte var1 = (byte)(2129872179 ^ var9);
      IntStream var4 = IntStream.range(var3, var1);
      Stream var5 = var4.boxed();
      List var6 = var5.toList();
      DEFAULT_CONTENT = var6;
   }

   public static String vhpupplrfs(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = qxgrdcvybp;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] eeckqsqmvftnseo() {
      return new byte[]{0, 0, 0, 22, 0, 0, 0, 0};
   }

   private static byte[] nwlrjdazbyrebwb() {
      return new byte[]{0, 0, 0, 0, 0, 0, 0, 22};
   }

   private static byte[] gauugmhirmpjmsy() {
      return new byte[]{0, 0, 0, 0, 0, 0, 0, 22};
   }

   private static byte[] vhmysimmniscjrm() {
      return new byte[]{0, 0, 0, 30, 0, 0, 0, 22};
   }

   private static byte[] qfxmjeeikgveogi() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, 52};
   }

   private static byte[] jqlmlgtntpuwpbs() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, 58};
   }

   private static byte[] ymczlznrlwajahd() {
      return new byte[]{0, 0, 0, 21, 0, 0, 0, 64};
   }

   private static byte[] ogutmvyinhuvkgt() {
      return new byte[]{0, 0, 0, 14, 0, 0, 0, 85};
   }

   private static byte[] tgvfwkoyurliuts() {
      return new byte[]{0, 0, 0, 4, 0, 0, 0, 99};
   }

   private static byte[] xqxahdromlhlplr() {
      return new byte[]{0, 0, 0, 4, 0, 0, 0, 103};
   }

   private static byte[] hkhavldubtknwyv() {
      return new byte[]{0, 0, 0, 11, 0, 0, 0, 107};
   }

   private static byte[] wsqdjajhekcvamo() {
      return new byte[]{0, 0, 0, 11, 0, 0, 0, 118};
   }

   private static byte[] wsmkkiciaorryqp() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -127};
   }

   private static byte[] cceycrzjtogslbn() {
      return new byte[]{0, 0, 0, 19, 0, 0, 0, -121};
   }

   private static byte[] gvtxrxqesbartwm() {
      return new byte[]{0, 0, 0, 12, 0, 0, 0, -102};
   }

   private static byte[] anfhpjnptfsxllz() {
      return new byte[]{0, 0, 0, 5, 0, 0, 0, -90};
   }

   private static byte[] qkvezvwuehtbkhv() {
      return new byte[]{0, 0, 0, 13, 0, 0, 0, -85};
   }

   private static byte[] izpzrrpncncfirn() {
      return new byte[]{0, 0, 0, 20, 0, 0, 0, -72};
   }

   private static byte[] pcvermwtjiimblb() {
      return new byte[]{0, 0, 0, 5, 0, 0, 0, -52};
   }

   private static byte[] qamlozraiaefxex() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, -47};
   }

   private static byte[] zmahprfbxysycqd() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, -38};
   }

   private static byte[] edukfpgsykkixdd() {
      return new byte[]{0, 0, 0, 16, 0, 0, 0, -29};
   }

   private static byte[] imthcmsuyrfqwfo() {
      return new byte[]{0, 0, 0, 13, 0, 0, 0, -13};
   }

   private static byte[] libwvhghorydrrg() {
      return new byte[]{0, 0, 0, 13, 0, 0, 1, 0};
   }

   private static byte[] lhkqwzhxdjckvct() {
      return new byte[]{0, 0, 0, 13, 0, 0, 1, 13};
   }

   private static byte[] sxqdutfvnjnwihm() {
      return new byte[]{0, 0, 0, 3, 0, 0, 1, 26};
   }

   private static byte[] kbezhophhahdtew() {
      return new byte[]{0, 0, 0, 3, 0, 0, 1, 29};
   }

   private static byte[] josrmpgebxnegim() {
      return new byte[]{0, 0, 0, 10, 0, 0, 1, 32};
   }

   private static byte[] krfuzerjdwcnjzw() {
      return new byte[]{0, 0, 0, 21, 0, 0, 1, 42};
   }

   private static byte[] rjrnyiukisiktls() {
      return new byte[]{0, 0, 0, 8, 0, 0, 1, 63};
   }

   private static byte[] yjfgdfkgixwqdbk() {
      return new byte[]{0, 0, 0, 18, 0, 0, 1, 71};
   }

   private static byte[] ofdjlmueirautnh() {
      return new byte[]{0, 0, 0, 11, 0, 0, 1, 89};
   }

   private static byte[] yzqfncdxdhoejix() {
      return new byte[]{0, 0, 0, 27, 0, 0, 1, 100};
   }

   private static byte[] wiunqypeceocgmn() {
      return new byte[]{0, 0, 0, 7, 0, 0, 1, 127};
   }

   private static byte[] qeypvndimzxzsit() {
      return new byte[]{0, 0, 0, 20, 0, 0, 1, -122};
   }

   private static byte[] zearknbaifjaqie() {
      return new byte[]{0, 0, 0, 7, 0, 0, 1, -102};
   }

   private static byte[] wsdeuawmbxtzsyt() {
      return new byte[]{0, 0, 0, 4, 0, 0, 1, -95};
   }

   private static byte[] polwffqkjdyscwu() {
      return new byte[]{0, 0, 0, 4, 0, 0, 1, -91};
   }

   private static byte[] agcnftrlclajlqj() {
      return new byte[]{0, 0, 0, 18, 0, 0, 1, -87};
   }

   private static byte[] zyuhvldoxvqmjci() {
      return new byte[]{0, 0, 0, 30, 0, 0, 1, -69};
   }

   private static byte[] swxeazanhlfisdz() {
      return new byte[]{0, 0, 0, 29, 0, 0, 1, -39};
   }

   private static byte[] bbwxyjltapiqnsf() {
      return new byte[]{0, 0, 0, 26, 0, 0, 1, -10};
   }

   private static byte[] nvwjglpcjcrptcv() {
      return new byte[]{0, 0, 0, 7, 0, 0, 2, 16};
   }

   private static byte[] rybtjbgcrjgcqfq() {
      return new byte[]{0, 0, 0, 17, 0, 0, 2, 23};
   }

   private static byte[] mlzmqmykwjsirgp() {
      return new byte[]{0, 0, 0, 23, 0, 0, 2, 40};
   }

   private static byte[] opfkxuvwcsnmcur() {
      return new byte[]{0, 0, 0, 15, 0, 0, 2, 63};
   }

   private static byte[] aqtonyqaczgpvvt() {
      return new byte[]{0, 0, 0, 26, 0, 0, 2, 78};
   }

   private static byte[] cyagcrmkttxofzm() {
      return new byte[]{0, 0, 0, 12, 0, 0, 2, 104};
   }

   private static byte[] trtofqirgezpnmt() {
      return new byte[]{0, 0, 0, 4, 0, 0, 2, 116};
   }

   private static byte[] bbxndtnhoivkxzx() {
      return new byte[]{0, 0, 0, 4, 0, 0, 2, 120};
   }

   private static byte[] gfbyojezwizfavz() {
      return new byte[]{0, 0, 0, 11, 0, 0, 2, 124};
   }

   private static byte[] qpnaevsnrpfccls() {
      return new byte[]{0, 0, 0, 23, 0, 0, 2, -121};
   }

   private static byte[] vdfzqsptqekyvty() {
      return new byte[]{0, 0, 0, 25, 0, 0, 2, -98};
   }

   private static byte[] ndnhjsovkrepqvm() {
      return new byte[]{0, 0, 0, 20, 0, 0, 2, -73};
   }

   private static byte[] paqsjvflbmafocu() {
      return new byte[]{0, 0, 0, 29, 0, 0, 2, -53};
   }

   private static byte[] tlzqiosykocyaqj() {
      return new byte[]{0, 0, 0, 30, 0, 0, 2, -24};
   }

   private static byte[] ltzbkrdprcvhppv() {
      return new byte[]{0, 0, 0, 4, 0, 0, 3, 6};
   }

   private static byte[] lzozodgzoqtssvm() {
      return new byte[]{0, 0, 0, 4, 0, 0, 3, 10};
   }

   private static byte[] rmperddpghxsyzz() {
      return new byte[]{0, 0, 0, 11, 0, 0, 3, 14};
   }

   private static byte[] bmliizbugusikgd() {
      return new byte[]{0, 0, 0, 15, 0, 0, 3, 25};
   }

   private static byte[] xgpxywjgtgztxih() {
      return new byte[]{0, 0, 0, 6, 0, 0, 3, 40};
   }

   private static byte[] fdhwnmteneypugk() {
      return new byte[]{0, 0, 0, 24, 0, 0, 3, 46};
   }

   private static byte[] etnkjqsbakwffwz() {
      return new byte[]{0, 0, 0, 1, 0, 0, 3, 70};
   }

   private static byte[] nerpijzwonvxotp() {
      return new byte[]{0, 0, 0, 6, 0, 0, 3, 71};
   }

   private static byte[] mjzhypxmcanxhac() {
      return new byte[]{0, 0, 0, 6, 0, 0, 3, 77};
   }

   private static byte[] godzwrikuwlkrln() {
      return new byte[]{0, 0, 0, 13, 0, 0, 3, 83};
   }

   private static byte[] pgbylnikjtcovxf() {
      return new byte[]{0, 0, 0, 17, 0, 0, 3, 96};
   }

   private static byte[] ryecdmavcapfmsa() {
      return new byte[]{0, 0, 0, 13, 0, 0, 3, 113};
   }

   private static byte[] hfrewhusdtjsgkc() {
      return new byte[]{0, 0, 0, 22, 0, 0, 3, 126};
   }

   private static byte[] ambhhqwhcnffbea() {
      return new byte[]{0, 0, 0, 2, 0, 0, 3, -108};
   }

   private static byte[] splauorgxvrdrjk() {
      return new byte[]{0, 0, 0, 1, 0, 0, 3, -106};
   }

   private static byte[] jirtqujqnqvkxyb() {
      return new byte[]{0, 0, 0, 6, 0, 0, 3, -105};
   }

   private static byte[] kiuhgavxgwhmbjv() {
      return new byte[]{0, 0, 0, 41, 0, 0, 3, -99};
   }

   private static byte[] lptjbsbexiwzppx() {
      return new byte[]{0, 0, 0, 27, 0, 0, 3, -58};
   }

   private static byte[] ldadfmpyqgewshm() {
      return new byte[]{0, 0, 0, 14, 0, 0, 3, -31};
   }

   private static byte[] urbxdkaejmlykob() {
      return new byte[]{0, 0, 0, 12, 0, 0, 3, -17};
   }

   private static byte[] kghgzzczmhbovmd() {
      return new byte[]{0, 0, 0, 8, 0, 0, 3, -5};
   }

   private static byte[] gmxwhnglesguxmu() {
      return new byte[]{0, 0, 0, 6, 0, 0, 4, 3};
   }

   private static byte[] rtzbmsuqxdqgehu() {
      return new byte[]{0, 0, 0, 9, 0, 0, 4, 9};
   }

   private static byte[] tzpviscbquqjsgz() {
      return new byte[]{0, 0, 0, 12, 0, 0, 4, 18};
   }

   private static byte[] omkszfrwfsxqkxq() {
      return new byte[]{0, 0, 0, 13, 0, 0, 4, 30};
   }

   private static byte[] kdlhljoqoogdpgf() {
      return new byte[]{0, 0, 0, 25, 0, 0, 4, 43};
   }

   private static byte[] fabtncvrxqtexxq() {
      return new byte[]{0, 0, 0, 1, 0, 0, 4, 68};
   }

   private static byte[] vbezgxhcemqficf() {
      return new byte[]{0, 0, 0, 10, 0, 0, 4, 69};
   }

   private static byte[] cxmnfytwfjzyolt() {
      return new byte[]{0, 0, 0, 34, 0, 0, 4, 79};
   }

   private static byte[] xebjfzwrvjmzyvy() {
      return new byte[]{0, 0, 0, 6, 0, 0, 4, 113};
   }

   private static byte[] obxfceplmbfxszy() {
      return new byte[]{0, 0, 0, 22, 0, 0, 4, 119};
   }

   private static byte[] osyrfbxqlgjcekg() {
      return new byte[]{49, 85, 57, 67, 55, 95, 50, 66, 54, 31, 49, 70, 57, 83, 55, 87, 50, 92, 54, 67, 49, 29, 57, 66, 55, 83, 50, 80, 54, 93, 49, 91, 57, 88, 55, 80, 50, 94, 54, 87, 49, 71, 57, 95, 46, 42, 47, 53, 37, 52, 45, 62, 56, 19, 51, 88, 48, 76, -109, 0, 46, 55, 51, 11, 50, 18, 56, 17, 48, 71, 56, 86, 49, 83, 50, 85, 52, 21, 51, 24, 51, 25, 50, 98, 56, 85, 48, 84, 56, 86, 49, 18, 50, 29, 52, 64, 51, 89, 51, 86, 50, 87, 56, 17, 51, 20, 50, 70, 56, 81, 48, 82, 56, 94, 49, 23, 51, 20, 50, 66, 56, 85, 48, 84, 56, 86, 49, 23, 57, 82, 48, 68, 50, 67, 50, 76, 49, 86, 48, 94, 49, 65, 55, 28, 56, 84, 57, 93, 48, 65, 50, 67, 50, 65, 49, 23, 48, 85, 49, 92, 55, 83, 56, 83, 57, 92, 48, 84, 50, 83, 49, 18, 55, 88, 50, 89, 55, 93, 56, 95, 49, 89, 55, 82, 50, 104, 55, 82, 56, 89, 49, 91, 55, 88, 50, 69, 55, 20, 49, 94, 54, 81, 53, 77, 48, 69, 49, 94, 54, 81, 53, 77, 48, 69, 49, 19, 54, 5, 53, 115, 48, 119, 55, 116, 49, 9, 54, 12, 55, 65, 45, 54, 55, 72, 44, 43, 49, 22, 54, 82, 53, 123, 48, 84, 55, 72, 49, 68, 54, 20, 53, 69, 48, 80, 55, 87, 49, 85, 49, 21, 54, 68, 53, 84, 48, 86, 55, 85, 49, 21, 49, 68, 54, 65, 49, 65, 56, 29, 51, 74, 49, 64, 54, 86, 49, 69, 56, 69, 51, 74, 49, 26, 54, 83, 49, 88, 56, 67, 51, 88, 49, 86, 54, 91, 49, 84, 56, 84, 49, 23, 54, 113, 49, 119, 56, 1, 51, 125, 49, 5, 54, 115, 49, 23, 56, 92, 51, 118, 49, 114, 54, 113, 57, 81, 49, 88, 51, 64, 53, 65, 54, 64, 57, 23, 49, 4, 51, 118, 53, 115, 54, 125, 52, 8, 53, 11, 50, 95, 55, 66, 36, 20, 51, 95, 46, 43, 40, 50, 57, 18, 49, 83, 51, 100, 53, 93, 54, 80, 52, 66, 53, 19, 48, 70, 53, 90, 57, 91, 49, 65, 51, 16, 53, 92, 54, 74, 52, 17, 53, 86, 48, 88, 53, 70, 57, 64, 49, 76, 51, 29, 50, 94, 57, 80, 50, 64, 52, 22, 50, 69, 49, 82, 53, 81, 53, 92, 48, 28, 50, 89, 49, 88, 53, 93, 53, 84, 50, 69, 49, 82, 53, 81, 53, 92, 48, 28, 50, 89, 49, 88, 53, 93, 53, 84, 50, 18, 49, 6, 53, 118, 53, 119, 48, 117, 50, 8, 49, 15, 40, 43, 40, 54, 45, 49, 47, 60, 49, 23, 55, -84, 40, 62, 45, 60, 47, 54, 50, 20, 49, 95, 53, 95, 53, 92, 48, 84, 50, 110, 49, 68, 53, 68, 53, 80, 48, 69, 50, 68, 49, 68, 53, 21, 50, 20, 49, 95, 53, 95, 53, 92, 48, 84, 50, 110, 49, 68, 53, 68, 53, 80, 48, 69, 50, 68, 49, 68, 53, 21, 49, 82, 49, 87, 55, 93, 53, 65, 49, 93, 49, 95, 49, 76, 55, 30, 53, 70, 49, 84, 49, 94, 49, 76, 55, 64, 49, 64, 49, 64, 53, 68, 49, 64, 49, 64, 53, 68, 49, 19, 49, 7, 53, 114, 49, 127, 50, 114, 49, 9, 49, 14, 40, 44, 44, 25, 47, 46, 49, 22, 49, 80, 53, 119, 49, 76, 50, 68, 49, 66, 49, 83, 53, 90, 49, 77, 50, 90, 49, 73, 49, 12, 53, 20, 49, 28, 50, 69, 49, 68, 49, 87, 53, 64, 49, 76, 50, 69, 49, 21, 49, 21, 49, 69, 53, 64, 49, 88, 50, 66, 49, 69, 49, 69, 53, 17, 51, 67, 56, 67, 50, 68, 49, 25, 51, 64, 56, 65, 50, 85, 49, 64, 51, 70, 56, 70, 50, 26, 49, 81, 51, 93, 56, 84, 50, 86, 49, 88, 51, 86, 56, 81, 51, 16, 56, 6, 50, 117, 49, 114, 51, 117, 56, 5, 50, 4, 49, 18, 51, 95, 56, 122, 50, 122, 56, 92, 52, 86, 50, 93, 50, 87, 56, 84, 52, 65, 50, 29, 50, 70, 56, 69, 52, 82, 50, 68, 50, 64, 56, 66, 52, 29, 50, 95, 50, 83, 56, 87, 52, 95, 50, 89, 50, 91, 56, 84, 52, 30, 50, 83, 50, 90, 56, 93, 52, 92, 50, 66, 56, 18, 52, 117, 50, 118, 50, 4, 56, 117, 52, 2, 50, 116, 57, 69, 54, 89, 51, 64, 57, 66, 55, 20, 54, 85, 54, 92, 50, 85, 54, 88, 57, 68, 54, 69, 51, 28, 57, 69, 55, 92, 54, 90, 54, 86, 50, 90, 54, 67, 57, 83, 54, 82, 57, 21, 54, 7, 51, 116, 57, 112, 55, 125, 54, 15, 54, 11, 50, 76, 48, 86, 51, 83, 52, 89, 50, 76, 48, 86, 51, 83, 52, 89, 50, 27, 48, 2, 51, 116, 52, 114, 56, 118, 56, 9, 51, 11, 47, 47, 41, 63, 47, 56, 45, 62, 51, 18, 52, 17, 56, 70, 56, 85, 51, 82, 50, 89, 52, 29, 50, 30, 48, 85, 51, 107, 52, 91, 56, 71, 56, 16, 51, 82, 50, 70, 52, 93, 50, 24, 48, 69, 51, 91, 52, 81, 56, 69, 56, 89, 51, 93, 50, 83, 52, 24, 50, 89, 48, 93, 51, 93, 52, 64, 56, 90, 56, 85, 51, 65, 50, 20, 52, 76, 50, 93, 48, 82, 51, 95, 50, 30, 48, 4, 51, 102, 52, 91, 56, 70, 56, 81, 51, 95, 50, 20, 52, 85, 50, 93, 48, 94, 51, 80, 52, 81, 56, 64, 56, 67, 51, 9, 50, 20, 52, 29, 50, 85, 48, 86, 51, 95, 52, 86, 56, 87, 56, 66, 51, 64, 50, 17, 52, 23, 50, 13, 48, 3, 50, 93, 54, 83, 49, 85, 55, 83, 52, 86, 50, 66, 54, 27, 49, 75, 55, 69, 52, 82, 50, 68, 54, 67, 49, 75, 55, 31, 52, 92, 50, 94, 54, 90, 49, 81, 55, 95, 52, 86, 50, 29, 54, 85, 49, 87, 55, 93, 52, 92, 50, 66, 50, 19, 54, 7, 49, 126, 55, 119, 52, 119, 50, 9, 54, 14, 52, 88, 53, 92, 57, 91, 52, 86, 53, 25, 48, 70, 51, 77, 54, 85, 51, 65, 52, 69, 53, 64, 57, 24, 52, 70, 53, 90, 48, 70, 51, 92, 54, 64, 52, 22, 53, 85, 57, 98, 52, 91, 53, 93, 48, 70, 51, 25, 54, 64, 51, 80, 52, 81, 53, 94, 57, 22, 52, 91, 53, 85, 48, 70, 51, 25, 54, 90, 51, 90, 52, 16, 53, 91, 57, 89, 52, 94, 53, 81, 49, 91, 49, 87, 56, 93, 51, 80, 55, 20, 49, 64, 49, 76, 56, 81, 51, 65, 55, 76, 49, 64, 49, 22, 56, 67, 51, 80, 55, 77, 49, 21, 49, 94, 56, 100, 51, 93, 55, 80, 49, 64, 49, 24, 56, 68, 51, 80, 55, 88, 49, 94, 49, 24, 56, 88, 51, 84, 55, 74, 49, 19, 49, 89, 56, 16, 51, 93, 55, 86, 49, 94, 49, 93, 56, 16, 51, 70, 55, 92, 49, 71, 50, 16, 50, 67, 53, 84, 52, 65, 50, 95, 53, 109, 51, 86, 49, 91, 51, 94, 50, 90, 50, 65, 53, 20, 56, 67, 57, 91, 48, 69, 54, 76, 56, 67, 57, 91, 48, 69, 54, 76, 56, 19, 57, 5, 48, 113, 54, 126, 52, 124, 48, 0, 52, 8, 51, 99, 37, 59, 58, -80, 36, 47, 56, 21, 57, 94, 48, 88, 54, 81, 52, 86, 48, 102, 52, 83, 55, 89, 56, 88, 56, 95, 57, 70, 48, 18, 22, 26, 52, 24, 48, 115, 52, 95, 55, 95, 56, 90, 56, 16, 57, 80, 48, 86, 54, 76, 52, 93, 56, 21, 57, 68, 48, 82, 54, 74, 52, 85, 48, 102, 52, 83, 55, 89, 56, 88, 56, 95, 57, 70, 48, 18, 22, 26, 52, 24, 48, 105, 52, 85, 55, 68, 56, 89, 56, 89, 57, 71, 48, 68, 54, 81, 52, 87, 48, 87, 52, 67, 56, 21, 57, 89, 48, 88, 54, 86, 52, 93, 48, 64, 52, 111, 55, 85, 56, 91, 56, 92, 57, 91, 48, 69, 54, 29, 20, 26, 48, 25, 52, 125, 55, 89, 56, 90, 56, 85, 57, 77, 56, 21, 57, 85, 48, 91, 54, 72, 52, 80, 48, 88, 52, 111, 55, 85, 56, 91, 56, 92, 57, 91, 48, 69, 54, 29, 20, 26, 48, 25, 52, 113, 55, 90, 56, 68, 56, 88, 57, 85, 48, 85, 54, 93, 52, 76, 48, 80, 52, 83, 55, 87, 56, 88, 56, 92, 57, 77, 56, 21, 57, 91, 48, 89, 54, 84, 52, 81, 48, 87, 52, 85, 55, 105, 56, 87, 56, 95, 57, 88, 48, 88, 54, 74, 52, 29, 16, 27, 52, 16, 55, 121, 56, 90, 56, 92, 57, 93, 48, 89, 54, 93, 52, 24, 48, 116, 52, 85, 55, 91, 56, 86, 56, 85, 57, 70, 48, 68, 57, 81, 52, 84, 50, 84, 55, 89, 57, 81, 52, 84, 50, 84, 55, 89, 57, 16, 52, 4, 50, 113, 55, 116, 52, 125, 51, 13, 53, 10, 53, -82, 47, 52, 36, 55, 41, 62, 57, 21, 52, 83, 50, 103, 55, 64, 52, 92, 51, 66, 53, 91, 55, 88, 50, 65, 57, 64, 52, 21, 50, 71, 55, 83, 52, 94, 51, 81, 57, 22, 52, 69, 50, 86, 55, 85, 52, 92, 51, 17, 49, 94, 51, 84, 54, 95, 52, 87, 50, 86, 49, 65, 51, 28, 54, 65, 52, 65, 50, 82, 49, 71, 51, 68, 54, 65, 52, 27, 50, 92, 49, 93, 51, 93, 54, 91, 52, 91, 50, 86, 49, 30, 51, 85, 54, 93, 52, 65, 20, -109, 55, 64, 56, 93, 54, 81, 51, 65, 53, 84, 51, 80, 55, 64, 56, 93, 54, 81, 51, 65, 53, 84, 51, 80, 55, 16, 56, 9, 54, 118, 51, 117, 53, 115, 51, 1, 56, 14, 52, 102, 46, 50, 42, 51, 58, -72, 43, 52, 49, -81, 55, 21, 56, 94, 54, 115, 51, 95, 53, 94, 51, 91, 56, 93, 48, 19, 51, 65, 55, 92, 56, 24, 54, 67, 51, 86, 53, 86, 51, 74, 56, 85, 48, 91, 56, 18, 48, 88, 52, 93, 50, 68, 50, 80, 55, 81, 57, 107, 49, 81, 52, 93, 56, 91, 48, 86, 52, 67, 50, 17, 56, 70, 56, 91, 50, 66, 50, 65, 54, 21, 53, 91, 52, 93, 48, 94, 53, 89, 56, 71, 56, 71, 50, 30, 50, 64, 54, 86, 53, 75, 52, 87, 48, 94, 53, 83, 56, 86, 56, 64, 50, 85, 50, 81, 56, 19, 56, 82, 19, 41, 49, 84, 51, 92, 49, 91, 56, 90, 54, 84, 49, 75, 49, 28, 51, 74, 49, 66, 56, 89, 54, 69, 49, 76, 51, 74, 49, 105, 56, 91, 54, 94, 49, 85, 51, 86, 49, 68, 56, 29, 54, 20, 49, 74, 51, 77, 49, 87, 56, 76, 54, 68, 49, 74, 51, 102, 49, 82, 56, 87, 54, 69, 49, 28, 51, 26, 49, 7, 56, 126, 54, 119, 49, 125, 51, 0, 49, 14, 56, 29, 54, 65, 49, 85, 51, 88, 49, 79, 56, 93, 54, 67, 49, 28, 49, 31, 51, 95, 49, 111, 56, 87, 54, 68, 49, 25, 51, 88, 49, 68, 56, 93, 54, 17, 49, 79, 51, 80, 49, 83, 56, 79, 54, 88, 49, 87, 51, 94, 49, 22, 56, 76, 54, 89, 49, 80, 51, 74, 49, 22, 56, 76, 54, 84, 49, 88, 51, 84, 49, 28, 51, 74, 49, 66, 56, 89, 54, 69, 49, 76, 51, 74, 49, 105, 56, 91, 54, 94, 49, 85, 51, 86, 49, 68, 56, 29, 49, 28, 51, 74, 49, 66, 56, 89, 54, 69, 49, 76, 51, 74, 49, 105, 56, 92, 54, 94, 49, 77, 51, 28, 49, 28, 51, 73, 49, 90, 56, 89, 54, 72, 49, 92, 51, 75, 49, 19, 52, 18, 53, 67, 55, 84, 54, 86, 51, 89, 55, 16, 52, 18, 53, 90, 55, 84, 54, 90, 51, 86, 55, 80, 55, 69, 49, 69, 55, 22, 55, 20, 48, 93, 49, 92, 49, 94, 55, 95, 48, 104, 49, 80, 49, 88, 55, 93, 48, 88, 49, 65, 49, 18, 57, 20, 54, 92, 49, 89, 54, 89, 52, 92, 49, 79, 49, 110, 54, 85, 55, 91, 57, 93, 54, 94, 49, 68, 54, 18, 49, 93, 50, 93, 52, 92, 57, 82, 48, 84, 48, 64, 56, 25, 49, 74, 48, 68, 49, 81, 50, 76, 52, 68, 57, 67, 48, 31, 48, 93, 56, 82, 49, 95, 48, 92, 49, 89, 50, 86, 52, 84, 57, 29, 48, 85, 48, 93, 56, 64, 20, -112, 49, 90, 49, 94, 57, 67, 48, 28, 56, 84, 49, 81, 49, 92, 57, 85, 48, 84, 56, 75, 49, 18, 49, 82, 57, 110, 48, 94, 56, 76, 49, 20, 49, 80, 57, 69, 48, 84, 56, 25, 49, 90, 49, 94, 57, 67, 48, 17, 56, 88, 49, 20, 49, 65, 57, 86, 48, 67, 56, 77, 49, 20, 49, 94, 57, 81, 48, 17, 56, 77, 49, 92, 49, 88, 57, 68, 48, 17, 56, 77, 49, 81, 49, 80, 57, 90, 48, 31, 49, 17, 49, 69, 57, 82, 48, 80, 56, 84, 49, 17, 49, 70, 48, 81, 57, 89, 56, 93, 55, 67, 49, 28, 48, 64, 57, 93, 56, 81, 55, 93, 49, 91, 48, 90, 57, 94, 56, 95, 55, 87, 49, 71, 48, 93, 57, 22, 56, 84, 55, 85, 49, 92, 48, 77};
   }

   private static int doiknbyxvpnlzzvj(int var0, int var1) {
      return var1 ^ var0;
   }
}
