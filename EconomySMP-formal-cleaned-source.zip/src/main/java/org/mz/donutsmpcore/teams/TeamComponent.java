package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import skido.KoOo0KKoOK;
import skido.oOKo0Ko0K;
import skido.oOo0KKoOoOK;
import skido.oOoOo0oOo0K;

public final class TeamComponent {
   private static byte[] mnlrqxpfut;

   private TeamComponent() {
   }

   private static String currentServerId() {
      int var12 = 415999759 ^ 1408261929 ^ 1717039346;
      var12 = 855766995 ^ var12;

      label49: {
         label48: {
            label47: {
               try {
                  KoOo0KKoOK var0 = KoOo0KKoOK.getInstance();
                  String var2 = var0.getServerId();
                  var12 = 1994964871 ^ var12;
                  if (var2 != null) {
                     var12 = 2144669425 ^ var12;
                     byte var5 = var2.isEmpty();
                     if (var5 != (391138929 ^ var12)) {
                        break label47;
                     }

                     var12 = 1449703578 ^ var12;
                     var12 = 729557374 ^ var12;
                     return var2;
                  }
               } catch (Throwable var13) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var12)) {
                     case -1165855864 -> var12 = 2008376480 ^ var12;
                     case -210765768 -> var12 = shuizqborhldonva(var12, 2122896854);
                     case 164083546 -> var12 = 568187962 ^ var12;
                     case 1143604227 -> var12 = 140536401 ^ var12;
                     default -> throw new IOException("Error in hash");
                  }

                  var12 = 2027273954 ^ var12;
                  break label49;
               }

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                     case 176309373:
                        var12 ^= 662750171;
                        break label48;
                     case 271315467:
                     default:
                        throw new RuntimeException();
                     case 431191664:
                        break;
                     case 1614644487:
                        break label48;
                  }
               }
            }

            var12 = 1482018090 ^ var12;
         }

         var12 = shuizqborhldonva(var12, 1463097192);
      }

      String var6 = TeamService.currentServerId();
      return var6;
   }

   public static void run(Player var0, TeamService var1) {
      int var91 = 1439060085 ^ 1717532462 ^ 1717039346;
      var91 = 1289411148 ^ var91;
      if (var1 != null) {
         var91 = 215296386 ^ var91;
         byte var21 = var1.hasTeamHome();
         if (var21 != (364979303 ^ var91)) {
            var91 = 1377534373 ^ var91;
            String var23 = var1.getTeamHomeWorld();
            var91 = 1607623581 ^ var91;
            if (var23 == null) {
               var91 = 1515105016 ^ var91;
               String var3 = pkryvupoxh(nqrdleplymhfvix(), var91);
               oOo0KKoOoOK.sendActionBarAndChat(var0, var3);
               var91 = 1818498970 ^ var91;
               return;
            }

            String var27;
            String var28;
            byte var61;
            label127: {
               var91 = 446345984 ^ var91;
               var27 = var1.getTeamHomeServer();
               var91 = 1355451834 ^ var91;
               var28 = currentServerId();
               var91 = 565854508 ^ var91;
               if (var27 != null) {
                  var91 ^= 1896644974;
                  if (var28 != null) {
                     var91 = 752610346 ^ var91;
                     byte var32 = var27.equals(var28);
                     if (var32 == (775279757 ^ var91)) {
                        var91 = 1413346447 ^ var91;
                        var61 = (byte)(2047352835 ^ var91);

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var91)) {
                              case 208651275:
                                 var91 ^= 1540237363;
                                 break label127;
                              case 480499632:
                                 break;
                              case 1133270402:
                              default:
                                 throw new IOException();
                              case 1181588315:
                                 break label127;
                           }
                        }
                     }

                     var91 = 886462663 ^ var91;
                  } else {
                     label115:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var91)) {
                           case 46094322:
                              var91 ^= 403551469;
                              break label115;
                           case 739059702:
                           default:
                              throw new IOException();
                           case 1064337005:
                              break;
                           case 1729891056:
                              break label115;
                        }
                     }
                  }
               } else {
                  label125:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var91)) {
                        case 8860695:
                           var91 ^= 1761686915;
                           break label125;
                        case 695650033:
                        default:
                           throw new IOException();
                        case 1675504790:
                           break label125;
                        case 1974817217:
                     }
                  }
               }

               var61 = (byte)(451120202 ^ var91);
               var91 = 992314491 ^ var91;
            }

            var91 = 405733836 ^ var91;
            if (var61 == (971573757 ^ var91)) {
               var91 = 79354018 ^ var91;
               Location var35 = var1.getTeamHome();
               var91 = 31284014 ^ var91;
               if (var35 != null) {
                  var91 = 1963377298 ^ var91;
                  World var38 = var35.getWorld();
                  if (var38 != null) {
                     var91 = 715734106 ^ var91;
                     TeamHomeComponent var59 = new TeamHomeComponent(var0, var35);
                     var59.start();
                     var91 = 1951760285 ^ var91;
                     return;
                  }

                  var91 = 863950588 ^ var91;
               } else {
                  var91 = 1182274670 ^ var91;
               }

               World var40 = Bukkit.getWorld(var23);
               var91 = 428992500 ^ var91;
               if (var40 != null) {
                  var91 = 68817469 ^ var91;
                  var91 = 820112052 ^ var91;
                  double var77 = var1.getTeamHomeX();
                  double var80 = var1.getTeamHomeY();
                  double var82 = var1.getTeamHomeZ();
                  var91 = 1265118553 ^ var91;
                  float var84 = var1.getTeamHomeYaw();
                  float var85 = var1.getTeamHomePitch();
                  Location var5 = new Location(var40, var77, var80, var82, var84, var85);
                  TeamHomeComponent var42 = new TeamHomeComponent(var0, var5);
                  var42.start();
                  var91 = 791278440 ^ var91;
                  return;
               }

               var91 = shuizqborhldonva(var91, 226550727);
            } else {
               var91 = shuizqborhldonva(var91, 1460573137);
            }

            oOoOo0oOo0K var86;
            label91: {
               try {
                  oOoOo0oOo0K var43 = oOoOo0oOo0K.getInstance();
                  var86 = var43;
                  var91 = 551954461 ^ var91;
               } catch (Throwable var92) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var91)) {
                     case 2000474467:
                        var91 = 1627746703 ^ var91;
                        var91 = 1998109547 ^ var91;
                        Object var58 = null;
                        var86 = (oOoOo0oOo0K)var58;
                        var91 = 1880850930 ^ var91;
                        break label91;
                     default:
                        throw new RuntimeException("Error in hash");
                  }
               }

               var91 = 1189110539 ^ var91;
            }

            if (var86 == null) {
               var91 = 1016040169 ^ var91;
               String var63 = pkryvupoxh(jcfezjrbrfzidfy(), var91);
               oOo0KKoOoOK.sendActionBarAndChat(var0, var63);
               var91 = 2076107019 ^ var91;
               return;
            }

            label82:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var91)) {
                  case 20286849:
                     var91 ^= 1958569363;
                     break label82;
                  case 934292855:
                  default:
                     throw new IOException();
                  case 1084963586:
                     break label82;
                  case 1218011556:
               }
            }

            String var87 = var27;
            var91 = 1577007342 ^ var91;
            if (var27 == null) {
               var91 = 1744868905 ^ var91;
               String var49 = var86.getServerForWorld(var23);
               var87 = var49;
               var91 = 356228601 ^ var91;
            } else {
               var91 = 2101021648 ^ var91;
            }

            if (var87 != null) {
               var91 = 1616215419 ^ var91;
               byte var52 = var87.equals(var28);
               if (var52 == (1020132076 ^ var91)) {
                  var91 = 2097255974 ^ var91;
                  var91 = 810461376 ^ var91;
                  var91 = 306079556 ^ var91;
                  String var66 = pkryvupoxh(nxleyhxugzahven(), var91);
                  Runnable var71 = () -> {
                     int var29 = 1308786429 ^ 1721202129 ^ 1717039346;
                     var29 = 1735802138 ^ var29;
                     var29 = 1167714464 ^ var29;
                     double var19 = var1.getTeamHomeX();
                     double var21 = var1.getTeamHomeY();
                     double var23x = var1.getTeamHomeZ();
                     var29 = 1332717870 ^ var29;
                     float var25 = var1.getTeamHomeYaw();
                     float var26 = var1.getTeamHomePitch();
                     var29 = 1097421885 ^ var29;
                     byte var15 = var86.teleportToCoords(var0, var23, var19, var21, var23x, var25, var26, var87);
                     var29 = 1939061115 ^ var29;
                     if (var15 == (297298444 ^ var29)) {
                        var29 = 68612060 ^ var29;
                        String var18 = pkryvupoxh(dckgwewbrgjhpsh(), var29);
                        oOo0KKoOoOK.sendActionBarAndChat(var0, var18);
                        var29 = 298631067 ^ var29;
                     } else {
                        var29 = shuizqborhldonva(var29, 366628935);
                     }

                  };
                  oOKo0Ko0K.startThen(var0, var66, var71);
                  var91 = 1872935814 ^ var91;
                  return;
               }

               var91 = 111481817 ^ var91;
            } else {
               var91 = 1727032994 ^ var91;
            }

            String var68 = "#FF5555Your team home is on another server. Set &fworld-servers." + var23 + " &cin config.yml so it can be reached.";
            oOo0KKoOoOK.sendActionBarAndChat(var0, var68);
            var91 = 51073200 ^ var91;
            return;
         }

         var91 = 916944963 ^ var91;
      } else {
         var91 = 980570561 ^ var91;
      }

      String var69 = pkryvupoxh(azuwidmaddmzjzx(), var91);
      oOo0KKoOoOK.sendActionBarAndChat(var0, var69);
      var91 = 1753920869 ^ var91;
   }

   public static String pkryvupoxh(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = mnlrqxpfut;
         byte[] var34 = mnlrqxpfut;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   static {
      mnlrqxpfut = vraxpgwckjlcxwb();
   }

   private static byte[] vraxpgwckjlcxwb() {
      return new byte[]{118, 116, 69, 81, 15, 121, 15, 72, 27, 66, 36, 97, 126, 96, 14, 9, 18, 76, 78, 14, 47, 2, 54, 66, 7, 6, 57, 113, 90, 50, 1, 118, 13, 113, 14, 106, 15, 105, 2, 65, 65, 13, 53, 64, 89, 21, 25, 63, 49, 83, 22, 28, 23, 62, 21, 108, 96, 124, 113, 112, 73, 26, 123, 61, 50, 12, 11, 126, 52, 64, 21, 42, 92, 35, 14, 10, 92, 56, 23, 32, 106, 10, 119, 8, 48, 13};
   }

   private static byte[] nqrdleplymhfvix() {
      return new byte[]{-71, -70, 116, 70, 54, 43, 62, 36, 34, 28, 21, 37, 79, 35, 55, 24, 35, 13, 119, 90, 30, 82, 7, 30, 62, 23, 8, 44, 99, 108, 48, 42, 60, 37, 55, 123, 62, 43, 59, 31, 112, 78, 4, 29, 96, 64, 40, 42, 8, 1, 39, 66, 38, 122, 44, 49, 81, 45, 72, 97, 120, 69, 74, 99, 11, 73, 58, 107, 13, 19, 36, 126, 109, 50, 55, 93, 109, 98, 46, 100, 91, 85, 70, 93, 9, 18};
   }

   private static byte[] azuwidmaddmzjzx() {
      return new byte[]{-67, -78, 118, 78, 62, 42, 55, 35, 43, 24, 29, 39, 71, 35, 62, 17, 32, 8, 123, 82, 28, 90, 7, 31, 63, 20, 9, 32, 99, 110, 56, 34, 61, 58, 60, 122, 58, 62, 49, 23, 112, 73, 13, 82, 105, 72, 32, 109, 8, 20, 38, 65, 37, 46, 32, 52, 83, 101, 64, 40, 113, 71, 75, 101, 11, 90, 50, 111, 4, 11, 39, 127, 105, 110, 61, 29};
   }

   private static byte[] jcfezjrbrfzidfy() {
      return new byte[]{-80, -68, 124, 65, 59, 45, 57, 37, 34, 18, 19, 61, 72, 116, 57, 75, 43, 16, 118, 88, 22, 89, 2, 85, 49, 87, 0, 38, 109, 102, 55, 39, 58, 103, 55, 58, 55, 45, 59, 87, 117, 85, 3, 23, 96, 13, 46, 103, 7, 9, 33, 69, 46, 115, 45, 51, 89, 47, 69, 53, 127, 3, 66, 118, 5, 80, 61, 56, 3, 0, 44, 118, 100, 102, 55, 16, 104, 47, 33, 110, 83, 90, 64, 88, 6, 90, 65, 42, 124, 72, 55, 39, 54, 13, 47, 85, 18, 45, 71, 54, 57, 81, 36, 14, 121, 89, 22, 82, 14, 25, 62, 81, 13, 36, 108, 103, 56, 43, 58, 104, 56, 44, 56, 54, 59, 31, 121, 82, 12, 2, 109, 2, 47, 104, 8, 4, 33, 82, 33, 36};
   }

   private static byte[] nxleyhxugzahven() {
      return new byte[]{-71, -67, 114, 22, 60, 44, 57, 16, 46, 23, 21, 122, 73, 59, 61, 86, 36, 24, 123, 83};
   }

   private static byte[] dckgwewbrgjhpsh() {
      return new byte[]{-69, -67, 118, 64, 58, 35, 63, 36, 45, 30, 18, 39, 73, 39, 55, 25, 39, 14, 125, 93, 28, 84, 3, 22, 55, 19, 15, 42, 108, 110, 54, 46, 52, 36, 59, 124, 60, 40, 49, 25, 116, 70, 5, 25, 111, 66, 47, 44, 6, 5, 47, 67, 34, 125, 38, 54, 83, 47, 68, 105, 121, 65, 77, 97, 4, 75, 60, 107, 13, 18, 32, 121, 111, 53, 61, 91, 105, 110, 39, 96, 92, 87, 65, 95, 7, 22};
   }

   private static int shuizqborhldonva(int var0, int var1) {
      return var0 ^ var1;
   }
}
