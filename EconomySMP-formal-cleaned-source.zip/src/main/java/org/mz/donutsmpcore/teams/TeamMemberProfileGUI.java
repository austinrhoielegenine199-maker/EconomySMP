package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.KKoOoOo0oOK;
import skido.o0KoOo0o0oOK;
import skido.oOoOKo0o0K;

public class TeamMemberProfileGUI implements KKoOK {
   private final Player leader;
   private final UUID targetUuid;
   private final TeamService team;
   private Inventory inv;
   private int kickSlot;
   private int manageSlot;
   private int pvpSlot;
   private int visitHomeSlot;
   private int teamChatSlot;
   private int setHomeSlot;
   private int backSlot;
   private static final o0KoOo0o0oOK GUI;
   private static byte[] phkyyvpgmu;

   public TeamMemberProfileGUI(Player var1, UUID var2, TeamService var3) {
      byte var5 = -1;
      this.kickSlot = var5;
      byte var16 = -1;
      this.manageSlot = var16;
      byte var17 = -1;
      this.pvpSlot = var17;
      byte var18 = -1;
      this.visitHomeSlot = var18;
      byte var19 = -1;
      this.teamChatSlot = var19;
      byte var20 = -1;
      this.setHomeSlot = var20;
      byte var21 = -1;
      this.backSlot = var21;
      this.leader = var1;
      this.targetUuid = var2;
      this.team = var3;
   }

   public Inventory createInventory() {
      int var28 = 1134670964 ^ 599711106 ^ 1868160709;
      var28 = 1203880869 ^ var28;
      UUID var10 = this.targetUuid;
      OfflinePlayer var11 = Bukkit.getOfflinePlayer(var10);
      var28 = 1346964231 ^ var28;
      Object var2 = null;
      InventoryHolder var16 = (InventoryHolder)var2;
      o0KoOo0o0oOK var3 = GUI;
      byte var4 = (byte)(416186250 ^ var28);
      int var18 = var3.size(var4);
      o0KoOo0o0oOK var19 = GUI;
      String var5 = xbxjisrwvm(wxsphodiqkzruzh(), var28);
      byte var6 = (byte)(416186259 ^ var28);
      Object[] var21 = new Object[var6];
      byte var7 = (byte)(416186257 ^ var28);
      String var8 = xbxjisrwvm(izpcquugichabdm(), var28);
      var21[var7] = var8;
      byte var22 = (byte)(416186256 ^ var28);
      String var24 = var11.getName();
      String var25 = String.valueOf(var24);
      var21[var22] = var25;
      String var20 = var19.title(var5, var21);
      Inventory var17 = Bukkit.createInventory(var16, var18, var20);
      this.inv = var17;
      var28 = 1437188218 ^ var28;
      this.decorate();
      var28 = 1830617906 ^ var28;
      Inventory var15 = this.inv;
      return var15;
   }

   public void decorate() {
      String var23;
      byte var38;
      int var222;
      label48: {
         var222 = 174120045 ^ 1339395183 ^ 1868160709;
         var222 = 637305322 ^ var222;
         UUID var19 = this.targetUuid;
         OfflinePlayer var20 = Bukkit.getOfflinePlayer(var19);
         var222 = 1341004961 ^ var222;
         String var22 = var20.getName();
         var23 = String.valueOf(var22);
         var222 = 116594433 ^ var222;
         TeamService var25 = this.team;
         UUID var39 = this.targetUuid;
         byte var26 = var25.canInvite(var39);
         if (var26 != (1175258253 ^ var222)) {
            var222 = 1815634168 ^ var222;
            TeamService var28 = this.team;
            UUID var41 = this.targetUuid;
            byte var29 = var28.canKick(var41);
            if (var29 != (708142197 ^ var222)) {
               var222 = 916150870 ^ var222;
               var38 = (byte)(481181218 ^ var222);

               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var222)) {
                     case 126977229:
                        var222 ^= 1987812315;
                     case 260954358:
                        break label48;
                     case 844668647:
                        break;
                     case 1533284377:
                     default:
                        throw new RuntimeException();
                  }
               }
            }

            label36:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var222)) {
                  case 29841559:
                     var222 ^= 1583077662;
                  case 991366633:
                     break label36;
                  case 1218466700:
                  default:
                     throw new RuntimeException();
                  case 1689371933:
               }
            }
         } else {
            var222 = gliyoxcdglbrkwgo(var222, 845396454);
         }

         var38 = (byte)(1953414507 ^ var222);
         var222 = 515578003 ^ var222;
      }

      var222 = 538296278 ^ var222;
      o0KoOo0o0oOK var42 = GUI;
      Inventory var58 = this.inv;
      String var4 = xbxjisrwvm(byudwcgsbtacakf(), var222);
      byte var5 = (byte)(1254103589 ^ var222);
      o0KoOo0o0oOK var6 = GUI;
      String var7 = xbxjisrwvm(dioqcmdgmvualnp(), var222);
      Material var8 = Material.OAK_DOOR;
      String var9 = xbxjisrwvm(hukqqziyignmhwx(), var222);
      String var10 = xbxjisrwvm(usaikyxpytytvas(), var222);
      var222 = 1642661864 ^ var222;
      List var114 = List.of(var10);
      byte var11 = (byte)(724114884 ^ var222);
      Object[] var127 = new Object[var11];
      byte var12 = (byte)(724114886 ^ var222);
      String var13 = xbxjisrwvm(dfnjijqtfrdoznc(), var222);
      var127[var12] = var13;
      byte var145 = (byte)(724114887 ^ var222);
      var127[var145] = var23;
      ItemStack var83 = var6.item(var7, var8, var9, var114, var127);
      var222 = 460552750 ^ var222;
      int var43 = var42.place(var58, var4, var5, var83);
      this.kickSlot = var43;
      var222 = 2084013653 ^ var222;
      o0KoOo0o0oOK var44 = GUI;
      Inventory var60 = this.inv;
      String var71 = xbxjisrwvm(hfstthxnbzfbwhg(), var222);
      byte var77 = (byte)(1282269617 ^ var222);
      o0KoOo0o0oOK var84 = GUI;
      String var96 = xbxjisrwvm(ozbsrtbyzgebxag(), var222);
      Material var102 = Material.IRON_HELMET;
      String var108 = xbxjisrwvm(qshvcegnfdzwudg(), var222);
      String var115 = xbxjisrwvm(oidqgcbytdjrvui(), var222);
      String var128 = xbxjisrwvm(zumdnbtglwksywr(), var222);
      var222 = 1364865315 ^ var222;
      List var116 = List.of(var115, var128);
      byte var129 = (byte)(490197146 ^ var222);
      Object[] var130 = new Object[var129];
      byte var146 = (byte)(490197150 ^ var222);
      String var169 = xbxjisrwvm(ixoedcmtlfdcoun(), var222);
      var130[var146] = var169;
      byte var147 = (byte)(490197151 ^ var222);
      var130[var147] = var23;
      byte var148 = (byte)(490197148 ^ var222);
      String var171 = xbxjisrwvm(cbvgimiousvtdqe(), var222);
      var130[var148] = var171;
      byte var149 = (byte)(490197149 ^ var222);
      var222 = 532376588 ^ var222;
      String var173 = this.status((boolean)var38);
      var130[var149] = var173;
      var222 = 1478980392 ^ var222;
      ItemStack var85 = var84.item(var96, var102, var108, var116, var130);
      var222 = 1034061273 ^ var222;
      int var45 = var44.place(var60, var71, var77, var85);
      this.manageSlot = var45;
      var222 = 612409463 ^ var222;
      o0KoOo0o0oOK var46 = GUI;
      Inventory var62 = this.inv;
      String var72 = xbxjisrwvm(rvpkvvlrjkxzwyt(), var222);
      byte var78 = (byte)(1133111833 ^ var222);
      o0KoOo0o0oOK var86 = GUI;
      String var97 = xbxjisrwvm(lptukmltqzblcpb(), var222);
      Material var103 = Material.DIAMOND_SWORD;
      String var109 = xbxjisrwvm(yqnfqdshlyifugt(), var222);
      String var117 = xbxjisrwvm(ekwhoxeavpvxste(), var222);
      String var131 = xbxjisrwvm(evjjipeynkrqusr(), var222);
      var222 = 1468313706 ^ var222;
      List var118 = List.of(var117, var131);
      byte var132 = (byte)(336419450 ^ var222);
      Object[] var133 = new Object[var132];
      byte var150 = (byte)(336419454 ^ var222);
      String var174 = xbxjisrwvm(zsgskwwblckagrs(), var222);
      var133[var150] = var174;
      byte var151 = (byte)(336419455 ^ var222);
      var133[var151] = var23;
      byte var152 = (byte)(336419452 ^ var222);
      String var176 = xbxjisrwvm(dafigpaffvpjljo(), var222);
      var133[var152] = var176;
      byte var153 = (byte)(336419453 ^ var222);
      TeamService var197 = this.team;
      UUID var208 = this.targetUuid;
      var222 = 1495575282 ^ var222;
      boolean var198 = var197.canTogglePvP(var208);
      String var178 = this.status(var198);
      var133[var153] = var178;
      var222 = 1099135860 ^ var222;
      ItemStack var87 = var86.item(var97, var103, var109, var118, var133);
      var222 = 852987947 ^ var222;
      int var47 = var46.place(var62, var72, var78, var87);
      this.pvpSlot = var47;
      var222 = 1225823730 ^ var222;
      o0KoOo0o0oOK var48 = GUI;
      Inventory var64 = this.inv;
      String var73 = xbxjisrwvm(theakpkqmwidqoz(), var222);
      byte var79 = (byte)(2003668527 ^ var222);
      o0KoOo0o0oOK var88 = GUI;
      String var98 = xbxjisrwvm(slaaqyplkbdewvu(), var222);
      Material var104 = Material.COMPASS;
      String var110 = xbxjisrwvm(beryrljzhlmmhds(), var222);
      String var119 = xbxjisrwvm(iddjazeqgvooepr(), var222);
      String var134 = xbxjisrwvm(vwkvekmdzsmvocj(), var222);
      var222 = 1398237428 ^ var222;
      List var120 = List.of(var119, var134);
      byte var135 = (byte)(607839953 ^ var222);
      Object[] var136 = new Object[var135];
      byte var154 = (byte)(607839957 ^ var222);
      String var179 = xbxjisrwvm(bzwlnmwhdwadmlu(), var222);
      var136[var154] = var179;
      byte var155 = (byte)(607839956 ^ var222);
      var136[var155] = var23;
      byte var156 = (byte)(607839959 ^ var222);
      String var181 = xbxjisrwvm(eyggqedpnclsfwn(), var222);
      var136[var156] = var181;
      byte var157 = (byte)(607839958 ^ var222);
      TeamService var200 = this.team;
      UUID var210 = this.targetUuid;
      var222 = 1556149646 ^ var222;
      boolean var201 = var200.canVisitHome(var210);
      String var183 = this.status(var201);
      var136[var157] = var183;
      var222 = 1399570868 ^ var222;
      ItemStack var89 = var88.item(var98, var104, var110, var120, var136);
      var222 = 1757335430 ^ var222;
      int var49 = var48.place(var64, var73, var79, var89);
      this.visitHomeSlot = var49;
      var222 = 880614518 ^ var222;
      o0KoOo0o0oOK var50 = GUI;
      Inventory var66 = this.inv;
      String var74 = xbxjisrwvm(jqmqzbilywzxaoj(), var222);
      byte var80 = (byte)(2001862928 ^ var222);
      o0KoOo0o0oOK var90 = GUI;
      String var99 = xbxjisrwvm(cmortxpgmgdwgww(), var222);
      Material var105 = Material.FEATHER;
      String var111 = xbxjisrwvm(vzwwyjwhbdsfrnu(), var222);
      String var121 = xbxjisrwvm(ltohyvtijygvydb(), var222);
      String var137 = xbxjisrwvm(jktbbofpjdjfdoo(), var222);
      var222 = 1618439218 ^ var222;
      List var122 = List.of(var121, var137);
      byte var138 = (byte)(388328745 ^ var222);
      Object[] var139 = new Object[var138];
      byte var158 = (byte)(388328749 ^ var222);
      String var184 = xbxjisrwvm(ichzgmwibqhwggf(), var222);
      var139[var158] = var184;
      byte var159 = (byte)(388328748 ^ var222);
      var139[var159] = var23;
      byte var160 = (byte)(388328751 ^ var222);
      String var186 = xbxjisrwvm(qkoyctdtcixoksi(), var222);
      var139[var160] = var186;
      byte var161 = (byte)(388328750 ^ var222);
      TeamService var203 = this.team;
      UUID var212 = this.targetUuid;
      var222 = 1957312501 ^ var222;
      boolean var204 = var203.isTeamChatEnabled(var212);
      String var188 = this.status(var204);
      var139[var161] = var188;
      var222 = 12812733 ^ var222;
      ItemStack var91 = var90.item(var99, var105, var111, var122, var139);
      var222 = 694790434 ^ var222;
      int var51 = var50.place(var66, var74, var80, var91);
      this.teamChatSlot = var51;
      var222 = 1891151589 ^ var222;
      o0KoOo0o0oOK var52 = GUI;
      Inventory var68 = this.inv;
      String var75 = xbxjisrwvm(ibnxyyodurnyqyb(), var222);
      byte var81 = (byte)(983424168 ^ var222);
      o0KoOo0o0oOK var92 = GUI;
      String var100 = xbxjisrwvm(ekwwjpdreeczehh(), var222);
      Material var106 = Material.WHITE_BANNER;
      String var112 = xbxjisrwvm(xuqspjfqffnuqol(), var222);
      String var123 = xbxjisrwvm(qbyxgkuyhlvoiem(), var222);
      String var140 = xbxjisrwvm(hyxrxpgbzoxpqxb(), var222);
      var222 = 602501365 ^ var222;
      List var124 = List.of(var123, var140);
      byte var141 = (byte)(427076691 ^ var222);
      Object[] var142 = new Object[var141];
      byte var162 = (byte)(427076695 ^ var222);
      String var189 = xbxjisrwvm(pvdfkrmuigyqjwv(), var222);
      var142[var162] = var189;
      byte var163 = (byte)(427076694 ^ var222);
      var142[var163] = var23;
      byte var164 = (byte)(427076693 ^ var222);
      String var191 = xbxjisrwvm(hvveolesohsjcsl(), var222);
      var142[var164] = var191;
      byte var165 = (byte)(427076692 ^ var222);
      TeamService var206 = this.team;
      UUID var214 = this.targetUuid;
      var222 = 1899700383 ^ var222;
      boolean var207 = var206.canSetHome(var214);
      String var193 = this.status(var207);
      var142[var165] = var193;
      var222 = 371850880 ^ var222;
      ItemStack var93 = var92.item(var100, var106, var112, var124, var142);
      var222 = 427529382 ^ var222;
      int var53 = var52.place(var68, var75, var81, var93);
      this.setHomeSlot = var53;
      var222 = 646316375 ^ var222;
      o0KoOo0o0oOK var54 = GUI;
      Inventory var70 = this.inv;
      String var76 = xbxjisrwvm(pifisoxuramjjcj(), var222);
      byte var82 = (byte)(1100736427 ^ var222);
      o0KoOo0o0oOK var94 = GUI;
      String var101 = xbxjisrwvm(fperfldznntdvga(), var222);
      Material var107 = Material.RED_STAINED_GLASS_PANE;
      String var113 = xbxjisrwvm(fwkdlotzicenype(), var222);
      String var125 = xbxjisrwvm(fejwaopepryttes(), var222);
      var222 = 653755366 ^ var222;
      List var126 = List.of(var125);
      byte var143 = (byte)(1735156829 ^ var222);
      Object[] var144 = new Object[var143];
      byte var166 = (byte)(1735156831 ^ var222);
      String var194 = xbxjisrwvm(bqknguepibxgrim(), var222);
      var144[var166] = var194;
      byte var167 = (byte)(1735156830 ^ var222);
      var144[var167] = var23;
      ItemStack var95 = var94.item(var101, var107, var113, var126, var144);
      var222 = 1363956982 ^ var222;
      int var55 = var54.place(var70, var76, var82, var95);
      this.backSlot = var55;
      var222 = 976538560 ^ var222;
      o0KoOo0o0oOK var37 = GUI;
      Inventory var57 = this.inv;
      var37.fill(var57);
      var222 = 1193326929 ^ var222;
   }

   private String status(boolean var1) {
      int var12 = 1722849876 ^ 646592772 ^ 1868160709;
      var12 = 681031383 ^ var12;
      String var7;
      if (var1 != (133483330 ^ var12)) {
         var12 = 476970339 ^ var12;
         o0KoOo0o0oOK var5 = GUI;
         String var3 = xbxjisrwvm(ufofmbmcyiaoxvp(), var12);
         String var4 = xbxjisrwvm(jswndtpppjdfzme(), var12);
         var7 = var5.raw(var3, var4);
         var12 = 910715863 ^ var12;
      } else {
         var12 = 137109109 ^ var12;
         o0KoOo0o0oOK var6 = GUI;
         String var8 = xbxjisrwvm(tyckkehinxejlxa(), var12);
         String var9 = xbxjisrwvm(xaleixeneqqgeuh(), var12);
         var7 = var6.raw(var8, var9);
         var12 = 571050177 ^ var12;
      }

      return var7;
   }

   public void onClick(InventoryClickEvent var1) {
      int var111 = 555396122 ^ 1442516824 ^ 1868160709;
      var111 = 854331789 ^ var111;
      byte var3 = (byte)(693398539 ^ var111);
      var1.setCancelled((boolean)var3);
      var111 = 2072019273 ^ var111;
      int var9 = var1.getRawSlot();
      var111 = 727860798 ^ var111;
      if (var9 < (2042014589 ^ var111)) {
         var111 = 1075233252 ^ var111;
      } else {
         var111 = gliyoxcdglbrkwgo(var111, 1714530474);
         int var57 = this.backSlot;
         if (var9 == var57) {
            var111 = 605733822 ^ var111;
            Player var13 = this.leader;
            KKo0KoOoOK.click(var13);
            var111 = 766723477 ^ var111;
            KKoOoOo0oOK var14 = KKoOoOo0oOK.getInstance();
            Player var59 = this.leader;
            Runnable var94 = () -> {
               int var6 = 1305457015 ^ 565454632 ^ 1868160709;
               var6 = 674013619 ^ var6;
               Player var3 = this.leader;
               TeamMenu var1 = new TeamMenu(var3);
               var1.open();
            };
            var14.runAtEntity(var59, var94);
            var111 = 264404895 ^ var111;
         } else {
            var111 = 1909293560 ^ var111;
            int var61 = this.kickSlot;
            if (var9 == var61) {
               var111 = 1189303164 ^ var111;
               Player var17 = this.leader;
               KKo0KoOoOK.click(var17);
               var111 = 1371435333 ^ var111;
               Player var96 = this.leader;
               UUID var107 = this.targetUuid;
               TeamService var108 = this.team;
               TeamInviteGUI var18 = new TeamInviteGUI(var96, var107, var108);
               var18.open();
               var111 = 1448990255 ^ var111;
            } else {
               var111 = 95146794 ^ var111;
               int var63 = this.manageSlot;
               if (var9 == var63) {
                  var111 = 1062584516 ^ var111;
                  TeamService var49 = this.team;
                  UUID var89 = this.targetUuid;
                  var49.toggleInvitePerm(var89);
                  var111 = 1528641200 ^ var111;
                  TeamService var51 = this.team;
                  UUID var91 = this.targetUuid;
                  var51.toggleKickPerm(var91);
                  var111 = 440953834 ^ var111;
                  TeamService2 var52 = TeamService2.getInstance();
                  TeamService var93 = this.team;
                  UUID var106 = this.targetUuid;
                  var52.savePermissions(var93, var106);
                  var111 = 1684829754 ^ var111;
                  Player var54 = this.leader;
                  KKo0KoOoOK.click(var54);
                  var111 = 131497494 ^ var111;
                  this.decorate();
                  var111 = 380167086 ^ var111;
               } else {
                  var111 = gliyoxcdglbrkwgo(var111, 801277793);
                  int var65 = this.pvpSlot;
                  if (var9 != var65) {
                     var111 = gliyoxcdglbrkwgo(var111, 1892371820);
                     int var71 = this.visitHomeSlot;
                     if (var9 == var71) {
                        var111 = 21391070 ^ var111;
                        TeamService var29 = this.team;
                        UUID var73 = this.targetUuid;
                        var29.toggleVisitHomePerm(var73);
                        var111 = 63050242 ^ var111;
                        TeamService2 var30 = TeamService2.getInstance();
                        TeamService var75 = this.team;
                        UUID var100 = this.targetUuid;
                        var30.savePermissions(var75, var100);
                        var111 = 23791662 ^ var111;
                        Player var32 = this.leader;
                        KKo0KoOoOK.click(var32);
                        var111 = 1738454044 ^ var111;
                        this.decorate();
                        var111 = 812283135 ^ var111;
                     } else {
                        var111 = gliyoxcdglbrkwgo(var111, 220115145);
                        int var77 = this.teamChatSlot;
                        if (var9 == var77) {
                           var111 = 1524718402 ^ var111;
                           TeamService var36 = this.team;
                           UUID var79 = this.targetUuid;
                           var36.toggleTeamChat(var79);
                           var111 = 75303149 ^ var111;
                           TeamService2 var37 = TeamService2.getInstance();
                           TeamService var81 = this.team;
                           UUID var102 = this.targetUuid;
                           var37.savePermissions(var81, var102);
                           var111 = 790314432 ^ var111;
                           Player var39 = this.leader;
                           KKo0KoOoOK.click(var39);
                           var111 = 1253872328 ^ var111;
                           this.decorate();
                           var111 = 1648291967 ^ var111;
                        } else {
                           var111 = gliyoxcdglbrkwgo(var111, 278049595);
                           int var83 = this.setHomeSlot;
                           if (var9 == var83) {
                              var111 = 1513423395 ^ var111;
                              TeamService var43 = this.team;
                              UUID var85 = this.targetUuid;
                              var43.toggleHomePerm(var85);
                              var111 = 1162589237 ^ var111;
                              TeamService2 var44 = TeamService2.getInstance();
                              TeamService var87 = this.team;
                              UUID var104 = this.targetUuid;
                              var44.savePermissions(var87, var104);
                              var111 = 1433600735 ^ var111;
                              Player var46 = this.leader;
                              KKo0KoOoOK.click(var46);
                              var111 = 1850252729 ^ var111;
                              this.decorate();
                              var111 = 1842517651 ^ var111;
                           } else {
                              var111 = gliyoxcdglbrkwgo(var111, 1234681827);
                           }
                        }
                     }
                  } else {
                     var111 = 1450107360 ^ var111;
                     TeamService var22 = this.team;
                     UUID var67 = this.targetUuid;
                     var22.togglePvPPerm(var67);
                     var111 = 1880881494 ^ var111;
                     TeamService2 var23 = TeamService2.getInstance();
                     TeamService var69 = this.team;
                     UUID var98 = this.targetUuid;
                     var23.savePermissions(var69, var98);
                     var111 = 763416548 ^ var111;
                     Player var25 = this.leader;
                     KKo0KoOoOK.click(var25);
                     var111 = 371660795 ^ var111;
                     this.decorate();

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var111)) {
                           case 239289820:
                              var111 = 956445140 ^ var111;
                              return;
                           case 541292033:
                              break;
                           case 897526970:
                           default:
                              throw new RuntimeException();
                           case 1178553722:
                              return;
                        }
                     }
                  }
               }

            }
         }
      }
   }

   public void open() {
      int var12 = 574845278 ^ 2080971432 ^ 1868160709;
      var12 = 732688229 ^ var12;
      Player var4 = this.leader;
      Inventory var7 = this.createInventory();
      var4.openInventory(var7);
      var12 = 392869038 ^ var12;
      oOoOKo0o0K var6 = oOoOKo0o0K.getInstance();
      Inventory var9 = this.inv;
      var6.register(var9, this);
      var12 = 741366419 ^ var12;
   }

   static {
      int var4 = 1246600157 ^ 846188031 ^ Integer.parseInt("1806636107");
      phkyyvpgmu = mfcqtwwdxlrxozm();
      var4 = 1727387734 ^ var4;
      String var0 = xbxjisrwvm(grlspsstpwqyakt(), var4);
      o0KoOo0o0oOK var1 = o0KoOo0o0oOK.of(var0);
      GUI = var1;
   }

   public static String xbxjisrwvm(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = phkyyvpgmu;
         byte[] var34 = phkyyvpgmu;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   private static byte[] mfcqtwwdxlrxozm() {
      return new byte[]{67, 38, 21, 114, 125, 18, 64, 4, 103, 126, 126, 34, 119, 124, 100, 105, 120, 84, 107, 25, 52, 67, 82, 45, 103, 110, 3, 16, 10, 32, 26, 64, 20, 80, 126, 14, 20, 87, 124, 29, 90, 102, 81, 31, 22, 87, 75, 27, 66, 98, 59, 122, 22, 108, 22, 57, 122, 61, 91, 102, 123, 123, 71, 80, 24, 15, 25, 73, 6, 74, 41, 25, 87, 25, 15, 117, 107, 98, 48, 120, 67, 37, 111, 18, 14, 4, 56, 47, 123, 69, 126, 11, 71, 11, 102, 101, 98, 3, 95, 50, 44, 109, 92, 87, 37, 105, 53, 21, 92, 118, 89, 34, 66, 21, 119, 96, 10, 84, 61, 111, 49, 100, 117, 43, 99, 118};
   }

   private static byte[] grlspsstpwqyakt() {
      return new byte[]{-116, -32, 34, 37, 69, 84, 120, 93, 80, 52, 79, 52, 64, 56, 92, 63, 64, 5, 92, 77, 5, 9, 101, 50, 95, 56, 59, 68, 61, 112, 43, 13, 35, 13, 70, 88, 44, 10, 75, 70, 107, 58, 102, 93, 46, 3, 115, 94, 117, 50};
   }

   private static byte[] wxsphodiqkzruzh() {
      return new byte[]{-119, -24, 62, 68, 88, 33, 112, 91, 77, 81, 79, 52, 70, 97, 82, 43, 77, 15, 95, 73, 2, 11, 106, 126, 85, 41, 52, 1};
   }

   private static byte[] izpcquugichabdm() {
      return new byte[]{-119, -24, 35, 102, 69, 84, 114, 93, 80, 43, 79, 109, 70, 33, 82, 41, 77, 70};
   }

   private static byte[] pvdfkrmuigyqjwv() {
      return new byte[]{-119, -21, 34, 103, 74, 84, 118, 81, 82, 43, 76, 108, 71, 46, 82, 45, 65, 68};
   }

   private static byte[] hvveolesohsjcsl() {
      return new byte[]{-119, -21, 34, 103, 74, 87, 118, 73, 82, 43, 76, 97, 71, 62, 82, 44, 65, 68};
   }

   private static byte[] dfnjijqtfrdoznc() {
      return new byte[]{-118, -21, 33, 102, 76, 86, 120, 80, 81, 40, 76, 111, 70, 40, 80, 35, 64, 71};
   }

   private static byte[] pifisoxuramjjcj() {
      return new byte[]{-116, -24, 37, 32, 74, 64, 118, 83, 83, 36};
   }

   private static byte[] fperfldznntdvga() {
      return new byte[]{-116, -24, 37, 32, 74, 64, 118, 83, 83, 36};
   }

   private static byte[] fwkdlotzicenype() {
      return new byte[]{-116, -24, 37, 97, 74, 103, 118, 118, 83, 126, 79, 87, 71, 125, 83, 30, 76, -7, 66, 40, 24, 118, 127, 22};
   }

   private static byte[] fejwaopepryttes() {
      return new byte[]{-116, -24, 37, 100, 74, 71, 118, 115, 83, 35, 79, 122, 71, 47, 83, 49, 78, 64, 95, 92, 5, 29, 98, 61, 80, 47, 53, 65, 62, 101, 43, 4, 36, 18, 73, 83};
   }

   private static byte[] zsgskwwblckagrs() {
      return new byte[]{-114, -22, 35, 99, 76, 91, 116, 93, 83, 44, 77, 109, 67, 40, 93, 47, 77, 69};
   }

   private static byte[] dafigpaffvpjljo() {
      return new byte[]{-114, -22, 35, 99, 76, 88, 116, 69, 83, 44, 77, 96, 67, 56, 93, 46, 77, 69};
   }

   private static byte[] byudwcgsbtacakf() {
      return new byte[]{-116, -21, 32, 45, 76, 75, 115, 82, 94, 45};
   }

   private static byte[] dioqcmdgmvualnp() {
      return new byte[]{-116, -21, 32, 45, 76, 75, 115, 82, 94, 45};
   }

   private static byte[] hukqqziyignmhwx() {
      return new byte[]{-116, -21, 32, 101, 76, 19, 115, 119, 94, 0, 79, 84, 66, 113, 85, 97, 86, 106, 80, 75, 24, 117, 122, 18};
   }

   private static byte[] usaikyxpytytvas() {
      return new byte[]{-116, -21, 32, 96, 76, 68, 115, 114, 94, 42, 79, 121, 66, 43, 85, 50, 75, 65, 82, 85, 5, 30, 103, 57, 86, 53, 48, 76, 51, 123, 43, 25, 33, 68, 79, 27, 39, 18, 69, 73, 107, 53, 100, 82, 39, 2, 120, 92, 123, 127};
   }

   private static byte[] theakpkqmwidqoz() {
      return new byte[]{-113, -23, 37, 55, 75, 77, 120, 66, 86, 36, 76, 102, 71, 98, 82, 55, 64, 14, 90, 71, 6, 22};
   }

   private static byte[] slaaqyplkbdewvu() {
      return new byte[]{-113, -23, 37, 55, 75, 77, 120, 66, 86, 36, 76, 102, 71, 98, 82, 55, 64, 14, 90, 71, 6, 22};
   }

   private static byte[] beryrljzhlmmhds() {
      return new byte[]{-113, -23, 37, 98, 75, 21, 120, 119, 86, 11, 76, 86, 71, 118, 82, 103, 93, 65, 88, 64, 6, 0, 96, 116, 76, 67, 59, 5, 38, 8, 53, 119, 57, 99, 85, 53, 44, 66, 79, -78, 117, 89, 124, 33, 61, 102};
   }

   private static byte[] iddjazeqgvooepr() {
      return new byte[]{-113, -23, 37, 103, 75, 66, 120, 125, 86, 40, 76, 102, 71, 111, 82, 122, 64, 17, 90, 70, 6, 18, 98, 103, 81, 61, 59, 87, 59, 54, 40, 80, 36, 22, 72, 75, 44, 7, 77, 14, 104, 121, 97, 88, 32, 4, 115, 79, 115, 60, 9, 106, 38, 55, 32, 96, 66, 101, 106, 48};
   }

   private static byte[] vwkvekmdzsmvocj() {
      return new byte[]{-113, -23, 37, 103, 75, 66, 120, 114, 86, 56, 76, 96, 71, 61, 82, 58, 64, 15, 90, 94, 6, 31, 98, 103, 81, 120, 59, 0, 59, 96, 40, 4, 36, 2, 72, 76, 44, 23, 77, 93, 104, 115};
   }

   private static byte[] bqknguepibxgrim() {
      return new byte[]{-116, -18, 38, 98, 76, 87, 118, 80, 84, 46, 79, 108, 68, 44, 85, 46, 78, 73};
   }

   private static byte[] rvpkvvlrjkxzwyt() {
      return new byte[]{-116, -24, 38, 53, 76, 76, 113, 91, 85, 33, 79, 127, 68, 42, 85, 117, 73, 28, 89, 87, 5, 2};
   }

   private static byte[] lptukmltqzblcpb() {
      return new byte[]{-116, -24, 38, 53, 76, 76, 113, 91, 85, 33, 79, 127, 68, 42, 85, 117, 73, 28, 89, 87, 5, 2};
   }

   private static byte[] yqnfqdshlyifugt() {
      return new byte[]{-116, -24, 38, 98, 76, 18, 113, 122, 85, 0, 79, 87, 68, 118, 85, 96, 84, 119, 68, 46, 7, 16, 99, 124, 84, -64, 47, 47, 56, 56, 54, 105, 58, 67, 82, 39};
   }

   private static byte[] ekwhoxeavpvxste() {
      return new byte[]{-116, -24, 38, 103, 76, 69, 113, 112, 85, 35, 79, 103, 68, 111, 85, 125, 73, 28, 89, 77, 5, 19, 97, 103, 86, 58, 50, 90, 56, 61, 43, 81, 39, 23, 79, 80, 37, 8, 78, 66, 107, 59, 98, 73, 39, 70, 122, 87, 112, 63, 10, 42, 37, 50, 39, 40, 75, 85, 105, 40, 74, 26};
   }

   private static byte[] evjjipeynkrqusr() {
      return new byte[]{-116, -24, 38, 103, 76, 69, 113, 127, 85, 51, 79, 97, 68, 61, 85, 61, 73, 2, 89, 85, 5, 30, 97, 103, 86, 127, 50, 13, 56, 107, 43, 5, 39, 2, 79, 75, 37, 26, 78, 86, 107, 114};
   }

   private static byte[] ichzgmwibqhwggf() {
      return new byte[]{-114, -31, 45, 100, 79, 90, 119, 92, 94, 44, 70, 99, 68, 43, 92, 44, 76, 72};
   }

   private static byte[] qkoyctdtcixoksi() {
      return new byte[]{-114, -31, 45, 100, 79, 89, 119, 68, 94, 44, 70, 110, 68, 59, 92, 45, 76, 72};
   }

   private static byte[] bzwlnmwhdwadmlu() {
      return new byte[]{-117, -23, 34, 111, 78, 91, 121, 93, 80, 41, 78, 108, 79, 42, 93, 34, 77, 70};
   }

   private static byte[] eyggqedpnclsfwn() {
      return new byte[]{-117, -23, 34, 111, 78, 88, 121, 69, 80, 41, 78, 97, 79, 58, 93, 35, 77, 70};
   }

   private static byte[] ibnxyyodurnyqyb() {
      return new byte[]{-124, -31, 38, 35, 79, 66, 113, 91, 85, 51, 70, 60, 67, 38, 80, 55, 78, 11, 82, 68};
   }

   private static byte[] ekwwjpdreeczehh() {
      return new byte[]{-124, -31, 38, 35, 79, 66, 113, 91, 85, 51, 70, 60, 67, 38, 80, 55, 78, 11, 82, 68};
   }

   private static byte[] xuqspjfqffnuqol() {
      return new byte[]{-124, -31, 38, 101, 79, 23, 113, 116, 85, 1, 70, 85, 67, 119, 80, 96, 83, 97, 79, 36, 5, 29, 125, 2, 86, 120, 51, -75, 47, 28, 51, 127, 61, 102};
   }

   private static byte[] qbyxgkuyhlvoiem() {
      return new byte[]{-124, -31, 38, 96, 79, 64, 113, 126, 85, 34, 70, 101, 67, 110, 80, 125, 78, 22, 82, 77, 7, 22, 96, 96, 86, 61, 49, 91, 50, 54, 46, 82, 32, 18, 72, 89, 45, 27, 79, 6, 104, 32, 96, 76, 36, 3, 115, 71, 118, 38, 15, 46, 32, 126, 47, 117, 73, 108, 105, 51, 74, 32, 117, 73, 32, 84, 45, 20, 50, 22, 31, 78};
   }

   private static byte[] hyxrxpgbzoxpqxb() {
      return new byte[]{-124, -31, 38, 96, 79, 64, 113, 113, 85, 50, 70, 99, 67, 60, 80, 61, 78, 8, 82, 85, 7, 27, 96, 96, 86, 120, 49, 12, 50, 96, 46, 6, 32, 0, 72, 72, 45, 26, 79, 90, 104, 119};
   }

   private static byte[] hfstthxnbzfbwhg() {
      return new byte[]{-116, -21, 45, 45, 79, 69, 121, 92, 85, 38, 79, 119, 79, 43, 86, 114, 65, 22, 89, 69, 5, 16, 106, 114, 85, 53, 58, 71, 56, 109, 43, 23, 44, 17};
   }

   private static byte[] ozbsrtbyzgebxag() {
      return new byte[]{-116, -21, 45, 45, 79, 69, 121, 92, 85, 38, 79, 119, 79, 43, 86, 114, 65, 22, 89, 69, 5, 16, 106, 114, 85, 53, 58, 71, 56, 109, 43, 23, 44, 17};
   }

   private static byte[] qshvcegnfdzwudg() {
      return new byte[]{-116, -21, 45, 99, 79, 21, 121, 116, 85, 1, 79, 84, 79, 119, 86, 103, 92, 111, 68, 32, 7, 5, 119, 31, 87, 58, 39, 33, 56, 57, 54, 105, 49, 101, 81, 56, 48, 108, 83, 41, 118, 84, 116, 54, 57, 102, 118, 120};
   }

   private static byte[] oidqgcbytdjrvui() {
      return new byte[]{-116, -21, 45, 102, 79, 66, 121, 126, 85, 34, 79, 100, 79, 110, 86, 122, 65, 18, 89, 76, 5, 16, 106, 102, 85, 61, 58, 84, 56, 60, 43, 82, 44, 11, 76, 86, 45, 23, 78, 77, 107, 32, 105, 72, 36, 65, 114, 76, 112, 53, 10, 44, 46, 126, 36, 100, 67, 98, 105, 60, 74, 34};
   }

   private static byte[] zumdnbtglwksywr() {
      return new byte[]{-116, -21, 45, 102, 79, 66, 121, 113, 85, 50, 79, 98, 79, 60, 86, 58, 65, 12, 89, 84, 5, 29, 106, 102, 85, 120, 58, 3, 56, 106, 43, 6, 44, 3, 76, 76, 45, 20, 78, 87, 107, 113};
   }

   private static byte[] ixoedcmtlfdcoun() {
      return new byte[]{-119, -32, 37, 102, 68, 85, 113, 93, 87, 43, 71, 107, 70, 32, 83, 42, 77, 65};
   }

   private static byte[] cbvgimiousvtdqe() {
      return new byte[]{-119, -32, 37, 102, 68, 86, 113, 69, 87, 43, 71, 102, 70, 48, 83, 43, 77, 65};
   }

   private static byte[] jqmqzbilywzxaoj() {
      return new byte[]{-113, -23, 37, 55, 69, 65, 114, 92, 83, 32, 76, 63, 71, 46, 92, 55, 74, 12, 95, 94};
   }

   private static byte[] cmortxpgmgdwgww() {
      return new byte[]{-113, -23, 37, 55, 69, 65, 114, 92, 83, 32, 76, 63, 71, 46, 92, 55, 74, 12, 95, 94};
   }

   private static byte[] vzwwyjwhbdsfrnu() {
      return new byte[]{-113, -23, 37, 96, 69, 21, 114, 123, 83, 11, 76, 86, 71, 116, 92, 103, 87, 118, 66, 45, 27, 115, 127, 17, 95, 120, 44, 45, 60, -113, 53, 112, 57, 122};
   }

   private static byte[] ltohyvtijygvydb() {
      return new byte[]{-113, -23, 37, 101, 69, 66, 114, 113, 83, 40, 76, 102, 71, 109, 92, 122, 74, 29, 95, 70, 6, 18, 98, 101, 95, 61, 49, 91, 62, 54, 40, 80, 36, 18, 70, 72, 38, 11, 72, 79, 104, 61, 97, 14, 46, 8, 121, 76, 118, 113, 9, 62, 38, 56, 46, 110, 72, 105, 111, 117, 73, 40, 119, 9, 32, 88, 43, 4};
   }

   private static byte[] jktbbofpjdjfdoo() {
      return new byte[]{-113, -23, 37, 101, 69, 66, 114, 126, 83, 56, 76, 96, 71, 63, 92, 58, 74, 3, 95, 94, 6, 31, 98, 101, 95, 120, 49, 12, 62, 96, 40, 4, 36, 0, 70, 76, 38, 27, 72, 93, 104, 115};
   }

   private static byte[] tyckkehinxejlxa() {
      return new byte[]{-113, -17, 32, 57, 75, 94, 117, 92, 94, 56, 72, 98, 79, 57, 92, 114, 65, 9, 89, 70, 1, 8, 100, 116, 82, 53, 58, 78, 60, 112, 34, 18};
   }

   private static byte[] xaleixeneqqgeuh() {
      return new byte[]{-113, -17, 32, 105, 75, 108, 117, 123, 94, 125, 72, 83, 79, 123, 92, 24, 65, 75, 89, 67, 1, 52, 100, 83, 82, 17};
   }

   private static byte[] ufofmbmcyiaoxvp() {
      return new byte[]{-119, -17, 38, 49, 79, 83, 118, 92, 80, 62, 72, 100, 71, 61, 81, 113, 65, 6, 95, 65, 7, 18, 96, 122, 81, 59, 52, 65, 60, 119};
   }

   private static byte[] jswndtpppjdfzme() {
      return new byte[]{-119, -17, 38, 97, 79, 20, 118, 124, 80, 12, 72, 87, 71, 126, 81, 111, 65, 69, 95, 67, 7, 60, 96, 86};
   }

   private static int gliyoxcdglbrkwgo(int var0, int var1) {
      return var0 ^ var1;
   }
}
