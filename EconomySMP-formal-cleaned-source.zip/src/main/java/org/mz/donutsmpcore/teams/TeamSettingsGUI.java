package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.o0KoOo0o0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;

public class TeamSettingsGUI implements KKoOK {
   private final Player player;
   private final TeamService team;
   private Inventory inv;
   private int cancelSlot;
   private int confirmSlot;
   private static final o0KoOo0o0oOK GUI;

   public TeamSettingsGUI(Player var1, TeamService var2) {
      byte var4 = -1;
      this.cancelSlot = var4;
      byte var9 = -1;
      this.confirmSlot = var9;
      this.player = var1;
      this.team = var2;
   }

   public Inventory createInventory() {
      int var25 = 449144026 ^ 286746491 ^ 1576035388;
      var25 = 2038894201 ^ var25;
      Object var2 = null;
      InventoryHolder var12 = (InventoryHolder)var2;
      o0KoOo0o0oOK var3 = GUI;
      byte var4 = (byte)(799369727 ^ var25);
      int var14 = var3.size(var4);
      o0KoOo0o0oOK var15 = GUI;
      String var5 = crxtkdjmab(lebfhqrpwknubni(), aogaiygvczuzuoy(), var25);
      byte var6 = (byte)(799369702 ^ var25);
      Object[] var17 = new Object[var6];
      byte var7 = (byte)(799369700 ^ var25);
      String var8 = crxtkdjmab(hndxwlkjsnmjojb(), aogaiygvczuzuoy(), var25);
      var17[var7] = var8;
      byte var18 = (byte)(799369701 ^ var25);
      TeamService var20 = this.team;
      String var21 = var20.getName();
      String var22 = String.valueOf(var21);
      var17[var18] = var22;
      String var16 = var15.title(var5, var17);
      Inventory var13 = Bukkit.createInventory(var12, var14, var16);
      this.inv = var13;
      var25 = 1317211189 ^ var25;
      this.decorate();
      var25 = 2103340797 ^ var25;
      Inventory var11 = this.inv;
      return var11;
   }

   public void decorate() {
      int var51 = 628976892 ^ 2105292438 ^ 1576035388;
      var51 = 1011387661 ^ var51;
      TeamService var15 = this.team;
      String var16 = var15.getName();
      String var17 = String.valueOf(var16);
      var51 = 476908814 ^ var51;
      o0KoOo0o0oOK var2 = GUI;
      Inventory var26 = this.inv;
      String var4 = crxtkdjmab(ysssptnsamaevxf(), aogaiygvczuzuoy(), var51);
      byte var5 = (byte)(634699358 ^ var51);
      o0KoOo0o0oOK var6 = GUI;
      String var7 = crxtkdjmab(bmndwfdqfwywcar(), aogaiygvczuzuoy(), var51);
      Material var8 = Material.RED_STAINED_GLASS_PANE;
      String var9 = crxtkdjmab(edemqesiqmumrmu(), aogaiygvczuzuoy(), var51);
      String var10 = crxtkdjmab(draspqzzzfpwumi(), aogaiygvczuzuoy(), var51);
      var51 = 832681247 ^ var51;
      List var37 = List.of(var10);
      byte var11 = (byte)(343214920 ^ var51);
      Object[] var40 = new Object[var11];
      byte var12 = (byte)(343214922 ^ var51);
      String var13 = crxtkdjmab(nztgzjgwltzkwtk(), aogaiygvczuzuoy(), var51);
      var40[var12] = var13;
      byte var43 = (byte)(343214923 ^ var51);
      var40[var43] = var17;
      ItemStack var31 = var6.item(var7, var8, var9, var37, var40);
      var51 = 1722207891 ^ var51;
      int var21 = var2.place(var26, var4, var5, var31);
      this.cancelSlot = var21;
      var51 = 979092650 ^ var51;
      o0KoOo0o0oOK var22 = GUI;
      Inventory var28 = this.inv;
      String var29 = crxtkdjmab(wjhnrxobypfsvpv(), aogaiygvczuzuoy(), var51);
      byte var30 = (byte)(1216872828 ^ var51);
      o0KoOo0o0oOK var32 = GUI;
      String var34 = crxtkdjmab(llelzcdgwoeiwqm(), aogaiygvczuzuoy(), var51);
      Material var35 = Material.LIME_STAINED_GLASS_PANE;
      String var36 = crxtkdjmab(zudtlhttbltszgy(), aogaiygvczuzuoy(), var51);
      String var38 = crxtkdjmab(rqsdizhxlgeazsx(), aogaiygvczuzuoy(), var51);
      var51 = 571968239 ^ var51;
      List var39 = List.of(var38);
      byte var41 = (byte)(1788840862 ^ var51);
      Object[] var42 = new Object[var41];
      byte var44 = (byte)(1788840860 ^ var51);
      String var47 = crxtkdjmab(eltxatsjpnzbduo(), aogaiygvczuzuoy(), var51);
      var42[var44] = var47;
      byte var45 = (byte)(1788840861 ^ var51);
      var42[var45] = var17;
      ItemStack var33 = var32.item(var34, var35, var36, var39, var42);
      var51 = 6504602 ^ var51;
      int var23 = var22.place(var28, var29, var30, var33);
      this.confirmSlot = var23;
      var51 = 1820727321 ^ var51;
      o0KoOo0o0oOK var20 = GUI;
      Inventory var25 = this.inv;
      var20.fill(var25);
      var51 = 1578954997 ^ var51;
   }

   public void onClick(InventoryClickEvent var1) {
      int var48 = 736308506 ^ 1733473697 ^ 1576035388;
      var48 = 397498107 ^ var48;
      byte var3 = (byte)(116435581 ^ var48);
      var1.setCancelled((boolean)var3);
      var48 = 993259276 ^ var48;
      int var12 = var1.getRawSlot();
      var48 = 1021402298 ^ var48;
      if (var12 >= (19012042 ^ var48)) {
         var48 = 700356747 ^ var48;
         int var29 = this.cancelSlot;
         if (var12 != var29) {
            var48 = 620629120 ^ var48;
            int var31 = this.confirmSlot;
            if (var12 != var31) {
               var48 = 1564521925 ^ var48;
               return;
            }

            var48 = 1479444315 ^ var48;
         } else {
            var48 = xizjqmnmpfrjrqzg(var48, 2094042075);
         }

         Player var17 = this.player;
         KKo0KoOoOK.click(var17);
         var48 = 229419634 ^ var48;
         int var33 = this.cancelSlot;
         if (var12 == var33) {
            var48 = 1317834711 ^ var48;
            Player var20 = this.player;
            var20.closeInventory();
            var48 = 510241595 ^ var48;
         } else {
            var48 = 2095857205 ^ var48;
            int var35 = this.confirmSlot;
            if (var12 == var35) {
               var48 = 740849645 ^ var48;
               Player var23 = this.player;
               var23.closeInventory();
               var48 = 544522595 ^ var48;
               TeamService2 var24 = TeamService2.getInstance();
               var48 = 389281904 ^ var48;
               TeamService var37 = this.team;
               var24.disbandTeam(var37);
               var48 = 292804141 ^ var48;
               Player var27 = this.player;
               o0KoOo0o0oOK var38 = GUI;
               String var4 = crxtkdjmab(hyevhhafifmkohh(), aogaiygvczuzuoy(), var48);
               String var5 = crxtkdjmab(robqiyfadhvqksl(), aogaiygvczuzuoy(), var48);
               byte var6 = (byte)(789579276 ^ var48);
               Object[] var40 = new Object[var6];
               byte var7 = (byte)(789579278 ^ var48);
               String var8 = crxtkdjmab(gxjxhgsmsfmgreq(), aogaiygvczuzuoy(), var48);
               var40[var7] = var8;
               byte var41 = (byte)(789579279 ^ var48);
               TeamService var43 = this.team;
               String var44 = var43.getName();
               String var45 = String.valueOf(var44);
               var40[var41] = var45;
               String var39 = var38.msg(var4, var5, var40);
               oOo0KKoOoOK.sendActionBarAndChat(var27, var39);
               var48 = 638943754 ^ var48;
            } else {
               var48 = xizjqmnmpfrjrqzg(var48, 738794201);
            }
         }

      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var48)) {
               case 17824015:
                  var48 = 1342185934 ^ var48;
                  return;
               case 532071678:
                  return;
               case 1013156111:
                  break;
               case 1041016441:
               default:
                  throw new IOException();
            }
         }
      }
   }

   public void open() {
      int var12 = 408104045 ^ 1176329858 ^ 1576035388;
      var12 = 1195357282 ^ var12;
      Player var4 = this.player;
      Inventory var7 = this.createInventory();
      var4.openInventory(var7);
      var12 = 1627928357 ^ var12;
      oOoOKo0o0K var6 = oOoOKo0o0K.getInstance();
      Inventory var9 = this.inv;
      var6.register(var9, this);
      var12 = 338303450 ^ var12;
   }

   static {
      int var4 = 1941507482 ^ 2002680327 ^ Integer.parseInt("18589495");
      var4 = 847045387 ^ var4;
      String var0 = crxtkdjmab(rhckipcroelmzql(), aogaiygvczuzuoy(), var4);
      o0KoOo0o0oOK var1 = o0KoOo0o0oOK.of(var0);
      GUI = var1;
   }

   public static String crxtkdjmab(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] aogaiygvczuzuoy() {
      return new byte[]{94, 101, 4};
   }

   private static byte[] rhckipcroelmzql() {
      return new byte[]{-103, -87, 53, 8, 81, 73, 105, 60, 49, 20, 86, 26, 111, 37, 60, 12, 85, 80, 103, 59, 53, 28, 81, 19, 105, 49, 49, 14, 86, 70, 111, 51, 60, 8, 85, 95, 103, 50, 53, 12, 81, 83, 105, 59, 49, 1, 86, 92, 111, 35, 60, 4, 85, 86, 103, 35, 53, 6};
   }

   private static byte[] lebfhqrpwknubni() {
      return new byte[]{-105, -93, 32, 105, 78, 50, 107, 33, -109, 89, 94, 87, 111, -45, 32, 100, 85, 20, 116, 89, 63, 7, 87, 104, 107, -52, 41, 105, 94, 73, 112, 86, 63, 3, 87, 64, 107, 62, 61, 77, 78, 38, 116, 82, 41, 105, 65, 48};
   }

   private static byte[] hndxwlkjsnmjojb() {
      return new byte[]{-105, -93, 61, 72, 83, 73, 105, 48, 52, 8, 92, 80, 109, 118};
   }

   private static byte[] nztgzjgwltzkwtk() {
      return new byte[]{-109, -82, 55, 73, 84, 68, 103, 50, 54, 12, 81, 90, 108, 113};
   }

   private static byte[] ysssptnsamaevxf() {
      return new byte[]{-106, -87, 48, 11, 92, 92, 109, 63, 61, 11, 86, 85, 104, 48};
   }

   private static byte[] bmndwfdqfwywcar() {
      return new byte[]{-106, -87, 48, 11, 92, 92, 109, 63, 61, 11, 86, 85, 104, 48};
   }

   private static byte[] edemqesiqmumrmu() {
      return new byte[]{-106, -87, 48, 75, 92, 123, 109, 23, 61, 89, 86, 116, 104, 109, 61, 41, 76, 57, 117, 86, 50, 28, 65, 57, 112, 86, 63, -9};
   }

   private static byte[] draspqzzzfpwumi() {
      return new byte[]{-106, -87, 48, 78, 92, 91, 109, 18, 61, 4, 86, 89, 104, 63, 61, 6, 81, 29, 104, 34, 48, 7, 92, 29, 109, 50, 61, 9, 86, 94, 104, 63, 61, 8, 81, 81};
   }

   private static byte[] wjhnrxobypfsvpv() {
      return new byte[]{-111, -88, 53, 11, 93, 92, 108, 51, 53, 1, 84, 95, 111, 33, 60, 4};
   }

   private static byte[] llelzcdgwoeiwqm() {
      return new byte[]{-111, -88, 53, 11, 93, 92, 108, 51, 53, 1, 84, 95, 111, 33, 60, 4};
   }

   private static byte[] zudtlhttbltszgy() {
      return new byte[]{-111, -88, 53, 75, 93, 0, 108, 28, 53, 33, 84, 112, 111, 99, 60, 89, 74, 56, 114, 83, 55, 24, -13, 2, 100, 56, 52, -26, 73, 48};
   }

   private static byte[] rqsdizhxlgeazsx() {
      return new byte[]{-111, -88, 53, 78, 93, 85, 108, 30, 53, 11, 84, 95, 111, 48, 60, 2, 87, 28, 111, 40, 53, 3, 84, 18, 102, 49, 54, 9, 84, 83, 111, 49, 53, 1, 93, 65, 108, 48};
   }

   private static byte[] eltxatsjpnzbduo() {
      return new byte[]{-111, -83, 60, 67, 93, 68, 110, 56, 50, 15, 84, 94, 102, 120};
   }

   private static byte[] hyevhhafifmkohh() {
      return new byte[]{-105, -94, 61, 15, 82, 84, 108, 33, 60, 11, 93, 92, 107, 60, 61, 8, 82, 89, 105, 57};
   }

   private static byte[] robqiyfadhvqksl() {
      return new byte[]{-105, -94, 61, 77, 82, 10, 108, 11, 60, 6, 93, 72, 107, 114, 61, 8, 82, 85, 105, 46, 61, 9, 82, 92, 108, 60, 60, 13, 93, 88, 107, 54, 61, 76, 82, 69, 105, 50, 61, 30, 82, 79, 108, 114, 60, 29, 93, 88, 107, 51, 61, 1, 82, 18};
   }

   private static byte[] gxjxhgsmsfmgreq() {
      return new byte[]{-105, -94, 61, 78, 82, 73, 108, 55, 60, 8, 93, 80, 107, 119};
   }

   private static int xizjqmnmpfrjrqzg(int var0, int var1) {
      return var1 ^ var0;
   }
}
