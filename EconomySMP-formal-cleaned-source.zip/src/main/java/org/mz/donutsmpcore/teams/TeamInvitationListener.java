package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import skido.oOo0KKoOoOK;

public class TeamInvitationListener implements Listener {

   @EventHandler
   public void onChat(AsyncPlayerChatEvent var1) {
      int var59 = 1090560793 ^ 1315158270 ^ 1939718664;
      var59 = 1623091701 ^ var59;
      Player var12 = var1.getPlayer();
      var59 = 1842010347 ^ var59;
      TeamService2 var13 = TeamService2.getInstance();
      UUID var45 = var12.getUniqueId();
      TeamService var14 = var13.getTeamByPlayer(var45);
      var59 = 1534913962 ^ var59;
      if (var14 == null) {
         var59 = 1091195708 ^ var59;
      } else {
         var59 = 875767157 ^ var59;
         UUID var47 = var12.getUniqueId();
         byte var17 = var14.isTeamChatEnabled(var47);
         var59 = 1249070739 ^ var59;
         UUID var49 = var12.getUniqueId();
         byte var19 = var14.isTeamChatEnabled(var49);
         var59 = 1364545863 ^ var59;
         if (var17 == (98811898 ^ var59)) {
            var59 = cobvalvofqsvvaev(var59, 1150583105);
         } else {
            var59 = 271774616 ^ var59;
            if (var19 == (366038114 ^ var59)) {
               var59 = 1545528320 ^ var59;
               String var55 = vwofazpfsj(haohxduydsdwjjb(), dvfamzzrcszoamq(), var59);
               oOo0KKoOoOK.sendActionBarAndChat(var12, var55);
               var59 = 1898161419 ^ var59;
               byte var56 = (byte)(954994024 ^ var59);
               var1.setCancelled((boolean)var56);
               var59 = 1491572478 ^ var59;
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var59)) {
                     case 172332588:
                        var59 ^= 70466564;
                     case 317730193:
                        byte var50 = (byte)(300052583 ^ var59);
                        var1.setCancelled((boolean)var50);
                        var59 = 1293769057 ^ var59;
                        String var24 = var12.getName();
                        String var52 = var1.getMessage();
                        String var25 = "#2399FF[TEAM] " + var24 + "&f: &f" + var52;
                        String var26 = oOo0KKoOoOK.color(var25);
                        String var8 = var26;
                        var59 = 231286631 ^ var59;
                        Set var28 = var14.getMembers();
                        Iterator var29 = var28.iterator();
                        Iterator var9 = var29;
                        var59 = 436072533 ^ var59;

                        while(true) {
                           byte var31 = var9.hasNext();
                           if (var31 == (1221328437 ^ var59)) {
                              var59 = cobvalvofqsvvaev(var59, 163365006);
                              return;
                           }

                           var59 = 1092596603 ^ var59;
                           Object var33 = var9.next();
                           UUID var34 = (UUID)var33;
                           var59 = 1864677412 ^ var59;
                           TeamService2 var35 = TeamService2.getInstance();
                           byte var36 = var35.isInTeam(var34);
                           if (var36 == (1727067498 ^ var59)) {
                              var59 = 2084841426 ^ var59;
                              var59 = cobvalvofqsvvaev(var59, 1384066189);
                           } else {
                              var59 = cobvalvofqsvvaev(var59, 605736721);
                              Player var38 = Bukkit.getPlayer(var34);
                              var59 = 799534839 ^ var59;
                              if (var38 != null) {
                                 var59 = 249632815 ^ var59;
                                 byte var41 = var38.isOnline();
                                 if (var41 != (1672268963 ^ var59)) {
                                    var59 = 721499351 ^ var59;
                                    var38.sendMessage(var8);
                                    var59 = 1928039050 ^ var59;
                                 } else {
                                    var59 = cobvalvofqsvvaev(var59, 1508556381);
                                 }
                              } else {
                                 var59 = cobvalvofqsvvaev(var59, 1460381298);
                              }

                              var59 = cobvalvofqsvvaev(var59, 1921879243);
                           }
                        }
                     case 376705599:
                     default:
                        throw new IllegalAccessException();
                     case 588882014:
                  }
               }
            }
         }
      }
   }

   public static String vwofazpfsj(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] dvfamzzrcszoamq() {
      return new byte[]{51, 4, 76, 46, 8, 72, 124, 79, 115, 74, 17, 14, 33, 117, 118, 36, 10, 64, 57, 24, 125, 10, 121, 98, 11, 30, 115, 113, 39, 52, 56, 90, 123, 67, 6, 42, 120, 71, 10, 73, 3, 89, 126, 57, 98, 58, 76, 27, 94, 9, 4, 121, 96, 113, 2, 17, 74, 40, 121, 105, 9, 14, 53, 87, 60, 14, 80, 85, 47, 35, 46, 19, 119, 84, 115, 107, 34, 64, 52, 16, 61, 66, 96, 60};
   }

   private static byte[] haohxduydsdwjjb() {
      return new byte[]{-4, -55, 127, 48, 59, 31, 73, 46, 65, 19, 32, 73, 18, 109, 69, 116, 63, 23, 11, 14, 76, 86, 74, 53, 56, 94, 70, 105, 21, 106, 9, 9, 72, 13, 53, 123, 77, 95, 56, 15, 50, 14, 77, 115, 81, 99, 121, 74, 108, 76, 53, 56, 83, 32, 49, 74, 127, 126, 75, 127, 56, 72, 6, 0, 15, 26, 101, 30, 29, 112, 31, 79, 68, 8, 64, 127, 23, 21, 6, 67, 12, 3, 83, 119, 0, 81, 121, 113, 58, 27, 77, 14, 64, 82, 34, 83, 20, 35, 68, 50, 59, 6, 10, 69, 78, 95, 76, 55, 57, 8, 66, 32, 20, 100, 11, 15, 78, 15, 52, 50};
   }

   private static int cobvalvofqsvvaev(int var0, int var1) {
      return var1 ^ var0;
   }

   static {
   }
}
