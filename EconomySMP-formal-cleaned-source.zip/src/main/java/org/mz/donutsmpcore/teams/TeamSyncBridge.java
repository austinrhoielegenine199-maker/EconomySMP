package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.logging.Logger;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.KKo0KoOoOK;
import skido.KKoOoOo0oOK;
import skido.oOo0KKoOoOK;
import skido.oOo0o0oOo0oOK;

public final class TeamSyncBridge {
   private static final int TEAM_INVITES_SLOT = 30;
   private static volatile TeamSyncDispatcher dispatcher;
   private static String oakazzuick;

   private TeamSyncBridge() {
   }

   public static void setDispatcher(TeamSyncDispatcher var0) {
      int var13 = 2086543533 ^ 1274444653 ^ 715018896;
      var13 = 726747474 ^ var13;
      dispatcher = var0;
      var13 = 189852241 ^ var13;

      label41: {
         try {
            if (var0 != null) {
               var13 = 1949350940 ^ var13;
               DonutSMPCore var5 = DonutSMPCore.getInstance();
               Logger var6 = var5.getLogger();
               var13 = 721014623 ^ var13;
               Class var8 = var0.getClass();
               String var9 = var8.getSimpleName();
               String var10 = "Team cross-server dispatcher installed by " + var9 + ".";
               var13 = 1282116425 ^ var13;
               var6.info(var10);
               var13 = 102773180 ^ var13;
               break label41;
            }
         } catch (Throwable var14) {
            switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var13)) {
               case -373468519 -> var13 = 1564312952 ^ var13;
               case 536266883 -> var13 = qwlzmuxwwbexfaev(var13, 66385467);
               case 1211675258 -> var13 = qwlzmuxwwbexfaev(var13, 688732516);
               case 2091553481 -> var13 = 1335852402 ^ var13;
               default -> throw new IOException("Error in hash");
            }

            var13 = 210554387 ^ var13;
            return;
         }

         label35:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var13)) {
               case 110880567:
                  var13 ^= 344115638;
               case 113288265:
                  break label35;
               case 207161521:
               default:
                  throw new IllegalAccessException();
               case 1771376029:
            }
         }
      }

      var13 = qwlzmuxwwbexfaev(var13, 1161003741);
   }

   public static boolean hasDispatcher() {
      int var4 = 348407122 ^ 998650302 ^ 715018896;
      var4 = 404811428 ^ var4;
      TeamSyncDispatcher var0 = dispatcher;
      byte var1;
      if (var0 != null) {
         var4 = 128900197 ^ var4;
         var1 = (byte)(441586876 ^ var4);
         var4 = qwlzmuxwwbexfaev(var4, 160290176);
      } else {
         var4 = qwlzmuxwwbexfaev(var4, 1473522878);
         var1 = (byte)(1244193894 ^ var4);
         var4 = 1509369179 ^ var4;
      }

      return (boolean)var1;
   }

   public static boolean tryDispatchInvite(Player var0, String var1, String var2) {
      int var24 = 1377539901 ^ 811795380 ^ 715018896;
      var24 = 603584256 ^ var24;
      TeamSyncDispatcher var3 = dispatcher;
      TeamSyncDispatcher var7 = var3;
      var24 = 1273428162 ^ var24;
      if (var3 == null) {
         var24 = 1287869211 ^ var24;
         byte var18 = (byte)(1815780032 ^ var24);
         return (boolean)var18;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var24)) {
               case 266590177:
                  var24 ^= 1395011899;
               case 1768352140:
                  try {
                     boolean var12 = var7.dispatchCrossServerInvite(var0, var1, var2);
                     var24 = 1161349934 ^ var24;
                     return var12;
                  } catch (Throwable var26) {
                     switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var24)) {
                        case -1627404541:
                           var24 = 72807328 ^ var24;
                           Throwable var8 = var26;
                           var24 = 344263482 ^ var24;

                           label28: {
                              try {
                                 DonutSMPCore var14 = DonutSMPCore.getInstance();
                                 Logger var15 = var14.getLogger();
                                 String var20 = var8.getMessage();
                                 String var21 = "[Teams] dispatchCrossServerInvite failed: " + var20;
                                 var15.warning(var21);
                                 var24 = 2119035113 ^ var24;
                              } catch (Throwable var25) {
                                 switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var24)) {
                                    case 408945619:
                                       var24 = qwlzmuxwwbexfaev(var24, 1292486655);
                                       var24 = 63859533 ^ var24;
                                       break label28;
                                    default:
                                       throw new RuntimeException("Error in hash");
                                 }
                              }

                              var24 = 814367835 ^ var24;
                           }

                           byte var17 = (byte)(768322760 ^ var24);
                           return (boolean)var17;
                        default:
                           throw new RuntimeException("Error in hash");
                     }
                  }
               case 1209383680:
                  break;
               case 1717276989:
               default:
                  throw new RuntimeException();
            }
         }
      }
   }

   public static void publishTeamChanged(String var0, UUID var1, boolean var2) {
      int var21 = 1587295540 ^ 639188203 ^ 715018896;
      var21 = 247588914 ^ var21;
      TeamSyncDispatcher var3 = dispatcher;
      TeamSyncDispatcher var7 = var3;
      var21 = 1849618377 ^ var21;
      if (var3 == null) {
         var21 = 2034860518 ^ var21;
      } else {
         var21 = 504146920 ^ var21;

         try {
            var7.publishTeamChanged(var0, var1, var2);
            var21 = 47624559 ^ var21;
         } catch (Throwable var23) {
            switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var21)) {
               case 1732754145:
                  var21 = 1610783795 ^ var21;
                  Throwable var8 = var23;
                  var21 = 1923385825 ^ var21;

                  try {
                     DonutSMPCore var13 = DonutSMPCore.getInstance();
                     Logger var14 = var13.getLogger();
                     String var17 = var8.getMessage();
                     String var18 = "[Teams] publishTeamChanged failed: " + var17;
                     var14.warning(var18);
                     var21 = 64637529 ^ var21;
                  } catch (Throwable var22) {
                     switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var21)) {
                        case -227077007:
                           var21 = qwlzmuxwwbexfaev(var21, 1852795235);
                           var21 = 1763274272 ^ var21;
                           return;
                        default:
                           throw new IllegalAccessException("Error in hash");
                     }
                  }

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var21)) {
                        case 122698420:
                           var21 = 78400794 ^ var21;
                           return;
                        case 564449213:
                        default:
                           throw new IllegalAccessException();
                        case 884482985:
                           break;
                        case 1585651786:
                           return;
                     }
                  }
               default:
                  throw new IOException("Error in hash");
            }
         }

         var21 = qwlzmuxwwbexfaev(var21, 386311166);
      }
   }

   public static void onIncomingInvite(String var0, String var1, String var2) {
      int var64 = 172557138 ^ 1074964740 ^ 715018896;
      var64 = 1517032268 ^ var64;
      Player var16 = Bukkit.getPlayerExact(var1);
      Player var8 = var16;
      var64 = 930307350 ^ var64;
      if (var16 != null) {
         var64 = 635404209 ^ var64;
         byte var19 = var16.isOnline();
         if (var19 == (671467821 ^ var64)) {
            var64 = 966928323 ^ var64;
         } else {
            var64 = qwlzmuxwwbexfaev(var64, 733144986);

            label84: {
               try {
                  oOo0o0oOo0oOK var20 = oOo0o0oOo0oOK.getInstance();
                  byte var5 = (byte)(62336681 ^ var64);
                  byte var21 = var20.isEnabled(var8, var5);
                  if (var21 == (62336695 ^ var64)) {
                     var64 = 438913701 ^ var64;
                     return;
                  }
               } catch (Throwable var66) {
                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var64)) {
                     case 498693560:
                        var64 = 947817913 ^ var64;
                        var64 = 942726520 ^ var64;
                        break label84;
                     default:
                        throw new RuntimeException("Error in hash");
                  }
               }

               var64 = 394155219 ^ var64;
               var64 = qwlzmuxwwbexfaev(var64, 389022738);
            }

            TeamService2 var23 = TeamService2.getInstance();
            var64 = 1748365549 ^ var64;
            TeamService var25 = var23.getTeam(var2);
            TeamService var10 = var25;
            var64 = 1952705371 ^ var64;
            if (var25 == null) {
               var64 = 941129781 ^ var64;
               var23.reloadTeam(var2);
               var64 = 1226387805 ^ var64;
               TeamService var29 = var23.getTeam(var2);
               var10 = var29;
               var64 = 1075556525 ^ var64;
            } else {
               label70:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var64)) {
                     case 224643723:
                        var64 ^= 823787973;
                        break label70;
                     case 637678461:
                     default:
                        throw new RuntimeException();
                     case 1152170503:
                        break label70;
                     case 1860048484:
                  }
               }
            }

            if (var10 == null) {
               var64 = 2045581592 ^ var64;
            } else {
               label59:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var64)) {
                     case 164108507:
                        break;
                     case 176119676:
                        var64 ^= 147726016;
                        break label59;
                     case 850820998:
                     default:
                        throw new RuntimeException();
                     case 922176510:
                        break label59;
                  }
               }

               UUID var32 = var16.getUniqueId();
               byte var33 = TeamService3.hasInvite(var32);
               if (var33 != (645626565 ^ var64)) {
                  var64 = 1455509813 ^ var64;
               } else {
                  var64 = 2083249879 ^ var64;
                  TeamService3.addInvite(var16, var10);
                  var64 = 1342330550 ^ var64;
                  String var36 = "#2399FF" + var0;
                  var64 = 2002758297 ^ var64;
                  String var38 = var10.getName();
                  String var39 = "#2399FF" + var38;
                  var64 = 112436871 ^ var64;
                  String var55 = var36 + " &7invited you to the team " + var39 + " &8[CLICK TO ACCEPT]";
                  var64 = 1894032060 ^ var64;
                  String var56 = oOo0KKoOoOK.color(var55);
                  var64 = 706903996 ^ var64;
                  BaseComponent[] var57 = TextComponent.fromLegacyText(var56);
                  TextComponent var40 = new TextComponent(var57);
                  var64 = 547844204 ^ var64;
                  ClickEvent.Action var60 = Action.RUN_COMMAND;
                  String var7 = zeesspvwou(npjljmwtlfbkmky(), var64);
                  ClickEvent var51 = new ClickEvent(var60, var7);
                  var40.setClickEvent(var51);
                  var64 = 133448680 ^ var64;
                  Player.Spigot var43 = var16.spigot();
                  var43.sendMessage(var40);
                  var64 = 2074006573 ^ var64;
                  Player var14 = var16;
                  var64 = 918903846 ^ var64;

                  try {
                     KKoOoOo0oOK var45 = KKoOoOo0oOK.getInstance();
                     Runnable var59 = () -> {
                        int var10 = 1322352671 ^ 882771158 ^ 715018896;
                        var10 = 793139816 ^ var10;

                        try {
                           String var2 = zeesspvwou(tnfntvwxlrvcfmn(), var10);
                           Sound var3 = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;
                           float var4 = 1.0F;
                           float var5 = 1.4F;
                           KKo0KoOoOK.play(var14, var2, var3, var4, var5);
                           var10 = 782239669 ^ var10;
                        } catch (Throwable var11) {
                           switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var10)) {
                              case -54763125:
                                 var10 = qwlzmuxwwbexfaev(var10, 2054032113);
                                 var10 = 2045720152 ^ var10;
                                 return;
                              default:
                                 throw new RuntimeException("Error in hash");
                           }
                        }

                        var10 = 757152540 ^ var10;
                     };
                     var45.runAtEntity(var14, var59);
                     var64 = 1492726144 ^ var64;
                  } catch (Throwable var65) {
                     switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var64)) {
                        case 1535426986:
                           var64 = qwlzmuxwwbexfaev(var64, 589390415);
                           var64 = 743603227 ^ var64;
                           return;
                        default:
                           throw new IOException("Error in hash");
                     }
                  }

                  var64 = 1468674004 ^ var64;
               }
            }
         }
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var64)) {
               case 59624988:
                  break;
               case 181914644:
                  var64 = 477976690 ^ var64;
                  return;
               case 1073614670:
                  return;
               case 1145186720:
               default:
                  throw new RuntimeException();
            }
         }
      }
   }

   public static void onIncomingTeamChanged(String var0, UUID var1, boolean var2) {
      int var16 = 1972196801 ^ 1224502156 ^ 715018896;
      var16 = 1703799555 ^ var16;
      TeamService2 var3 = TeamService2.getInstance();
      var16 = 75008020 ^ var16;
      if (var2 != (1981419466 ^ var16)) {
         var16 = 786777143 ^ var16;
         if (var0 != null) {
            var16 = 146293938 ^ var16;
            var3.dropTeamFromCache(var0);
            var16 = 1404112325 ^ var16;
            return;
         }

         label43:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 136875099:
               default:
                  throw new IllegalAccessException();
               case 208600005:
                  var16 ^= 1709156937;
               case 1496409365:
                  break label43;
               case 1988589770:
            }
         }
      } else {
         var16 = qwlzmuxwwbexfaev(var16, 1262153342);
      }

      if (var0 != null) {
         var16 = 1747057667 ^ var16;
         var3.reloadTeam(var0);
         var16 = 1002184638 ^ var16;
      } else {
         var16 = 1402856381 ^ var16;
      }

      if (var1 != null) {
         var16 = 1696696664 ^ var16;
         TeamService3.removeInvite(var1);
         var16 = 1271875676 ^ var16;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 109993292:
                  var16 = 787398916 ^ var16;
                  return;
               case 140469090:
                  break;
               case 965343574:
                  return;
               case 1667819093:
               default:
                  throw new IllegalAccessException();
            }
         }
      }
   }

   public static String zeesspvwou(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = oakazzuick;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] npjljmwtlfbkmky() {
      return new byte[]{0, 0, 0, 12, 0, 0, 0, 0};
   }

   private static byte[] tnfntvwxlrvcfmn() {
      return new byte[]{0, 0, 0, 27, 0, 0, 0, 12};
   }

   static {
      oakazzuick = ByteBuffer.wrap(yuidjhzbelanayx()).asCharBuffer().toString();
   }

   private static byte[] yuidjhzbelanayx() {
      return new byte[]{51, 30, 52, 69, 51, 87, 48, 87, 51, 92, 52, 17, 51, 83, 48, 85, 51, 82, 52, 84, 51, 66, 48, 66, 50, 69, 52, 85, 54, 82, 56, 95, 53, 68, 50, 31, 52, 68, 54, 86, 56, 83, 53, 90, 50, 66, 52, 73, 54, 93, 56, 81, 53, 85, 50, 67, 52, 89, 54, 87, 56, 85, 53, 82, 50, 31, 52, 66, 54, 86, 56, 69, 53, 86, 50, 67, 52, 84};
   }

   private static int qwlzmuxwwbexfaev(int var0, int var1) {
      return var1 ^ var0;
   }
}
