package org.mz.donutsmpcore.teams;

import java.util.UUID;
import org.bukkit.entity.Player;

public interface TeamSyncDispatcher {
   boolean dispatchCrossServerInvite(Player var1, String var2, String var3);

   void publishTeamChanged(String var1, UUID var2, boolean var3);
}
