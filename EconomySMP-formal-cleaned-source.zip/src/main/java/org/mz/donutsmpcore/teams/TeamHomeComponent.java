package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.mz.donutsmpcore.libs.folialib.wrapper.task.WrappedTask;
import skido.KKo0KoOoOK;
import skido.KKoOoOo0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0K;

public class TeamHomeComponent {
   private final Player player;
   private final Location target;
   private final Location startLoc;
   private int seconds;
   private WrappedTask task;
   private static String prihtxsdxq;

   public TeamHomeComponent(Player var1, Location var2) {
      String var4 = "team-home";
      int var13 = oOoOKo0K.seconds(var4);
      this.seconds = var13;
      this.player = var1;
      this.target = var2;
      Location var17 = var1.getLocation();
      Location var18 = var17.clone();
      this.startLoc = var18;
      String var19 = "teams.teamhometeleporttask.click";
      Sound var5 = Sound.UI_BUTTON_CLICK;
      float var6 = 1.0F;
      float var7 = 1.0F;
      KKo0KoOoOK.play(var1, var19, var5, var6, var7);
   }

   public void start() {
      int var28 = 598586329 ^ 268677098 ^ 334940952;
      var28 = 1483301202 ^ var28;
      int var8 = this.seconds;
      if (var8 <= (2016523897 ^ var28)) {
         var28 = 1839303434 ^ var28;
         this.arrive();
         var28 = 1956152255 ^ var28;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var28)) {
               case 148908475:
                  var28 ^= 1356746392;
               case 1328039530:
                  Player var10 = this.player;
                  String var2 = dtwirwqhrr(xuvplofyyndisus(), var28);
                  int var19 = this.seconds;
                  String var15 = oOoOKo0K.countdown(var2, var19);
                  oOo0KKoOoOK.sendActionBar(var10, var15);
                  var28 = 1676470818 ^ var28;
                  Player var12 = this.player;
                  String var16 = dtwirwqhrr(gulcxwjuspkoymz(), var28);
                  Sound var20 = Sound.BLOCK_NOTE_BLOCK_HAT;
                  float var4 = 1.0F;
                  float var5 = 2.0F;
                  KKo0KoOoOK.play(var12, var16, var20, var4, var5);
                  var28 = 1497157491 ^ var28;
                  KKoOoOo0oOK var17 = KKoOoOo0oOK.getInstance();
                  Player var22 = this.player;
                  Runnable var24 = this::tick;
                  long var25 = 20L;
                  long var6 = 20L;
                  WrappedTask var18 = var17.runAtEntityTimer(var22, var24, var25, var6);
                  this.task = var18;
                  var28 = 2046009833 ^ var28;
                  return;
               case 192751181:
               default:
                  throw new IllegalAccessException();
               case 1344115053:
            }
         }
      }
   }

   private void tick() {
   }

   private void arrive() {
      int var19 = 965812679 ^ 505934433 ^ 334940952;
      var19 = 162381905 ^ var19;
      KKoOoOo0oOK var1 = KKoOoOo0oOK.getInstance();
      Player var10 = this.player;
      Location var14 = this.target;
      var1.teleportAsync(var10, var14);
      var19 = 329038810 ^ var19;
      Player var7 = this.player;
      String var11 = dtwirwqhrr(ikijvkjltfvxskb(), var19);
      String var15 = dtwirwqhrr(nzdgnaqqooxuxxb(), var19);
      String var12 = oOoOKo0K.msg(var11, var15);
      oOo0KKoOoOK.sendActionBar(var7, var12);
      var19 = 881414764 ^ var19;
      Player var9 = this.player;
      String var13 = dtwirwqhrr(allcryowufbjzjj(), var19);
      Sound var16 = Sound.ENTITY_ENDERMAN_TELEPORT;
      float var4 = 1.0F;
      float var5 = 1.0F;
      KKo0KoOoOK.play(var9, var13, var16, var4, var5);
      var19 = 1924589318 ^ var19;
   }

   public void cancel() {
      int var9 = 1294381823 ^ 627345957 ^ 334940952;
      var9 = 233131703 ^ var9;
      WrappedTask var3 = this.task;
      if (var3 != null) {
         var9 = 1845278386 ^ var9;
         WrappedTask var5 = this.task;
         var5.cancel();
         var9 = 1192199097 ^ var9;
         Object var2 = null;
         this.task = (WrappedTask)var2;
         var9 = 1794176057 ^ var9;
      } else {
         var9 = 1073987890 ^ var9;
      }

   }

   public static String dtwirwqhrr(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = prihtxsdxq;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] gulcxwjuspkoymz() {
      return new byte[]{0, 0, 0, 31, 0, 0, 0, 0};
   }

   private static byte[] xuvplofyyndisus() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, 31};
   }

   private static byte[] qgfaqimjbkpbkww() {
      return new byte[]{0, 0, 0, 31, 0, 0, 0, 40};
   }

   private static byte[] smfowlpshdbfetx() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, 71};
   }

   private static byte[] pzcoeoajrjkuntz() {
      return new byte[]{0, 0, 0, 32, 0, 0, 0, 80};
   }

   private static byte[] wjurxnkzhypgfeo() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, 112};
   }

   private static byte[] khnkctvosqkukdb() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, 121};
   }

   private static byte[] allcryowufbjzjj() {
      return new byte[]{0, 0, 0, 35, 0, 0, 0, -126};
   }

   private static byte[] ikijvkjltfvxskb() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, -91};
   }

   private static byte[] nzdgnaqqooxuxxb() {
      return new byte[]{0, 0, 0, 10, 0, 0, 0, -82};
   }

   static {
      prihtxsdxq = ByteBuffer.wrap(lcuofiiesdxobpj()).asCharBuffer().toString();
   }

   private static byte[] lcuofiiesdxobpj() {
      return new byte[]{49, 70, 53, 93, 52, 88, 50, 91, 49, 66, 49, 28, 53, 76, 52, 92, 50, 87, 49, 92, 49, 90, 53, 87, 52, 84, 50, 83, 49, 69, 49, 87, 53, 84, 52, 92, 50, 70, 49, 94, 49, 64, 53, 76, 52, 77, 50, 87, 49, 66, 49, 89, 53, 22, 52, 77, 50, 95, 49, 82, 49, 89, 54, 76, 54, 93, 49, 84, 52, 88, 55, 27, 56, 94, 56, 94, 53, 89, 53, 82, 49, 70, 57, 80, 49, 86, 55, 93, 57, 66, 49, 28, 57, 65, 49, 82, 55, 81, 57, 92, 49, 90, 57, 90, 49, 90, 55, 85, 57, 69, 49, 87, 57, 89, 49, 82, 55, 64, 57, 94, 49, 64, 57, 65, 49, 67, 55, 81, 57, 66, 49, 89, 57, 27, 49, 83, 55, 85, 57, 95, 49, 75, 49, 69, 55, 82, 51, 82, 54, 90, 52, 31, 49, 89, 55, 88, 51, 94, 54, 82, 49, 69, 57, 87, 52, 84, 55, 85, 51, 65, 49, 31, 57, 70, 52, 80, 55, 89, 51, 95, 49, 89, 57, 93, 52, 88, 55, 93, 51, 70, 49, 84, 57, 94, 52, 80, 55, 72, 51, 93, 49, 67, 57, 70, 52, 65, 55, 89, 51, 65, 49, 90, 57, 28, 52, 65, 55, 81, 51, 81, 49, 90, 57, 0, 49, 77, 54, 86, 57, 86, 48, 85, 50, 29, 49, 81, 54, 92, 57, 90, 48, 93, 49, 90, 54, 82, 57, 89, 48, 91, 50, 85, 49, 85, 54, 95, 57, 82, 48, 92, 52, 65, 50, 81, 55, 82, 49, 90, 55, 71, 53, 28, 52, 67, 51, 84, 55, 86, 52, 88, 50, 92, 55, 92, 49, 90, 55, 81, 53, 70, 52, 82, 51, 93, 55, 82, 52, 69, 50, 91, 55, 65, 49, 67, 55, 64, 53, 83, 52, 68, 51, 90, 55, 25, 52, 65, 50, 81, 55, 95, 49, 82, 55, 68, 53, 93, 52, 69, 51, 69, 55, 67, 57, 84, 56, 83, 57, 93, 49, 26, 55, 81, 49, 87, 50, 84, 48, 84, 55, 67, 57, 84, 56, 94, 57, 85, 49, 71, 55, 86, 49, 74, 50, 77, 48, 84, 55, 83};
   }

   private static int utmsdlqfnaubzwfv(int var0, int var1) {
      return var0 ^ var1;
   }
}
