package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.KKoOoOo0oOK;
import skido.o0KoOo0o0oOK;
import skido.o0oOKo0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;

public class TeamInviteGUI implements KKoOK {
   private final Player leader;
   private final UUID targetUuid;
   private final TeamService team;
   private Inventory inv;
   private int cancelSlot;
   private int confirmSlot;
   private static final o0KoOo0o0oOK GUI;
   private static byte[] nrruqklmno;

   public TeamInviteGUI(Player var1, UUID var2, TeamService var3) {
      byte var5 = -1;
      this.cancelSlot = var5;
      byte var11 = -1;
      this.confirmSlot = var11;
      this.leader = var1;
      this.targetUuid = var2;
      this.team = var3;
   }

   public Inventory createInventory() {
      int var30 = 1374983136 ^ 1206176023 ^ 184797776;
      var30 = 1189160553 ^ var30;
      UUID var10 = this.targetUuid;
      OfflinePlayer var11 = Bukkit.getOfflinePlayer(var10);
      var30 = 1014195531 ^ var30;
      Object var2 = null;
      InventoryHolder var16 = (InventoryHolder)var2;
      o0KoOo0o0oOK var3 = GUI;
      byte var4 = (byte)(1736561566 ^ var30);
      int var20 = var3.size(var4);
      o0KoOo0o0oOK var21 = GUI;
      String var5 = gqltdluiwu(khlkamlmvtionwy(), var30);
      byte var6 = (byte)(1736561543 ^ var30);
      Object[] var23 = new Object[var6];
      byte var7 = (byte)(1736561541 ^ var30);
      String var8 = gqltdluiwu(rvlwbeerhniabmn(), var30);
      var23[var7] = var8;
      byte var24 = (byte)(1736561540 ^ var30);
      String var26 = var11.getName();
      String var27 = String.valueOf(var26);
      var23[var24] = var27;
      String var22 = var21.title(var5, var23);
      Inventory var17 = Bukkit.createInventory(var16, var20, var22);
      this.inv = var17;
      var30 = 945768286 ^ var30;
      String var19 = var11.getName();
      this.decorate(var19);
      var30 = 302705691 ^ var30;
      Inventory var15 = this.inv;
      return var15;
   }

   public void decorate() {
      int var5 = 135990847 ^ 730831098 ^ 184797776;
      var5 = 1551853868 ^ var5;
      Object var2 = null;
      this.decorate((String)var2);
      var5 = 1814288164 ^ var5;
   }

   public void decorate(String var1) {
      int var83 = 1420024302 ^ 1546639072 ^ 184797776;
      var83 = 419301516 ^ var83;
      String var18 = String.valueOf(var1);
      var83 = 1359917839 ^ var83;
      o0KoOo0o0oOK var3 = GUI;
      Inventory var41 = this.inv;
      String var5 = gqltdluiwu(hbctjrwejnzkkac(), var83);
      byte var6 = (byte)(1249869526 ^ var83);
      o0KoOo0o0oOK var7 = GUI;
      String var8 = gqltdluiwu(wuzfuisbkhagqsq(), var83);
      Material var9 = Material.RED_STAINED_GLASS_PANE;
      String var10 = gqltdluiwu(hpwqxacndmkjhwf(), var83);
      String var11 = gqltdluiwu(baxhqzgdbhufovt(), var83);
      var83 = 1936106714 ^ var83;
      List var63 = List.of(var11);
      byte var12 = (byte)(957995525 ^ var83);
      Object[] var68 = new Object[var12];
      byte var13 = (byte)(957995527 ^ var83);
      String var14 = gqltdluiwu(wzrugjfgptilewr(), var83);
      var68[var13] = var14;
      byte var73 = (byte)(957995526 ^ var83);
      var68[var73] = var18;
      ItemStack var53 = var7.item(var8, var9, var10, var63, var68);
      var83 = 1197774245 ^ var83;
      int var32 = var3.place(var41, var5, var6, var53);
      this.cancelSlot = var32;
      var83 = 245172701 ^ var83;
      o0KoOo0o0oOK var33 = GUI;
      Inventory var43 = this.inv;
      String var48 = gqltdluiwu(rljmqfazcbbciql(), var83);
      byte var50 = (byte)(1893746288 ^ var83);
      o0KoOo0o0oOK var54 = GUI;
      String var57 = gqltdluiwu(lhohunnzdeyjgnk(), var83);
      Material var59 = Material.LIME_STAINED_GLASS_PANE;
      String var61 = gqltdluiwu(znrcyotolpwlrog(), var83);
      String var64 = gqltdluiwu(uziyupoisbzzltz(), var83);
      var83 = 1961860531 ^ var83;
      List var65 = List.of(var64);
      byte var69 = (byte)(68148174 ^ var83);
      Object[] var70 = new Object[var69];
      byte var74 = (byte)(68148172 ^ var83);
      String var79 = gqltdluiwu(zmmtujimrrjdqna(), var83);
      var70[var74] = var79;
      byte var75 = (byte)(68148173 ^ var83);
      var70[var75] = var18;
      ItemStack var55 = var54.item(var57, var59, var61, var65, var70);
      var83 = 861605807 ^ var83;
      int var34 = var33.place(var43, var48, var50, var55);
      this.confirmSlot = var34;
      var83 = 544088959 ^ var83;
      if (var1 != null) {
         var83 = 1419164524 ^ var83;
         Material var44 = Material.PLAYER_HEAD;
         ItemStack var22 = new ItemStack(var44);
         var83 = 2107746939 ^ var83;
         ItemMeta var24 = var22.getItemMeta();
         SkullMeta var25 = (SkullMeta)var24;
         var83 = 1638766586 ^ var83;
         o0oOKo0oOK var26 = o0oOKo0oOK.getInstance();
         UUID var46 = this.targetUuid;
         var26.apply(var25, var46);
         var83 = 622153463 ^ var83;
         var22.setItemMeta(var25);
         var83 = 1903698820 ^ var83;
         o0KoOo0o0oOK var29 = GUI;
         Inventory var38 = this.inv;
         String var47 = gqltdluiwu(jeefkixnomwloli(), var83);
         byte var49 = (byte)(197991567 ^ var83);
         o0KoOo0o0oOK var51 = GUI;
         String var58 = gqltdluiwu(wlytytxfjkilupy(), var83);
         String var60 = gqltdluiwu(dmhazabgrnfhspf(), var83);
         Object var62 = null;
         byte var66 = (byte)(197991552 ^ var83);
         Object[] var67 = new Object[var66];
         byte var71 = (byte)(197991554 ^ var83);
         String var76 = gqltdluiwu(jrqypyjjsqevstx(), var83);
         var67[var71] = var76;
         byte var72 = (byte)(197991555 ^ var83);
         var67[var72] = var18;
         ItemStack var52 = var51.apply(var22, var58, var60, (List)var62, var67);
         var29.place(var38, var47, var49, var52);
         var83 = 141019970 ^ var83;
      } else {
         var83 = ikvhelxszusztfmq(var83, 344989916);
      }

      o0KoOo0o0oOK var31 = GUI;
      Inventory var40 = this.inv;
      var31.fill(var40);
      var83 = 1071353918 ^ var83;
   }

   public void onClick(InventoryClickEvent var1) {
      int var90 = 1297152112 ^ 832641997 ^ 184797776;
      var90 = 1136987508 ^ var90;
      byte var3 = (byte)(876029080 ^ var90);
      var1.setCancelled((boolean)var3);
      var90 = 283236502 ^ var90;
      int var17 = var1.getRawSlot();
      var90 = 535679212 ^ var90;
      if (var17 >= (993733859 ^ var90)) {
         var90 = 766106199 ^ var90;
         int var61 = this.cancelSlot;
         if (var17 != var61) {
            var90 = 1481375544 ^ var90;
            int var63 = this.confirmSlot;
            if (var17 != var63) {
               var90 = 875379290 ^ var90;
               return;
            }

            var90 = 821669428 ^ var90;
         } else {
            var90 = ikvhelxszusztfmq(var90, 1756516620);
         }

         HumanEntity var22 = var1.getWhoClicked();
         Player var23 = (Player)var22;
         KKo0KoOoOK.click(var23);
         var90 = 1473807506 ^ var90;
         HumanEntity var25 = var1.getWhoClicked();
         Player var26 = (Player)var25;
         var90 = 464019260 ^ var90;
         int var65 = this.cancelSlot;
         if (var17 == var65) {
            var90 = 1934644212 ^ var90;
            var26.closeInventory();
            var90 = 887958006 ^ var90;
         } else {
            var90 = 1608470143 ^ var90;
            int var67 = this.confirmSlot;
            if (var17 == var67) {
               var90 = 121207497 ^ var90;
               var26.closeInventory();
               var90 = 766534774 ^ var90;
               UUID var32 = this.targetUuid;
               OfflinePlayer var33 = Bukkit.getOfflinePlayer(var32);
               OfflinePlayer var11 = var33;
               var90 = 1098607140 ^ var90;
               Player var35 = var33.getPlayer();
               var90 = 1730625142 ^ var90;
               TeamService var37 = this.team;
               Set var38 = var37.getMembers();
               UUID var69 = this.targetUuid;
               var38.remove(var69);
               var90 = 1817981717 ^ var90;
               TeamService2 var40 = TeamService2.getInstance();
               UUID var71 = this.targetUuid;
               var40.leaveTeam(var71);
               var90 = 1515849638 ^ var90;
               o0KoOo0o0oOK var72 = GUI;
               String var4 = gqltdluiwu(vauwdbcctvnsvoy(), var90);
               String var5 = gqltdluiwu(jqeuqdmzcwsdgic(), var90);
               byte var6 = (byte)(1465666613 ^ var90);
               Object[] var83 = new Object[var6];
               byte var7 = (byte)(1465666615 ^ var90);
               String var8 = gqltdluiwu(ztrgzamkugakqhe(), var90);
               var83[var7] = var8;
               byte var84 = (byte)(1465666614 ^ var90);
               String var86 = var33.getName();
               String var87 = String.valueOf(var86);
               var83[var84] = var87;
               String var73 = var72.msg(var4, var5, var83);
               oOo0KKoOoOK.sendActionBarAndChat(var26, var73);
               var90 = 1054181015 ^ var90;
               if (var35 != null) {
                  var90 = 1909510149 ^ var90;
                  KKoOoOo0oOK var43 = KKoOoOo0oOK.getInstance();
                  Runnable var79 = () -> {
                     int var10 = 568443534 ^ 336378231 ^ 1103625384;
                     var10 = 43424510 ^ var10;
                     o0KoOo0o0oOK var2 = GUI;
                     String var3 = gqltdluiwu(igxprmrvousrndh(), var10);
                     String var4 = gqltdluiwu(abgqfzobzrfgvjg(), var10);
                     byte var5 = (byte)(1992039855 ^ var10);
                     Object[] var7 = new Object[var5];
                     String var6 = var2.msg(var3, var4, var7);
                     oOo0KKoOoOK.sendActionBarAndChat(var35, var6);
                  };
                  var43.runAtEntity(var35, var79);
                  var90 = 1755724668 ^ var90;
               } else {
                  var90 = ikvhelxszusztfmq(var90, 427223929);
               }

               TeamService var45 = this.team;
               Set var46 = var45.getMembers();
               Iterator var47 = var46.iterator();
               Iterator var13 = var47;
               var90 = 991881424 ^ var90;

               label102:
               while(true) {
                  byte var49 = var13.hasNext();
                  if (var49 == (1273088265 ^ var90)) {
                     label53:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                           case 22793799:
                              break;
                           case 50675296:
                              var90 ^= 909570780;
                              break label53;
                           case 123334424:
                           default:
                              throw new IOException();
                           case 632756630:
                              break label53;
                        }
                     }

                     KKoOoOo0oOK var59 = KKoOoOo0oOK.getInstance();
                     Runnable var77 = () -> {
                        int var6 = 656701914 ^ 797604280 ^ 184797776;
                        var6 = 1292751314 ^ var6;
                        TeamService2 var1 = TeamService2.getInstance();
                        TeamService var3 = this.team;
                        var1.broadcastTeamUpdate(var3);
                     };
                     var59.runNextTick(var77);
                     var90 = 446427209 ^ var90;
                     break;
                  }

                  var90 = 158681326 ^ var90;
                  Object var51 = var13.next();
                  UUID var52 = (UUID)var51;
                  var90 = 1095174597 ^ var90;
                  Player var54 = Bukkit.getPlayer(var52);
                  var90 = 1534172542 ^ var90;
                  if (var54 != null) {
                     var90 ^= 510407262;
                     byte var57 = var54.isOnline();
                     if (var57 != (1187915522 ^ var90)) {
                        var90 = 1138302405 ^ var90;
                        KKoOoOo0oOK var58 = KKoOoOo0oOK.getInstance();
                        Runnable var81 = () -> {
                           int var17 = 2097469182 ^ 72052047 ^ 1103625384;
                           var17 = 1274648845 ^ var17;
                           o0KoOo0o0oOK var3 = GUI;
                           String var4 = gqltdluiwu(cqzblxmmvztyqnb(), var17);
                           String var5 = gqltdluiwu(bpbwekxtfkmhtwn(), var17);
                           byte var6 = (byte)(1936842262 ^ var17);
                           Object[] var10 = new Object[var6];
                           byte var7 = (byte)(1936842260 ^ var17);
                           String var8 = gqltdluiwu(vzlikkokmkrbrfq(), var17);
                           var10[var7] = var8;
                           byte var11x = (byte)(1936842261 ^ var17);
                           String var13 = var11.getName();
                           String var14 = String.valueOf(var13);
                           var10[var11x] = var14;
                           String var9 = var3.msg(var4, var5, var10);
                           oOo0KKoOoOK.sendActionBarAndChat(var54, var9);
                        };
                        var58.runAtEntity(var54, var81);
                        var90 = 430447490 ^ var90;
                     } else {
                        label69:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                              case 154086749:
                                 var90 ^= 1517356615;
                              case 470981379:
                                 break label69;
                              case 1702184318:
                                 break;
                              case 1710856104:
                              default:
                                 throw new IOException();
                           }
                        }
                     }
                  } else {
                     label84:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                           case 25690734:
                              break;
                           case 196760000:
                              var90 ^= 1142764569;
                           case 2015540172:
                              break label84;
                           case 2118890076:
                           default:
                              throw new IOException();
                        }
                     }
                  }

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
                        case 93705150:
                           continue label102;
                        case 129125578:
                           var90 ^= 1465837644;
                           continue label102;
                        case 635168349:
                        default:
                           throw new IOException();
                        case 1200991082:
                     }
                  }
               }
            } else {
               var90 = ikvhelxszusztfmq(var90, 180615669);
            }

         }
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var90)) {
               case 46308812:
                  var90 = 1104092981 ^ var90;
                  return;
               case 284348124:
                  return;
               case 779512024:
                  break;
               case 1685628893:
               default:
                  throw new IOException();
            }
         }
      }
   }

   public void open() {
      int var12 = 535069024 ^ 1850448163 ^ 184797776;
      var12 = 556505277 ^ var12;
      Player var4 = this.leader;
      Inventory var7 = this.createInventory();
      var4.openInventory(var7);
      var12 = 701476974 ^ var12;
      oOoOKo0o0K var6 = oOoOKo0o0K.getInstance();
      Inventory var9 = this.inv;
      var6.register(var9, this);
      var12 = 1852214524 ^ var12;
   }

   static {
      int var4 = 1479227243 ^ 571832979 ^ Integer.parseInt("499846223");
      nrruqklmno = wxchjneigpggllb();
      var4 = 1384509544 ^ var4;
      String var0 = gqltdluiwu(keumwtmixgtdpgb(), var4);
      o0KoOo0o0oOK var1 = o0KoOo0o0oOK.of(var0);
      GUI = var1;
   }

   public static String gqltdluiwu(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = nrruqklmno;
         byte[] var34 = nrruqklmno;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] wxchjneigpggllb() {
      return new byte[]{6, 25, 41, 103, 42, 86, 54, 62, 50, 1, 22, 120, 99, 93, 18, 93, 2, 71, 87, 93, 23, 17, 47, 105, 110, 109, 29, 59, 22, 32, 30, 98, 123, 107, 3, 119, 105, 45, 20, 1, 125, 44, 60, 82, 52, 120, 103, 26};
   }

   private static byte[] keumwtmixgtdpgb() {
      return new byte[]{-64, -33, 31, 53, 29, 27, 6, 102, 7, 74, 47, 97, 86, 30, 42, 8, 51, 19, 111, 9, 33, 87, 24, 126, 94, 55, 40, 106, 47, 117, 43, 62, 67, 56, 50, 45, 81, 122, 34, 82, 74, 125, 12, 17, 1, 45, 94, 75, 51, 91, 17, 62};
   }

   private static byte[] cqzblxmmvztyqnb() {
      return new byte[]{-55, -33, 26, 60, 18, 7, 4, 97, 4, 83, 39, 36, 80, 25, 42, 68, 48, 2, 97, 12, 38, 91, 28, 114, 86, 50, 47, 96, 32, 115, 47, 48, 72, 56, 59, 39};
   }

   private static byte[] bpbwekxtfkmhtwn() {
      return new byte[]{-55, -33, 26, 119, 18, 85, 4, 92, 4, 93, 39, 32, 80, 18, 42, 12, 48, 7, 97, 77, 38, 11, 28, 109, 86, 106, 47, 48, 32, 41, 47, 29, 72, 27, 59, 102, 91, 111, 34, 93, 76, 116, 15, 29, 12, 41, 85, 90, 48, 12, 24, 126, 25, 70, 14, 61, 0, 68, 32, 41, 82, 23, 33, 75, 58, 24, 101, 6, 33, 66, 30, 59, 93, 62, 37, 107, 36, 50, 40, 52, 74, 32, 48, 46, 81, 116, 38, 19, 75, 104, 13, 3, 7, 43, 95, 14, 52, 95, 31, 50, 27, 14, 5, 101};
   }

   private static byte[] vzlikkokmkrbrfq() {
      return new byte[]{-55, -33, 26, 116, 18, 18, 4, 96, 4, 80, 39, 56, 80, 14, 42, 27, 48, 80};
   }

   private static byte[] igxprmrvousrndh() {
      return new byte[]{-55, -33, 16, 44, 26, 10, 15, 115, 7, 25, 39, 54, 90, 10, 34, 28, 59, 26, 98, 69, 38, 67, 22, 50, 94, 61, 36, 104, 35, 112, 47, 63};
   }

   private static byte[] abgqfzobzrfgvjg() {
      return new byte[]{-55, -33, 16, 115, 26, 82, 15, 95, 7, 91, 39, 52, 90, 79, 34, 25, 59, 26, 98, 26, 38, 77, 22, 123, 94, 53, 36, 106, 35, 118, 47, 48, 66, 60, 51, 32, 80, 53, 33, 82, 76, 103, 5, 15, 4, 38, 94, 2, 51, 88, 24, 54, 19, 1, 6, 45, 11, 77, 35, 40, 82, 5, 43, 2};
   }

   private static byte[] khlkamlmvtionwy() {
      return new byte[]{-55, -47, 7, 85, 2, 111, 5, 127, -95, 0, 37, 37, 82, -21, 58, 102, 51, 82, 126, 103, 36, 76, 1, 91, 70, 80};
   }

   private static byte[] rvlwbeerhniabmn() {
      return new byte[]{-55, -47, 26, 116, 31, 16, 7, 103, 6, 81, 39, 54, 80, 14, 39, 25, 51, 87};
   }

   private static byte[] rljmqfazcbbciql() {
      return new byte[]{-55, -34, 16, 55, 29, 13, 0, 99, 2, 84, 39, 41, 90, 28, 37, 4};
   }

   private static byte[] lhohunnzdeyjgnk() {
      return new byte[]{-55, -34, 16, 55, 29, 13, 0, 99, 2, 84, 39, 41, 90, 28, 37, 4};
   }

   private static byte[] znrcyotolpwlrog() {
      return new byte[]{-55, -34, 16, 119, 29, 81, 0, 76, 2, 116, 39, 6, 90, 94, 37, 89, 41, 112, 122, 97, 36, 93, -79, 106, 91, 51, 41, -120, 59, 30};
   }

   private static byte[] uziyupoisbzzltz() {
      return new byte[]{-55, -34, 16, 114, 29, 4, 0, 78, 2, 94, 39, 41, 90, 13, 37, 2, 52, 84, 103, 26, 38, 70, 22, 122, 89, 50, 43, 97, 38, 112, 47, 49};
   }

   private static byte[] zmmtujimrrjdqna() {
      return new byte[]{-50, -34, 24, 118, 18, 23, 1, 96, 4, 88, 39, 53, 91, 9, 37, 29, 52, 90};
   }

   private static byte[] jeefkixnomwloli() {
      return new byte[]{-55, -33, 30, 42, 19, 6, 3, 121, 6, 87, 47, 42, 90, 16};
   }

   private static byte[] wlytytxfjkilupy() {
      return new byte[]{-55, -33, 30, 42, 19, 6, 3, 121, 6, 87, 47, 42, 90, 16};
   }

   private static byte[] dmhazabgrnfhspf() {
      return new byte[]{-55, -33, 30, 125, 19, 33, 3, 77, 6, 1, 47, 11, 90, 85, 35, 44, 55, 86, 102, 20, 32, 68, 22, 57, 91, 33, 41, 111, 47, 101, 39, 126};
   }

   private static byte[] jrqypyjjsqevstx() {
      return new byte[]{-55, -33, 30, 123, 19, 23, 3, 103, 6, 81, 47, 54, 90, 1, 35, 26, 55, 86};
   }

   private static byte[] hbctjrwejnzkkac() {
      return new byte[]{-55, -44, 29, 61, 18, 1, 15, 101, 1, 81, 39, 47, 87, 8};
   }

   private static byte[] wuzfuisbkhagqsq() {
      return new byte[]{-55, -44, 29, 61, 18, 1, 15, 101, 1, 81, 39, 47, 87, 8};
   }

   private static byte[] hpwqxacndmkjhwf() {
      return new byte[]{-55, -44, 29, 125, 18, 38, 15, 77, 1, 3, 39, 14, 87, 85, 42, 47, 38, 118, 121, 110, 36, 87, 6, 84, 75, 92, 38, -111};
   }

   private static byte[] baxhqzgdbhufovt() {
      return new byte[]{-55, -44, 29, 120, 18, 6, 15, 72, 1, 94, 39, 35, 87, 7, 42, 0, 59, 82, 100, 26, 38, 76, 27, 112, 86, 56, 36, 111, 37, 125, 47, 51, 79, 55, 59, 45};
   }

   private static byte[] wzrugjfgptilewr() {
      return new byte[]{-63, -45, 30, 123, 19, 19, 3, 96, 5, 89, 35, 54, 90, 1, 39, 26, 48, 85};
   }

   private static byte[] vauwdbcctvnsvoy() {
      return new byte[]{-55, -46, 31, 57, 28, 9, 0, 107, 3, 95, 39, 41, 85, 12};
   }

   private static byte[] jqeuqdmzcwsdgic() {
      return new byte[]{-55, -46, 31, 116, 28, 87, 0, 69, 3, 81, 39, 33, 85, 10, 36, 14, 52, 3, 102, 72, 38, 78, 25, 53, 88, 56, 43, 102, 39, 112, 47, 50};
   }

   private static byte[] ztrgzamkugakqhe() {
      return new byte[]{-55, -46, 31, 119, 28, 16, 0, 100, 3, 85, 39, 53, 85, 13, 36, 25, 52, 84};
   }

   private static int ikvhelxszusztfmq(int var0, int var1) {
      return var0 ^ var1;
   }
}
