package org.mz.donutsmpcore.teams;

import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryView;
import skido.KKoOoOo0oOK;
import skido.Ko0Ko0oOoOK;

public class TeamService2 {
   private static TeamService2 instance;
   private final Map<String, TeamService> teams;
   private final Map<UUID, String> playerTeam;
   private static String gfbkkutmpu;

   public TeamService2() {
      ConcurrentHashMap var2 = new ConcurrentHashMap();
      this.teams = var2;
      ConcurrentHashMap var5 = new ConcurrentHashMap();
      this.playerTeam = var5;
   }

   public static TeamService2 getInstance() {
      TeamService2 var0 = instance;
      if (var0 == null) {
         TeamService2 var1 = new TeamService2();
         instance = var1;
      }

      TeamService2 var2 = instance;
      return var2;
   }

   public TeamService createTeam(String var1, UUID var2) {
      TeamService var3 = new TeamService(var1, var2);
      Map var8 = this.teams;
      String var16 = var3.getName();
      var8.put(var16, var3);
      Map var11 = this.playerTeam;
      String var22 = var3.getName();
      var11.put(var2, var22);
      KKoOoOo0oOK var13 = KKoOoOo0oOK.getInstance();
      Runnable var19 = () -> {
         this.saveTeamToDb(var3);
         String var10 = var3.getName();
         this.saveMemberToDb(var10, var2);
         String var8 = var3.getName();
         boolean var12 = false;
         TeamSyncBridge.publishTeamChanged(var8, var2, var12);
      };
      var13.runAsync(var19);
      return var3;
   }

   public TeamService getTeam(String var1) {
      Map var4 = this.teams;
      String var7 = var1.toLowerCase();
      Object var5 = var4.get(var7);
      TeamService var6 = (TeamService)var5;
      return var6;
   }

   public TeamService getTeamByPlayer(UUID var1) {
      Map var5 = this.playerTeam;
      Object var6 = var5.get(var1);
      String var7 = (String)var6;
      TeamService var12;
      if (var7 == null) {
         var12 = null;
      } else {
         Map var10 = this.teams;
         Object var11 = var10.get(var7);
         var12 = (TeamService)var11;
      }

      return var12;
   }

   public boolean isInTeam(UUID var1) {
      Map var4 = this.playerTeam;
      boolean var5 = var4.containsKey(var1);
      return var5;
   }

   public void joinTeam(UUID var1, TeamService var2) {
      Map var7 = this.playerTeam;
      String var16 = var2.getName();
      var7.put(var1, var16);
      Set var10 = var2.getMembers();
      var10.add(var1);
      KKoOoOo0oOK var12 = KKoOoOo0oOK.getInstance();
      Runnable var15 = () -> {
         String var8 = var2.getName();
         this.saveMemberToDb(var8, var1);
         String var7 = var2.getName();
         boolean var10 = false;
         TeamSyncBridge.publishTeamChanged(var7, var1, var10);
      };
      var12.runAsync(var15);
   }

   public void leaveTeam(UUID var1) {
      Map var7 = this.playerTeam;
      Object var8 = var7.remove(var1);
      String var9 = (String)var8;
      if (var9 != null) {
         Map var12 = this.teams;
         Object var13 = var12.get(var9);
         TeamService var14 = (TeamService)var13;
         if (var14 != null) {
            Set var17 = var14.getMembers();
            var17.remove(var1);
            Set var20 = var14.getTeamChatEnabled();
            var20.remove(var1);
         }

         KKoOoOo0oOK var22 = KKoOoOo0oOK.getInstance();
         Runnable var27 = () -> {
            try {
               Connection var2 = Ko0Ko0oOoOK.getConnection();
               Connection var5 = var2;

               try {
                  String var3 = lqgoptmhew(jqpfzmomxovudjq(), 1280192421);
                  PreparedStatement var10 = var5.prepareStatement(var3);
                  PreparedStatement var6 = var10;

                  try {
                     byte var48 = 1;
                     var6.setString(var48, var9);
                     byte var49 = 2;
                     String var61 = var1.toString();
                     var6.setString(var49, var61);
                     int var14 = var6.executeUpdate();
                  } catch (Throwable var76) {
                     if (var10 != null) {
                        try {
                           var6.close();
                        } catch (Throwable var74) {
                           var76.addSuppressed(var74);
                        }
                     }

                     throw var76;
                  }

                  if (var10 != null) {
                     var10.close();
                  }

                  String var50 = lqgoptmhew(mhtgscnaogmbwxy(), 927019331);
                  PreparedStatement var18 = var5.prepareStatement(var50);
                  PreparedStatement var67 = var18;

                  try {
                     byte var51 = 1;
                     var67.setString(var51, var9);
                     byte var52 = 2;
                     String var64 = var1.toString();
                     var67.setString(var52, var64);
                     int var22 = var67.executeUpdate();
                  } catch (Throwable var75) {
                     if (var18 != null) {
                        try {
                           var67.close();
                        } catch (Throwable var73) {
                           var75.addSuppressed(var73);
                        }
                     }

                     throw var75;
                  }

                  if (var18 != null) {
                     var18.close();
                  }
               } catch (Throwable var77) {
                  if (var2 != null) {
                     try {
                        var5.close();
                     } catch (Throwable var72) {
                        var77.addSuppressed(var72);
                     }
                  }

                  throw var77;
               }

               if (var2 != null) {
                  var2.close();
               }
            } catch (SQLException var78) {
               Logger var36 = Bukkit.getLogger();
               String var56 = var78.getMessage();
               String var57 = "[DonutTeams] Failed to remove member from DB: " + var56;
               var36.warning(var57);
            }

            boolean var65 = false;
            TeamSyncBridge.publishTeamChanged(var9, var1, var65);
         };
         var22.runAsync(var27);
      }

   }

   public void disbandTeam(TeamService var1) {
      String var7 = var1.getName();
      Set var9 = var1.getMembers();
      Iterator var10 = var9.iterator();
      Iterator var5 = var10;

      while(true) {
         boolean var12 = var5.hasNext();
         if (!var12) {
            Set var20 = var1.getTeamChatEnabled();
            var20.clear();
            Map var22 = this.teams;
            var22.remove(var7);
            KKoOoOo0oOK var24 = KKoOoOo0oOK.getInstance();
            Runnable var27 = () -> {
               try {
                  Connection var1 = Ko0Ko0oOoOK.getConnection();
                  Connection var4 = var1;

                  try {
                     String var2 = lqgoptmhew(unsruoggajtmwue(), 93041337);
                     PreparedStatement var9 = var4.prepareStatement(var2);
                     PreparedStatement var5 = var9;

                     try {
                        byte var58 = 1;
                        var5.setString(var58, var7);
                        int var12 = var5.executeUpdate();
                     } catch (Throwable var89) {
                        if (var9 != null) {
                           try {
                              var5.close();
                           } catch (Throwable var86) {
                              var89.addSuppressed(var86);
                           }
                        }

                        throw var89;
                     }

                     if (var9 != null) {
                        var9.close();
                     }

                     String var59 = lqgoptmhew(bhqhveykjvbuvxo(), 1873615095);
                     PreparedStatement var16 = var4.prepareStatement(var59);
                     PreparedStatement var75 = var16;

                     try {
                        byte var60 = 1;
                        var75.setString(var60, var7);
                        int var19 = var75.executeUpdate();
                     } catch (Throwable var88) {
                        if (var16 != null) {
                           try {
                              var75.close();
                           } catch (Throwable var85) {
                              var88.addSuppressed(var85);
                           }
                        }

                        throw var88;
                     }

                     if (var16 != null) {
                        var16.close();
                     }

                     String var61 = lqgoptmhew(oqnnhfujpqpsmsm(), 423833475);
                     PreparedStatement var23 = var4.prepareStatement(var61);
                     PreparedStatement var76 = var23;

                     try {
                        byte var62 = 1;
                        var76.setString(var62, var7);
                        int var26 = var76.executeUpdate();
                     } catch (Throwable var87) {
                        if (var23 != null) {
                           try {
                              var76.close();
                           } catch (Throwable var84) {
                              var87.addSuppressed(var84);
                           }
                        }

                        throw var87;
                     }

                     if (var23 != null) {
                        var23.close();
                     }
                  } catch (Throwable var90) {
                     if (var1 != null) {
                        try {
                           var4.close();
                        } catch (Throwable var83) {
                           var90.addSuppressed(var83);
                        }
                     }

                     throw var90;
                  }

                  if (var1 != null) {
                     var1.close();
                  }
               } catch (SQLException var91) {
                  Logger var36 = Bukkit.getLogger();
                  String var64 = var91.getMessage();
                  String var65 = "[DonutTeams] Failed to disband team from DB: " + var64;
                  var36.warning(var65);
               }

               Object var66 = null;
               boolean var73 = true;
               TeamSyncBridge.publishTeamChanged(var7, (UUID)var66, var73);
            };
            var24.runAsync(var27);
            return;
         }

         Object var14 = var5.next();
         UUID var15 = (UUID)var14;
         Map var17 = this.playerTeam;
         var17.remove(var15);
      }
   }

   public void kickFromTeam(TeamService var1, UUID var2) {
      Set var6 = var1.getMembers();
      var6.remove(var2);
      Set var9 = var1.getTeamChatEnabled();
      var9.remove(var2);
      Map var12 = this.playerTeam;
      var12.remove(var2);
      KKoOoOo0oOK var14 = KKoOoOo0oOK.getInstance();
      Runnable var18 = () -> {
         try {
            Connection var2x = Ko0Ko0oOoOK.getConnection();
            Connection var5 = var2x;

            try {
               String var3 = lqgoptmhew(svkpqngrxuujzom(), 585546275);
               PreparedStatement var10 = var5.prepareStatement(var3);
               PreparedStatement var6 = var10;

               try {
                  byte var49 = 1;
                  String var61 = var1.getName();
                  var6.setString(var49, var61);
                  byte var50 = 2;
                  String var63 = var2.toString();
                  var6.setString(var50, var63);
                  int var14 = var6.executeUpdate();
               } catch (Throwable var79) {
                  if (var10 != null) {
                     try {
                        var6.close();
                     } catch (Throwable var77) {
                        var79.addSuppressed(var77);
                     }
                  }

                  throw var79;
               }

               if (var10 != null) {
                  var10.close();
               }

               String var57 = lqgoptmhew(yzgtbfprmjohmpf(), 1231878959);
               PreparedStatement var34 = var5.prepareStatement(var57);
               PreparedStatement var71 = var34;

               try {
                  byte var58 = 1;
                  String var66 = var1.getName();
                  var71.setString(var58, var66);
                  byte var59 = 2;
                  String var68 = var2.toString();
                  var71.setString(var59, var68);
                  int var38 = var71.executeUpdate();
               } catch (Throwable var78) {
                  if (var34 != null) {
                     try {
                        var71.close();
                     } catch (Throwable var76) {
                        var78.addSuppressed(var76);
                     }
                  }

                  throw var78;
               }

               if (var34 != null) {
                  var34.close();
               }
            } catch (Throwable var80) {
               if (var2x != null) {
                  try {
                     var5.close();
                  } catch (Throwable var75) {
                     var80.addSuppressed(var75);
                  }
               }

               throw var80;
            }

            if (var2x != null) {
               var2x.close();
            }
         } catch (SQLException var81) {
            Logger var24 = Bukkit.getLogger();
            String var52 = var81.getMessage();
            String var53 = "[DonutTeams] Failed to kick member from DB: " + var52;
            var24.warning(var53);
         }

         String var26 = var1.getName();
         boolean var64 = false;
         TeamSyncBridge.publishTeamChanged(var26, var2, var64);
      };
      var14.runAsync(var18);
   }

   public void reloadTeam(String var1) {
      if (var1 != null) {
         String var39 = var1.toLowerCase();
         String var16 = var39;
         Map var41 = this.playerTeam;
         Set var42 = var41.entrySet();
         Predicate var228 = (var1x) -> {
            Object var4 = var1x.getValue();
            boolean var9;
            if (var4 != null) {
               Object var6 = var1x.getValue();
               String var7 = (String)var6;
               boolean var8 = var7.equalsIgnoreCase(var39);
               if (var8) {
                  var9 = true;
                  return var9;
               }
            }

            var9 = false;
            return var9;
         };
         var42.removeIf(var228);

         try {
            Connection var44 = Ko0Ko0oOoOK.getConnection();
            Connection var17 = var44;

            label267: {
               try {
                  Object var45 = null;
                  TeamService var18 = (TeamService)var45;
                  String var229 = lqgoptmhew(apipcxsulwhmvgw(), 1124024125);
                  PreparedStatement var47 = var17.prepareStatement(var229);
                  PreparedStatement var19 = var47;

                  try {
                     byte var230 = 1;
                     var19.setString(var230, var16);
                     ResultSet var50 = var19.executeQuery();
                     ResultSet var20 = var50;

                     try {
                        boolean var52 = var20.next();
                        if (var52) {
                           String var231 = lqgoptmhew(urtsbrvspvvvrcw(), 787295882);
                           String var54 = var20.getString(var231);
                           String var232 = lqgoptmhew(toejhdymrepbiff(), 350238203);
                           String var56 = var20.getString(var232);
                           String var233 = lqgoptmhew(jfxjxofvjrczyce(), 12625180);
                           String var58 = var20.getString(var233);
                           UUID var59 = UUID.fromString(var58);
                           String var234 = lqgoptmhew(szjsfjqoditnthy(), 608346977);
                           long var61 = var20.getLong(var234);
                           long var24 = var61;
                           String var235 = lqgoptmhew(hyuseowrmcewigq(), 1409032219);
                           boolean var64 = var20.getBoolean(var235);
                           TeamService var65 = new TeamService(var54, var59);
                           var18 = var65;
                           if (var56 != null) {
                              boolean var68 = var56.isEmpty();
                              if (!var68) {
                                 var65.setDisplayName(var56);
                              }
                           }

                           try {
                              Class var70 = TeamService.class;
                              String var237 = lqgoptmhew(qxcinvipmbtrmyg(), 865051612);
                              Field var71 = var70.getDeclaredField(var237);
                              boolean var238 = true;
                              var71.setAccessible(var238);
                              var71.setLong(var18, var24);
                           } catch (Exception var330) {
                           }

                           var65.setPvpEnabled(var64);
                           String var241 = lqgoptmhew(fqnqfriezxxxwgz(), 927293925);
                           String var76 = var20.getString(var241);
                           if (var76 != null) {
                              boolean var79 = var20.wasNull();
                              if (!var79) {
                                 String var242 = lqgoptmhew(ldjvierjohsgwod(), 59695476);
                                 double var81 = var20.getDouble(var242);
                                 String var243 = lqgoptmhew(qpjftoayweiqswz(), 1341592291);
                                 double var84 = var20.getDouble(var243);
                                 String var244 = lqgoptmhew(zquujimxykvjgdo(), 223461054);
                                 double var87 = var20.getDouble(var244);
                                 String var245 = lqgoptmhew(rhobiccgfqqwatw(), 1140492105);
                                 float var90 = var20.getFloat(var245);
                                 String var246 = lqgoptmhew(ahlkvjjdjqzjlvv(), 592270141);
                                 float var92 = var20.getFloat(var246);
                                 Object var93 = null;
                                 String var36 = (String)var93;

                                 try {
                                    String var247 = lqgoptmhew(fmfbmmtbpxvpsyf(), 1621180772);
                                    String var95 = var20.getString(var247);
                                    var36 = var95;
                                 } catch (SQLException var329) {
                                 }

                                 var65.setTeamHomeWorld(var76);
                                 var65.setTeamHomeCoords(var81, var84, var87, var90, var92);
                                 World var99 = Bukkit.getWorld(var76);
                                 if (var99 != null) {
                                    Location var251 = new Location(var99, var81, var84, var87, var90, var92);
                                    var65.setTeamHome(var251);
                                 }

                                 var65.setTeamHomeServer(var36);
                              }
                           }
                        }
                     } catch (Throwable var331) {
                        if (var50 != null) {
                           try {
                              var20.close();
                           } catch (Throwable var328) {
                              var331.addSuppressed(var328);
                           }
                        }

                        throw var331;
                     }

                     if (var50 != null) {
                        var50.close();
                     }
                  } catch (Throwable var332) {
                     if (var47 != null) {
                        try {
                           var19.close();
                        } catch (Throwable var327) {
                           var332.addSuppressed(var327);
                        }
                     }

                     throw var332;
                  }

                  if (var47 != null) {
                     var47.close();
                  }

                  if (var18 == null) {
                     Map var109 = this.teams;
                     var109.remove(var16);
                     break label267;
                  }

                  Map var122 = this.teams;
                  var122.put(var16, var18);
                  String var258 = lqgoptmhew(clzfqcvssinijkh(), 1142902807);
                  PreparedStatement var125 = var17.prepareStatement(var258);
                  PreparedStatement var301 = var125;

                  try {
                     byte var259 = 1;
                     var301.setString(var259, var16);
                     ResultSet var128 = var301.executeQuery();
                     ResultSet var303 = var128;

                     try {
                        while(true) {
                           boolean var130 = var303.next();
                           if (!var130) {
                              break;
                           }

                           String var260 = lqgoptmhew(hxmrdjmqiqnypxc(), 1445050753);
                           String var132 = var303.getString(var260);
                           UUID var133 = UUID.fromString(var132);
                           Set var135 = var18.getMembers();
                           var135.add(var133);
                           Map var138 = this.playerTeam;
                           var138.put(var133, var16);
                        }
                     } catch (Throwable var333) {
                        if (var128 != null) {
                           try {
                              var303.close();
                           } catch (Throwable var326) {
                              var333.addSuppressed(var326);
                           }
                        }

                        throw var333;
                     }

                     if (var303 != null) {
                        var303.close();
                     }
                  } catch (Throwable var334) {
                     if (var125 != null) {
                        try {
                           var301.close();
                        } catch (Throwable var325) {
                           var334.addSuppressed(var325);
                        }
                     }

                     throw var334;
                  }

                  if (var125 != null) {
                     var125.close();
                  }

                  String var265 = lqgoptmhew(ffwrvshapoaqjhf(), 1576235546);
                  PreparedStatement var157 = var17.prepareStatement(var265);
                  PreparedStatement var302 = var157;

                  try {
                     byte var266 = 1;
                     var302.setString(var266, var16);
                     ResultSet var160 = var302.executeQuery();
                     ResultSet var305 = var160;

                     try {
                        while(true) {
                           boolean var162 = var305.next();
                           if (!var162) {
                              break;
                           }

                           String var267 = lqgoptmhew(sfwfxzlbvbjjuuq(), 1347128575);
                           String var164 = var305.getString(var267);
                           UUID var165 = UUID.fromString(var164);
                           String var268 = lqgoptmhew(vqhrsjlugtqwdsx(), 1066355026);
                           boolean var167 = var305.getBoolean(var268);
                           if (var167) {
                              Set var169 = var18.getCanInvite();
                              var169.add(var165);
                           }

                           String var270 = lqgoptmhew(ikwswkbijvyvlyw(), 1962240075);
                           boolean var172 = var305.getBoolean(var270);
                           if (var172) {
                              Set var174 = var18.getCanKick();
                              var174.add(var165);
                           }

                           String var272 = lqgoptmhew(lmnxhnzdmujealr(), 1864503009);
                           boolean var177 = var305.getBoolean(var272);
                           if (var177) {
                              Set var179 = var18.getCanTogglePvP();
                              var179.add(var165);
                           }

                           String var274 = lqgoptmhew(culsdqljshtwmnt(), 762991730);
                           boolean var182 = var305.getBoolean(var274);
                           if (var182) {
                              Set var184 = var18.getCanSetHome();
                              var184.add(var165);
                           }

                           String var276 = lqgoptmhew(gshephoelmluefx(), 56078540);
                           boolean var187 = var305.getBoolean(var276);
                           if (var187) {
                              Set var189 = var18.getCanVisitHome();
                              var189.add(var165);
                           }

                           String var278 = lqgoptmhew(adoskrwltxwqvbx(), 2108776876);
                           boolean var192 = var305.getBoolean(var278);
                           if (var192) {
                              Set var194 = var18.getTeamChatEnabled();
                              var194.add(var165);
                           }
                        }
                     } catch (Throwable var335) {
                        if (var160 != null) {
                           try {
                              var305.close();
                           } catch (Throwable var324) {
                              var335.addSuppressed(var324);
                           }
                        }

                        throw var335;
                     }

                     if (var305 != null) {
                        var305.close();
                     }
                  } catch (Throwable var336) {
                     if (var157 != null) {
                        try {
                           var302.close();
                        } catch (Throwable var323) {
                           var336.addSuppressed(var323);
                        }
                     }

                     throw var336;
                  }

                  if (var157 != null) {
                     var157.close();
                  }
               } catch (Throwable var337) {
                  if (var44 != null) {
                     try {
                        var17.close();
                     } catch (Throwable var322) {
                        var337.addSuppressed(var322);
                     }
                  }

                  throw var337;
               }

               if (var44 != null) {
                  var44.close();
               }

               return;
            }

            if (var44 != null) {
               var44.close();
            }

         } catch (SQLException var338) {
            Logger var114 = Bukkit.getLogger();
            String var288 = var338.getMessage();
            String var255 = "[DonutTeams] reloadTeam(" + var39 + ") failed: " + var288;
            var114.warning(var255);
         }
      }
   }

   public void dropTeamFromCache(String var1) {
      if (var1 != null) {
         String var10 = var1.toLowerCase();
         String var5 = var10;
         Map var12 = this.teams;
         Object var13 = var12.remove(var10);
         TeamService var14 = (TeamService)var13;
         if (var14 != null) {
            Set var17 = var14.getMembers();
            Iterator var18 = var17.iterator();
            Iterator var7 = var18;

            while(true) {
               boolean var20 = var7.hasNext();
               if (!var20) {
                  break;
               }

               Object var26 = var7.next();
               UUID var27 = (UUID)var26;
               Map var29 = this.playerTeam;
               var29.remove(var27, var5);
            }
         }

         Map var22 = this.playerTeam;
         Set var23 = var22.entrySet();
         Predicate var32 = (var1x) -> {
            Object var5x = var1x.getValue();
            boolean var4 = var5.equals(var5x);
            return var4;
         };
         var23.removeIf(var32);
      }
   }

   private void saveTeamToDb(TeamService var1) {
      try {
         Connection var2 = Ko0Ko0oOoOK.getConnection();
         Connection var5 = var2;

         try {
            boolean var10 = Ko0Ko0oOoOK.isMySql();
            String var63;
            if (var10) {
               var63 = lqgoptmhew(hjwzlhhuurozsgb(), 1594088464);
            } else {
               var63 = lqgoptmhew(zlzshfckzplfljv(), 1461432150);
            }

            PreparedStatement var12 = var5.prepareStatement(var63);
            PreparedStatement var7 = var12;

            try {
               label57: {
                  byte var64 = 1;
                  String var91 = var1.getName();
                  var7.setString(var64, var91);
                  byte var65 = 2;
                  String var93 = var1.getRawDisplayName();
                  var7.setString(var65, var93);
                  byte var66 = 3;
                  UUID var95 = var1.getLeader();
                  String var96 = var95.toString();
                  var7.setString(var66, var96);
                  byte var67 = 4;
                  long var98 = var1.getCreatedAt();
                  var7.setLong(var67, var98);
                  byte var68 = 5;
                  boolean var101 = var1.isPvpEnabled();
                  var7.setBoolean(var68, var101);
                  boolean var19 = var1.hasTeamHome();
                  if (var19) {
                     String var21 = var1.getTeamHomeWorld();
                     if (var21 != null) {
                        byte var69 = 6;
                        String var103 = var1.getTeamHomeWorld();
                        var7.setString(var69, var103);
                        Location var24 = var1.getTeamHome();
                        if (var24 != null) {
                           Location var26 = var1.getTeamHome();
                           byte var70 = 7;
                           double var105 = var26.getX();
                           var7.setDouble(var70, var105);
                           byte var71 = 8;
                           double var108 = var26.getY();
                           var7.setDouble(var71, var108);
                           byte var72 = 9;
                           double var111 = var26.getZ();
                           var7.setDouble(var72, var111);
                           byte var73 = 10;
                           float var114 = var26.getYaw();
                           var7.setFloat(var73, var114);
                           byte var74 = 11;
                           float var116 = var26.getPitch();
                           var7.setFloat(var74, var116);
                        } else {
                           byte var80 = 7;
                           double var118 = var1.getTeamHomeX();
                           var7.setDouble(var80, var118);
                           byte var81 = 8;
                           double var121 = var1.getTeamHomeY();
                           var7.setDouble(var81, var121);
                           byte var82 = 9;
                           double var124 = var1.getTeamHomeZ();
                           var7.setDouble(var82, var124);
                           byte var83 = 10;
                           float var127 = var1.getTeamHomeYaw();
                           var7.setFloat(var83, var127);
                           byte var84 = 11;
                           float var129 = var1.getTeamHomePitch();
                           var7.setFloat(var84, var129);
                        }
                        break label57;
                     }
                  }

                  byte var85 = 6;
                  byte var130 = 12;
                  var7.setNull(var85, var130);
                  byte var86 = 7;
                  byte var131 = 8;
                  var7.setNull(var86, var131);
                  byte var87 = 8;
                  byte var132 = 8;
                  var7.setNull(var87, var132);
                  byte var88 = 9;
                  byte var133 = 8;
                  var7.setNull(var88, var133);
                  byte var89 = 10;
                  byte var134 = 6;
                  var7.setNull(var89, var134);
                  byte var90 = 11;
                  byte var135 = 6;
                  var7.setNull(var90, var135);
               }

               int var33 = var7.executeUpdate();
            } catch (Throwable var142) {
               if (var12 != null) {
                  try {
                     var7.close();
                  } catch (Throwable var141) {
                     var142.addSuppressed(var141);
                  }
               }

               throw var142;
            }

            if (var12 != null) {
               var12.close();
            }
         } catch (Throwable var143) {
            if (var2 != null) {
               try {
                  var5.close();
               } catch (Throwable var140) {
                  var143.addSuppressed(var140);
               }
            }

            throw var143;
         }

         if (var2 != null) {
            var2.close();
         }
      } catch (SQLException var144) {
         Logger var39 = Bukkit.getLogger();
         String var76 = var144.getMessage();
         String var77 = "[DonutTeams] Failed to save team to DB: " + var76;
         var39.warning(var77);
      }

   }

   private void saveMemberToDb(String var1, UUID var2) {
      try {
         Connection var3 = Ko0Ko0oOoOK.getConnection();
         Connection var6 = var3;

         try {
            boolean var11 = Ko0Ko0oOoOK.isMySql();
            String var37;
            if (var11) {
               var37 = lqgoptmhew(sgedmctzvrusses(), 1317124053);
            } else {
               var37 = lqgoptmhew(ytimsogpisjvblg(), 1463591948);
            }

            PreparedStatement var13 = var6.prepareStatement(var37);
            PreparedStatement var8 = var13;

            try {
               byte var38 = 1;
               var8.setString(var38, var1);
               byte var39 = 2;
               String var47 = var2.toString();
               var8.setString(var39, var47);
               byte var40 = 3;
               long var48 = System.currentTimeMillis();
               var8.setLong(var40, var48);
               int var18 = var8.executeUpdate();
            } catch (Throwable var55) {
               if (var13 != null) {
                  try {
                     var8.close();
                  } catch (Throwable var54) {
                     var55.addSuppressed(var54);
                  }
               }

               throw var55;
            }

            if (var13 != null) {
               var13.close();
            }
         } catch (Throwable var56) {
            if (var3 != null) {
               try {
                  var6.close();
               } catch (Throwable var53) {
                  var56.addSuppressed(var53);
               }
            }

            throw var56;
         }

         if (var3 != null) {
            var3.close();
         }
      } catch (SQLException var57) {
         Logger var24 = Bukkit.getLogger();
         String var42 = var57.getMessage();
         String var43 = "[DonutTeams] Failed to save member to DB: " + var42;
         var24.warning(var43);
      }

   }

   public void saveTeamHome(TeamService var1) {
      KKoOoOo0oOK var2 = KKoOoOo0oOK.getInstance();
      Runnable var5 = () -> {
         Map var10 = this.teams;
         String var26 = var1.getName();
         String var27 = var26.toLowerCase();
         Object var11 = var10.get(var27);
         TeamService var12 = (TeamService)var11;
         if (var12 != null && var12 != var1) {
            Location var16 = var1.getTeamHome();
            if (var16 != null) {
               Location var30 = var1.getTeamHome();
               var12.setTeamHome(var30);
               String var32 = var1.getTeamHomeServer();
               var12.setTeamHomeServer(var32);
            } else {
               String var37 = var1.getTeamHomeServer();
               var12.setTeamHomeServer(var37);
               String var39 = var1.getTeamHomeWorld();
               var12.setTeamHomeWorld(var39);
               double var41 = var1.getTeamHomeX();
               double var43 = var1.getTeamHomeY();
               double var45 = var1.getTeamHomeZ();
               float var47 = var1.getTeamHomeYaw();
               float var48 = var1.getTeamHomePitch();
               var12.setTeamHomeCoords(var41, var43, var45, var47, var48);
            }
         }

         this.saveTeamMetaToDb(var1);
         this.saveTeamHomeToDb(var1);
         String var22 = var1.getName();
         Object var35 = null;
         boolean var4 = false;
         TeamSyncBridge.publishTeamChanged(var22, (UUID)var35, var4);
      };
      var2.runAsync(var5);
   }

   public void savePermissions(TeamService var1, UUID var2) {
      KKoOoOo0oOK var3 = KKoOoOo0oOK.getInstance();
      Runnable var6 = () -> {
         try {
            Connection var2x = Ko0Ko0oOoOK.getConnection();
            Connection var6 = var2x;

            try {
               String var11 = lqgoptmhew(dalybeykblivdqd(), 1604151415);
               PreparedStatement var13 = var6.prepareStatement(var11);
               PreparedStatement var8 = var13;

               try {
                  byte var44 = 1;
                  String var58 = var1.getName();
                  var8.setString(var44, var58);
                  byte var45 = 2;
                  String var60 = var2.toString();
                  var8.setString(var45, var60);
                  byte var46 = 3;
                  boolean var62 = var1.canInvite(var2);
                  var8.setBoolean(var46, var62);
                  byte var47 = 4;
                  boolean var64 = var1.canKick(var2);
                  var8.setBoolean(var47, var64);
                  byte var48 = 5;
                  boolean var66 = var1.canTogglePvP(var2);
                  var8.setBoolean(var48, var66);
                  byte var49 = 6;
                  boolean var68 = var1.canSetHome(var2);
                  var8.setBoolean(var49, var68);
                  byte var50 = 7;
                  boolean var70 = var1.canVisitHome(var2);
                  var8.setBoolean(var50, var70);
                  byte var51 = 8;
                  boolean var72 = var1.isTeamChatEnabled(var2);
                  var8.setBoolean(var51, var72);
                  int var23 = var8.executeUpdate();
               } catch (Throwable var84) {
                  if (var13 != null) {
                     try {
                        var8.close();
                     } catch (Throwable var83) {
                        var84.addSuppressed(var83);
                     }
                  }

                  throw var84;
               }

               if (var13 != null) {
                  var13.close();
               }
            } catch (Throwable var85) {
               if (var2x != null) {
                  try {
                     var6.close();
                  } catch (Throwable var82) {
                     var85.addSuppressed(var82);
                  }
               }

               throw var85;
            }

            if (var2x != null) {
               var2x.close();
            }
         } catch (SQLException var86) {
            Logger var31 = Bukkit.getLogger();
            String var54 = var86.getMessage();
            String var55 = "[DonutTeams] Failed to save permissions: " + var54;
            var31.warning(var55);
         }

         String var29 = var1.getName();
         boolean var73 = false;
         TeamSyncBridge.publishTeamChanged(var29, var2, var73);
      };
      var3.runAsync(var6);
   }

   public void savePvpToggle(TeamService var1) {
      KKoOoOo0oOK var2 = KKoOoOo0oOK.getInstance();
      Runnable var5 = () -> {
         this.saveTeamMetaToDb(var1);
         String var6 = var1.getName();
         Object var7 = null;
         boolean var4 = false;
         TeamSyncBridge.publishTeamChanged(var6, (UUID)var7, var4);
      };
      var2.runAsync(var5);
   }

   private void saveTeamMetaToDb(TeamService var1) {
      try {
         Connection var2 = Ko0Ko0oOoOK.getConnection();
         Connection var5 = var2;

         label101: {
            try {
               String var3 = lqgoptmhew(priaergzhkuwook(), 1978214587);
               PreparedStatement var10 = var5.prepareStatement(var3);
               PreparedStatement var6 = var10;

               label94: {
                  try {
                     byte var56 = 1;
                     String var72 = var1.getRawDisplayName();
                     var6.setString(var56, var72);
                     byte var57 = 2;
                     UUID var74 = var1.getLeader();
                     String var75 = var74.toString();
                     var6.setString(var57, var75);
                     byte var58 = 3;
                     boolean var77 = var1.isPvpEnabled();
                     var6.setBoolean(var58, var77);
                     byte var59 = 4;
                     String var79 = var1.getName();
                     var6.setString(var59, var79);
                     int var16 = var6.executeUpdate();
                     if (var16 <= 0) {
                        break label94;
                     }
                  } catch (Throwable var102) {
                     if (var10 != null) {
                        try {
                           var6.close();
                        } catch (Throwable var100) {
                           var102.addSuppressed(var100);
                        }
                     }

                     throw var102;
                  }

                  if (var10 != null) {
                     var10.close();
                  }
                  break label101;
               }

               if (var10 != null) {
                  var10.close();
               }

               String var60 = lqgoptmhew(cfhsykancfllacl(), 1348459657);
               PreparedStatement var20 = var5.prepareStatement(var60);
               PreparedStatement var93 = var20;

               try {
                  byte var61 = 1;
                  String var81 = var1.getName();
                  var93.setString(var61, var81);
                  byte var62 = 2;
                  String var83 = var1.getRawDisplayName();
                  var93.setString(var62, var83);
                  byte var63 = 3;
                  UUID var85 = var1.getLeader();
                  String var86 = var85.toString();
                  var93.setString(var63, var86);
                  byte var64 = 4;
                  long var88 = var1.getCreatedAt();
                  var93.setLong(var64, var88);
                  byte var65 = 5;
                  boolean var91 = var1.isPvpEnabled();
                  var93.setBoolean(var65, var91);
                  int var27 = var93.executeUpdate();
               } catch (Throwable var101) {
                  if (var20 != null) {
                     try {
                        var93.close();
                     } catch (Throwable var99) {
                        var101.addSuppressed(var99);
                     }
                  }

                  throw var101;
               }

               if (var20 != null) {
                  var20.close();
               }
            } catch (Throwable var103) {
               if (var2 != null) {
                  try {
                     var5.close();
                  } catch (Throwable var98) {
                     var103.addSuppressed(var98);
                  }
               }

               throw var103;
            }

            if (var2 != null) {
               var2.close();
            }

            return;
         }

         if (var2 != null) {
            var2.close();
         }

      } catch (SQLException var104) {
         Logger var33 = Bukkit.getLogger();
         String var67 = var104.getMessage();
         String var68 = "[DonutTeams] Failed to save team meta to DB: " + var67;
         var33.warning(var68);
      }
   }

   private void saveTeamHomeToDb(TeamService var1) {
      Map var10 = this.teams;
      String var67 = var1.getName();
      String var68 = var67.toLowerCase();
      Object var11 = var10.getOrDefault(var68, var1);
      TeamService var12 = (TeamService)var11;
      TeamService var5 = var12;

      try {
         Connection var13 = Ko0Ko0oOoOK.getConnection();
         Connection var6 = var13;

         try {
            String var69 = lqgoptmhew(cdkjeegfwazwmwp(), 1732136124);
            PreparedStatement var15 = var6.prepareStatement(var69);
            PreparedStatement var7 = var15;

            try {
               label63: {
                  boolean var17 = var5.hasTeamHome();
                  if (var17) {
                     String var19 = var5.getTeamHomeWorld();
                     if (var19 != null) {
                        byte var70 = 1;
                        String var96 = var5.getTeamHomeWorld();
                        var7.setString(var70, var96);
                        Location var22 = var5.getTeamHome();
                        if (var22 != null) {
                           byte var84 = 2;
                           double var116 = var22.getX();
                           var7.setDouble(var84, var116);
                           byte var85 = 3;
                           double var119 = var22.getY();
                           var7.setDouble(var85, var119);
                           byte var86 = 4;
                           double var122 = var22.getZ();
                           var7.setDouble(var86, var122);
                           byte var87 = 5;
                           float var125 = var22.getYaw();
                           var7.setFloat(var87, var125);
                           byte var88 = 6;
                           float var127 = var22.getPitch();
                           var7.setFloat(var88, var127);
                        } else {
                           byte var71 = 2;
                           double var98 = var5.getTeamHomeX();
                           var7.setDouble(var71, var98);
                           byte var72 = 3;
                           double var101 = var5.getTeamHomeY();
                           var7.setDouble(var72, var101);
                           byte var73 = 4;
                           double var104 = var5.getTeamHomeZ();
                           var7.setDouble(var73, var104);
                           byte var74 = 5;
                           float var107 = var5.getTeamHomeYaw();
                           var7.setFloat(var74, var107);
                           byte var75 = 6;
                           float var109 = var5.getTeamHomePitch();
                           var7.setFloat(var75, var109);
                        }
                        break label63;
                     }
                  }

                  byte var89 = 1;
                  byte var128 = 12;
                  var7.setNull(var89, var128);
                  byte var90 = 2;
                  byte var129 = 8;
                  var7.setNull(var90, var129);
                  byte var91 = 3;
                  byte var130 = 8;
                  var7.setNull(var91, var130);
                  byte var92 = 4;
                  byte var131 = 8;
                  var7.setNull(var92, var131);
                  byte var93 = 5;
                  byte var132 = 6;
                  var7.setNull(var93, var132);
                  byte var94 = 6;
                  byte var133 = 6;
                  var7.setNull(var94, var133);
               }

               label58: {
                  boolean var30 = var5.hasTeamHome();
                  if (var30) {
                     String var32 = var5.getTeamHomeServer();
                     if (var32 != null) {
                        byte var76 = 7;
                        String var111 = var5.getTeamHomeServer();
                        var7.setString(var76, var111);
                        break label58;
                     }
                  }

                  byte var83 = 7;
                  byte var114 = 12;
                  var7.setNull(var83, var114);
               }

               byte var77 = 8;
               String var113 = var5.getName();
               var7.setString(var77, var113);
               int var36 = var7.executeUpdate();
            } catch (Throwable var140) {
               if (var15 != null) {
                  try {
                     var7.close();
                  } catch (Throwable var139) {
                     var140.addSuppressed(var139);
                  }
               }

               throw var140;
            }

            if (var15 != null) {
               var15.close();
            }
         } catch (Throwable var141) {
            if (var13 != null) {
               try {
                  var6.close();
               } catch (Throwable var138) {
                  var141.addSuppressed(var138);
               }
            }

            throw var141;
         }

         if (var13 != null) {
            var13.close();
         }
      } catch (SQLException var142) {
         Logger var42 = Bukkit.getLogger();
         String var79 = var142.getMessage();
         String var80 = "[DonutTeams] Failed to save team home to DB: " + var79;
         var42.warning(var80);
      }

   }

   public void saveAllTeams() {
      Map var14 = this.teams;
      Collection var15 = var14.values();
      Iterator var16 = var15.iterator();
      Iterator var5 = var16;

      while(true) {
         boolean var18 = var5.hasNext();
         if (!var18) {
            return;
         }

         Object var20 = var5.next();
         TeamService var21 = (TeamService)var20;
         TeamService var6 = var21;
         this.saveTeamToDb(var21);
         Set var24 = var21.getMembers();
         Iterator var25 = var24.iterator();
         Iterator var7 = var25;

         while(true) {
            boolean var27 = var7.hasNext();
            if (!var27) {
               break;
            }

            Object var29 = var7.next();
            UUID var30 = (UUID)var29;
            UUID var8 = var30;
            String var65 = var6.getName();
            this.saveMemberToDb(var65, var30);

            try {
               Connection var32 = Ko0Ko0oOoOK.getConnection();
               Connection var9 = var32;

               try {
                  String var33 = lqgoptmhew(piynunlwprwcent(), 294774075);
                  PreparedStatement var35 = var9.prepareStatement(var33);
                  PreparedStatement var11 = var35;

                  try {
                     byte var67 = 1;
                     String var81 = var6.getName();
                     var11.setString(var67, var81);
                     byte var68 = 2;
                     String var83 = var8.toString();
                     var11.setString(var68, var83);
                     byte var69 = 3;
                     boolean var85 = var6.canInvite(var8);
                     var11.setBoolean(var69, var85);
                     byte var70 = 4;
                     boolean var87 = var6.canKick(var8);
                     var11.setBoolean(var70, var87);
                     byte var71 = 5;
                     boolean var89 = var6.canTogglePvP(var8);
                     var11.setBoolean(var71, var89);
                     byte var72 = 6;
                     boolean var91 = var6.canSetHome(var8);
                     var11.setBoolean(var72, var91);
                     byte var73 = 7;
                     boolean var93 = var6.canVisitHome(var8);
                     var11.setBoolean(var73, var93);
                     byte var74 = 8;
                     boolean var95 = var6.isTeamChatEnabled(var8);
                     var11.setBoolean(var74, var95);
                     int var45 = var11.executeUpdate();
                  } catch (Throwable var106) {
                     if (var35 != null) {
                        try {
                           var11.close();
                        } catch (Throwable var105) {
                           var106.addSuppressed(var105);
                        }
                     }

                     throw var106;
                  }

                  if (var35 != null) {
                     var35.close();
                  }
               } catch (Throwable var107) {
                  if (var32 != null) {
                     try {
                        var9.close();
                     } catch (Throwable var104) {
                        var107.addSuppressed(var104);
                     }
                  }

                  throw var107;
               }

               if (var32 != null) {
                  var32.close();
               }
            } catch (SQLException var108) {
               Logger var51 = Bukkit.getLogger();
               String var76 = var108.getMessage();
               String var77 = "[DonutTeams] Failed to save permissions: " + var76;
               var51.warning(var77);
            }
         }
      }
   }

   public void saveAllTeamsAsync() {
      KKoOoOo0oOK var1 = KKoOoOo0oOK.getInstance();
      Runnable var3 = this::saveAllTeams;
      var1.runAsync(var3);
   }

   public void loadAllTeams() {
      try {
         Connection var1 = Ko0Ko0oOoOK.getConnection();
         Connection var15 = var1;

         try {
            Map var36 = this.teams;
            var36.clear();
            Map var38 = this.playerTeam;
            var38.clear();

            try {
               String var2 = lqgoptmhew(gtqabmyyfantymk(), 1456577710);
               PreparedStatement var40 = var15.prepareStatement(var2);
               int var41 = var40.executeUpdate();
            } catch (SQLException var261) {
            }

            String var185 = lqgoptmhew(rpzhmvesbyhifom(), 75295455);
            PreparedStatement var44 = var15.prepareStatement(var185);
            ResultSet var46 = var44.executeQuery();
            ResultSet var17 = var46;

            while(true) {
               boolean var48 = var17.next();
               if (!var48) {
                  var17.close();
                  var44.close();
                  String var186 = lqgoptmhew(ihzedlowwpmlkkh(), 1718180189);
                  PreparedStatement var52 = var15.prepareStatement(var186);
                  ResultSet var54 = var52.executeQuery();
                  ResultSet var19 = var54;

                  while(true) {
                     boolean var56 = var19.next();
                     if (!var56) {
                        var19.close();
                        var52.close();
                        String var187 = lqgoptmhew(tsliewbzpmsrail(), 2097763695);
                        PreparedStatement var60 = var15.prepareStatement(var187);
                        ResultSet var62 = var60.executeQuery();
                        ResultSet var21 = var62;

                        while(true) {
                           boolean var64 = var21.next();
                           if (!var64) {
                              var21.close();
                              var60.close();
                              if (var15 != null) {
                                 var15.close();
                              }

                              return;
                           }

                           String var190 = lqgoptmhew(ormfdgrudulhcys(), 866485175);
                           String var79 = var21.getString(var190);
                           String var80 = var79.toLowerCase();
                           String var191 = lqgoptmhew(snzutvsvpvcgvwq(), 1271526054);
                           String var82 = var21.getString(var191);
                           UUID var83 = UUID.fromString(var82);
                           Map var85 = this.teams;
                           Object var86 = var85.get(var80);
                           TeamService var87 = (TeamService)var86;
                           if (var87 != null) {
                              String var193 = lqgoptmhew(ieukhttjkewuvnv(), 1630415197);
                              boolean var90 = var21.getBoolean(var193);
                              if (var90) {
                                 Set var92 = var87.getCanInvite();
                                 var92.add(var83);
                              }

                              String var195 = lqgoptmhew(efbbqsoarbxcxph(), 1305480298);
                              boolean var95 = var21.getBoolean(var195);
                              if (var95) {
                                 Set var97 = var87.getCanKick();
                                 var97.add(var83);
                              }

                              String var197 = lqgoptmhew(xfepockmmzjuzxc(), 1600051119);
                              boolean var100 = var21.getBoolean(var197);
                              if (var100) {
                                 Set var102 = var87.getCanTogglePvP();
                                 var102.add(var83);
                              }

                              String var199 = lqgoptmhew(slkxucpqtptaoyd(), 1833240534);
                              boolean var105 = var21.getBoolean(var199);
                              if (var105) {
                                 Set var107 = var87.getCanSetHome();
                                 var107.add(var83);
                              }

                              String var201 = lqgoptmhew(hxcyaoikekjoqbf(), 1718895354);
                              boolean var110 = var21.getBoolean(var201);
                              if (var110) {
                                 Set var112 = var87.getCanVisitHome();
                                 var112.add(var83);
                              }

                              String var203 = lqgoptmhew(qnliriuinbukwza(), 1809543244);
                              boolean var115 = var21.getBoolean(var203);
                              if (var115) {
                                 Set var117 = var87.getTeamChatEnabled();
                                 var117.add(var83);
                              }
                           }
                        }
                     }

                     String var205 = lqgoptmhew(flduwgyhfxztipp(), 46271000);
                     String var120 = var19.getString(var205);
                     String var206 = lqgoptmhew(tqpxtqulyzzxisr(), 1494014092);
                     String var122 = var19.getString(var206);
                     UUID var123 = UUID.fromString(var122);
                     Map var125 = this.teams;
                     String var208 = var120.toLowerCase();
                     Object var126 = var125.get(var208);
                     TeamService var127 = (TeamService)var126;
                     if (var127 != null) {
                        Set var130 = var127.getMembers();
                        var130.add(var123);
                        Map var133 = this.playerTeam;
                        String var233 = var120.toLowerCase();
                        var133.put(var123, var233);
                     }
                  }
               }

               String var211 = lqgoptmhew(dhpwlvxghzhfrde(), 1740632538);
               String var136 = var17.getString(var211);
               String var212 = lqgoptmhew(zitoxsdfzzxhpnd(), 1965835510);
               String var138 = var17.getString(var212);
               String var213 = lqgoptmhew(mdfxmetcotarjuz(), 2085038224);
               String var140 = var17.getString(var213);
               UUID var141 = UUID.fromString(var140);
               String var214 = lqgoptmhew(urcdtcsqnouzwos(), 1122869799);
               long var143 = var17.getLong(var214);
               long var252 = var143;
               String var215 = lqgoptmhew(rxfiuovvrbdtnvf(), 1868443616);
               boolean var146 = var17.getBoolean(var215);
               TeamService var147 = new TeamService(var136, var141);
               TeamService var256 = var147;
               if (var138 != null) {
                  boolean var150 = var138.isEmpty();
                  if (!var150) {
                     var147.setDisplayName(var138);
                  }
               }

               try {
                  Class var152 = TeamService.class;
                  String var217 = lqgoptmhew(cefbtvvnmvlcssd(), 1547617356);
                  Field var153 = var152.getDeclaredField(var217);
                  boolean var218 = true;
                  var153.setAccessible(var218);
                  var153.setLong(var256, var252);
               } catch (Exception var260) {
               }

               var147.setPvpEnabled(var146);
               String var221 = lqgoptmhew(ptovllneqywbgnn(), 342578072);
               String var158 = var17.getString(var221);
               if (var158 != null) {
                  boolean var161 = var17.wasNull();
                  if (!var161) {
                     String var222 = lqgoptmhew(thegchzbuddphzn(), 1995569407);
                     double var163 = var17.getDouble(var222);
                     String var223 = lqgoptmhew(dlrisjkkeortxve(), 82532044);
                     double var166 = var17.getDouble(var223);
                     String var224 = lqgoptmhew(xxmdfskewoaslnn(), 544634895);
                     double var169 = var17.getDouble(var224);
                     String var225 = lqgoptmhew(hwhjxpprbjplhem(), 1729278453);
                     float var172 = var17.getFloat(var225);
                     String var226 = lqgoptmhew(lupjprwtjmchhgn(), 1586099424);
                     float var174 = var17.getFloat(var226);
                     var147.setTeamHomeWorld(var158);
                     var147.setTeamHomeCoords(var163, var166, var169, var172, var174);
                     World var178 = Bukkit.getWorld(var158);
                     if (var178 != null) {
                        Location var230 = new Location(var178, var163, var166, var169, var172, var174);
                        var147.setTeamHome(var230);
                     }
                  }
               }

               Map var182 = this.teams;
               String var232 = var136.toLowerCase();
               var182.put(var232, var147);
            }
         } catch (Throwable var262) {
            if (var1 != null) {
               try {
                  var15.close();
               } catch (Throwable var259) {
                  var262.addSuppressed(var259);
               }
            }

            throw var262;
         }
      } catch (SQLException var263) {
         Logger var70 = Bukkit.getLogger();
         String var188 = lqgoptmhew(gvahdhxlywgcrfl(), 1414088996);
         var70.severe(var188);
         var263.printStackTrace();
      }
   }

   public Collection<TeamService> getAllTeamsInternal() {
      Map var2 = this.teams;
      Collection var3 = var2.values();
      Collection var4 = Collections.unmodifiableCollection(var3);
      return var4;
   }

   public void broadcastTeamUpdate(TeamService var1) {
      Set var8 = var1.getMembers();
      Iterator var9 = var8.iterator();
      Iterator var5 = var9;

      while(true) {
         boolean var11 = var5.hasNext();
         if (!var11) {
            return;
         }

         Object var13 = var5.next();
         UUID var14 = (UUID)var13;
         Player var16 = Bukkit.getPlayer(var14);
         if (var16 != null) {
            boolean var19 = var16.isOnline();
            if (var19) {
               KKoOoOo0oOK var20 = KKoOoOo0oOK.getInstance();
               Runnable var21 = () -> {
                  InventoryView var5 = var16.getOpenInventory();
                  String var6 = var5.getTitle();
                  String var2 = lqgoptmhew(hwahvylbgjnxwyx(), 1959125822);
                  boolean var8 = var6.contains(var2);
                  if (!var8) {
                     String var14 = lqgoptmhew(jvksyvhydrflxlu(), 214593296);
                     boolean var10 = var6.contains(var14);
                     if (!var10) {
                        String var15 = lqgoptmhew(xofepadjtpgdsip(), 150614835);
                        boolean var12 = var6.contains(var15);
                        if (!var12) {
                           return;
                        }
                     }
                  }

                  TeamMenu var13 = new TeamMenu(var16);
                  var13.open();
               };
               var20.onEntity(var16, var21);
            }
         }
      }
   }

   public static String lqgoptmhew(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = gfbkkutmpu;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] jvksyvhydrflxlu() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, 0};
   }

   private static byte[] hwahvylbgjnxwyx() {
      return new byte[]{0, 0, 0, 4, 0, 0, 0, 7};
   }

   private static byte[] xofepadjtpgdsip() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, 11};
   }

   private static byte[] dalybeykblivdqd() {
      return new byte[]{0, 0, 0, -91, 0, 0, 0, 18};
   }

   private static byte[] yzgtbfprmjohmpf() {
      return new byte[]{0, 0, 0, 68, 0, 0, 0, -73};
   }

   private static byte[] svkpqngrxuujzom() {
      return new byte[]{0, 0, 0, 64, 0, 0, 0, -5};
   }

   private static byte[] unsruoggajtmwue() {
      return new byte[]{0, 0, 0, 48, 0, 0, 1, 59};
   }

   private static byte[] bhqhveykjvbuvxo() {
      return new byte[]{0, 0, 0, 44, 0, 0, 1, 107};
   }

   private static byte[] oqnnhfujpqpsmsm() {
      return new byte[]{0, 0, 0, 32, 0, 0, 1, -105};
   }

   private static byte[] jqpfzmomxovudjq() {
      return new byte[]{0, 0, 0, 64, 0, 0, 1, -73};
   }

   private static byte[] mhtgscnaogmbwxy() {
      return new byte[]{0, 0, 0, 68, 0, 0, 1, -9};
   }

   private static byte[] qpjftoayweiqswz() {
      return new byte[]{0, 0, 0, 11, 0, 0, 2, 59};
   }

   private static byte[] adoskrwltxwqvbx() {
      return new byte[]{0, 0, 0, 9, 0, 0, 2, 70};
   }

   private static byte[] fmfbmmtbpxvpsyf() {
      return new byte[]{0, 0, 0, 16, 0, 0, 2, 79};
   }

   private static byte[] culsdqljshtwmnt() {
      return new byte[]{0, 0, 0, 12, 0, 0, 2, 95};
   }

   private static byte[] qxcinvipmbtrmyg() {
      return new byte[]{0, 0, 0, 9, 0, 0, 2, 107};
   }

   private static byte[] rhobiccgfqqwatw() {
      return new byte[]{0, 0, 0, 13, 0, 0, 2, 116};
   }

   private static byte[] sfwfxzlbvbjjuuq() {
      return new byte[]{0, 0, 0, 11, 0, 0, 2, -127};
   }

   private static byte[] fqnqfriezxxxwgz() {
      return new byte[]{0, 0, 0, 15, 0, 0, 2, -116};
   }

   private static byte[] hxmrdjmqiqnypxc() {
      return new byte[]{0, 0, 0, 11, 0, 0, 2, -101};
   }

   private static byte[] toejhdymrepbiff() {
      return new byte[]{0, 0, 0, 12, 0, 0, 2, -90};
   }

   private static byte[] clzfqcvssinijkh() {
      return new byte[]{0, 0, 0, 56, 0, 0, 2, -78};
   }

   private static byte[] apipcxsulwhmvgw() {
      return new byte[]{0, 0, 0, 34, 0, 0, 2, -22};
   }

   private static byte[] ldjvierjohsgwod() {
      return new byte[]{0, 0, 0, 11, 0, 0, 3, 12};
   }

   private static byte[] szjsfjqoditnthy() {
      return new byte[]{0, 0, 0, 10, 0, 0, 3, 23};
   }

   private static byte[] ikwswkbijvyvlyw() {
      return new byte[]{0, 0, 0, 8, 0, 0, 3, 33};
   }

   private static byte[] ffwrvshapoaqjhf() {
      return new byte[]{0, 0, 0, 50, 0, 0, 3, 41};
   }

   private static byte[] vqhrsjlugtqwdsx() {
      return new byte[]{0, 0, 0, 10, 0, 0, 3, 91};
   }

   private static byte[] jfxjxofvjrczyce() {
      return new byte[]{0, 0, 0, 11, 0, 0, 3, 101};
   }

   private static byte[] ahlkvjjdjqzjlvv() {
      return new byte[]{0, 0, 0, 15, 0, 0, 3, 112};
   }

   private static byte[] hyuseowrmcewigq() {
      return new byte[]{0, 0, 0, 11, 0, 0, 3, 127};
   }

   private static byte[] zquujimxykvjgdo() {
      return new byte[]{0, 0, 0, 11, 0, 0, 3, -118};
   }

   private static byte[] gshephoelmluefx() {
      return new byte[]{0, 0, 0, 14, 0, 0, 3, -107};
   }

   private static byte[] urtsbrvspvvvrcw() {
      return new byte[]{0, 0, 0, 4, 0, 0, 3, -93};
   }

   private static byte[] lmnxhnzdmujealr() {
      return new byte[]{0, 0, 0, 14, 0, 0, 3, -89};
   }

   private static byte[] zlzshfckzplfljv() {
      return new byte[]{0, 0, 0, -40, 0, 0, 3, -75};
   }

   private static byte[] hjwzlhhuurozsgb() {
      return new byte[]{0, 0, 2, 35, 0, 0, 4, -115};
   }

   private static byte[] sgedmctzvrusses() {
      return new byte[]{0, 0, 0, -127, 0, 0, 6, -80};
   }

   private static byte[] ytimsogpisjvblg() {
      return new byte[]{0, 0, 0, 88, 0, 0, 7, 49};
   }

   private static byte[] priaergzhkuwook() {
      return new byte[]{0, 0, 0, 82, 0, 0, 7, -119};
   }

   private static byte[] cfhsykancfllacl() {
      return new byte[]{0, 0, 0, 99, 0, 0, 7, -37};
   }

   private static byte[] cdkjeegfwazwmwp() {
      return new byte[]{0, 0, 0, -92, 0, 0, 8, 62};
   }

   private static byte[] piynunlwprwcent() {
      return new byte[]{0, 0, 0, -91, 0, 0, 8, -30};
   }

   private static byte[] tqpxtqulyzzxisr() {
      return new byte[]{0, 0, 0, 11, 0, 0, 9, -121};
   }

   private static byte[] slkxucpqtptaoyd() {
      return new byte[]{0, 0, 0, 12, 0, 0, 9, -110};
   }

   private static byte[] rpzhmvesbyhifom() {
      return new byte[]{0, 0, 0, 19, 0, 0, 9, -98};
   }

   private static byte[] xxmdfskewoaslnn() {
      return new byte[]{0, 0, 0, 11, 0, 0, 9, -79};
   }

   private static byte[] efbbqsoarbxcxph() {
      return new byte[]{0, 0, 0, 8, 0, 0, 9, -68};
   }

   private static byte[] ptovllneqywbgnn() {
      return new byte[]{0, 0, 0, 15, 0, 0, 9, -60};
   }

   private static byte[] rxfiuovvrbdtnvf() {
      return new byte[]{0, 0, 0, 11, 0, 0, 9, -45};
   }

   private static byte[] urcdtcsqnouzwos() {
      return new byte[]{0, 0, 0, 10, 0, 0, 9, -34};
   }

   private static byte[] hwhjxpprbjplhem() {
      return new byte[]{0, 0, 0, 13, 0, 0, 9, -24};
   }

   private static byte[] tsliewbzpmsrail() {
      return new byte[]{0, 0, 0, 30, 0, 0, 9, -11};
   }

   private static byte[] ihzedlowwpmlkkh() {
      return new byte[]{0, 0, 0, 26, 0, 0, 10, 19};
   }

   private static byte[] gvahdhxlywgcrfl() {
      return new byte[]{0, 0, 0, 48, 0, 0, 10, 45};
   }

   private static byte[] dlrisjkkeortxve() {
      return new byte[]{0, 0, 0, 11, 0, 0, 10, 93};
   }

   private static byte[] hxcyaoikekjoqbf() {
      return new byte[]{0, 0, 0, 14, 0, 0, 10, 104};
   }

   private static byte[] zitoxsdfzzxhpnd() {
      return new byte[]{0, 0, 0, 12, 0, 0, 10, 118};
   }

   private static byte[] snzutvsvpvcgvwq() {
      return new byte[]{0, 0, 0, 11, 0, 0, 10, -126};
   }

   private static byte[] mdfxmetcotarjuz() {
      return new byte[]{0, 0, 0, 11, 0, 0, 10, -115};
   }

   private static byte[] dhpwlvxghzhfrde() {
      return new byte[]{0, 0, 0, 4, 0, 0, 10, -104};
   }

   private static byte[] qnliriuinbukwza() {
      return new byte[]{0, 0, 0, 9, 0, 0, 10, -100};
   }

   private static byte[] cefbtvvnmvlcssd() {
      return new byte[]{0, 0, 0, 9, 0, 0, 10, -91};
   }

   private static byte[] lupjprwtjmchhgn() {
      return new byte[]{0, 0, 0, 15, 0, 0, 10, -82};
   }

   private static byte[] xfepockmmzjuzxc() {
      return new byte[]{0, 0, 0, 14, 0, 0, 10, -67};
   }

   private static byte[] thegchzbuddphzn() {
      return new byte[]{0, 0, 0, 11, 0, 0, 10, -53};
   }

   private static byte[] ormfdgrudulhcys() {
      return new byte[]{0, 0, 0, 9, 0, 0, 10, -42};
   }

   private static byte[] ieukhttjkewuvnv() {
      return new byte[]{0, 0, 0, 10, 0, 0, 10, -33};
   }

   private static byte[] flduwgyhfxztipp() {
      return new byte[]{0, 0, 0, 9, 0, 0, 10, -23};
   }

   private static byte[] gtqabmyyfantymk() {
      return new byte[]{0, 0, 0, 54, 0, 0, 10, -14};
   }

   static {
      gfbkkutmpu = ByteBuffer.wrap(ecprlabbkhqtpaa()).asCharBuffer().toString();
   }

   private static byte[] ecprlabbkhqtpaa() {
      return "/5):;G\u0095\t4X3´(4,\"(>,2(5,02\\\u0096\u0005:ª(17D+41d0q1e1x1t1u0q1\u00151}1{1b0{1\u00151@1P1W0Y1j1D1P1D0Y1\\1G1F1_0[1[1G1\u00151\u001e0@1P1U1X1i0Z1T1Y1P1\u001a0\u00141E1X1T1O0Q1G1k1@1C0]1Q1\u00181\u00151U0U1[1k1\\1X0B1\\1@1P1\u001a0\u00141V1U1[1i0_1\\1W1^1\u001a0\u00141V1U1[1i0@1Z1S1R1Z0Q1j1D1C1F0\u00181\u00151W1T1X0k1F1Q1A1i0\\1Z1Y1P1\u001a0\u00141V1U1[1i0B1\\1G1\\1B0k1]1[1X1S0\u00181\u00151@1P1W0Y1j1W1]1W0@1\u001c1\u00141c1w0x1`1q1f1\u00160\u001c1\n1\u00181\u00151\t0\u00181\u00151\u000b1\u00191\u00160\u000b1\u00191\u00141\n1\u001a0\u00141\n1\u00181\u00151\t0\u00181\u00151\u000b1\u001c1v3t8{8|5m1w3\u00118q8k5v1\u007f3\u00118C8\\5X1_3n8G8\\5K1_3X8D8J5P1]3_8D8\u00195n1z3t8e8|5\u00191F3T8V8T5f1\\3P8Z8\\5\u00191\u000f3\u00118\b8\u00195x1|3u8\u00178I5U1S3H8R8K5f1G3D8^8]5\u00191\u000f3\u00118\b5|5p4z2r5a8p5\u00146t7g5w5x4\u00162C5P8T5Y6m7X5]5X4T2R5G8F5\u00146e7}5}5g4s2\u00175A8P5U6_7j5V5T4[2R5\u00158\b5\u00146\r7\u00155y5{4r2\u00175E8Y5U6K7P5J5j4C2B5\\8Q5\u00146\u000f7\u00155\u00079w0q1\u007f3r9g0q1\u00133q9a0{1~3\u00179G0Q1R3Z9l0D1V3E9^0]1@3D9Z0[1]3D9\u00130c1{3r9a0q1\u00133C9V0U1^3h9]0U1^3R9\u00130\t1\u00133\b1|7v6}5u9a1}7\u00136w5b9z1u7\u00136E5U9T1U7l6\\5U9X1Z7V6C5C9\u00151o7{6t5b9p1\u00187G6T5Q9X1g7]6P5]9P1\u00187\u000e6\u00115\u000f4v3}3\u007f4r5`2v8\u00133r7g4}3u3\u00134C5Q2R8^3G7\u00154e3p3v4e5q2\u00138]3U7X4W3\u00183\u000e4\u00175\u000b1v8u1u2q2e1w8\u00101\u007f2f2~1\u007f8\u00101M2Q2P1_8o1T2Q2\\1P8U1K2G2\u00111e8x1|2f2t1\u00128D1\\2U2\\1m8^1X2Y2T1\u00128\r1\u00192\u000b2\u00111s8~1}2\u00142A1^8Q1@2Q2C1m8E1L2]2U1\u00128\r1\u00192\u000b9v7u1u3v1m2r0\u00119u3c9}7}1\u00193G1\\2V0\\9l3A9W7B1T3Z1J2D0X9\\3_9A7\u00101n3{1|2e0t9\u00133E9W7Q1T3l1W2V0\\9V3\u00119\u000f7\u00101\u00063\u00131x2y0u9\u00133A9^7Q1@3V1K2h0D9F3X9V7\u00101\u00043\u00131\u00061G4T5X2_9n1[4^5T2W9n1J2E0]7V6U7i2R0P7V6L1B2T1Y0Z7m1^2^1U0R7m1E2T1J0A7W1D7U2X9_7l0D6W9M1h3X7Y2T9T8U5B5T6P2L6P0Q1w1F1E4U4X2\\0j1Y4_4T2T0j1H4Q4N1C4[1S8L7P1A4h1G8@7\\1W9F7W9R9_5f2_2V3T2P9m7E9\\9@5U2S1D4Y0T0N5V1F4j0@0B5Z1P3Q0[3K2@3_5Q2J8m0]3T0_3]1b4w9|2}0t1e4\u00129@2T0V1H4W9B2g0B1D4[9T2\u00180q1c4}9}2\u00180C1T4S9]2g0Z1T4_9R2]0E1B4\u00129g2p0r1c4w9\u00102L0R1P4_9o2V0V1\\4W9\u00102\u00050\u00171\u000e1b2q0~4t2v1e2\u00140\u00184\u00112s1c2{0\u007f4\u00112A1T2U0_4B2\u00151f2|0w4c2p1\u00112Z0S4\\2P1\u00112\t0\u00124\u000e5M6\\5U7[5f6Q5[7[5\\6f5L6S8A4S9V7B0]3P6f7V6D1Z6S2Z0o7^1P6Q2_1f7s2\u007f5p4u1a7\u00162\u00195\u00154p1g7y2~5\u00154B1P7W2^5j4F1P7D2^5\\4E1F7_2\\5[4E1\u00157a2{5p4d1p7\u00162G5P4W1X7i2]5T4[1P7\u00162\u000e5\u00154\t1S6W3[5o2_1^6@3\\5D2S1^6W5P8T1W6@5n8E1G6[5U5M2W7Q1Y1j9Z2X0\\4T5f2B7Y1@1V9Z1D0O0C2m1\\1Z0X0Q2^1\\1P2F3Q6P0X4m2[4Y1]5Q2m3N5U0V8[4o5@0^8F4Y5B0h8]4_5[0R7V7S9X8]1[6U5^3o0M1W6S5W3\\0\\1g6D5F3@1}6\u007f4`2t5b1`6\u00114|2c5\u00101f6t4c2}5q1w6t4\u00132x5~1`6~4\u00132E5U1U6\\4@2\u00115\u00181Z6P4^2T5\u001c1\u00146U4Z2B5@1X6P4J2n5^1U6\\4V2\u001d5\u00101X6T4R2U5U1F6n4F2D5Y1P6\u001d4\u00132R5B1Q6P4G2T5T1k6P4G2\u001d5\u00101D6G4C2n5U1Z6P4Q2]5U1P6\u001d4\u00132E5U1U6\\4l2Y5_1Y6T4l2F5_1F6]4W2\u001d5\u00101@6T4R2\\5o1\\6^4^2T5o1L6\u001d4\u00132E5U1U6\\4l2Y5_1Y6T4l2H5\u001c1\u00146E4V2P5]1k6Y4\\2\\5U1k6K4\u001f2\u00115D1Q6P4^2n5X1[6\\4V2n5I1U6F4\u001f2\u00115D1Q6P4^2n5X1[6\\4V2n5@1]6E4P2Y5\u00191\u00146g4r2}5e1q6b4\u00132\u00195\u000f1\u00186\u00114\f2\u001d5\u00101\u000b6\u001d4\u00132\u000e5\u001c1\u00146\u000e4\u001f2\u00115\u000f1\u00186\u00114\f2\u001d5\u00101\u000b6\u001d4\u00132\u000e5\u001c1\u00146\u000e4\u001f2\u00115\u000f1\u001d1|9z0k8q6f1a9\u00140q8z6`1z9\u00140L8Q6U1X9G0\u00188\u001c6Z1T9Y0]8\u00186\u00141Q9]0K8D6X1T9M0g8Z6U1X9Q0\u00148\u00146X1P9U0\\8Q6F1j9A0M8]6P1\u00199\u00140[8F6Q1T9@0]8P6k1T9@0\u00148\u00146D1C9D0g8Q6Z1T9V0T8Q6P1\u00199\u00140L8Q6U1X9k0P8[6Y1P9k0O8[6F1Y9P0\u00148\u00146@1P9U0U8k6\\1Z9Y0]8k6L1\u00199\u00140L8Q6U1X9k0P8[6Y1P9k0A8\u00186\u00141A9Q0Y8Y6k1]9[0U8Q6k1O9\u00180\u00188@6Q1T9Y0g8\\6[1X9Q0g8M6U1B9\u00180\u00188@6Q1T9Y0g8\\6[1X9Q0g8D6]1A9W0P8\u001d6\u00141c9u0t8a6q1f9\u00140\u00108\u000b6\u00181\u00159\u000b0\u00148\u00146\u000b1\u00199\u00140\u00078\u00186\u00141\n9\u00180\u00188\u000b6\u00181\u00159\u000b0\u00148\u00146\u000b1\u00199\u00140\u00078\u00186\u00141\n9\u00180\u00188\u000b6\u001d1\u00159{0v8\u00146p1`9d0t8}6w1t9`0}8\u00146\u007f1p9m0\u00188a6d1q9u0l8q6\u00141Q9]0K8D6X1T9M0g8Z6U1X9Q0\u00058b6u1y9a0}8g6\u001c1Q9]0K8D6X1T9M0g8Z6U1X9Q0\u00118\u00186\u00141Y9Q0Y8P6Q1G9k0M8A6]1Q9\t0n8u6x1`9q0k8\u001c6X1P9U0\\8Q6F1j9A0M8]6P1\u001c9\u00180\u00188D6B1E9k0]8Z6U1W9X0]8P6\t1c9u0t8a6q1f9\u001c0H8B6D1j9Q0V8U6V1Y9Q0\\8\u001d6\u00181\u00159@0]8U6Y1j9\\0W8Y6Q1j9C0W8F6X1Q9\t0n8u6x1`9q0k8\u001c6@1P9U0U8k6\\1Z9Y0]8k6C1Z9F0T8P6\u001d1\u00199\u00140L8Q6U1X9k0P8[6Y1P9k0@8\t6b1t9x0m8q6g1\u001d9@0]8U6Y1j9\\0W8Y6Q1j9L0\u00118\u00186\u00141A9Q0Y8Y6k1]9[0U8Q6k1L9\t0n8u6x1`9q0k8\u001c6@1P9U0U8k6\\1Z9Y0]8k6M1\u001c9\u00180\u00188@6Q1T9Y0g8\\6[1X9Q0g8N6\t1c9u0t8a6q1f9\u001c0L8Q6U1X9k0P8[6Y1P9k0B8\u001d6\u00181\u00159@0]8U6Y1j9\\0W8Y6Q1j9M0Y8C6\t1c9u0t8a6q1f9\u001c0L8Q6U1X9k0P8[6Y1P9k0A8U6C1\u001c9\u00180\u00188@6Q1T9Y0g8\\6[1X9Q0g8D6]1A9W0P8\t6b1t9x0m8q6g1\u001d9@0]8U6Y1j9\\0W8Y6Q1j9D0Q8@6W1]9\u001d1z1y1a4u5a1g1\u00171{4~5g1|1\u00171F4U5R1^1h1_4U5^1Q1R1@4C5\u00131\u001b1C1W4Q5^1l1Y1S4]5V1\u001f1\u00171B4\\5R1J1R1@4o5F1F1^1V4\u001c5\u00131Y1X1[4^5V1W1h1S4D5\u001a1\u00131a1s4|5f1v1d1\u00124\u00185\f1\u001f1\u00171\r4\u001c5\u00131\f1\u001e1\u00124\u007f5}1\u00131s1g4`5\u007f1z1t1s4d5v1\u00131|1w4i5\u00131f1g1v4q5g1v1\u00171F4U5R1^1h1\\4Q5^1V1\n1d4q5\u007f1f1r1a4\u00185G1V1V1_4o5]1R1Z1W4\u00191}6}5j1|4j1`6\u00135v1k4\u00181f6v5i1u4y1w6v5\u00191p4v1`6|5\u00191M4]1U6^5f1T4]1Y6Q5\\1K4K1\u00146\u001b5M1\\4Y1Y6l5W1X4U1Q6\u001f5\u00191I4T1U6J5\\1K4g1A6F5P1]4\u00141\u00146Y5V1P4V1Q6W5f1X4L1\u001d6\u00135o1x4t1a6v5j1\u00194\u00101\u000b6\u001f5\u00191\u00064\u00141\u00146\f5\u00101l7h2u4t8c1|7\u00182E4P8V1T7K2\u00114f8r1m7\u00182U4\\8D1I7T2P4L8h1W7Y2\\4P8\u00171\u00047\u00182\u000e4\u00198\u00171U7]2P4Q8R1K7g2D4@8^1]7\u00182\f4\u00158\b1\u00157\u00182A4C8G1f7]2_4T8U1U7]2U4\u00158\n1\u00197\u00072\u00114b8\u007f1|7j2t4\u00158Y1X7U2T4\u00158\n1\u00197\u00071z4v4f9s5e1g4\u00184|9x5c1|4\u00184A9S5V1^4K4\u00159\u001e5Y1R4U4P9\u001a5\u00171W4Q4F9F5[1R4A4j9X5V1^4]4\u00199\u00165[1V4Y4Q9S5E1l4M4@9_5S1\u001f4\u00184V9D5R1R4L4P9R5h1R4L4\u00199\u00165G1E4H4j9S5Y1R4Z4Y9S5S1\u001a4\u00184c9w5{1f4}4f9\u00165\u001f1\f4\u00144\u00159\t5\u001b1\u00134\u00074\u00199\u00165\b1\u001f4\u00184\n9\u001f1b3b1w6p2`1r3\u00121G6T2U1Z3A1\u00136b2q1c3\u00121G6T2U1Z3m1[6^2Y1R3m1D6^2F1[3V1\u00136\f2\u00141\b3\u001e1\u00136E2Q1V3_1l6Y2[1Z3W1l6I2\u00141\n3\u00121\f6\u001d2\u00141C3W1R6\\2k1_3]1^6T2k1N3\u00121\u000e6\u00112\u000b1\u001b3\u00121G6T2U1Z3m1[6^2Y1R3m1I6\u00112\t1\u00173\r1\u001f6\u00112@1R3S1^6n2\\1X3_1V6n2M1V3E1\u00136\f2\u00141\b3\u001e1\u00136E2Q1V3_1l6Y2[1Z3W1l6A2]1C3Q1[6\u00112\t1\u00173\r1\u001f6\u00112@1R3S1^6n2\\1X3_1V6n2G1R3@1E6T2F1\u00173\u000f1\u00136\u000e2\u00141`3z1v6c2q1\u00173\\1R6\\2Q1\u00173\u000f1\u00136\u000e2k4r7d0{5s9w7r4\u00107|2w4c7{0\u00175F9Q7V4]7j2I4R7F0Z5[9G7D4Y7Z2W4D7\u00140\u001f5F9Q7V4]7j2W4V7Y0R5\u001e9\u00147G4\\7T2@4R7F0h5G9A7^4T7\u00192\u00194T7U0Y5m9]7Y4F7\\2M4R7\u00180\u00175Q9U7Y4o7^2P4T7_0\u001b5\u00129W7V4^7j2M4X7S0P5^9Q7h4@7C2I4\u001b7\u00140T5S9Z7h4C7P2M4h7\\0X5_9Q7\u001b4\u00107V2X4Y7k0A5[9G7^4D7j2Q4X7Y0R5\u001e9\u00147C4U7T2T4h7W0_5S9@7\u001e4\u00107c2x4{7a0r5a9\u00147\u001f4\u000f7\u00192\u00194\b7\u00180\u00175\r9\u00187\u00174\u000f7\u00192\u00194\b7\u00180\u00175\r9\u00187\u00174\u000f7\u00192\u00194\b7\u001d1D9X0P4I9W1F9k0D4E9[1P1[3R2Z0j3G1]3G2k0]3[1U3V7f2|5x5p7v2m5\u00145\u001f7\u00152\u007f5f5z7x2\u00195@5P7T2T5G5@4S3U8T5j4\\6\\4U9P5k4L1P0T4V0m9S1Z0V4S3@2P7Y0Z2l4Z5X8]7W3k2B7W0E2_4V1H6N4D3i1S1V6Y4V3Z1S1\\1R2@8S9V9M1T2V8i9V9M1C2\\2V8Y5l1_2V2Z8Q5l1N2X2@2c9r7z3s9v2d9\u00177\u001c3\u00169s2b9x7{3\u00169A2U9V7[3i9E2U9E7[3_9F2C9^7Y3X9F1d1}1t0t8z1c1\u00181\u00120\u00118\u007f1e1w1u0\u00118M1R1Y1U0n8T1R1U1Z0T8K1D1o1p0W8W9C1@1`0]8X9[1G1i0\u00188\u007f9W1]1X0]8]9\u00161@1[0\u00188U9Y1U1P0\u00188M9S1U1Y0K8\u00199P1F1[0U8\u00199R1U1@0Y8[9W1G1Q0\u00198F5V2Q4Y8m5[2_4Y8W5l2I1T1Y8W5l5B1^1K8P5G5k1_1W8T5V1]6\\8@5E1\\1X6L8l5[1Q1T6P1B7]5S6I5Q1@7n5G6E5]1V2\\8P0R8V2Q2B8j0F8G2]2T1Y4Q6^2P1L0\\5U3_4k1[0Q5U3F1V4E6T7R5B1P4S6p7G1A8S0X9Y2k1]8Y0T9Q2k1E8_0M9W2\\1U0Q0[1n1M1Y0W0R1]1\\1i0@0C1A1M9P5W9Y0h1Q9Z5[9Q0h1A8B6Q8T1Z5g6X4Y5\\7P1U3Q4_5n9^1X3F4X5E9R4B2R1Q0]4i2Y1Q0]4S1u5z5c7r1b1\u00145b5v7u1|1q5\u00165C7R1Q1Y5E5\u00177v1t1p5\u00165t7x1|1a5{5y7\u00171T1]5E5G7[1Q1M5i5Y7V1]1Q5\u00165a7v1b1w5~5v7e1\u00181\u00065\u00035\u00027\u001e".getBytes("ISO-8859-1");
   }
}
