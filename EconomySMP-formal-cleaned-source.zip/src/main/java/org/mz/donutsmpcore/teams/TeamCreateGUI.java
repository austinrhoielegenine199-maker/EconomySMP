package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import skido.KKo0KoOoOK;
import skido.KKoOK;
import skido.KKoOoOo0oOK;
import skido.o0KoOo0o0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOKo0o0K;

public class TeamCreateGUI implements KKoOK {
   private final Player player;
   private final TeamService team;
   private Inventory inv;
   private int cancelSlot;
   private int confirmSlot;
   private static final o0KoOo0o0oOK GUI;
   private static String hgplgzlnby;

   public TeamCreateGUI(Player var1, TeamService var2) {
      byte var4 = -1;
      this.cancelSlot = var4;
      byte var9 = -1;
      this.confirmSlot = var9;
      this.player = var1;
      this.team = var2;
   }

   public Inventory createInventory() {
      int var25 = 1494619692 ^ 683537985 ^ 1683682566;
      var25 = 1013554069 ^ var25;
      Object var2 = null;
      InventoryHolder var12 = (InventoryHolder)var2;
      o0KoOo0o0oOK var3 = GUI;
      byte var4 = (byte)(697863909 ^ var25);
      int var14 = var3.size(var4);
      o0KoOo0o0oOK var15 = GUI;
      String var5 = ruatcbkvcw(ofqhgxgrvfaedbl(), var25);
      byte var6 = (byte)(697863932 ^ var25);
      Object[] var17 = new Object[var6];
      byte var7 = (byte)(697863934 ^ var25);
      String var8 = ruatcbkvcw(sraovztduxwaabs(), var25);
      var17[var7] = var8;
      byte var18 = (byte)(697863935 ^ var25);
      TeamService var20 = this.team;
      String var21 = var20.getName();
      String var22 = String.valueOf(var21);
      var17[var18] = var22;
      String var16 = var15.title(var5, var17);
      Inventory var13 = Bukkit.createInventory(var12, var14, var16);
      this.inv = var13;
      var25 = 1465220417 ^ var25;
      this.decorate();
      var25 = 451399262 ^ var25;
      Inventory var11 = this.inv;
      return var11;
   }

   public void decorate() {
      int var51 = 932050512 ^ 1154918316 ^ 1683682566;
      var51 = 1252591672 ^ var51;
      TeamService var15 = this.team;
      String var16 = var15.getName();
      String var17 = String.valueOf(var16);
      var51 = 838136420 ^ var51;
      o0KoOo0o0oOK var2 = GUI;
      Inventory var26 = this.inv;
      String var4 = ruatcbkvcw(rrfnzrqyldgptkt(), var51);
      byte var5 = (byte)(1817992877 ^ var51);
      o0KoOo0o0oOK var6 = GUI;
      String var7 = ruatcbkvcw(fadkpdfhzsjdiwh(), var51);
      Material var8 = Material.RED_STAINED_GLASS_PANE;
      String var9 = ruatcbkvcw(vudkhpcwzvtcnpl(), var51);
      String var10 = ruatcbkvcw(mlvhlvdzldolibw(), var51);
      var51 = 1005866776 ^ var51;
      List var37 = List.of(var10);
      byte var11 = (byte)(1470632380 ^ var51);
      Object[] var40 = new Object[var11];
      byte var12 = (byte)(1470632382 ^ var51);
      String var13 = ruatcbkvcw(ywbkjiauhamabmt(), var51);
      var40[var12] = var13;
      byte var43 = (byte)(1470632383 ^ var51);
      var40[var43] = var17;
      ItemStack var31 = var6.item(var7, var8, var9, var37, var40);
      var51 = 1232904645 ^ var51;
      int var21 = var2.place(var26, var4, var5, var31);
      this.cancelSlot = var21;
      var51 = 898255373 ^ var51;
      o0KoOo0o0oOK var22 = GUI;
      Inventory var28 = this.inv;
      String var29 = ruatcbkvcw(ogotufyefxfgfjy(), var51);
      byte var30 = (byte)(727644793 ^ var51);
      o0KoOo0o0oOK var32 = GUI;
      String var34 = ruatcbkvcw(jibxlpbuogeqpbi(), var51);
      Material var35 = Material.LIME_STAINED_GLASS_PANE;
      String var36 = ruatcbkvcw(gjakfkuxdjzylru(), var51);
      String var38 = ruatcbkvcw(bdzdrfggtjxudrg(), var51);
      var51 = 1933912775 ^ var51;
      List var39 = List.of(var38);
      byte var41 = (byte)(1478217907 ^ var51);
      Object[] var42 = new Object[var41];
      byte var44 = (byte)(1478217905 ^ var51);
      String var47 = ruatcbkvcw(ymczywdfchqtepy(), var51);
      var42[var44] = var47;
      byte var45 = (byte)(1478217904 ^ var51);
      var42[var45] = var17;
      ItemStack var33 = var32.item(var34, var35, var36, var39, var42);
      var51 = 1422560003 ^ var51;
      int var23 = var22.place(var28, var29, var30, var33);
      this.confirmSlot = var23;
      var51 = 1893824694 ^ var51;
      o0KoOo0o0oOK var20 = GUI;
      Inventory var25 = this.inv;
      var20.fill(var25);
      var51 = 1385686904 ^ var51;
   }

   public void onClick(InventoryClickEvent var1) {
      int var82 = 129145330 ^ 1593320603 ^ 1683682566;
      var82 = 360765210 ^ var82;
      byte var3 = (byte)(680566644 ^ var82);
      var1.setCancelled((boolean)var3);
      var82 = 1725850305 ^ var82;
      int var15 = var1.getRawSlot();
      var82 = 552458479 ^ var82;
      if (var15 < (1856185691 ^ var82)) {
         var82 = bdgpvafmvkehbgts(var82, 958560504);
      } else {
         var82 = 2005038811 ^ var82;
         int var52 = this.cancelSlot;
         if (var15 != var52) {
            var82 ^= 1359200773;
            int var54 = this.confirmSlot;
            if (var15 != var54) {
               var82 = 530828326 ^ var82;
               return;
            }

            label94:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var82)) {
                  case 191221143:
                     break;
                  case 197308883:
                     var82 ^= 512627509;
                  case 839549990:
                     break label94;
                  case 1781408461:
                  default:
                     throw new IllegalAccessException();
               }
            }
         } else {
            label104:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var82)) {
                  case 11569385:
                     var82 ^= 1334694192;
                     break label104;
                  case 256394465:
                  default:
                     throw new IllegalAccessException();
                  case 1078576980:
                     break label104;
                  case 2109285154:
               }
            }
         }

         Player var20 = this.player;
         KKo0KoOoOK.click(var20);
         var82 = 1955797110 ^ var82;
         int var56 = this.cancelSlot;
         if (var15 == var56) {
            var82 = 1254020703 ^ var82;
            Player var50 = this.player;
            var50.closeInventory();
            var82 = 1979323973 ^ var82;
         } else {
            label83:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var82)) {
                  case 39524832:
                     var82 ^= 336632135;
                  case 91690701:
                     break label83;
                  case 202551084:
                     break;
                  case 836109143:
                  default:
                     throw new IllegalAccessException();
               }
            }

            int var58 = this.confirmSlot;
            if (var15 == var58) {
               var82 = 1456534188 ^ var82;
               Player var24 = this.player;
               var24.closeInventory();
               var82 = 133051223 ^ var82;
               TeamService2 var25 = TeamService2.getInstance();
               var82 = 92445885 ^ var82;
               Player var60 = this.player;
               UUID var61 = var60.getUniqueId();
               var25.leaveTeam(var61);
               var82 = 552958788 ^ var82;
               TeamService var28 = this.team;
               Set var29 = var28.getMembers();
               Player var63 = this.player;
               UUID var64 = var63.getUniqueId();
               var29.remove(var64);
               var82 = 571982716 ^ var82;
               Player var32 = this.player;
               o0KoOo0o0oOK var65 = GUI;
               String var4 = ruatcbkvcw(lhdfuypiostmevm(), var82);
               String var5 = ruatcbkvcw(cmsabrvivwhitpl(), var82);
               byte var6 = (byte)(1618077437 ^ var82);
               Object[] var74 = new Object[var6];
               byte var7 = (byte)(1618077439 ^ var82);
               String var8 = ruatcbkvcw(dxaarskmxmozxjf(), var82);
               var74[var7] = var8;
               byte var75 = (byte)(1618077438 ^ var82);
               TeamService var77 = this.team;
               String var78 = var77.getName();
               String var79 = String.valueOf(var78);
               var74[var75] = var79;
               String var66 = var65.msg(var4, var5, var74);
               oOo0KKoOoOK.sendActionBarAndChat(var32, var66);
               var82 = 748800383 ^ var82;
               TeamService var34 = this.team;
               Set var35 = var34.getMembers();
               Iterator var36 = var35.iterator();
               Iterator var11 = var36;
               var82 = 444667763 ^ var82;

               label70:
               while(true) {
                  byte var38 = var11.hasNext();
                  if (var38 == (1448163571 ^ var82)) {
                     label50:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var82)) {
                           case 121440263:
                              var82 ^= 615578550;
                              break label50;
                           case 742340814:
                           default:
                              throw new IllegalAccessException();
                           case 1089597895:
                              break label50;
                           case 1983067325:
                        }
                     }

                     KKoOoOo0oOK var48 = KKoOoOo0oOK.getInstance();
                     Runnable var69 = () -> {
                        int var7 = 351925931 ^ 873325405 ^ 1683682566;
                        var7 = 835254162 ^ var7;
                        TeamService var4 = this.team;
                        var25.broadcastTeamUpdate(var4);
                     };
                     var48.runNextTick(var69);
                     var82 = 1137272777 ^ var82;
                     break;
                  }

                  var82 = 300577878 ^ var82;
                  Object var40 = var11.next();
                  UUID var41 = (UUID)var40;
                  var82 = 1614823111 ^ var82;
                  Player var43 = Bukkit.getPlayer(var41);
                  var82 = 234786375 ^ var82;
                  if (var43 != null) {
                     var82 = 1905688136 ^ var82;
                     byte var46 = var43.isOnline();
                     if (var46 != (1536393837 ^ var82)) {
                        var82 = 1300617105 ^ var82;
                        KKoOoOo0oOK var47 = KKoOoOo0oOK.getInstance();
                        Runnable var71 = () -> {
                           int var17 = 1665795711 ^ 813557908 ^ 1683682566;
                           var17 = 1110252086 ^ var17;
                           o0KoOo0o0oOK var3 = GUI;
                           String var4 = ruatcbkvcw(peypzacckplsvts(), var17);
                           String var5 = ruatcbkvcw(xdgfwnsklbisjpa(), var17);
                           byte var6 = (byte)(1967129049 ^ var17);
                           Object[] var10 = new Object[var6];
                           byte var7 = (byte)(1967129051 ^ var17);
                           String var8 = ruatcbkvcw(jioezdfffmnwkqn(), var17);
                           var10[var7] = var8;
                           byte var11 = (byte)(1967129050 ^ var17);
                           Player var13 = this.player;
                           String var14 = var13.getName();
                           var10[var11] = var14;
                           String var9 = var3.msg(var4, var5, var10);
                           oOo0KKoOoOK.sendActionBarAndChat(var43, var9);
                        };
                        var47.runAtEntity(var43, var71);
                        var82 = 1988290961 ^ var82;
                     } else {
                        var82 = 990330368 ^ var82;
                     }
                  } else {
                     var82 = 1251033160 ^ var82;
                  }

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var82)) {
                        case 130470913:
                           break;
                        case 186666375:
                           var82 ^= 918914206;
                           continue label70;
                        case 625805767:
                        default:
                           throw new IllegalAccessException();
                        case 1619834483:
                           continue label70;
                     }
                  }
               }
            } else {
               var82 = 117942029 ^ var82;
            }

         }
      }
   }

   public void open() {
      int var12 = 1904387043 ^ 1877690065 ^ 1683682566;
      var12 = 1277936055 ^ var12;
      Player var4 = this.player;
      Inventory var7 = this.createInventory();
      var4.openInventory(var7);
      var12 = 1936144759 ^ var12;
      oOoOKo0o0K var6 = oOoOKo0o0K.getInstance();
      Inventory var9 = this.inv;
      var6.register(var9, this);
      var12 = 1806323439 ^ var12;
   }

   static {
      int var4 = 2003132176 ^ 481203499 ^ Integer.parseInt("1227378159");
      hgplgzlnby = ByteBuffer.wrap(pjjlyjtczzoxwxd()).asCharBuffer().toString();
      var4 = 135115610 ^ var4;
      String var0 = ruatcbkvcw(vvelgvcfgiopkdo(), var4);
      o0KoOo0o0oOK var1 = o0KoOo0o0oOK.of(var0);
      GUI = var1;
   }

   public static String ruatcbkvcw(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = hgplgzlnby;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] vvelgvcfgiopkdo() {
      return new byte[]{0, 0, 0, 26, 0, 0, 0, 0};
   }

   private static byte[] peypzacckplsvts() {
      return new byte[]{0, 0, 0, 11, 0, 0, 0, 26};
   }

   private static byte[] xdgfwnsklbisjpa() {
      return new byte[]{0, 0, 0, 40, 0, 0, 0, 37};
   }

   private static byte[] jioezdfffmnwkqn() {
      return new byte[]{0, 0, 0, 8, 0, 0, 0, 77};
   }

   private static byte[] ofqhgxgrvfaedbl() {
      return new byte[]{0, 0, 0, 20, 0, 0, 0, 85};
   }

   private static byte[] sraovztduxwaabs() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, 105};
   }

   private static byte[] ogotufyefxfgfjy() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, 111};
   }

   private static byte[] jibxlpbuogeqpbi() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, 118};
   }

   private static byte[] gjakfkuxdjzylru() {
      return new byte[]{0, 0, 0, 14, 0, 0, 0, 125};
   }

   private static byte[] bdzdrfggtjxudrg() {
      return new byte[]{0, 0, 0, 25, 0, 0, 0, -117};
   }

   private static byte[] rrfnzrqyldgptkt() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -92};
   }

   private static byte[] fadkpdfhzsjdiwh() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -86};
   }

   private static byte[] vudkhpcwzvtcnpl() {
      return new byte[]{0, 0, 0, 13, 0, 0, 0, -80};
   }

   private static byte[] mlvhlvdzldolibw() {
      return new byte[]{0, 0, 0, 17, 0, 0, 0, -67};
   }

   private static byte[] ymczywdfchqtepy() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -50};
   }

   private static byte[] ywbkjiauhamabmt() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -44};
   }

   private static byte[] lhdfuypiostmevm() {
      return new byte[]{0, 0, 0, 4, 0, 0, 0, -38};
   }

   private static byte[] cmsabrvivwhitpl() {
      return new byte[]{0, 0, 0, 19, 0, 0, 0, -34};
   }

   private static byte[] dxaarskmxmozxjf() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -15};
   }

   private static byte[] pjjlyjtczzoxwxd() {
      return new byte[]{55, 85, 48, 71, 53, 93, 48, 74, 52, 24, 50, 68, 50, 80, 52, 81, 57, 89, 55, 65, 48, 29, 53, 88, 48, 92, 52, 86, 50, 70, 50, 80, 52, 83, 57, 91, 55, 92, 48, 84, 53, 93, 48, 75, 52, 90, 50, 87, 50, 64, 52, 89, 49, 84, 54, 82, 49, 95, 57, 82, 53, 84, 49, 75, 54, 26, 49, 94, 57, 85, 53, 87, 49, 77, 49, 31, 54, 0, 49, 98, 57, 92, 53, 80, 49, 64, 54, 82, 49, 64, 57, 16, 53, 18, 49, 11, 54, 4, 49, 11, 57, 9, 53, 119, 49, 127, 54, 18, 49, 66, 57, 92, 53, 80, 49, 64, 54, 82, 49, 64, 57, 21, 53, 17, 49, 31, 54, 0, 49, 94, 57, 85, 53, 87, 49, 77, 54, 23, 49, 70, 57, 88, 53, 84, 49, 25, 54, 67, 49, 87, 57, 81, 53, 92, 49, 28, 54, 71, 49, 94, 57, 81, 53, 72, 49, 92, 54, 69, 49, 23, 43, 61, 42, 55, 52, 71, -98, 3, 54, 92, 59, -73, 37, 59, 51, 25, 49, -85, 43, 62, 42, 56, 43, 19, 59, 89, 54, 66, 59, 85, 56, 22, 46, 34, 46, 51, 43, 57, 42, 53, 54, 28, 55, 76, 54, 86, 57, 82, 52, 91, 57, 18, 55, 81, 55, 89, 52, 90, 55, 95, 48, 94, 50, 69, 54, 89, 55, 81, 55, 89, 52, 90, 55, 95, 48, 94, 50, 69, 54, 89, 55, 17, 55, 5, 52, 117, 55, 127, 48, 113, 50, 7, 54, 4, 41, 51, 36, 63, 53, 70, -112, 6, 54, 94, 53, -71, 45, 58, 55, 20, 55, 80, 52, 119, 55, 85, 48, 94, 50, 84, 54, 95, 52, 23, 57, 68, 55, 93, 55, 22, 52, 88, 55, 92, 48, 86, 50, 65, 54, 81, 52, 23, 57, 68, 55, 90, 55, 83, 52, 20, 55, 77, 48, 82, 50, 86, 54, 89, 49, 91, 49, 86, 57, 87, 50, 91, 55, 85, 49, 84, 49, 91, 49, 86, 57, 87, 50, 91, 55, 85, 49, 84, 49, 27, 49, 113, 57, 127, 50, 9, 55, 116, 49, 9, 49, 115, 36, 61, 47, 56, 53, 68, 44, 60, 44, 48, 59, -90, 49, 30, 49, 81, 57, 122, 50, 84, 55, 89, 49, 91, 49, 92, 57, 25, 50, 76, 55, 95, 49, 24, 49, 84, 57, 88, 50, 86, 55, 83, 49, 93, 49, 91, 49, 17, 55, 76, 50, 84, 55, 88, 48, 88, 49, 17, 49, 17, 55, 68, 54, 86, 50, 82, 56, 95, 49, 17, 49, 90, 49, 93, 48, 81, 55, 64, 49, 16, 49, 15, 48, 110, 55, 91, 51, 76, 49, 22, 49, 84, 48, 82, 55, 82, 51, 77, 49, 22, 49, 76, 48, 95, 55, 81, 51, 25, 49, 66, 49, 93, 48, 86, 55, 89, 49, 19, 49, 76, 48, 82, 55, 85, 51, 84, 49, 19};
   }

   private static int bdgpvafmvkehbgts(int var0, int var1) {
      return var0 ^ var1;
   }
}
