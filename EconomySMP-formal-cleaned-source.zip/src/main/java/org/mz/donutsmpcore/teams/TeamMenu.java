package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.Stream;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.mz.donutsmpcore.DonutSMPCore;
import org.mz.donutsmpcore.libs.signgui.SignGUI;
import org.mz.donutsmpcore.libs.signgui.SignGUIBuilder;
import org.mz.donutsmpcore.libs.signgui.SignGUIFinishHandler;
import skido.KKo0KoOoOK;
import skido.KKoOoOo0oOK;
import skido.KoOKKo0K;
import skido.KoOo0Ko0oOK;
import skido.o0KoOKKo0K;
import skido.o0KoOo0o0oOK;
import skido.o0o0oOKo0K;
import skido.o0oOKo0oOK;
import skido.oOo0KKoOoOK;

public class TeamMenu extends KoOKKo0K {
   private final TeamService team;
   private int page;
   private K sortType;
   private static final o0KoOo0o0oOK GUI;
   private static final List<Integer> DEFAULT_MEMBER_SLOTS;

   private static String title(int var0) {
      int var14 = 1372222388 ^ 606355393 ^ 1136106976;
      var14 = 1775173325 ^ var14;
      o0KoOo0o0oOK var1 = GUI;
      String var2 = lwcngthmfi(ptsyixflkrnkgbh(), kioffyrnyshogjc(), var14);
      String var3 = lwcngthmfi(ebuhkqllmjbrvrz(), kioffyrnyshogjc(), var14);
      byte var4 = (byte)(1603743578 ^ var14);
      Object[] var8 = new Object[var4];
      byte var5 = (byte)(1603743576 ^ var14);
      String var6 = lwcngthmfi(sfehofgknykmowo(), kioffyrnyshogjc(), var14);
      var8[var5] = var6;
      byte var9 = (byte)(1603743577 ^ var14);
      Integer var11 = var0;
      var8[var9] = var11;
      String var7 = var1.text(var2, var3, var8);
      return var7;
   }

   public TeamMenu(Player var1) {
      o0KoOo0o0oOK var4 = GUI;
      byte var5 = 54;
      int var13 = var4.size(var5);
      byte var16 = 1;
      String var17 = title(var16);
      super(var1, var13, var17);
      byte var9 = 1;
      this.page = var9;
      K var10 = firstSort();
      this.sortType = var10;
      TeamService2 var11 = TeamService2.getInstance();
      UUID var15 = var1.getUniqueId();
      TeamService var12 = var11.getTeamByPlayer(var15);
      this.team = var12;
   }

   protected Sound clickSound(int var1) {
      int var5 = 1610369167 ^ 1898330771 ^ 1341929048;
      var5 = 1539494394 ^ var5;
      Sound var2 = KKo0KoOoOK.CLICK;
      return var2;
   }

   private List<Integer> memberSlots() {
      int var28 = 1449797989 ^ 777285807 ^ 1341929048;
      var28 = 132452363 ^ var28;
      ArrayList var1 = new ArrayList();
      ArrayList var3 = var1;
      var28 = 177394315 ^ var28;
      o0KoOo0o0oOK var6 = GUI;
      String var20 = lwcngthmfi(xpjoovbournlygq(), kioffyrnyshogjc(), var28);
      List var2 = DEFAULT_MEMBER_SLOTS;
      List var7 = var6.slots(var20, var2);
      Iterator var8 = var7.iterator();
      Iterator var4 = var8;
      var28 = 1862857666 ^ var28;

      label44:
      while(true) {
         byte var10 = var4.hasNext();
         if (var10 == (1438473936 ^ var28)) {
            var28 = mdylhuvyxeiobwow(var28, 1333397058);
            return var3;
         }

         var28 = 509012550 ^ var28;
         Object var13 = var4.next();
         Integer var14 = (Integer)var13;
         int var15 = var14;
         var28 = 190494953 ^ var28;
         if (var15 >= (1085344895 ^ var28)) {
            var28 = 1827284540 ^ var28;
            Inventory var22 = this.inventory;
            int var23 = var22.getSize();
            if (var15 < var23) {
               var28 = 1500015248 ^ var28;
               Integer var25 = var15;
               boolean var19 = var3.add(var25);
               var28 = 1411508088 ^ var28;
            } else {
               label39:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var28)) {
                     case 92168607:
                        break;
                     case 99651002:
                        var28 ^= 222924264;
                        break label39;
                     case 973359124:
                     default:
                        throw new IllegalAccessException();
                     case 1342864405:
                        break label39;
                  }
               }
            }
         } else {
            var28 = mdylhuvyxeiobwow(var28, 1638116308);
         }

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var28)) {
               case 1312201:
                  var28 ^= 1957689723;
               case 104439497:
                  continue label44;
               case 1285114452:
                  break;
               case 1559968758:
               default:
                  throw new IllegalAccessException();
            }
         }
      }
   }

   private static ItemStack item(String var0, Material var1, String var2, List<String> var3, Object... var4) {
      Material var14;
      String var20;
      int var97;
      label89: {
         var97 = 1793897595 ^ 701676983 ^ 1136106976;
         var97 = 299666363 ^ var97;
         var20 = "items." + var0 + ".";
         var97 = 231710215 ^ var97;
         o0KoOo0o0oOK var21 = GUI;
         String var56 = var20 + "material";
         Material var22 = var21.material(var56, var1);
         var14 = var22;
         var97 = 733109876 ^ var97;
         if (var22 != null) {
            var97 = 762006078 ^ var97;
            byte var25 = var22.isAir();
            if (var25 == (440636890 ^ var97)) {
               var97 = 1946906650 ^ var97;
               break label89;
            }

            var97 = 559696198 ^ var97;
         } else {
            var97 = 204931960 ^ var97;
         }

         var14 = var1;
         var97 = 1431779676 ^ var97;
      }

      byte var8 = (byte)(1850271169 ^ var97);
      byte var9 = (byte)(1850271104 ^ var97);
      o0KoOo0o0oOK var10 = GUI;
      String var87 = var20 + "amount";
      byte var12 = (byte)(1850271169 ^ var97);
      int var86 = var10.integer(var87, var12);
      int var84 = Math.min(var9, var86);
      int var79 = Math.max(var8, var84);
      ItemStack var27 = new ItemStack(var14, var79);
      var97 = 1930551814 ^ var97;
      ItemMeta var29 = var27.getItemMeta();
      var97 = 1845976864 ^ var97;
      if (var29 != null) {
         var97 = 1691553830 ^ var97;
         o0KoOo0o0oOK var31 = GUI;
         String var58 = var20 + "name";
         String var32 = var31.text(var58, var2, var4);
         var97 = 407082885 ^ var97;
         byte var34 = var32.isEmpty();
         if (var34 == (265215813 ^ var97)) {
            var97 = 1878183694 ^ var97;
            var29.setDisplayName(var32);
            var97 = 802563763 ^ var97;
         } else {
            var97 = 1076160957 ^ var97;
         }

         o0KoOo0o0oOK var36 = GUI;
         String var61 = var20 + "lore";
         List var37 = var36.lines(var61, var3, var4);
         var97 = 1964410145 ^ var97;
         byte var39 = var37.isEmpty();
         if (var39 == (989639641 ^ var97)) {
            var97 = 1907253138 ^ var97;
            var29.setLore(var37);
            var97 = 50625455 ^ var97;
         } else {
            var97 = mdylhuvyxeiobwow(var97, 1923753021);
         }

         o0KoOo0o0oOK var41 = GUI;
         String var64 = var20 + "glow";
         byte var76 = (byte)(1213634532 ^ var97);
         byte var42 = var41.bool(var64, (boolean)var76);
         if (var42 != (1213634532 ^ var97)) {
            var97 = 745874603 ^ var97;
            String var43 = lwcngthmfi(xffzmklfcuzbtnx(), kioffyrnyshogjc(), var97);
            Enchantment var44 = Enchantment.getByName(var43);
            var97 = 1029168336 ^ var97;
            if (var44 != null) {
               var97 = 934131090 ^ var97;
               byte var77 = (byte)(1859770892 ^ var97);
               byte var82 = (byte)(1859770892 ^ var97);
               var29.addEnchant(var44, var77, (boolean)var82);
               var97 = 914464176 ^ var97;
            } else {
               label50:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var97)) {
                     case 223461680:
                        var97 ^= 19671074;
                        break label50;
                     case 1344778241:
                     default:
                        throw new IOException();
                     case 1714282649:
                        break;
                     case 1982318455:
                        break label50;
                  }
               }
            }

            byte var66 = (byte)(1482180540 ^ var97);
            ItemFlag[] var67 = new ItemFlag[var66];
            byte var83 = (byte)(1482180541 ^ var97);
            ItemFlag var85 = ItemFlag.HIDE_ENCHANTS;
            var67[var83] = var85;
            var29.addItemFlags(var67);
            var97 = 1194618982 ^ var97;
         } else {
            label64:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var97)) {
                  case 152528029:
                     break;
                  case 203918879:
                     var97 ^= 1463459903;
                  case 976760460:
                     break label64;
                  case 1420544210:
                  default:
                     throw new IOException();
               }
            }
         }

         o0KoOo0o0oOK var49 = GUI;
         String var69 = var20 + "custom-model-data";
         byte var78 = (byte)(527185883 ^ var97);
         int var50 = var49.integer(var69, var78);
         var97 = 139212565 ^ var97;
         if (var50 != (387973326 ^ var97)) {
            var97 = 1501196177 ^ var97;
            Integer var71 = var50;
            var29.setCustomModelData(var71);
            var97 = 9922741 ^ var97;
         } else {
            var97 = 1508706084 ^ var97;
         }

         boolean var54 = var27.setItemMeta(var29);
         var97 = 277870923 ^ var97;
         return var27;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var97)) {
               case 252459440:
               default:
                  throw new IOException();
               case 260489059:
                  var97 = 756852295 ^ var97;
                  return var27;
               case 538578894:
                  return var27;
               case 691365914:
            }
         }
      }
   }

   private void place(String var1, int var2, ItemStack var3, Consumer<InventoryClickEvent> var4) {
      int var15 = 1113285001 ^ 1600235544 ^ 1341929048;
      var15 = 487743288 ^ var15;
      o0KoOKKo0K var8 = new o0KoOKKo0K();
      o0KoOKKo0K var9 = var8.item(var3);
      o0KoOKKo0K var10 = var9.consumer(var4);
      this.place(var1, var2, var10);
      var15 = 1250901126 ^ var15;
   }

   private void place(String var1, int var2, o0KoOKKo0K var3) {
      int var25 = 1127666516 ^ 1970257977 ^ 1341929048;
      var25 = 493703815 ^ var25;
      o0KoOo0o0oOK var4 = GUI;
      String var14 = "items." + var1 + ".enabled";
      byte var6 = (byte)(1690859443 ^ var25);
      byte var8 = var4.bool(var14, (boolean)var6);
      if (var8 == (1690859442 ^ var25)) {
         var25 = 159675870 ^ var25;
      } else {
         var25 = 644082197 ^ var25;
         o0KoOo0o0oOK var9 = GUI;
         String var16 = "items." + var1 + ".slot";
         int var10 = var9.integer(var16, var2);
         var25 = 1920879681 ^ var25;
         if (var10 >= (819319270 ^ var25)) {
            var25 = 547662454 ^ var25;
            Inventory var18 = this.inventory;
            int var19 = var18.getSize();
            if (var10 < var19) {
               var25 = mdylhuvyxeiobwow(var25, 549898115);
               this.addButton(var10, var3);
               var25 = 246806542 ^ var25;
               return;
            }

            var25 = 1398986216 ^ var25;
         } else {
            var25 = mdylhuvyxeiobwow(var25, 1942388638);
         }

      }
   }

   public void decorate() {
      int var301 = 1427893223 ^ 1927604641 ^ 1341929048;
      var301 = 1275979348 ^ var301;
      Inventory var27 = this.inventory;
      var27.clear();
      var301 = 852513379 ^ var301;
      Map var29 = this.buttons;
      var29.clear();
      var301 = 854126449 ^ var301;
      TeamService var31 = this.team;
      if (var31 == null) {
         var301 = 128144916 ^ var301;
      } else {
         var301 = 1677111137 ^ var301;
         o0KoOo0o0oOK var32 = GUI;
         Inventory var112 = this.inventory;
         var32.fill(var112);
         var301 = 2025154263 ^ var301;
         List var34 = this.memberSlots();
         List var10 = var34;
         var301 = 639641157 ^ var301;
         List var36 = this.getSortedMembers();
         List var11 = var36;
         var301 = 475445844 ^ var301;
         byte var37 = (byte)(84097790 ^ var301);
         int var114 = var34.size();
         int var38 = Math.max(var37, var114);
         var301 = 505240083 ^ var301;
         int var40 = this.page;
         byte var115 = (byte)(454975725 ^ var301);
         int var41 = var40 - var115;
         int var42 = var41 * var38;
         int var13 = var42;
         var301 = 20823307 ^ var301;
         o0KoOo0o0oOK var43 = GUI;
         String var117 = lwcngthmfi(saekxqjjqbcickk(), kioffyrnyshogjc(), var301);
         String var3 = lwcngthmfi(rxdkymlryxrzqlx(), kioffyrnyshogjc(), var301);
         String var44 = var43.raw(var117, var3);
         String var14 = var44;
         var301 = 1712132253 ^ var301;
         o0KoOo0o0oOK var45 = GUI;
         String var118 = lwcngthmfi(hallvdamnqzohnj(), kioffyrnyshogjc(), var301);
         String var148 = lwcngthmfi(gagnpykzcylzhns(), kioffyrnyshogjc(), var301);
         String var46 = var45.raw(var118, var148);
         String var15 = var46;
         var301 = 362589210 ^ var301;
         o0KoOo0o0oOK var47 = GUI;
         String var119 = lwcngthmfi(dnniaaqrtqjzbqv(), kioffyrnyshogjc(), var301);
         String var149 = lwcngthmfi(ibozzxxdlqiehvl(), kioffyrnyshogjc(), var301);
         String var48 = var47.raw(var119, var149);
         String var16 = var48;
         var301 = 1077283806 ^ var301;
         byte var49 = (byte)(696543934 ^ var301);
         int var17 = var49;
         var301 = 533492897 ^ var301;

         while(true) {
            label260: {
               int var121 = var10.size();
               String var111;
               if (var17 < var121) {
                  var301 = 321184048 ^ var301;
                  Object var52 = var10.get(var17);
                  Integer var53 = (Integer)var52;
                  int var54 = var53;
                  var301 = 388222551 ^ var301;
                  int var56 = var13 + var17;
                  var301 = 1200785093 ^ var301;
                  int var125 = var11.size();
                  if (var56 >= var125) {
                     var301 = mdylhuvyxeiobwow(var301, 1017904406);
                     o0KoOo0o0oOK var58 = GUI;
                     String var126 = lwcngthmfi(wbklrgsrceveemq(), kioffyrnyshogjc(), var301);
                     byte var150 = (byte)(1232489130 ^ var301);
                     byte var59 = var58.bool(var126, (boolean)var150);
                     if (var59 != (1232489131 ^ var301)) {
                        var301 = 727970709 ^ var301;
                        o0KoOKKo0K var151 = new o0KoOKKo0K();
                        String var180 = lwcngthmfi(tospgltetbfcxwh(), kioffyrnyshogjc(), var301);
                        Material var4 = Material.GRAY_STAINED_GLASS_PANE;
                        String var5 = lwcngthmfi(vzatbqaozpmezwn(), kioffyrnyshogjc(), var301);
                        String var6 = lwcngthmfi(drnrahmmkcpcsmt(), kioffyrnyshogjc(), var301);
                        var301 = 1417324874 ^ var301;
                        List var252 = List.of(var6);
                        byte var7 = (byte)(913248372 ^ var301);
                        Object[] var263 = new Object[var7];
                        ItemStack var181 = item(var180, var4, var5, var252, var263);
                        o0KoOKKo0K var152 = var151.item(var181);
                        Consumer var183 = (var1) -> {
                           int var14 = 283850677 ^ 990459881 ^ 1341929048;
                           var14 = 2118884734 ^ var14;
                           Player var7 = this.player;
                           var7.closeInventory();
                           var14 = 594871936 ^ var14;
                           Player var9 = this.player;
                           o0KoOo0o0oOK var3 = GUI;
                           String var4 = lwcngthmfi(szrblojjeygzmgh(), kioffyrnyshogjc(), var14);
                           String var5 = lwcngthmfi(bdermgzudkfdpjx(), kioffyrnyshogjc(), var14);
                           byte var6 = (byte)(958443002 ^ var14);
                           Object[] var11 = new Object[var6];
                           String var10 = var3.msg(var4, var5, var11);
                           oOo0KKoOoOK.sendActionBarAndChat(var9, var10);
                           var14 = 855395114 ^ var14;
                        };
                        var301 = 1828311891 ^ var301;
                        o0KoOKKo0K var153 = var152.consumer(var183);
                        var301 = 781579769 ^ var301;
                        this.addButton(var54, var153);
                        var301 = 1253425272 ^ var301;
                     } else {
                        var301 = mdylhuvyxeiobwow(var301, 2009119757);
                     }
                     break label260;
                  }

                  UUID var63;
                  OfflinePlayer var65;
                  byte var87;
                  label169: {
                     var301 = 1288853557 ^ var301;
                     Object var62 = var11.get(var56);
                     var63 = (UUID)var62;
                     var301 = 1650858739 ^ var301;
                     var65 = Bukkit.getOfflinePlayer(var63);
                     var301 = 1677444771 ^ var301;
                     byte var67 = var65.isOnline();
                     if (var67 == (949105624 ^ var301)) {
                        var301 = 788435799 ^ var301;
                        Player var69 = Bukkit.getPlayer(var63);
                        if (var69 == null) {
                           label154:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var301)) {
                                 case 171767151:
                                    break label154;
                                 case 192045433:
                                    var301 ^= 617550955;
                                    break label154;
                                 case 685732307:
                                    break;
                                 case 824959058:
                                 default:
                                    throw new IOException();
                              }
                           }

                           var87 = (byte)(849589476 ^ var301);
                           var301 = 209507566 ^ var301;
                           break label169;
                        }

                        var301 = 142213010 ^ var301;
                     } else {
                        label167:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var301)) {
                              case 228293856:
                                 var301 ^= 646409413;
                                 break label167;
                              case 513820406:
                              default:
                                 throw new IOException();
                              case 2062490946:
                                 break label167;
                              case 2115355881:
                           }
                        }
                     }

                     var87 = (byte)(504717084 ^ var301);
                     var301 = 550125335 ^ var301;
                  }

                  var301 = 240914484 ^ var301;
                  String var71 = var65.getName();
                  String var86;
                  if (var71 == null) {
                     var301 = 954734355 ^ var301;
                     var86 = lwcngthmfi(pnaztmhtbydldcc(), kioffyrnyshogjc(), var301);
                     var301 = 801251512 ^ var301;
                  } else {
                     var301 = 1915881294 ^ var301;
                     var86 = var65.getName();
                     var301 = 1696084197 ^ var301;
                  }

                  var301 = 1246877383 ^ var301;
                  Material var154 = Material.PLAYER_HEAD;
                  ItemStack var72 = new ItemStack(var154);
                  var301 = 1234429118 ^ var301;
                  ItemMeta var74 = var72.getItemMeta();
                  SkullMeta var75 = (SkullMeta)var74;
                  var301 = 1037514807 ^ var301;
                  if (var75 != null) {
                     var301 = 1078295424 ^ var301;
                     o0oOKo0oOK var77 = o0oOKo0oOK.getInstance();
                     var77.apply(var75, var63);
                     var301 = 600277481 ^ var301;
                     byte var78 = (byte)(2050930618 ^ var301);
                     Object[] var79 = new Object[var78];
                     byte var156 = (byte)(2050930610 ^ var301);
                     String var184 = lwcngthmfi(dtqlkbfsmvdheis(), kioffyrnyshogjc(), var301);
                     var79[var156] = var184;
                     byte var157 = (byte)(2050930611 ^ var301);
                     String var216;
                     if (var87 != (2050930610 ^ var301)) {
                        var301 = 59277167 ^ var301;
                        var216 = var14;
                        var301 = 1461289557 ^ var301;
                     } else {
                        label139:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var301)) {
                              case 168775380:
                              default:
                                 throw new IOException();
                              case 215611862:
                                 var301 ^= 71296443;
                                 break label139;
                              case 1276735284:
                                 break;
                              case 1301242828:
                                 break label139;
                           }
                        }

                        var216 = var15;
                        var301 = 1353586817 ^ var301;
                     }

                     var79[var157] = var216;
                     byte var158 = (byte)(783239818 ^ var301);
                     String var186 = lwcngthmfi(vglchjyzvuiseng(), kioffyrnyshogjc(), var301);
                     var79[var158] = var186;
                     byte var159 = (byte)(783239819 ^ var301);
                     var79[var159] = var86;
                     byte var160 = (byte)(783239820 ^ var301);
                     String var188 = lwcngthmfi(lgkshrtdoxlplkx(), kioffyrnyshogjc(), var301);
                     var79[var160] = var188;
                     byte var161 = (byte)(783239821 ^ var301);
                     o0KoOo0o0oOK var189 = GUI;
                     var301 = 2070522814 ^ var301;
                     String var223;
                     if (var87 != (1439097142 ^ var301)) {
                        var301 = 1794469043 ^ var301;
                        var223 = lwcngthmfi(xzwuxwyrhnazolh(), kioffyrnyshogjc(), var301);
                        var301 = mdylhuvyxeiobwow(var301, 1863747100);
                     } else {
                        var301 = mdylhuvyxeiobwow(var301, 403721896);
                        var223 = lwcngthmfi(qznylvvnrixphxe(), kioffyrnyshogjc(), var301);
                        var301 = 502506503 ^ var301;
                     }

                     String var251;
                     if (var87 != (1344605081 ^ var301)) {
                        var301 = 1134316712 ^ var301;
                        var251 = lwcngthmfi(qrnfmpbmgukyqgi(), kioffyrnyshogjc(), var301);
                        var301 = 239533918 ^ var301;
                     } else {
                        label124:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var301)) {
                              case 189240925:
                                 var301 ^= 1794004653;
                                 break label124;
                              case 201144705:
                                 break;
                              case 406640575:
                              default:
                                 throw new IOException();
                              case 1626023170:
                                 break label124;
                           }
                        }

                        var251 = lwcngthmfi(piojnxqiksmmqck(), kioffyrnyshogjc(), var301);
                        var301 = 657778011 ^ var301;
                     }

                     String var190 = var189.raw(var223, var251);
                     var79[var161] = var190;
                     byte var162 = (byte)(503298153 ^ var301);
                     String var191 = lwcngthmfi(kvnivjwrshpouop(), kioffyrnyshogjc(), var301);
                     var79[var162] = var191;
                     byte var163 = (byte)(503298152 ^ var301);
                     var301 = 247085176 ^ var301;
                     TeamService var193 = this.team;
                     byte var194 = var193.isLeader(var63);
                     String var195;
                     if (var194 != (323321879 ^ var301)) {
                        var301 = 1683936366 ^ var301;
                        var195 = var16;
                        var301 = 63422249 ^ var301;
                     } else {
                        label110:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var301)) {
                              case 89570153:
                                 var301 ^= 820953547;
                                 break label110;
                              case 323555014:
                              default:
                                 throw new IOException();
                              case 1109695420:
                                 break label110;
                              case 1498319721:
                           }
                        }

                        var195 = lwcngthmfi(gimacgsisotkpqv(), kioffyrnyshogjc(), var301);
                        var301 = 1467460236 ^ var301;
                     }

                     var79[var163] = var195;
                     var301 = 796277601 ^ var301;
                     o0KoOo0o0oOK var130 = GUI;
                     String var164 = lwcngthmfi(nnpvhivgupbgnnz(), kioffyrnyshogjc(), var301);
                     String var196 = lwcngthmfi(zqjmyckwphxlkhs(), kioffyrnyshogjc(), var301);
                     String var131 = var130.text(var164, var196, var79);
                     var75.setDisplayName(var131);
                     var301 = 1323905893 ^ var301;
                     o0KoOo0o0oOK var132 = GUI;
                     String var165 = lwcngthmfi(lgtzlzyibvzwkbs(), kioffyrnyshogjc(), var301);
                     String var197 = lwcngthmfi(kbyiqzewriggneh(), kioffyrnyshogjc(), var301);
                     List var198 = List.of(var197);
                     List var133 = var132.lines(var165, var198, var79);
                     var75.setLore(var133);
                     var301 = 1731971090 ^ var301;
                     var72.setItemMeta(var75);
                     var301 = 1457105821 ^ var301;
                  } else {
                     var301 = 1025363200 ^ var301;
                  }

                  o0KoOKKo0K var166 = new o0KoOKKo0K();
                  o0KoOKKo0K var167 = var166.item(var72);
                  Consumer var201 = (var2) -> {
                     int var8 = 744128300 ^ 486483068 ^ 1341929048;
                     var8 = 866523750 ^ var8;
                     this.handleMemberClick(var2, var63);
                  };
                  o0KoOKKo0K var168 = var167.consumer(var201);
                  this.addButton(var54, var168);
                  var301 = 1589900515 ^ var301;

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var301)) {
                        case 220117838:
                           var301 ^= 1154777758;
                        case 728044229:
                           break label260;
                        case 2035063556:
                        default:
                           throw new IOException();
                        case 2141252525:
                     }
                  }
               } else {
                  var301 = mdylhuvyxeiobwow(var301, 1159109606);
                  String var136 = lwcngthmfi(zbwyqdyiuaytniw(), kioffyrnyshogjc(), var301);
                  byte var169 = (byte)(1935574484 ^ var301);
                  String var202 = lwcngthmfi(trjdktjnyaqjffl(), kioffyrnyshogjc(), var301);
                  Material var224 = Material.OAK_SIGN;
                  String var246 = lwcngthmfi(jctyrkpuqpcadzs(), kioffyrnyshogjc(), var301);
                  String var253 = lwcngthmfi(ztqrarpsjbkktwd(), kioffyrnyshogjc(), var301);
                  List var254 = List.of(var253);
                  byte var264 = (byte)(1935574521 ^ var301);
                  Object[] var265 = new Object[var264];
                  ItemStack var203 = item(var202, var224, var246, var254, var265);
                  Consumer var226 = this::handleSearch;
                  this.place(var136, var169, var203, var226);
                  var301 = 1518660137 ^ var301;
                  this.updateSortButton();
                  var301 = 1644966967 ^ var301;
                  String var137 = lwcngthmfi(pffsfsmqjafyegt(), kioffyrnyshogjc(), var301);
                  byte var170 = (byte)(1272339415 ^ var301);
                  String var204 = lwcngthmfi(ahsmhyxiizwcuvc(), kioffyrnyshogjc(), var301);
                  Material var227 = Material.ARROW;
                  String var247 = lwcngthmfi(qurbzgkpvbtwfiw(), kioffyrnyshogjc(), var301);
                  String var255 = lwcngthmfi(wzgqmzlgnaxahqu(), kioffyrnyshogjc(), var301);
                  List var256 = List.of(var255);
                  byte var266 = (byte)(1272339431 ^ var301);
                  Object[] var267 = new Object[var266];
                  ItemStack var205 = item(var204, var227, var247, var256, var267);
                  Consumer var229 = (var1) -> {
                     int var6 = 1169777862 ^ 1212677802 ^ 1341929048;
                     var6 = 674759738 ^ var6;
                     byte var3 = (byte)(-1782229007 ^ var6);
                     this.changePage(var3);
                  };
                  this.place(var137, var170, var205, var229);
                  var301 = 1266693536 ^ var301;
                  String var138 = lwcngthmfi(woezdybqjeaupxu(), kioffyrnyshogjc(), var301);
                  byte var171 = (byte)(5664373 ^ var301);
                  String var206 = lwcngthmfi(rxctgjfuciunwqg(), kioffyrnyshogjc(), var301);
                  Material var230 = Material.ARROW;
                  String var248 = lwcngthmfi(mssnmoodzkizehw(), kioffyrnyshogjc(), var301);
                  String var257 = lwcngthmfi(mjjejbulyipftag(), kioffyrnyshogjc(), var301);
                  List var258 = List.of(var257);
                  byte var268 = (byte)(5664327 ^ var301);
                  Object[] var269 = new Object[var268];
                  ItemStack var207 = item(var206, var230, var248, var258, var269);
                  Consumer var232 = (var1) -> {
                     int var6 = 217825589 ^ 339198824 ^ 1341929048;
                     var6 = 1591600894 ^ var6;
                     byte var3 = (byte)(166580986 ^ var6);
                     this.changePage(var3);
                  };
                  this.place(var138, var171, var207, var232);
                  var301 = 1554772014 ^ var301;
                  TeamService var93 = this.team;
                  byte var94 = var93.hasTeamHome();
                  var301 = 625438896 ^ var301;
                  String var95 = lwcngthmfi(hrmnqqzqambxlpy(), kioffyrnyshogjc(), var301);
                  Material var139 = Material.WHITE_BANNER;
                  String var172 = lwcngthmfi(nzncpaicxtyzcwb(), kioffyrnyshogjc(), var301);
                  List var208 = List.of();
                  byte var233 = (byte)(2042293977 ^ var301);
                  Object[] var234 = new Object[var233];
                  ItemStack var96 = item(var95, var139, var172, var208, var234);
                  var301 = 609732684 ^ var301;
                  ItemMeta var98 = var96.getItemMeta();
                  var301 = 266159407 ^ var301;
                  if (var98 != null) {
                     var301 = 886519476 ^ var301;
                     o0KoOo0o0oOK var140 = GUI;
                     String var179;
                     if (var94 != (1726436622 ^ var301)) {
                        var301 = 1967085223 ^ var301;
                        var179 = lwcngthmfi(exphujdiinxarbv(), kioffyrnyshogjc(), var301);
                        var301 = mdylhuvyxeiobwow(var301, 606870216);
                     } else {
                        label194:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var301)) {
                              case 123753004:
                                 var301 ^= 1337236436;
                                 break label194;
                              case 1121877107:
                                 break;
                              case 1698139379:
                                 break label194;
                              case 1881058591:
                              default:
                                 throw new IOException();
                           }
                        }

                        var179 = lwcngthmfi(ycpwswafnijoscd(), kioffyrnyshogjc(), var301);
                        var301 = 514316219 ^ var301;
                     }

                     String var217;
                     if (var94 != (938744161 ^ var301)) {
                        var301 = 2065760850 ^ var301;
                        var217 = lwcngthmfi(xtcwpakflhqcfpc(), kioffyrnyshogjc(), var301);
                        var301 = mdylhuvyxeiobwow(var301, 1561933985);
                     } else {
                        var301 = mdylhuvyxeiobwow(var301, 1474969772);
                        var217 = lwcngthmfi(vlocsxqwoppedfs(), kioffyrnyshogjc(), var301);
                        var301 = 1909619295 ^ var301;
                     }

                     List var210 = List.of(var217);
                     byte var235 = (byte)(298591122 ^ var301);
                     Object[] var236 = new Object[var235];
                     var301 = 73466032 ^ var301;
                     List var141 = var140.lines(var179, var210, var236);
                     var98.setLore(var141);
                     var301 = 1809918867 ^ var301;
                     var96.setItemMeta(var98);
                     var301 = 1581710356 ^ var301;
                  } else {
                     label206:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var301)) {
                           case 255693576:
                              var301 ^= 1916442399;
                              break label206;
                           case 931624045:
                              break;
                           case 1040093979:
                              break label206;
                           case 1455633137:
                           default:
                              throw new IOException();
                        }
                     }
                  }

                  String var143 = lwcngthmfi(otbuokxeuzirkgp(), kioffyrnyshogjc(), var301);
                  byte var174 = (byte)(537588881 ^ var301);
                  Consumer var238 = this::handleHome;
                  this.place(var143, var174, var96, var238);
                  var301 = 2121741400 ^ var301;
                  TeamService var105 = this.team;
                  byte var106 = var105.isPvpEnabled();
                  if (var106 != (1585299709 ^ var301)) {
                     var301 = 1295878012 ^ var301;
                     o0KoOo0o0oOK var110 = GUI;
                     String var147 = lwcngthmfi(jflnuwonbjiakjk(), kioffyrnyshogjc(), var301);
                     String var178 = lwcngthmfi(hhbergzalrzdnsx(), kioffyrnyshogjc(), var301);
                     var111 = var110.raw(var147, var178);
                     var301 = mdylhuvyxeiobwow(var301, 1127192523);
                  } else {
                     label181:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var301)) {
                           case 118750103:
                              var301 ^= 1024882787;
                              break label181;
                           case 1311145874:
                              break;
                           case 1474908844:
                              break label181;
                           case 2017766914:
                           default:
                              throw new IOException();
                        }
                     }

                     o0KoOo0o0oOK var107 = GUI;
                     String var144 = lwcngthmfi(rwiwbyjachxzngq(), kioffyrnyshogjc(), var301);
                     String var175 = lwcngthmfi(loyffqznpllrrql(), kioffyrnyshogjc(), var301);
                     var111 = var107.raw(var144, var175);
                     var301 = 855926996 ^ var301;
                  }
               }

               var301 = 1002166099 ^ var301;
               String var145 = lwcngthmfi(lflvonmiqersxvr(), kioffyrnyshogjc(), var301);
               byte var176 = (byte)(1809057580 ^ var301);
               String var212 = lwcngthmfi(jjkxbununhpkbnn(), kioffyrnyshogjc(), var301);
               Material var239 = Material.IRON_SWORD;
               String var249 = lwcngthmfi(irqzhbrcsvxkjxb(), kioffyrnyshogjc(), var301);
               String var259 = lwcngthmfi(vwofbxsansudgww(), kioffyrnyshogjc(), var301);
               List var260 = List.of(var259);
               byte var270 = (byte)(1809057563 ^ var301);
               Object[] var271 = new Object[var270];
               byte var8 = (byte)(1809057561 ^ var301);
               String var9 = lwcngthmfi(jzomtlutqchwaez(), kioffyrnyshogjc(), var301);
               var271[var8] = var9;
               byte var275 = (byte)(1809057560 ^ var301);
               var271[var275] = var111;
               ItemStack var213 = item(var212, var239, var249, var260, var271);
               Consumer var241 = this::handlePvPToggle;
               this.place(var145, var176, var213, var241);
               var301 = 1790335553 ^ var301;
               String var146 = lwcngthmfi(ahzpssknievmany(), kioffyrnyshogjc(), var301);
               byte var177 = (byte)(23223657 ^ var301);
               String var214 = lwcngthmfi(luozxfkgucnhwfq(), kioffyrnyshogjc(), var301);
               Material var242 = Material.IRON_HELMET;
               String var250 = lwcngthmfi(tcevcxmuslbndbe(), kioffyrnyshogjc(), var301);
               String var261 = lwcngthmfi(ubgjguumeeyxabg(), kioffyrnyshogjc(), var301);
               String var272 = lwcngthmfi(iafzxinhlhmenmf(), kioffyrnyshogjc(), var301);
               var301 = 1249467645 ^ var301;
               List var262 = List.of(var261, var272);
               byte var273 = (byte)(1260061091 ^ var301);
               Object[] var274 = new Object[var273];
               byte var276 = (byte)(1260061093 ^ var301);
               String var283 = lwcngthmfi(cachlmsrzmfwbsl(), kioffyrnyshogjc(), var301);
               var274[var276] = var283;
               byte var277 = (byte)(1260061092 ^ var301);
               TeamService var285 = this.team;
               var301 = 312159234 ^ var301;
               String var286 = var285.getDisplayName();
               var274[var277] = var286;
               byte var278 = (byte)(1501572517 ^ var301);
               String var287 = lwcngthmfi(suoarcksyfyuuue(), kioffyrnyshogjc(), var301);
               var274[var278] = var287;
               byte var279 = (byte)(1501572516 ^ var301);
               int var289 = var11.size();
               Integer var290 = var289;
               var274[var279] = var290;
               byte var280 = (byte)(1501572515 ^ var301);
               String var291 = lwcngthmfi(mdgcrrbpxrmetrn(), kioffyrnyshogjc(), var301);
               var274[var280] = var291;
               byte var281 = (byte)(1501572514 ^ var301);
               int var293 = this.page;
               Integer var294 = var293;
               var274[var281] = var294;
               var301 = 1228366208 ^ var301;
               ItemStack var215 = item(var214, var242, var250, var262, var274);
               Consumer var244 = (var1) -> {
                  int var7 = 57347988 ^ 1000103024 ^ 1341929048;
                  var7 = 1432928837 ^ var7;
                  Player var4 = this.player;
                  TeamMenu var2 = new TeamMenu(var4);
                  var2.open();
               };
               this.place(var146, var177, var215, var244);
               var301 = 638728879 ^ var301;
               return;
            }

            var17 += 1052178087 ^ var301;
            var301 = 150923449 ^ var301;
         }
      }
   }

   private static List<K> sortOrder() {
      int var40 = 408822152 ^ 1463709807 ^ 1136106976;
      var40 = 582182913 ^ var40;
      ArrayList var0 = new ArrayList();
      ArrayList var6 = var0;
      var40 = 819457891 ^ var40;
      String var10 = lwcngthmfi(pqyskqnstkcsooq(), kioffyrnyshogjc(), var40);
      o0o0oOKo0K var11 = o0o0oOKo0K.of(var10);
      String var32 = lwcngthmfi(qvjblofkgifhdzx(), kioffyrnyshogjc(), var40);
      String var1 = lwcngthmfi(hqksgokfeyiswoz(), kioffyrnyshogjc(), var40);
      String var2 = lwcngthmfi(atfgxqgcrcvlzbs(), kioffyrnyshogjc(), var40);
      String var3 = lwcngthmfi(azgeeuofnhcsdcp(), kioffyrnyshogjc(), var40);
      String var4 = lwcngthmfi(oeiyqvilxegnpbb(), kioffyrnyshogjc(), var40);
      String var5 = lwcngthmfi(zwgxqrsmhsdeiga(), kioffyrnyshogjc(), var40);
      var40 = 1180588673 ^ var40;
      List var37 = List.of(var1, var2, var3, var4, var5);
      var40 = 419386321 ^ var40;
      List var12 = var11.rawListAt(var32, var37);
      Iterator var13 = var12.iterator();
      Iterator var7 = var13;
      var40 = 1032712176 ^ var40;

      while(true) {
         byte var15 = var7.hasNext();
         if (var15 == (2107616709 ^ var40)) {
            var40 = 2034203552 ^ var40;
            byte var28 = var6.isEmpty();
            if (var28 != (77649509 ^ var40)) {
               var40 = 1602550439 ^ var40;
               K[] var35 = TeamMenu.K.values();
               List var36 = List.of(var35);
               boolean var30 = var6.addAll(var36);
               var40 = 1785958118 ^ var40;
               return var6;
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var40)) {
                     case 72797278:
                        var40 = 905409601 ^ var40;
                        return var6;
                     case 186274912:
                        break;
                     case 225365860:
                     default:
                        throw new RuntimeException();
                     case 1906427386:
                        return var6;
                  }
               }
            }
         }

         var40 = 2107329289 ^ var40;
         Object var17 = var7.next();
         String var18 = (String)var17;
         var40 = 990186132 ^ var40;
         String var20 = var18.trim();
         K var21 = TeamMenu.K.fromKey(var20);
         var40 = 1823910822 ^ var40;
         if (var21 != null) {
            var40 = 502695835 ^ var40;
            byte var24 = var6.contains(var21);
            if (var24 == (1245823077 ^ var40)) {
               var40 = 1501977310 ^ var40;
               var6.add(var21);
               var40 = 1717188985 ^ var40;
            } else {
               var40 = mdylhuvyxeiobwow(var40, 1071408039);
            }
         } else {
            var40 = mdylhuvyxeiobwow(var40, 573236284);
         }

         var40 = 134352391 ^ var40;
      }
   }

   private static K firstSort() {
      int var6 = 503393675 ^ 491541618 ^ 1136106976;
      var6 = 1694068568 ^ var6;
      List var0 = sortOrder();
      byte var1 = (byte)(604212033 ^ var6);
      Object var2 = var0.get(var1);
      K var3 = (K)var2;
      return var3;
   }

   private void updateSortButton() {
      int var101 = 979483031 ^ 203820942 ^ 1341929048;
      var101 = 941573366 ^ var101;
      List var1 = sortOrder();
      var101 = 200490366 ^ var101;
      K var46 = this.sortType;
      byte var17 = var1.contains(var46);
      if (var17 == (1247279561 ^ var101)) {
         var101 = 1596797041 ^ var101;
         byte var3 = (byte)(360368568 ^ var101);
         Object var48 = var1.get(var3);
         K var49 = (K)var48;
         this.sortType = var49;
         var101 = 998813622 ^ var101;
      } else {
         var101 = 1688575943 ^ var101;
      }

      String var19 = lwcngthmfi(wdssfnuounieouz(), kioffyrnyshogjc(), var101);
      Material var50 = Material.HOPPER;
      String var63 = lwcngthmfi(czemvszyoxzhlvh(), kioffyrnyshogjc(), var101);
      List var4 = List.of();
      byte var5 = (byte)(787637774 ^ var101);
      Object[] var83 = new Object[var5];
      ItemStack var20 = item(var19, var50, var63, var4, var83);
      var101 = 573928062 ^ var101;
      ItemMeta var22 = var20.getItemMeta();
      var101 = 1995026665 ^ var101;
      if (var22 == null) {
         var101 = 1612723793 ^ var101;
      } else {
         var101 = 477834753 ^ var101;
         o0KoOo0o0oOK var64 = GUI;
         String var73 = lwcngthmfi(xexhlbuqclcomng(), kioffyrnyshogjc(), var101);
         List var84 = List.of();
         byte var6 = (byte)(1716882072 ^ var101);
         Object[] var96 = new Object[var6];
         List var65 = var64.lines(var73, var84, var96);
         ArrayList var24 = new ArrayList(var65);
         ArrayList var10 = var24;
         var101 = 992339052 ^ var101;
         o0KoOo0o0oOK var25 = GUI;
         String var51 = lwcngthmfi(rvgbhuvxwsedpzb(), kioffyrnyshogjc(), var101);
         String var66 = lwcngthmfi(nqxycjcxmgznlcf(), kioffyrnyshogjc(), var101);
         String var26 = var25.raw(var51, var66);
         String var11 = var26;
         var101 = 1196358152 ^ var101;
         o0KoOo0o0oOK var27 = GUI;
         String var52 = lwcngthmfi(cahxrjddtuvnuxh(), kioffyrnyshogjc(), var101);
         String var67 = lwcngthmfi(klblziygtrzhiyn(), kioffyrnyshogjc(), var101);
         String var28 = var27.raw(var52, var67);
         String var12 = var28;
         var101 = 951682290 ^ var101;
         o0KoOo0o0oOK var29 = GUI;
         String var53 = lwcngthmfi(mowtaleyqwzbgyp(), kioffyrnyshogjc(), var101);
         String var68 = lwcngthmfi(ryezuyqvqgzcsws(), kioffyrnyshogjc(), var101);
         String var30 = var29.raw(var53, var68);
         String var13 = var30;
         var101 = 1217288585 ^ var101;
         Iterator var32 = var1.iterator();
         Iterator var14 = var32;
         var101 = 1108234383 ^ var101;

         while(true) {
            byte var34 = var14.hasNext();
            if (var34 == (671553800 ^ var101)) {
               var101 = 1812195398 ^ var101;
               o0KoOo0o0oOK var58 = GUI;
               String var71 = lwcngthmfi(eiecmexkvcjfsql(), kioffyrnyshogjc(), var101);
               List var78 = List.of();
               byte var90 = (byte)(1141174606 ^ var101);
               Object[] var91 = new Object[var90];
               List var59 = var58.lines(var71, var78, var91);
               boolean var41 = var10.addAll(var59);
               var101 = 385472733 ^ var101;
               var22.setLore(var10);
               var101 = 1836536363 ^ var101;
               var20.setItemMeta(var22);
               var101 = 629467504 ^ var101;
               break;
            }

            var101 = 1696303909 ^ var101;
            Object var36 = var14.next();
            K var37 = (K)var36;
            var101 = 1992166942 ^ var101;
            String var69 = lwcngthmfi(ordcrtiibkwzixh(), kioffyrnyshogjc(), var101);
            var101 = 1074474939 ^ var101;
            K var86 = this.sortType;
            String var77;
            if (var37 == var86) {
               var101 = 338129491 ^ var101;
               var77 = var11;

               label48:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var101)) {
                     case 113620550:
                        break label48;
                     case 136640534:
                        var101 ^= 345001175;
                        break label48;
                     case 771166063:
                     default:
                        throw new IOException();
                     case 1832834619:
                  }
               }
            } else {
               label38:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var101)) {
                     case 261664894:
                        var101 ^= 1309866221;
                        break label38;
                     case 1161096712:
                     default:
                        throw new IOException();
                     case 1354374204:
                        break label38;
                     case 1726313768:
                  }
               }

               var77 = var12;
               var101 = 1319487081 ^ var101;
            }

            String var55 = var13.replace(var69, var77);
            String var70 = lwcngthmfi(ftloqqiipnkhkhh(), kioffyrnyshogjc(), var101);
            o0KoOo0o0oOK var75 = GUI;
            String var88 = var37.key;
            String var89 = "sort.labels." + var88;
            String var98 = var37.label;
            var101 = 645735735 ^ var101;
            String var76 = var75.raw(var89, var98);
            String var56 = var55.replace(var70, var76);
            var101 = 364339215 ^ var101;
            String var57 = oOo0KKoOoOK.color(var56);
            boolean var39 = var10.add(var57);
            var101 = 61831435 ^ var101;
            var101 = mdylhuvyxeiobwow(var101, 1669113911);
         }
      }

      String var62 = lwcngthmfi(chkpjoycgpyzxzd(), kioffyrnyshogjc(), var101);
      byte var72 = (byte)(437162726 ^ var101);
      o0KoOKKo0K var79 = new o0KoOKKo0K();
      o0KoOKKo0K var80 = var79.item(var20);
      String var93 = lwcngthmfi(tuagnmzccxxvboa(), kioffyrnyshogjc(), var101);
      o0KoOKKo0K var81 = var80.filterSound(var93);
      Consumer var95 = (var1x) -> {
         int var22 = 674223111 ^ 1463745264 ^ 1341929048;
         var22 = 94647482 ^ var22;
         List var2 = sortOrder();
         var22 = 1536494315 ^ var22;
         K var12 = this.sortType;
         int var9 = var2.indexOf(var12);
         var22 = 15541377 ^ var22;
         byte var5 = (byte)(1848705662 ^ var22);
         int var16 = var9 + var5;
         int var19 = var2.size();
         int var17 = var16 % var19;
         Object var14 = var2.get(var17);
         K var15 = (K)var14;
         this.sortType = var15;
         var22 = 2115980339 ^ var22;
         this.decorate();
         var22 = 28205449 ^ var22;
      };
      o0KoOKKo0K var82 = var81.consumer(var95);
      this.place(var62, var72, var82);
      var101 = 970655135 ^ var101;
   }

   private void changePage(int var1) {
      int var38 = 485857568 ^ 69545481 ^ 1341929048;
      var38 = 1196461509 ^ var38;
      int var6 = this.page;
      int var7 = var6 + var1;
      var38 = 1731332155 ^ var38;
      byte var8 = (byte)(2001601678 ^ var38);
      List var23 = this.memberSlots();
      int var24 = var23.size();
      int var9 = Math.max(var8, var24);
      var38 = 1894962472 ^ var38;
      if (var1 < (129814951 ^ var38)) {
         var38 = 316345581 ^ var38;
         int var12 = this.page;
         byte var25 = (byte)(359128395 ^ var38);
         if (var12 <= var25) {
            var38 = mdylhuvyxeiobwow(var38, 1196657722);
            return;
         }

         var38 = 1543375838 ^ var38;
      } else {
         var38 = mdylhuvyxeiobwow(var38, 1227163443);
      }

      if (var1 > (1318704788 ^ var38)) {
         var38 = 1012842618 ^ var38;
         byte var26 = (byte)(1925650159 ^ var38);
         int var15 = var7 - var26;
         int var16 = var15 * var9;
         TeamService var29 = this.team;
         Set var30 = var29.getMembers();
         int var31 = var30.size();
         if (var16 >= var31) {
            var38 = 552814494 ^ var38;
            return;
         }

         var38 = mdylhuvyxeiobwow(var38, 2118632212);
      } else {
         var38 = mdylhuvyxeiobwow(var38, 1108935534);
      }

      this.page = var7;
      var38 = 1767268441 ^ var38;
      this.decorate();
      var38 = 285305380 ^ var38;
      Player var20 = this.player;
      InventoryView var21 = var20.getOpenInventory();
      int var34 = this.page;
      String var35 = title(var34);
      var21.setTitle(var35);
      var38 = 1202384554 ^ var38;
   }

   private void handleMemberClick(InventoryClickEvent var1, UUID var2) {
      int var45 = 433602760 ^ 906722550 ^ 1341929048;
      var45 = 56803533 ^ var45;
      TeamService var8 = this.team;
      byte var9 = var8.isLeader(var2);
      if (var9 != (1666042539 ^ var45)) {
         var45 = 762564526 ^ var45;
         Player var11 = this.player;
         String var22 = lwcngthmfi(nhwxtpinknvwcng(), kioffyrnyshogjc(), var45);
         Sound var5 = Sound.ENTITY_VILLAGER_NO;
         float var6 = 1.0F;
         float var7 = 1.0F;
         KKo0KoOoOK.play(var11, var22, var5, var6, var7);
         var45 = 2094382565 ^ var45;
         Player var13 = this.player;
         o0KoOo0o0oOK var23 = GUI;
         String var31 = lwcngthmfi(syrxjimhpqngtxh(), kioffyrnyshogjc(), var45);
         String var35 = lwcngthmfi(vndsawxulfersts(), kioffyrnyshogjc(), var45);
         byte var38 = (byte)(854309088 ^ var45);
         Object[] var39 = new Object[var38];
         String var24 = var23.msg(var31, var35, var39);
         oOo0KKoOoOK.sendActionBarAndChat(var13, var24);
         var45 = 128236268 ^ var45;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var45)) {
               case 6740966:
                  var45 ^= 1132612044;
               case 478653638:
                  TeamService var15 = this.team;
                  Player var26 = this.player;
                  UUID var27 = var26.getUniqueId();
                  byte var16 = var15.isLeader(var27);
                  if (var16 == (550470503 ^ var45)) {
                     var45 = 2118019326 ^ var45;
                     Player var18 = this.player;
                     String var28 = lwcngthmfi(bqztcaqbdzmscao(), kioffyrnyshogjc(), var45);
                     Sound var32 = Sound.ENTITY_VILLAGER_NO;
                     float var36 = 1.0F;
                     float var40 = 1.0F;
                     KKo0KoOoOK.play(var18, var28, var32, var36, var40);
                     var45 = 1531670457 ^ var45;
                     Player var20 = this.player;
                     String var29 = lwcngthmfi(nrhsprwexnwuwey(), kioffyrnyshogjc(), var45);
                     String var30 = KoOo0Ko0oOK.get(var29);
                     oOo0KKoOoOK.sendActionBarAndChat(var20, var30);
                     var45 = 241786861 ^ var45;
                     return;
                  }

                  var45 = mdylhuvyxeiobwow(var45, 268844865);
                  Player var34 = this.player;
                  TeamService var42 = this.team;
                  TeamMemberProfileGUI var21 = new TeamMemberProfileGUI(var34, var2, var42);
                  var21.open();
                  var45 = 1363058907 ^ var45;
                  return;
               case 36901425:
               default:
                  throw new IllegalAccessException();
               case 924269910:
            }
         }
      }
   }

   private void handleSearch(InventoryClickEvent var1) {
      int var40 = 1268388348 ^ 1851153781 ^ 1341929048;
      var40 = 789987486 ^ var40;
      Player var10 = this.player;
      var10.closeInventory();
      var40 = 1849227788 ^ var40;

      try {
         SignGUIBuilder var11 = SignGUI.builder();
         o0KoOo0o0oOK var3 = GUI;
         String var4 = lwcngthmfi(jsgcptlrxathbcl(), kioffyrnyshogjc(), var40);
         String var5 = lwcngthmfi(hgpcwzchussvqac(), kioffyrnyshogjc(), var40);
         String var6 = lwcngthmfi(pjmsimamybigvbq(), kioffyrnyshogjc(), var40);
         String var7 = lwcngthmfi(okqqxzuvahvmega(), kioffyrnyshogjc(), var40);
         String var8 = lwcngthmfi(cmbgprxmolgvnly(), kioffyrnyshogjc(), var40);
         var40 = 1874966800 ^ var40;
         List var32 = List.of(var5, var6, var7, var8);
         byte var34 = (byte)(1155496275 ^ var40);
         Object[] var35 = new Object[var34];
         List var20 = var3.lines(var4, var32, var35);
         byte var29 = (byte)(1155496275 ^ var40);
         String[] var30 = new String[var29];
         Object[] var21 = var20.toArray(var30);
         String[] var22 = (String[])var21;
         SignGUIBuilder var12 = var11.setLines(var22);
         SignGUIFinishHandler var23 = (var0, var1x) -> {
            int var69 = 1462984527 ^ 1613734619 ^ 1136106976;
            var69 = 2047390132 ^ var69;
            byte var3 = (byte)(245617088 ^ var69);
            String var13 = var1x.getLineWithoutColor(var3);
            String var14 = var13.trim();
            String var7 = var14;
            var69 = 267287287 ^ var69;
            byte var16 = var14.isEmpty();
            if (var16 != (21867319 ^ var69)) {
               var69 = 256693716 ^ var69;
               o0KoOo0o0oOK var48 = GUI;
               String var4 = lwcngthmfi(zqrgmvgfkligmms(), kioffyrnyshogjc(), var69);
               String var5 = lwcngthmfi(gppdnwkdltwvlvs(), kioffyrnyshogjc(), var69);
               byte var6 = (byte)(234979043 ^ var69);
               Object[] var63 = new Object[var6];
               String var49 = var48.msg(var4, var5, var63);
               oOo0KKoOoOK.sendActionBarAndChat(var0, var49);
               var69 = 2027556614 ^ var69;
               List var18 = Collections.emptyList();
               return var18;
            } else {
               OfflinePlayer var8;
               label138: {
                  var69 = 1729092501 ^ var69;
                  OfflinePlayer var20 = Bukkit.getOfflinePlayerIfCached(var14);
                  var8 = var20;
                  var69 = 2085067279 ^ var69;
                  if (var20 != null) {
                     var69 = 1685321816 ^ var69;
                     String var23 = var20.getName();
                     if (var23 != null) {
                        var69 = mdylhuvyxeiobwow(var69, 1024887447);
                        break label138;
                     }

                     var69 = 1770603859 ^ var69;
                  } else {
                     label129:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var69)) {
                           case 40594602:
                              var69 ^= 234536203;
                           case 659623049:
                              break label129;
                           case 675122675:
                           default:
                              throw new IOException();
                           case 1573408495:
                        }
                     }
                  }

                  OfflinePlayer[] var24 = Bukkit.getOfflinePlayers();
                  OfflinePlayer[] var9 = var24;
                  int var26 = var24.length;
                  int var10 = var26;
                  byte var27 = (byte)(402610086 ^ var69);
                  int var11 = var27;
                  var69 = 1803446237 ^ var69;

                  label116:
                  while(true) {
                     if (var11 >= var10) {
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var69)) {
                              case 20590959:
                                 var69 ^= 1071753241;
                                 break label116;
                              case 194816269:
                                 break;
                              case 836634806:
                                 break label116;
                              case 2094075951:
                              default:
                                 throw new IOException();
                           }
                        }
                     }

                     var69 = 147877910 ^ var69;
                     OfflinePlayer var30 = var9[var11];
                     var69 = 450298587 ^ var69;
                     String var32 = var30.getName();
                     if (var32 == null) {
                        var69 = mdylhuvyxeiobwow(var69, 2010301141);
                     } else {
                        var69 = 832419657 ^ var69;
                        String var34 = var30.getName();
                        byte var35 = var34.equalsIgnoreCase(var7);
                        if (var35 != (1595667967 ^ var69)) {
                           var69 = 1711851669 ^ var69;
                           var8 = var30;
                           var69 = 1371909140 ^ var69;
                           var69 = 733350172 ^ var69;
                           break;
                        }

                        label97:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var69)) {
                              case 9315032:
                                 break;
                              case 138834821:
                                 var69 ^= 1179612572;
                                 break label97;
                              case 760863028:
                              default:
                                 throw new IOException();
                              case 779394690:
                                 break label97;
                           }
                        }
                     }

                     var11 += 424968290 ^ var69;

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var69)) {
                           case 18063851:
                              var69 ^= 1708503064;
                              continue label116;
                           case 657494853:
                              break;
                           case 1393461928:
                              continue label116;
                           case 2140789462:
                           default:
                              throw new IOException();
                        }
                     }
                  }
               }

               TeamService var47;
               label69: {
                  if (var8 != null) {
                     var69 = 2032974596 ^ var69;
                     String var39 = var8.getName();
                     if (var39 != null) {
                        var69 = 1046542355 ^ var69;
                        TeamService2 var40 = TeamService2.getInstance();
                        UUID var54 = var8.getUniqueId();
                        var47 = var40.getTeamByPlayer(var54);

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var69)) {
                              case 65669521:
                                 var69 ^= 1680499264;
                              case 114806383:
                                 break label69;
                              case 937537078:
                                 break;
                              case 1471467386:
                              default:
                                 throw new IOException();
                           }
                        }
                     }

                     var69 = mdylhuvyxeiobwow(var69, 1663365447);
                  } else {
                     var69 = 436750915 ^ var69;
                  }

                  TeamService2 var46 = TeamService2.getInstance();
                  String var58 = var7.toLowerCase();
                  var47 = var46.getTeam(var58);
                  var69 = 963537684 ^ var69;
               }

               var69 = 1898497917 ^ var69;
               if (var47 == null) {
                  var69 = 1840434898 ^ var69;
                  o0KoOo0o0oOK var55 = GUI;
                  String var60 = lwcngthmfi(jkfycojvbmogzyw(), kioffyrnyshogjc(), var69);
                  String var62 = lwcngthmfi(spdzchntvtmvrmj(), kioffyrnyshogjc(), var69);
                  byte var64 = (byte)(2090643610 ^ var69);
                  Object[] var65 = new Object[var64];
                  String var56 = var55.msg(var60, var62, var65);
                  oOo0KKoOoOK.sendActionBarAndChat(var0, var56);
                  var69 = 1503235350 ^ var69;
                  List var45 = Collections.emptyList();
                  return var45;
               } else {
                  label53:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var69)) {
                        case 21628293:
                           var69 ^= 929056912;
                           break label53;
                        case 417375922:
                        default:
                           throw new IOException();
                        case 582127711:
                           break label53;
                        case 2075940606:
                     }
                  }

                  TeamManagementGUI var42 = new TeamManagementGUI(var0, var47);
                  var42.open();
                  var69 = 1654818957 ^ var69;
                  List var43 = Collections.emptyList();
                  return var43;
               }
            }
         };
         var40 = 1865883531 ^ var40;
         SignGUIBuilder var13 = var12.setHandler(var23);
         var40 = 1687646877 ^ var40;
         DonutSMPCore var24 = DonutSMPCore.getInstance();
         SignGUIBuilder var14 = var13.callHandlerSynchronously(var24);
         var40 = 1503986319 ^ var40;
         SignGUI var15 = var14.build();
         Player var26 = this.player;
         var40 = 2077796283 ^ var40;
         var15.open(var26);
         var40 = 637125600 ^ var40;
      } catch (Exception var41) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var40)) {
            case -1227835824 -> var40 = mdylhuvyxeiobwow(var40, 824648044);
            case 654035610 -> var40 = 1663192821 ^ var40;
            case 1492517401 -> var40 = 216266725 ^ var40;
            case 1598240449 -> var40 = 202723710 ^ var40;
            case 1746242443 -> var40 = mdylhuvyxeiobwow(var40, 1258260183);
            case 2079892010 -> var40 = 1753359331 ^ var40;
            default -> throw new RuntimeException("Error in hash");
         }

         var40 = 228986721 ^ var40;
         Player var18 = this.player;
         o0KoOo0o0oOK var27 = GUI;
         String var31 = lwcngthmfi(uoubwrddqfbsbnv(), kioffyrnyshogjc(), var40);
         String var33 = lwcngthmfi(tgcqditzbzoxchj(), kioffyrnyshogjc(), var40);
         byte var36 = (byte)(710621383 ^ var40);
         Object[] var37 = new Object[var36];
         String var28 = var27.msg(var31, var33, var37);
         var18.sendMessage(var28);
         var40 = 602009648 ^ var40;
         var41.printStackTrace();
         var40 = 1241325041 ^ var40;
         return;
      }

      var40 = mdylhuvyxeiobwow(var40, 146581399);
   }

   private void handleHome(InventoryClickEvent var1) {
      int var47 = 1258898836 ^ 528071438 ^ 1341929048;
      var47 = 964915816 ^ var47;
      TeamService var7 = this.team;
      byte var8 = var7.hasTeamHome();
      if (var8 == (571456170 ^ var47)) {
         var47 = 161333735 ^ var47;
         Player var21 = this.player;
         o0KoOo0o0oOK var31 = GUI;
         String var35 = lwcngthmfi(nlgydiodxvcaadk(), kioffyrnyshogjc(), var47);
         String var38 = lwcngthmfi(bmvgucoscqqmigp(), kioffyrnyshogjc(), var47);
         byte var42 = (byte)(731020109 ^ var47);
         Object[] var43 = new Object[var42];
         String var32 = var31.msg(var35, var38, var43);
         oOo0KKoOoOK.sendActionBarAndChat(var21, var32);
         var47 = 2139988299 ^ var47;
         Player var23 = this.player;
         String var33 = lwcngthmfi(sklnwgeiwuzyprm(), kioffyrnyshogjc(), var47);
         Sound var36 = Sound.ENTITY_VILLAGER_NO;
         float var39 = 1.0F;
         float var44 = 1.0F;
         KKo0KoOoOK.play(var23, var33, var36, var39, var44);
         var47 = 344969403 ^ var47;
      } else {
         var47 = 1837093231 ^ var47;
         TeamService var10 = this.team;
         Player var24 = this.player;
         UUID var25 = var24.getUniqueId();
         byte var11 = var10.canVisitHome(var25);
         if (var11 == (1332767685 ^ var47)) {
            var47 = 416169001 ^ var47;
            Player var13 = this.player;
            o0KoOo0o0oOK var26 = GUI;
            String var4 = lwcngthmfi(zflaxymmoptujtr(), kioffyrnyshogjc(), var47);
            String var5 = lwcngthmfi(etoalgfrkafdjsy(), kioffyrnyshogjc(), var47);
            byte var6 = (byte)(1472092140 ^ var47);
            Object[] var40 = new Object[var6];
            String var27 = var26.msg(var4, var5, var40);
            oOo0KKoOoOK.sendActionBarAndChat(var13, var27);
            var47 = 1282787645 ^ var47;
            Player var15 = this.player;
            String var28 = lwcngthmfi(xctafohtdloavbp(), kioffyrnyshogjc(), var47);
            Sound var34 = Sound.ENTITY_VILLAGER_NO;
            float var37 = 1.0F;
            float var41 = 1.0F;
            KKo0KoOoOK.play(var15, var28, var34, var37, var41);
            var47 = 1725326523 ^ var47;
         } else {
            var47 = 129308073 ^ var47;
            Player var17 = this.player;
            var17.closeInventory();
            var47 = 1475185558 ^ var47;
            Player var19 = this.player;
            TeamService var30 = this.team;
            TeamComponent.run(var19, var30);
            var47 = 1918634882 ^ var47;
         }
      }
   }

   private void handlePvPToggle(InventoryClickEvent var1) {
      int var54 = 325337212 ^ 305739623 ^ 1341929048;
      var54 = 1264936317 ^ var54;
      TeamService var11 = this.team;
      Player var40 = this.player;
      UUID var41 = var40.getUniqueId();
      byte var12 = var11.canTogglePvP(var41);
      if (var12 == (96740414 ^ var54)) {
         var54 = 1866027141 ^ var54;
         Player var37 = this.player;
         String var46 = lwcngthmfi(xkmjuuvcfmhbfrn(), kioffyrnyshogjc(), var54);
         Sound var50 = Sound.ENTITY_VILLAGER_NO;
         float var51 = 1.0F;
         float var6 = 1.0F;
         KKo0KoOoOK.play(var37, var46, var50, var51, var6);
         var54 = 1166074891 ^ var54;
         Player var39 = this.player;
         String var47 = lwcngthmfi(pktptmczvkfxlku(), kioffyrnyshogjc(), var54);
         String var48 = KoOo0Ko0oOK.get(var47);
         oOo0KKoOoOK.sendActionBarAndChat(var39, var48);
         var54 = 356049078 ^ var54;
      } else {
         var54 = 1400166762 ^ var54;
         TeamService var14 = this.team;
         byte var15 = var14.isPvpEnabled();
         byte var35;
         if (var15 == (1454439764 ^ var54)) {
            var54 = 1233201699 ^ var54;
            var35 = (byte)(523360118 ^ var54);
            var54 = mdylhuvyxeiobwow(var54, 133337725);
         } else {
            label70:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var54)) {
                  case 133610594:
                     var54 ^= 1492468360;
                     break label70;
                  case 200660765:
                  default:
                     throw new RuntimeException();
                  case 685886689:
                     break label70;
                  case 1320850387:
               }
            }

            var35 = (byte)(239452124 ^ var54);
            var54 = 377944790 ^ var54;
         }

         var54 = 353800666 ^ var54;
         TeamService var17 = this.team;
         var17.setPvpEnabled((boolean)var35);
         var54 = 895314803 ^ var54;
         TeamService2 var18 = TeamService2.getInstance();
         TeamService var44 = this.team;
         var18.savePvpToggle(var44);
         var54 = 1709133862 ^ var54;
         TeamService var20 = this.team;
         Set var21 = var20.getMembers();
         Iterator var22 = var21.iterator();
         Iterator var8 = var22;
         var54 = 742260619 ^ var54;

         label59:
         while(true) {
            byte var24 = var8.hasNext();
            if (var24 == (1902776334 ^ var54)) {
               var54 = 1036966264 ^ var54;
               this.decorate();
               var54 = 325199196 ^ var54;
               return;
            }

            var54 = 113732257 ^ var54;
            Object var27 = var8.next();
            UUID var28 = (UUID)var27;
            var54 = 1852394591 ^ var54;
            Player var30 = Bukkit.getPlayer(var28);
            var54 = 1934929808 ^ var54;
            if (var30 != null) {
               var54 = 1925369221 ^ var54;
               byte var33 = var30.isOnline();
               if (var33 != (408048869 ^ var54)) {
                  var54 = 1698328462 ^ var54;
                  KKoOoOo0oOK var34 = KKoOoOo0oOK.getInstance();
                  Runnable var49 = () -> {
                     int var21 = 889008371 ^ 49452962 ^ 1341929048;
                     var21 = 420015386 ^ var21;
                     InventoryView var7 = var30.getOpenInventory();
                     Inventory var8 = var7.getTopInventory();
                     var21 = 1327560125 ^ var21;
                     if (var8 == null) {
                        var21 = 1752774435 ^ var21;
                     } else {
                        var21 = 919417557 ^ var21;
                        InventoryHolder var11 = var8.getHolder();
                        var21 = 1344871681 ^ var21;
                        byte var13 = var11 instanceof TeamMenu;
                        if (var13 != (1228908154 ^ var21)) {
                           var21 = 462796945 ^ var21;
                           TeamMenu var15 = (TeamMenu)var11;
                           var21 = 1867225617 ^ var21;
                           if (var15 != this) {
                              var21 = 643439934 ^ var21;
                              var15.decorate();
                              var21 = 1964739371 ^ var21;
                              var30.updateInventory();
                              var21 = 688041058 ^ var21;
                           } else {
                              var21 = 2051226231 ^ var21;
                           }
                        } else {
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var21)) {
                                 case 233511859:
                                    var21 = 245176567 ^ var21;
                                    return;
                                 case 485781484:
                                 default:
                                    throw new IllegalAccessException();
                                 case 1670420646:
                                    return;
                                 case 2052214536:
                              }
                           }
                        }
                     }

                  };
                  var34.runAtEntity(var30, var49);
                  var54 = 516257926 ^ var54;
               } else {
                  var54 = mdylhuvyxeiobwow(var54, 2080315144);
               }
            } else {
               label41:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var54)) {
                     case 130732218:
                        break label41;
                     case 242762682:
                        var54 ^= 155048589;
                        break label41;
                     case 1392563105:
                     default:
                        throw new RuntimeException();
                     case 1833826637:
                  }
               }
            }

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var54)) {
                  case 18862134:
                     var54 ^= 315053027;
                     continue label59;
                  case 100993292:
                  default:
                     throw new RuntimeException();
                  case 1236284371:
                     continue label59;
                  case 2102912557:
               }
            }
         }
      }
   }

   private List<UUID> getSortedMembers() {
      int var11 = 426721936 ^ 473975650 ^ 1341929048;
      var11 = 2106986523 ^ var11;
      TeamService var3 = this.team;
      Set var4 = var3.getMembers();
      Stream var5 = var4.stream();
      Comparator var8 = (var1, var2) -> {
         String var25;
         String var50;
         int var71;
         label138: {
            var71 = 446295271 ^ 1709281887 ^ 1341929048;
            var71 = 8616959 ^ var71;
            OfflinePlayer var12 = Bukkit.getOfflinePlayer(var1);
            var71 = 1912738345 ^ var71;
            OfflinePlayer var14 = Bukkit.getOfflinePlayer(var2);
            var71 = 567303651 ^ var71;
            K var16 = this.sortType;
            int var17 = var16.ordinal();
            double var38;
            double var47;
            switch (var17) {
               case 1:
                  var71 = 1079966497 ^ var71;
                  byte var49 = (byte)(596346868 ^ var71);
                  return var49;
               case 2:
                  var71 = mdylhuvyxeiobwow(var71, 1096062979);
                  DonutSMPCore var34 = DonutSMPCore.getInstance();
                  Economy var35 = var34.getEconomy();
                  if (var35 != null) {
                     var71 = 1193832625 ^ var71;
                     DonutSMPCore var36 = DonutSMPCore.getInstance();
                     Economy var37 = var36.getEconomy();
                     var38 = var37.getBalance(var12);
                     var71 = 1512701992 ^ var71;
                  } else {
                     var71 = mdylhuvyxeiobwow(var71, 397508049);
                     var38 = (double)0.0F;
                     var71 = 179506504 ^ var71;
                  }

                  var71 = 977254253 ^ var71;
                  DonutSMPCore var40 = DonutSMPCore.getInstance();
                  Economy var41 = var40.getEconomy();
                  if (var41 != null) {
                     var71 = 2112438869 ^ var71;
                     DonutSMPCore var45 = DonutSMPCore.getInstance();
                     Economy var46 = var45.getEconomy();
                     var47 = var46.getBalance(var14);
                     var71 = mdylhuvyxeiobwow(var71, 1664124401);
                     break;
                  }

                  label88:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var71)) {
                        case 5704417:
                           break label88;
                        case 90203475:
                           var71 ^= 1940186847;
                           break label88;
                        case 1422279909:
                           break;
                        case 2008510147:
                        default:
                           throw new IllegalAccessException();
                     }
                  }

                  var47 = (double)0.0F;
                  var71 = 1836917115 ^ var71;
                  break;
               case 3:
                  label78:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var71)) {
                        case 23970313:
                           var71 ^= 1711622569;
                        case 629505781:
                           break label78;
                        case 1155844132:
                           break;
                        case 1289738346:
                        default:
                           throw new IllegalAccessException();
                     }
                  }

                  String var22 = var12.getName();
                  if (var22 != null) {
                     var71 = 1190222583 ^ var71;
                     var50 = var12.getName();
                     var71 = mdylhuvyxeiobwow(var71, 1461582454);
                  } else {
                     var71 = 880918920 ^ var71;
                     var50 = lwcngthmfi(etxuudozaljempk(), kioffyrnyshogjc(), var71);
                     var71 = 627925257 ^ var71;
                  }

                  var71 = 693911629 ^ var71;
                  String var24 = var14.getName();
                  if (var24 != null) {
                     var71 = 937128464 ^ var71;
                     var25 = var14.getName();

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var71)) {
                           case 69036108:
                              break;
                           case 80453245:
                              var71 ^= 1147521982;
                           case 1255265788:
                              break label138;
                           case 1261114226:
                           default:
                              throw new IllegalAccessException();
                        }
                     }
                  }

                  label67:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var71)) {
                        case 116106085:
                           var71 ^= 1582084382;
                           break label67;
                        case 284192760:
                           break;
                        case 1133382036:
                           break label67;
                        case 1157082387:
                        default:
                           throw new IllegalAccessException();
                     }
                  }

                  var25 = lwcngthmfi(jzvuzoebxhajnkx(), kioffyrnyshogjc(), var71);
                  var71 = 770836656 ^ var71;
                  break label138;
               case 4:
                  var71 = 935616446 ^ var71;
                  boolean var19 = var14.isOnline();
                  boolean var51 = var12.isOnline();
                  int var20 = Boolean.compare(var19, var51);
                  return var20;
               default:
                  label106:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var71)) {
                        case 23970313:
                           var71 = 853518352 ^ var71;
                           break label106;
                        case 504909825:
                        default:
                           throw new IllegalAccessException();
                        case 585160639:
                           break label106;
                        case 1840462354:
                     }
                  }

                  long var31 = var1.getMostSignificantBits();
                  long var55 = var2.getMostSignificantBits();
                  int var33 = Long.compare(var31, var55);
                  return var33;
            }

            var71 = 928059620 ^ var71;
            int var44 = Double.compare(var47, var38);
            return var44;
         }

         var71 = 1161019103 ^ var71;
         int var27 = var50.compareToIgnoreCase(var25);
         return var27;
      };
      Stream var6 = var5.sorted(var8);
      var11 = 819706664 ^ var11;
      List var7 = var6.toList();
      var11 = 753166595 ^ var11;
      return var7;
   }

   static {
      int var16 = 1700148732 ^ 365793218 ^ Integer.parseInt("344010933");
      var16 = 1294502820 ^ var16;
      String var0 = lwcngthmfi(bskqiiarwzrnagu(), kioffyrnyshogjc(), var16);
      o0KoOo0o0oOK var3 = o0KoOo0o0oOK.of(var0);
      GUI = var3;
      var16 = 2096458676 ^ var16;
      ArrayList var4 = new ArrayList();
      ArrayList var1 = var4;
      var16 = 705177066 ^ var16;
      byte var5 = (byte)(2144292721 ^ var16);
      int var2 = var5;
      var16 = 30020705 ^ var16;

      label27:
      while(true) {
         byte var11 = (byte)(2114280253 ^ var16);
         if (var2 >= var11) {
            var16 = mdylhuvyxeiobwow(var16, 845009759);
            List var8 = Collections.unmodifiableList(var1);
            DEFAULT_MEMBER_SLOTS = var8;
            var16 = 1941075248 ^ var16;
            return;
         }

         var16 ^= 2042613763;
         Integer var13 = var2;
         boolean var10 = var1.add(var13);
         var2 += 129665810 ^ var16;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 121562587:
                  var16 ^= 2042613763;
               case 345991944:
                  continue label27;
               case 1499512064:
               default:
                  throw new IllegalAccessException();
               case 1777594815:
            }
         }
      }
   }

   public static String lwcngthmfi(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] kioffyrnyshogjc() {
      return new byte[]{34, 112, 8, 12, 50, 96, 59, 62, 52, 21, 84, 106, 82, 96, 109, 71, 101, 75, 109, 121, 62, 47, 79, 32, 61, 88, 122, 31, 78, 115, 93, 88, 51, 87, 23, 87, 23, 35, 29, 93, 59, 16, 117, 97, 94, 37, 60, 50, 9, 48, 94, 105, 72, 21, 98, 115, 105, 63, 12, 3, 110, 36, 19, 40, 57, 88};
   }

   private static byte[] bskqiiarwzrnagu() {
      return new byte[]{-22, -74, 57, 90, 6, 39, 2, 98, 13, 80, 109, 116, 99, 32, 95, 27, 80, 19, 91, 45, 15, 121, 123, 103, 4, 4};
   }

   private static byte[] ptsyixflkrnkgbh() {
      return new byte[]{-19, -71, 56, 75, 5, 61, 8, 127, 3, 79, 101, 57};
   }

   private static byte[] ebuhkqllmjbrvrz() {
      return new byte[]{-19, -71, 37, 36, 24, 83, 21, 11, 30, 46, 101, 124, 98, 123, 90, 35, 86, 31, 90, 40, 15, 124, 127, 51, 10, 73, 73, 90, 121, 36, 108, 9, 3, 1, 32, 70, 36, 63};
   }

   private static byte[] sfehofgknykmowo() {
      return new byte[]{-19, -71, 56, 26, 5, 36, 8, 106, 3, 68, 101, 57, 98, 118};
   }

   private static byte[] xffzmklfcuzbtnx() {
      return new byte[]{-19, -71, 48, 105, 2, 24, 10, 78, 2, 116, 101, 25, 106, 17, 93, 58, 84, 48, 91, 4, 15, 94};
   }

   private static byte[] pqyskqnstkcsooq() {
      return new byte[]{-23, -66, 61, 91, 4, 35, 12, 101, 1, 83, 101, 112, 98, 34, 91, 21, 87, 31, 88, 37, 11, 120, 121, 99, 10, 3};
   }

   private static byte[] qvjblofkgifhdzx() {
      return new byte[]{-23, -66, 61, 79, 4, 57, 12, 126, 1, 84, 101, 113, 98, 57, 91, 0, 87, 10, 88, 33, 11, 112, 121, 120, 10, 25};
   }

   private static byte[] hqksgokfeyiswoz() {
      return new byte[]{-23, -66, 61, 86, 4, 57, 12, 101, 1, 78, 101, 114, 98, 50, 91, 17, 87, 10, 88, 45};
   }

   private static byte[] atfgxqgcrcvlzbs() {
      return new byte[]{-23, -66, 61, 76, 4, 51, 12, 126, 1, 77, 101, 54, 98, 37, 91, 3, 87, 23, 88, 39, 11, 113, 121, 101};
   }

   private static byte[] azgeeuofnhcsdcp() {
      return new byte[]{-23, -66, 61, 81, 4, 57, 12, 98, 1, 69, 101, 38};
   }

   private static byte[] oeiyqvilxegnpbb() {
      return new byte[]{-23, -66, 61, 93, 4, 58, 12, 124, 1, 72, 101, 62, 98, 52, 91, 21, 87, 10, 88, 33, 11, 124, 121, 119, 10, 6};
   }

   private static byte[] zwgxqrsmhsdeiga() {
      return new byte[]{-23, -66, 61, 83, 4, 56, 12, 96, 1, 73, 101, 49, 98, 51};
   }

   private static byte[] zqrgmvgfkligmms() {
      return new byte[]{-18, -68, 60, 70, 5, 60, 11, 107, 7, 85, 103, 61, 107, 63, 84, 90, 81, 29, 95, 39, 10, 102, 120, 109, 13, 21};
   }

   private static byte[] gppdnwkdltwvlvs() {
      return new byte[]{-18, -68, 60, 19, 5, 58, 11, 90, 7, 75, 103, 59, 107, 54, 84, 4, 81, 29, 95, 106, 10, 115, 120, 119, 13, 24, 73, 72, 125, 53, 100, 79, 10, 6, 35, 68, 37, 100, 41, 1, 12, 72, 69, 56, 109, 55, 15, 104, 48, 102, 103, 52, 124, 67, 80, 96, 93, 105, 59, 72, 94, 48, 32, 106, 10, 0, 27, 38, 49, 69, 6, 54, 9, 127, 0, 12, 99, 61, 98, 53, 94, 24, 86, 26, 84, 96};
   }

   private static byte[] jkfycojvbmogzyw() {
      return new byte[]{-18, -65, 49, 79, 4, 49, 8, 105, 5, 87, 102, 57, 107, 56, 91, 94, 86, 19, 92, 38, 12, 107, 118, 61, 11, 10, 73, 70, 127, 54, 111, 6, 10, 3};
   }

   private static byte[] spdzchntvtmvrmj() {
      return new byte[]{-18, -65, 49, 26, 4, 55, 8, 70, 5, 74, 102, 122, 107, 36, 91, 22, 86, 28, 92, 36, 12, 63, 118, 127, 11, 30, 73, 9, 127, 51, 111, 4, 10, 6, 33, 26, 36, 112, 44, 31, 9, 0, 76, 55, 104, 126, 15, 113, 56, 110, 108, 61, 113, 5, 84, 48, 90, 96, 61, 71, 92, 124, 42, 56, 15, 24, 17, 46, 57, 93, 0, 36, 2, 46, 2, 79, 103, 61, 99, 61, 95, 18, 92, 85};
   }

   private static byte[] etxuudozaljempk() {
      return new byte[0];
   }

   private static byte[] jzvuzoebxhajnkx() {
      return new byte[0];
   }

   private static byte[] szrblojjeygzmgh() {
      return new byte[]{-27, -70, 48, 81, 6, 61, 11, 120, 6, 69, 97, 38, 102, 49, 94, 90, 85, 17, 84, 37, 6, 117, 123, 103};
   }

   private static byte[] bdermgzudkfdpjx() {
      return new byte[]{-27, -70, 48, 30, 6, 100, 11, 90, 6, 85, 97, 34, 102, 49, 94, 87, 85, 86, 84, 56, 6, 126, 123, 114, 13, 5, 72, 6, 123, 34, 105, 2, 0, 17, 39, 12, 46, 98, 37, 12, 15, 3, 69, 121, 108, 114, 9, 107, 61, 105, 109, 60, 120, 14, 91, 102, 81, 127, 56, 95, 94, 52, 33, 120, 12, 14, 22, 50, 59, 85, 2, 38, 2, 110, 12, 1, 96, 56, 98, 112, 95, 14, 80, 31, 89, 44, 13, 102, 127, 119, 4, 31};
   }

   private static byte[] xpjoovbournlygq() {
      return new byte[]{-27, -73, 60, 88, 10, 49, 3, 102, 4, 78, 108, 59, 107, 42, 89, 82, 80, 8, 84, 45, 10, 121, 119, 96, 5, 30};
   }

   private static byte[] vglchjyzvuiseng() {
      return new byte[]{-21, -73, 59, 27, 1, 41, 3, 99, 2, 67, 108, 32, 96, 54, 84, 13, 84, 88};
   }

   private static byte[] lgkshrtdoxlplkx() {
      return new byte[]{-21, -73, 59, 27, 1, 42, 3, 123, 2, 67, 108, 45, 96, 38, 84, 12, 84, 88};
   }

   private static byte[] zbwyqdyiuaytniw() {
      return new byte[]{-19, -74, 59, 74, 7, 50, 15, 106, 6, 86, 101, 48, 97, 61};
   }

   private static byte[] trjdktjnyaqjffl() {
      return new byte[]{-19, -74, 59, 74, 7, 50, 15, 106, 6, 86, 101, 48, 97, 61};
   }

   private static byte[] jctyrkpuqpcadzs() {
      return new byte[]{-19, -74, 59, 26, 7, 103, 15, 59, 6, 98, 101, 16, 97, 109, 88, 72, 85, 43, 66, 79, 18, 22, 126, -107, 21, 107, 76, -74};
   }

   private static byte[] ztqrarpsjbkktwd() {
      return new byte[]{-19, -74, 59, 26, 7, 17, 15, 77, 6, 98, 101, 21, 97, 19, 88, 54, 81, 61, 95, 36, 15, 127, 124, 118, 8, 4, 78, 10, 124, 54, 108, 14, 0, 66, 34, 19, 35, 115, 47, 13, 10, 91, 70, 55, 107, 122};
   }

   private static byte[] lflvonmiqersxvr() {
      return new byte[]{-19, -73, 56, 69, 2, 35, 12, 123};
   }

   private static byte[] jjkxbununhpkbnn() {
      return new byte[]{-19, -73, 56, 69, 2, 35, 12, 123};
   }

   private static byte[] irqzhbrcsvxkjxb() {
      return new byte[]{-19, -73, 56, 22, 2, 101, 12, 59, 2, 98, 101, 17, 98, 97, 93, 74, 79, 102, 70, 104, 18, 15};
   }

   private static byte[] vwofbxsansudgww() {
      return new byte[]{-19, -73, 56, 22, 2, 19, 12, 77, 2, 98, 101, 20, 98, 31, 93, 52, 82, 61, 91, 61, 15, 101, 127, 107, 13, 8, 77, 68, 120, 54, 108, 12, 3, 23, 39, 88, 32, 54, 43, 73, 10, 91, 69, 44, 110, 113, 11, 115, 63, 116, 111, 34, 120, 9};
   }

   private static byte[] jzomtlutqchwaez() {
      return new byte[]{-19, -73, 56, 16, 2, 38, 12, 127, 2, 69, 101, 38, 98, 44, 93, 1, 82, 91};
   }

   private static byte[] ycpwswafnijoscd() {
      return new byte[]{-22, -74, 59, 86, 7, 44, 9, 98, 12, 78, 109, 42, 97, 123, 85, 29, 92, 28, 91, 45, 13, 121, 122, 54, 15, 13, 66, 70, 119, 50, 110, 8, 11, 72, 46, 26, 33, 116, 46, 29, 14, 77, 71, 44};
   }

   private static byte[] rwiwbyjachxzngq() {
      return new byte[]{-19, -71, 62, 93, 2, 36, 8, 98, 13, 64, 101, 47, 100, 118, 93, 7, 86, 4, 84, 49, 15, 55, 121, 119, 13, 14, 73, 64, 119, 102, 108, 26, 5, 10, 39, 31, 36, 110};
   }

   private static byte[] loyffqznpllrrql() {
      return new byte[]{-19, -71, 62, 23, 2, 22, 8, 65, 13, 29, 101, 108, 100, 104, 93, 71, 86, 84, 84, 45, 15, 86, 121, 94, 13, 46};
   }

   private static byte[] suoarcksyfyuuue() {
      return new byte[]{-19, -70, 56, 24, 7, 58, 9, 110, 5, 65, 101, 61, 98, 52, 88, 2, 87, 13, 92, 101};
   }

   private static byte[] mdgcrrbpxrmetrn() {
      return new byte[]{-19, -70, 56, 24, 7, 39, 9, 106, 5, 75, 101, 58, 98, 116};
   }

   private static byte[] qznylvvnrixphxe() {
      return new byte[]{-19, -68, 56, 84, 11, 52, 14, 97, 13, 67, 101, 60, 98, 39, 84, 88, 80, 22, 84, 43, 15, 122, 127, 121, 4, 0, 79, 67, 119, 34, 108, 70, 3, 22, 46, 3, 34, 105, 36, 29};
   }

   private static byte[] nnpvhivgupbgnnz() {
      return new byte[]{-19, -70, 59, 82, 11, 38, 10, 107, 3, 75, 101, 44, 97, 121, 84, 24, 84, 30, 90, 39, 15, 120, 124, 114, 4, 24, 75, 1, 121, 46, 108, 12, 0, 13, 46, 0};
   }

   private static byte[] zqjmyckwphxlkhs() {
      return new byte[]{-19, -70, 59, 30, 11, 33, 10, 122, 3, 71, 101, 43, 97, 34, 84, 6, 84, 36, 90, 41, 15, 117, 124, 123, 4, 5, 75, 93, 121, 101, 73, -51, 0, 64, 46, 70, 38, 35, 42, 94, 10, 99, 70, 21, 103, 47, 13, 58, 62, 38, 111, 44, 123, 78, 91, 32, 88, 118, 59, 85, 95, 99, 32, 58};
   }

   private static byte[] xzwuxwyrhnazolh() {
      return new byte[]{-19, -65, 62, 81, 1, 49, 8, 98, 3, 68, 101, 63, 100, 34, 94, 93, 86, 21, 90, 36, 15, 115, 121, 121, 14, 2, 73, 75, 121, 109, 108, 28, 5, 2, 36, 27, 36, 102};
   }

   private static byte[] ahzpssknievmany() {
      return new byte[]{-18, -68, 58, 87, 1, 56, 15, 104, 6, 73};
   }

   private static byte[] luozxfkgucnhwfq() {
      return new byte[]{-18, -68, 58, 87, 1, 56, 15, 104, 6, 73};
   }

   private static byte[] tcevcxmuslbndbe() {
      return new byte[]{-18, -68, 58, 29, 1, 102, 15, 62, 6, 96, 102, 27, 97, 110, 89, 79, 74, 99, 66, 76, 16, 25, 102, 29, 15, 75, 72, 8, 125, 49, 105, 13, 1, 5, 37, 8, 36, 74, 41, 3, 9, 66, 71, 62, 109, 118, 8, 39};
   }

   private static byte[] ubgjguumeeyxabg() {
      return new byte[]{-18, -68, 58, 29, 1, 16, 15, 72, 6, 96, 102, 30, 97, 16, 89, 49, 87, 59, 95, 39, 13, 112, 123, 115, 15, 0, 72, 13, 125, 49, 105, 7, 1, 68, 37, 23, 36, 112, 41, 11, 9, 81, 71, 54, 109, 96, 8, 106};
   }

   private static byte[] iafzxinhlhmenmf() {
      return new byte[]{-18, -68, 58, 29, 1, 23, 15, 79, 6, 103, 102, 25, 97, 23, 89, 54, 87, 57, 95, 47, 13, 125, 123, 48, 15, 30, 72, 93, 125, 101, 105, 28, 1, 11, 37, 69, 36, 32, 41, 93, 9, 3, 71, 39, 109, 118, 8, 99, 59, 110, 108, 123, 123, 78, 86, 38, 91, 97, 62, 83, 93, 119, 39, 106, 11, 24};
   }

   private static byte[] dnniaaqrtqjzbqv() {
      return new byte[]{-19, -72, 63, 82, 0, 60, 3, 99, 5, 65, 101, 56, 101, 33, 95, 80, 93, 23, 92, 42, 15, 121, 120, 119, 15, 4, 66, 93, 127, 104, 108, 27, 4, 5, 37, 9};
   }

   private static byte[] ibozzxxdlqiehvl() {
      return new byte[0];
   }

   private static byte[] pffsfsmqjafyegt() {
      return new byte[]{-19, -67, 63, 92, 1, 50, 2, 105, 7, 79};
   }

   private static byte[] ahsmhyxiizwcuvc() {
      return new byte[]{-19, -67, 63, 92, 1, 50, 2, 105, 7, 79};
   }

   private static byte[] qurbzgkpvbtwfiw() {
      return new byte[]{-19, -67, 63, 29, 1, 99, 2, 58, 7, 98, 101, 27, 101, 106, 94, 76, 94, -26, 67, 72, 18, 25, 101, 25};
   }

   private static byte[] wzgqmzlgnaxahqu() {
      return new byte[]{-19, -67, 63, 29, 1, 21, 2, 76, 7, 98, 101, 30, 101, 20, 94, 50, 92, 60, 94, 36, 15, 116, 120, 113, 14, 0, 67, 11, 125, 54, 108, 5, 4, 69, 36, 3, 46, 120, 46, 76, 10, 86, 66, 60, 109, 54, 5, 114, 58, 105, 111, 62, 127, 7, 81, 48, 80, 121, 63, 87, 95, 96, 36, 115, 10, 4, 27, 49, 59, 78, 3, 114, 12, 124, 7, 71, 109, 57, 97, 52};
   }

   private static byte[] jflnuwonbjiakjk() {
      return new byte[]{-17, -67, 58, 92, 5, 45, 12, 106, 7, 75, 102, 43, 107, 121, 84, 0, 84, 14, 94, 59, 12, 56, 120, 118, 10, 7, 73, 1, 124, 53, 100, 10, 10, 24, 38, 16};
   }

   private static byte[] hhbergzalrzdnsx() {
      return new byte[]{-17, -67, 58, 22, 5, 106, 12, 78, 7, 96, 102, 30, 107, 103, 84, 64, 84, 94, 94, 39, 12, 89, 120, 87};
   }

   private static byte[] otbuokxeuzirkgp() {
      return new byte[]{-23, -68, 63, 81, 10, 55, 2, 99, 5, 69};
   }

   private static byte[] dtqlkbfsmvdheis() {
      return new byte[]{-18, -65, 61, 25, 11, 32, 11, 124, 5, 68, 102, 46, 103, 37, 84, 7, 85, 34, 92, 42, 12, 112, 122, 124, 4, 4, 74, 91, 127, 102};
   }

   private static byte[] hrmnqqzqambxlpy() {
      return new byte[]{-18, -65, 60, 86, 0, 54, 8, 106, 3, 71};
   }

   private static byte[] nzncpaicxtyzcwb() {
      return new byte[]{-18, -65, 60, 29, 0, 105, 8, 55, 3, 100, 102, 25, 102, 106, 95, 70, 75, 105, 71, 73, 17, 31, 102, 31, 15, 65, 75, -70, 100, 75, 114, 101, 26, 98};
   }

   private static byte[] exphujdiinxarbv() {
      return new byte[]{-17, -68, 58, 92, 0, 39, 3, 106, 3, 75, 103, 43, 107, 124, 94, 23, 84, 19, 94, 39, 12, 115, 125, 61, 5, 5, 77, 67, 125, 51, 100, 15, 0, 66, 38, 19, 36, 117, 47, 16};
   }

   private static byte[] pnaztmhtbydldcc() {
      return new byte[]{-19, -69, 57, 107, 7, 56, 15, 108, 7, 74, 96, 52, 96, 34, 91, 29};
   }

   private static byte[] kvnivjwrshpouop() {
      return new byte[]{-23, -65, 59, 27, 11, 52, 10, 110, 13, 65, 100, 61, 96, 60, 85, 4, 80, 87};
   }

   private static byte[] wbklrgsrceveemq() {
      return new byte[]{-19, -67, 59, 87, 6, 44, 2, 106, 7, 73, 101, 43, 97, 124, 89, 22, 92, 20, 94, 62, 15, 116, 124, 102, 9, 5, 67, 0, 125, 39, 108, 4, 0, 4, 35, 13, 46, 126, 46, 9, 10, 70};
   }

   private static byte[] tospgltetbfcxwh() {
      return new byte[]{-19, -71, 60, 80, 7, 55, 11, 112, 0, 74, 101, 40, 102, 48};
   }

   private static byte[] vzatbqaozpmezwn() {
      return new byte[]{-19, -71, 60, 26, 7, 105, 11, 54, 0, 101, 101, 31, 102, 109, 88, 70, 87, 25, 91, 59, 18, 57, 121, 127, 21, 122, 87, 32};
   }

   private static byte[] drnrahmmkcpcsmt() {
      return new byte[]{-19, -71, 60, 26, 7, 31, 11, 64, 0, 101, 101, 26, 102, 19, 88, 56, 85, 48, 89, 35, 15, 112, 123, 118, 8, 10, 74, 7, 122, 49, 108, 1, 7, 66, 34, 7, 39, 117, 41, 29, 10, 79, 65, 32, 107, 121, 12, 42, 61, 103, 111, 127, 124, 78, 87, 47, 89, 112, 56, 21, 95, 98, 39, 113, 12, 0, 18, 49, 60, 95, 3, 36};
   }

   private static byte[] piojnxqiksmmqck() {
      return new byte[]{-27, -73, 62, 119, 2, 48, 10, 97, 2, 64, 108, 53, 102, 62, 91, 19};
   }

   private static byte[] saekxqjjqbcickk() {
      return new byte[]{-24, -68, 48, 84, 7, 61, 10, 107, 7, 67, 103, 55, 103, 39, 85, 88, 93, 23, 89, 36, 6, 118, 122, 113, 12, 14, 73, 78, 125, 102, 104, 14, 11, 9, 47, 8, 35, 127, 37, 26};
   }

   private static byte[] rxdkymlryxrzqlx() {
      return new byte[]{-24, -68, 48, 26, 7, 104, 10, 54, 7, 103, 103, 17, 103, 109, 85, 78};
   }

   private static byte[] woezdybqjeaupxu() {
      return new byte[]{-23, -71, 62, 86, 1, 55, 12, 115, 2, 87};
   }

   private static byte[] rxctgjfuciunwqg() {
      return new byte[]{-23, -71, 62, 86, 1, 55, 12, 115, 2, 87};
   }

   private static byte[] mssnmoodzkizehw() {
      return new byte[]{-23, -71, 62, 27, 1, 98, 12, 59, 2, 101, 96, 26, 96, 111, 88, 73, 81, 11, 67, 76, 13, 95, 100, 13};
   }

   private static byte[] mjjejbulyipftag() {
      return new byte[]{-23, -71, 62, 27, 1, 20, 12, 77, 2, 101, 96, 31, 96, 17, 88, 55, 83, 60, 94, 39, 9, 115, 121, 117, 9, 0, 72, 8, 123, 49, 107, 3, 0, 69, 32, 5, 33, 122, 41, 78, 9, 83, 64, 56, 104, 49, 15, 116, 62, 109, 104, 58, 124, 6, 80, 42, 92, 108, 58, 79, 93, 98, 36, 61, 15, 30, 22, 34, 58, 92, 7, 51};
   }

   private static byte[] qrnfmpbmgukyqgi() {
      return new byte[]{-17, -68, 56, 122, 2, 55, 15, 106, 13, 79, 103, 52, 107, 53};
   }

   private static byte[] hallvdamnqzohnj() {
      return new byte[]{-18, -65, 48, 82, 6, 49, 9, 99, 0, 69, 102, 63, 106, 33, 89, 93, 87, 20, 89, 45, 12, 121, 119, 127, 9, 5, 72, 65, 122, 36, 111, 69, 11, 7, 35, 12, 37, 127, 41, 0, 9, 82};
   }

   private static byte[] gagnpykzcylzhns() {
      return new byte[]{-18, -65, 48, 28, 6, 18, 9, 72, 0, 23, 102, 106, 106, 99, 89, 67};
   }

   private static byte[] xtcwpakflhqcfpc() {
      return new byte[]{-19, -67, 48, 22, 2, 21, 15, 77, 0, 100, 101, 30, 106, 31, 93, 50, 81, 61, 89, 34, 15, 116, 119, 122, 13, 0, 78, 10, 122, 48, 108, 5, 11, 78, 39, 16, 35, 115, 41, 6, 10, 71, 77, 40, 110, 121, 8, 117, 61, 115, 111, 123, 112, 88, 82, 47, 93, 42, 37, 47, 66, 17, 54, 17, 20, 102, 22, 101, 62, -89, 30, 93, 30, 10, 25, 33};
   }

   private static byte[] lgtzlzyibvzwkbs() {
      return new byte[]{-17, -70, 62, 82, 5, 36, 13, 111, 0, 75, 97, 47, 101, 121, 93, 28, 81, 26, 94, 33, 8, 122, 120, 117, 11, 30, 78, 2, 123, 41, 106, 0, 3, 19, 35, 6};
   }

   private static byte[] kbyiqzewriggneh() {
      return new byte[]{-17, -70, 62, 24, 5, 22, 13, 76, 0, 96, 97, 26, 101, 17, 93, 55, 81, 60, 94, 32, 8, 113, 120, 115, 11, 7, 78, 12, 123, 49, 106, 0, 3, 65, 35, 6, 36, 114, 43, 3, 12, 84};
   }

   private static byte[] gimacgsisotkpqv() {
      return new byte[0];
   }

   private static byte[] vlocsxqwoppedfs() {
      return new byte[]{-19, -71, 57, 29, 4, 22, 10, 64, 4, 102, 101, 26, 99, 20, 91, 49, 84, 32, 93, 41, 15, 109, 126, 50, 11, 28, 75, 79, 126, 35, 108, 78, 2, 17, 33, 2, 38, 122, 45, 5, 10, 6, 68, 59, 104, 122, 13, 103, 57, 96, 111, 127, 121, 80, 84, 42, 88, 115, 60, 94, 95, 50, 34, 53, 15, 28, 19, 45, 56, 88, 3, 59, 10, 44, 2, 86, 101, 55, 98, 33, 92, 25, 84, 22, 91, 36, 15, 114};
   }

   private static byte[] cachlmsrzmfwbsl() {
      return new byte[]{-19, -67, 62, 25, 2, 34, 10, 107, 13, 71, 101, 53, 100, 15, 93, 31, 84, 26, 84, 39, 15, 120, 121, 53};
   }

   private static byte[] wdssfnuounieouz() {
      return new byte[]{-21, -73, 63, 73, 1, 56, 12, 123, 0, 86};
   }

   private static byte[] czemvszyoxzhlvh() {
      return new byte[]{-21, -73, 63, 25, 1, 103, 12, 57, 0, 100, 108, 30, 100, 107, 90, 72, 86, 42, 71, 78, 11, -103, 97, 12};
   }

   private static byte[] ftloqqiipnkhkhh() {
      return new byte[]{-18, -65, 62, 28, 7, 53, 2, 104, 1, 65, 102, 63, 100, 57, 88, 91};
   }

   private static byte[] rvgbhuvxwsedpzb() {
      return new byte[]{-19, -70, 62, 72, 4, 59, 2, 121, 6, 85, 101, 113, 100, 36, 91, 22, 92, 18, 95, 40, 15, 121, 121, 99, 11, 9, 67, 78, 124, 106, 108, 29, 5, 18, 33, 6, 46, 112, 47, 0, 10, 93};
   }

   private static byte[] nqxycjcxmgznlcf() {
      return new byte[]{-19, -70, 62, 24, 4, 100, 2, 59, 6, 103, 101, 28, 100, 111, 91, 75, 124, 92, 95, 109};
   }

   private static byte[] ordcrtiibkwzixh() {
      return new byte[]{-19, -65, 56, 25, 7, 33, 9, 121, 2, 67, 101, 60, 98, 57, 88, 14, 87, 91};
   }

   private static byte[] mowtaleyqwzbgyp() {
      return new byte[]{-23, -72, 49, 77, 5, 57, 3, 125, 0, 84, 99, 125, 96, 59, 91, 22, 84, 17, 88, 43, 7, 48, 120, 112, 5, 6, 78, 88, 121, 39, 111, 14, 5, 27};
   }

   private static byte[] ryezuyqvqgzcsws() {
      return new byte[]{-23, -72, 49, 27, 5, 38, 3, 125, 0, 69, 99, 53, 96, 62, 91, 7, 84, 90, 88, 107, 7, 113, 120, 119, 5, 11, 78, 79, 121, 38, 111, 74};
   }

   private static byte[] eiecmexkvcjfsql() {
      return new byte[]{-19, -66, 60, 78, 3, 56, 15, 122, 4, 87, 101, 117, 102, 55, 92, 31, 81, 18, 93, 59, 15, 123, 123, 99};
   }

   private static byte[] xexhlbuqclcomng() {
      return new byte[]{-19, -72, 57, 73, 10, 55, 9, 124, 3, 83, 101, 115, 99, 62, 85, 26, 87, 26, 90, 47, 15, 125, 126, 100};
   }

   private static byte[] cahxrjddtuvnuxh() {
      return new byte[]{-24, -69, 56, 76, 2, 55, 2, 116, 12, 85, 96, 116, 97, 37, 85, 16, 93, 0, 89, 40, 14, 112, 127, 125, 4, 3, 66, 95, 122, 38, 110, 12, 11, 67, 47, 31, 35, 101, 45, 11, 11, 78, 76, 48, 102, 105};
   }

   private static byte[] klblziygtrzhiyn() {
      return new byte[]{-24, -69, 56, 28, 2, 30, 2, 64, 12, 103, 96, 28, 97, 22, 85, 56, 125, 81, 89, 109};
   }

   private static byte[] chkpjoycgpyzxzd() {
      return new byte[]{-24, -68, 63, 78, 4, 61, 13, 117, 2, 85};
   }

   private static byte[] tuagnmzccxxvboa() {
      return new byte[]{-24, -68, 63, 73, 4, 55, 13, 102, 2, 76, 103, 46, 99, 120, 95, 2, 92, 18, 89, 56, 9, 106};
   }

   private static byte[] nhwxtpinknvwcng() {
      return new byte[]{-19, -68, 57, 74, 4, 61, 12, 108, 2, 77, 101, 42, 99, 124, 91, 11, 82, 29, 91, 45, 15, 113, 126, 117, 11, 21, 77, 69, 120, 104, 108, 15, 2, 0, 33, 1, 32, 105};
   }

   private static byte[] bqztcaqbdzmscao() {
      return new byte[]{-19, -70, 49, 74, 11, 52, 9, 104, 13, 75, 101, 44, 107, 124, 84, 2, 87, 25, 84, 43, 15, 119, 118, 117, 4, 28, 72, 65, 119, 110, 108, 9, 10, 0, 46, 8, 37, 109, 36, 92};
   }

   private static byte[] nrhsprwexnwuwey() {
      return new byte[]{-27, -71, 57, 91, 11, 51, 11, 96, 13, 70, 101, 40, 107, 55, 93, 27, 92, 83, 92, 39, 7, 118, 127, 61, 4, 30, 75, 74, 119, 55, 109, 5, 10, 8, 38, 20, 46, 102, 45, 4, 2, 73, 68, 63};
   }

   private static byte[] syrxjimhpqngtxh() {
      return new byte[]{-28, -70, 60, 92, 2, 56, 11, 104, 12, 67, 97, 49, 97, 36, 84, 90, 93, 30, 85, 45, 10, 114, 127, 120, 13, 7, 66, 66, 123, 106, 110, 4, 10, 2, 47, 14, 47, 114, 41, 11, 11, 91};
   }

   private static byte[] vndsawxulfersts() {
      return new byte[]{-28, -70, 60, 25, 2, 58, 11, 95, 12, 66, 97, 43, 97, 112, 84, 20, 93, 18, 85, 34, 10, 114, 127, 118, 13, 20, 66, 7, 123, 42, 110, 9, 10, 9, 47, 14, 47, 113, 41, 11, 11, 9, 69, 45, 102, 117, 9, 99, 58, 32, 103, 45, 112, 72, 90, 39, 93, 97, 60, 26, 94, 112, 43, 117, 12, 13, 17, 36, 49, 89, 10, 42, 3, 37};
   }

   private static byte[] jsgcptlrxathbcl() {
      return new byte[]{-21, -67, 59, 75, 1, 48, 14, 103, 3, 80, 102, 58, 102, 59, 88, 95, 93, 15, 90, 34, 13, 124, 124, 123, 8, 78, 77, 68, 124, 41, 105, 5, 6, 7, 47, 19};
   }

   private static byte[] hgpcwzchussvqac() {
      return new byte[0];
   }

   private static byte[] pjmsimamybigvbq() {
      return new byte[]{-21, -67, 26, -87, 32, -60, 47, -105, 34, -77, 71, -56, 71, -62, 121, -29, 124, -19, 123, -38, 44, -118, 93, -124, 41, -15};
   }

   private static byte[] okqqxzuvahvmega() {
      return new byte[]{-21, -67, 59, 107, 1, 48, 14, 103, 3, 80, 102, 58, 102, 59};
   }

   private static byte[] cmbgprxmolgvnly() {
      return new byte[0];
   }

   private static byte[] uoubwrddqfbsbnv() {
      return new byte[]{-21, -66, 56, 73, 0, 56, 8, 97, 7, 76, 101, 61, 100, 39, 92, 29, 93, 85, 90, 46, 14, 120, 125, 120, 14, 12, 73, 77, 127, 39};
   }

   private static byte[] tgcqditzbzoxchj() {
      return new byte[]{-21, -66, 56, 28, 0, 50, 8, 85, 7, 75, 101, 61, 100, 60, 92, 51, 93, 45, 90, 1, 14, 57, 125, 119, 14, 1, 73, 65, 127, 47, 107, 15, 2, 0, 47, 68, 32, 102, 45, 4, 9, 1, 70, 54, 109, 98, 13, 103, 63, 108, 111, 116, 112, 6, 85, 11, 89, 122, 62, 18, 93, 117, 32, 107, 8, 72, 20, 43, 57, 81, 10, 32, 12, 123, 4, 66, 102, 55, 97, 52, 94, 21, 84, 31, 91, 116};
   }

   private static byte[] xctafohtdloavbp() {
      return new byte[]{-24, -71, 62, 75, 0, 60, 9, 102, 3, 76, 98, 47, 97, 124, 84, 1, 92, 25, 89, 46, 8, 113, 125, 126, 15, 20, 77, 66, 120, 107, 110, 14, 10, 0, 46, 14, 35, 108, 43, 90};
   }

   private static byte[] nlgydiodxvcaadk() {
      return new byte[]{-21, -68, 57, 82, 0, 63, 10, 35, 13, 74, 103, 52, 98, 63, 93, 19};
   }

   private static byte[] bmvgucoscqqmigp() {
      return new byte[]{-21, -68, 57, 26, 0, 51, 10, 87, 13, 77, 103, 46, 98, 32, 93, 86, 85, 6, 90, 47, 15, 126, 125, 125, 12, 72, 67, 76, 125, 45, 109, 15, 3, 21, 39, 78, 32, 126, 44, 2, 9, 84, 68, 113, 103, 122, 15, 98, 57, 116, 110, 61, 120, 12, 85, 33, 88, 47, 62, 91, 95, 123, 42, 114, 10, 12, 18, 108};
   }

   private static byte[] sklnwgeiwuzyprm() {
      return new byte[]{-19, -69, 57, 73, 1, 50, 8, 106, 3, 76, 101, 45, 99, 127, 94, 4, 86, 27, 90, 44, 15, 118, 126, 118, 14, 26, 73, 67, 121, 105, 108, 8, 2, 3, 36, 14, 36, 111, 42, 90};
   }

   private static byte[] zflaxymmoptujtr() {
      return new byte[]{-19, -69, 63, 80, 2, 54, 9, 34, 0, 77, 101, 49, 101, 63, 93, 27, 87, 87, 89, 57, 15, 126, 120, 96, 13, 12, 72, 71, 122, 48, 108, 31, 4, 12, 39, 1, 37, 124};
   }

   private static byte[] etoalgfrkafdjsy() {
      return new byte[]{-19, -69, 63, 24, 2, 58, 9, 86, 0, 74, 101, 43, 101, 114, 93, 26, 87, 21, 89, 105, 15, 117, 120, 125, 13, 21, 72, 14, 122, 43, 108, 13, 4, 19, 39, 11, 37, 50, 41, 29, 10, 65, 66, 33, 110, 113, 14, 106, 61, 115, 111, 46, 127, 78, 82, 37, 91, 96, 56, 19, 95, 100, 36, 117, 9, 65, 16, 38, 60, 83, 3, 116, 12, 120, 4, 67, 102, 123, 102, 36, 92, 27, 82, 28, 93, 96, 12, 106, 123, 117, 12, 13, 77, 64, 126, 106, 111, 1, 7, 8, 38, 14, 32, 116, 45, 74};
   }

   private static byte[] xkmjuuvcfmhbfrn() {
      return new byte[]{-19, -72, 49, 76, 11, 60, 14, 108, 12, 79, 101, 46, 107, 122, 84, 10, 80, 29, 85, 47, 15, 117, 118, 115, 4, 20, 79, 69, 118, 106, 108, 11, 10, 6, 46, 0, 34, 105, 37, 95};
   }

   private static byte[] pktptmczvkfxlku() {
      return new byte[]{-21, -74, 62, 92, 7, 61, 10, 105, 6, 71, 109, 46, 101, 52, 85, 26, 92, 87, 90, 46, 8, 119, 122, 53, 12, 17, 72, 77, 119, 55, 106, 0, 11, 15, 46, 22, 32, 105, 43, 3, 14, 71, 68, 54};
   }

   private static int mdylhuvyxeiobwow(int var0, int var1) {
      return var0 ^ var1;
   }

   public static enum K {
      JOIN_DATE,
      PERMISSIONS,
      MONEY,
      ALPHABETICAL,
      ONLINE_FIRST;

      public final String key;
      public final String label;
      private static String rcdcqnzvxe;

      private K(final String var3, final String var4) {
         this.key = var3;
         this.label = var4;
      }

      public static K fromKey(String var0) {
         int var26 = 1602445645 ^ 647564645 ^ 589001436;
         var26 = 823718431 ^ var26;
         K[] var1 = values();
         K[] var3 = var1;
         int var8 = var1.length;
         int var4 = var8;
         byte var9 = (byte)(1796861163 ^ var26);
         int var5 = var9;
         var26 = 916969015 ^ var26;

         while(var5 < var4) {
            var26 = 583342949 ^ var26;
            K var12 = var3[var5];
            var26 = 2042688010 ^ var26;
            String var14 = var12.key;
            byte var15 = var14.equalsIgnoreCase(var0);
            if (var15 == (112972723 ^ var26)) {
               var26 = 99770555 ^ var26;
               String var17 = var12.name();
               byte var18 = var17.equalsIgnoreCase(var0);
               if (var18 != (55161608 ^ var26)) {
                  var26 = 1765342842 ^ var26;
                  return var12;
               }

               var26 = wjbowudqqibyjavh(var26, 1604421720);
               var5 += 1558723409 ^ var26;
               var26 = wjbowudqqibyjavh(var26, 22413708);
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var26)) {
                     case 105910476:
                        var26 = 1825218241 ^ var26;
                        return var12;
                     case 902790540:
                        return var12;
                     case 977431222:
                     default:
                        throw new IllegalAccessException();
                     case 1890057737:
                  }
               }
            }
         }

         var26 = wjbowudqqibyjavh(var26, 523384146);
         Object var20 = null;
         return (K)var20;
      }

      private static K[] $values() {
         int var14 = 744311811 ^ 1901673288 ^ 589001436;
         var14 = 662491821 ^ var14;
         byte var0 = (byte)(1499715391 ^ var14);
         K[] var3 = new K[var0];
         byte var1 = (byte)(1499715386 ^ var14);
         K var2 = JOIN_DATE;
         var3[var1] = var2;
         byte var4 = (byte)(1499715387 ^ var14);
         K var8 = PERMISSIONS;
         var3[var4] = var8;
         byte var5 = (byte)(1499715384 ^ var14);
         K var9 = MONEY;
         var3[var5] = var9;
         byte var6 = (byte)(1499715385 ^ var14);
         K var10 = ALPHABETICAL;
         var3[var6] = var10;
         byte var7 = (byte)(1499715390 ^ var14);
         K var11 = ONLINE_FIRST;
         var3[var7] = var11;
         return var3;
      }

      static {
         int var28 = 1254680144 ^ 521894487 ^ Integer.parseInt("536360501");
         rcdcqnzvxe = ByteBuffer.wrap(eaptexhysokhlda()).asCharBuffer().toString();
         var28 = 1775996536 ^ var28;
         String var1 = ckwqsssbno(uueorrnbqvovcku(), var28);
         byte var2 = (byte)(602940490 ^ var28);
         String var3 = ckwqsssbno(atoucqokazvyeip(), var28);
         String var4 = ckwqsssbno(xevnzpqmjblxoqd(), var28);
         K var0 = new K(var1, var2, var3, var4);
         JOIN_DATE = var0;
         var28 = 812020743 ^ var28;
         String var10 = ckwqsssbno(dlwnaijanirmvry(), var28);
         byte var14 = (byte)(328618060 ^ var28);
         String var18 = ckwqsssbno(hnimphhgprlkosi(), var28);
         String var22 = ckwqsssbno(pcslxasdwhsixhq(), var28);
         K var5 = new K(var10, var14, var18, var22);
         PERMISSIONS = var5;
         var28 = 803143469 ^ var28;
         String var11 = ckwqsssbno(kzzhnzvessqdlxs(), var28);
         byte var15 = (byte)(1011396450 ^ var28);
         String var19 = ckwqsssbno(kxssocxqlmimfna(), var28);
         String var23 = ckwqsssbno(uvthfsiuzweekqh(), var28);
         K var6 = new K(var11, var15, var19, var23);
         MONEY = var6;
         var28 = 1466653896 ^ var28;
         String var12 = ckwqsssbno(bsdcvctztdfhehf(), var28);
         byte var16 = (byte)(1797518251 ^ var28);
         String var20 = ckwqsssbno(jrmayjkwyigoxsh(), var28);
         String var24 = ckwqsssbno(gffqmnirtpaimog(), var28);
         K var7 = new K(var12, var16, var20, var24);
         ALPHABETICAL = var7;
         var28 = 69232210 ^ var28;
         String var13 = ckwqsssbno(cferxccvqkqwnkv(), var28);
         byte var17 = (byte)(1862505982 ^ var28);
         String var21 = ckwqsssbno(lqqmjlwvpicnxfl(), var28);
         String var25 = ckwqsssbno(tmqivgynvgfoypi(), var28);
         K var8 = new K(var13, var17, var21, var25);
         ONLINE_FIRST = var8;
         var28 = 1278874240 ^ var28;
         K[] var9 = $values();
      }

      public static String ckwqsssbno(byte[] var0, int var1) {
         String var13 = Integer.toString(var1);
         byte[] var14 = var13.getBytes();
         byte[] var8 = var14;
         byte var3 = 0;
         byte var16 = var0[var3];
         short var36 = 255;
         int var17 = var16 & var36;
         byte var37 = 24;
         int var18 = var17 << var37;
         byte var4 = 1;
         byte var39 = var0[var4];
         short var68 = 255;
         int var40 = var39 & var68;
         byte var69 = 16;
         int var41 = var40 << var69;
         int var19 = var18 | var41;
         byte var70 = 2;
         byte var43 = var0[var70];
         short var71 = 255;
         int var44 = var43 & var71;
         byte var72 = 8;
         int var45 = var44 << var72;
         int var20 = var19 | var45;
         byte var73 = 3;
         byte var47 = var0[var73];
         short var74 = 255;
         int var48 = var47 & var74;
         int var21 = var20 | var48;
         byte var49 = 4;
         byte var23 = var0[var49];
         short var50 = 255;
         int var24 = var23 & var50;
         byte var51 = 24;
         int var25 = var24 << var51;
         byte var75 = 5;
         byte var53 = var0[var75];
         short var76 = 255;
         int var54 = var53 & var76;
         byte var77 = 16;
         int var55 = var54 << var77;
         int var26 = var25 | var55;
         byte var78 = 6;
         byte var57 = var0[var78];
         short var79 = 255;
         int var58 = var57 & var79;
         byte var80 = 8;
         int var59 = var58 << var80;
         int var27 = var26 | var59;
         byte var81 = 7;
         byte var61 = var0[var81];
         short var82 = 255;
         int var62 = var61 & var82;
         int var28 = var27 | var62;
         String var29 = rcdcqnzvxe;
         int var84 = var28 + var21;
         String var30 = var29.substring(var28, var84);
         Charset var64 = StandardCharsets.UTF_16BE;
         byte[] var31 = var30.getBytes(var64);
         byte[] var11 = var31;
         byte var32 = 0;
         int var12 = var32;

         while(true) {
            int var66 = var11.length;
            if (var12 >= var66) {
               Charset var89 = StandardCharsets.UTF_16BE;
               String var34 = new String(var11, var89);
               return var34;
            }

            byte var86 = var11[var12];
            int var93 = var8.length;
            int var92 = var12 % var93;
            byte var91 = var8[var92];
            int var87 = var86 ^ var91;
            byte var88 = (byte)var87;
            var11[var12] = var88;
            ++var12;
         }
      }

      private static byte[] dlwnaijanirmvry() {
         return new byte[]{0, 0, 0, 11, 0, 0, 0, 0};
      }

      private static byte[] hnimphhgprlkosi() {
         return new byte[]{0, 0, 0, 11, 0, 0, 0, 11};
      }

      private static byte[] pcslxasdwhsixhq() {
         return new byte[]{0, 0, 0, 11, 0, 0, 0, 22};
      }

      private static byte[] kzzhnzvessqdlxs() {
         return new byte[]{0, 0, 0, 5, 0, 0, 0, 33};
      }

      private static byte[] kxssocxqlmimfna() {
         return new byte[]{0, 0, 0, 5, 0, 0, 0, 38};
      }

      private static byte[] uvthfsiuzweekqh() {
         return new byte[]{0, 0, 0, 5, 0, 0, 0, 43};
      }

      private static byte[] cferxccvqkqwnkv() {
         return new byte[]{0, 0, 0, 12, 0, 0, 0, 48};
      }

      private static byte[] lqqmjlwvpicnxfl() {
         return new byte[]{0, 0, 0, 6, 0, 0, 0, 60};
      }

      private static byte[] tmqivgynvgfoypi() {
         return new byte[]{0, 0, 0, 14, 0, 0, 0, 66};
      }

      private static byte[] uueorrnbqvovcku() {
         return new byte[]{0, 0, 0, 9, 0, 0, 0, 80};
      }

      private static byte[] atoucqokazvyeip() {
         return new byte[]{0, 0, 0, 9, 0, 0, 0, 89};
      }

      private static byte[] xevnzpqmjblxoqd() {
         return new byte[]{0, 0, 0, 9, 0, 0, 0, 98};
      }

      private static byte[] bsdcvctztdfhehf() {
         return new byte[]{0, 0, 0, 12, 0, 0, 0, 107};
      }

      private static byte[] jrmayjkwyigoxsh() {
         return new byte[]{0, 0, 0, 12, 0, 0, 0, 119};
      }

      private static byte[] gffqmnirtpaimog() {
         return new byte[]{0, 0, 0, 14, 0, 0, 0, -125};
      }

      private static byte[] eaptexhysokhlda() {
         return new byte[]{51, 98, 56, 115, 49, 106, 48, 123, 49, 122, 50, 107, 54, 98, 56, 121, 54, 126, 51, 124, 56, 101, 51, 66, 56, 83, 49, 74, 48, 91, 49, 90, 50, 75, 54, 66, 56, 89, 54, 94, 51, 92, 56, 69, 51, 98, 56, 83, 49, 74, 48, 91, 49, 90, 50, 75, 54, 66, 56, 89, 54, 94, 51, 92, 56, 69, 49, 125, 49, 126, 51, 119, 54, 113, 52, 97, 49, 93, 49, 94, 51, 87, 54, 81, 52, 65, 49, 125, 49, 94, 51, 87, 54, 81, 52, 65, 49, 119, 54, 124, 53, 124, 53, 112, 55, 118, 49, 125, 54, 109, 53, 118, 53, 112, 55, 106, 49, 107, 54, 102, 49, 87, 54, 92, 53, 92, 53, 80, 55, 86, 49, 93, 49, 119, 54, 92, 53, 92, 53, 80, 55, 86, 49, 93, 54, 18, 53, 125, 53, 92, 55, 85, 49, 90, 54, 87, 53, 66, 53, 74, 54, 122, 50, 118, 52, 121, 52, 119, 48, 105, 48, 118, 57, 117, 48, 96, 57, 117, 54, 90, 50, 86, 52, 89, 52, 87, 48, 27, 48, 86, 57, 85, 48, 64, 57, 85, 54, 122, 50, 86, 52, 89, 52, 87, 48, 22, 48, 118, 57, 85, 48, 64, 57, 85, 49, 118, 57, 123, 53, 97, 56, 122, 52, 121, 49, 117, 57, 114, 53, 101, 56, 123, 52, 123, 49, 118, 57, 123, 49, 86, 57, 91, 53, 65, 56, 90, 52, 89, 49, 85, 57, 82, 53, 69, 56, 91, 52, 91, 49, 86, 57, 91, 49, 118, 57, 91, 53, 65, 56, 90, 52, 89, 49, 85, 57, 82, 53, 69, 56, 91, 52, 91, 49, 86, 57, 91, 53, 93, 56, 75};
      }

      private static int wjbowudqqibyjavh(int var0, int var1) {
         return var0 ^ var1;
      }
   }
}
