package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.oOo0KKoOoOK;

public class TeamService {
   private final String name;
   private String displayName;
   private final UUID leader;
   private final Set<UUID> members;
   private final long createdAt;
   private boolean pvpEnabled;
   private final Set<UUID> canInvite;
   private final Set<UUID> canKick;
   private final Set<UUID> canTogglePvP;
   private Location teamHome;
   private String teamHomeWorld;
   private String teamHomeServer;
   private double teamHomeX;
   private double teamHomeY;
   private double teamHomeZ;
   private float teamHomeYaw;
   private float teamHomePitch;
   private final Set<UUID> canSetHome;
   private final Set<UUID> canVisitHome;
   private final Set<UUID> teamChatEnabled;
   private static byte[] smpylnygvp;

   public TeamService(String var1, UUID var2) {
      ConcurrentHashMap.KeySetView var4 = ConcurrentHashMap.newKeySet();
      this.members = var4;
      boolean var21 = true;
      this.pvpEnabled = var21;
      ConcurrentHashMap.KeySetView var22 = ConcurrentHashMap.newKeySet();
      this.canInvite = var22;
      ConcurrentHashMap.KeySetView var23 = ConcurrentHashMap.newKeySet();
      this.canKick = var23;
      ConcurrentHashMap.KeySetView var24 = ConcurrentHashMap.newKeySet();
      this.canTogglePvP = var24;
      Object var25 = null;
      this.teamHome = (Location)var25;
      ConcurrentHashMap.KeySetView var26 = ConcurrentHashMap.newKeySet();
      this.canSetHome = var26;
      ConcurrentHashMap.KeySetView var27 = ConcurrentHashMap.newKeySet();
      this.canVisitHome = var27;
      ConcurrentHashMap.KeySetView var28 = ConcurrentHashMap.newKeySet();
      this.teamChatEnabled = var28;
      String var30 = oOo0KKoOoOK.color(var1);
      String var31 = ChatColor.stripColor(var30);
      String var32 = var31.toLowerCase();
      this.name = var32;
      this.displayName = var1;
      this.leader = var2;
      Set var18 = this.members;
      var18.add(var2);
      long var36 = System.currentTimeMillis();
      this.createdAt = var36;
   }

   public String getName() {
      int var5 = 831578921 ^ 830471062 ^ 1657915249;
      var5 = 2114306385 ^ var5;
      String var2 = this.name;
      return var2;
   }

   public String getDisplayName() {
      int var6 = 1529507792 ^ 1401892472 ^ 1657915249;
      var6 = 1644223223 ^ var6;
      String var2 = this.displayName;
      String var3 = oOo0KKoOoOK.color(var2);
      return var3;
   }

   public String getRawDisplayName() {
      int var5 = 1591935847 ^ 423777898 ^ 1657915249;
      var5 = 1744390072 ^ var5;
      String var2 = this.displayName;
      return var2;
   }

   public void setDisplayName(String var1) {
      int var6 = 883809081 ^ 1815836180 ^ 1657915249;
      var6 = 1694134114 ^ var6;
      this.displayName = var1;
      var6 = 614975303 ^ var6;
   }

   public UUID getLeader() {
      int var5 = 1936123471 ^ 639060347 ^ 1657915249;
      var5 = 2101602357 ^ var5;
      UUID var2 = this.leader;
      return var2;
   }

   public Set<UUID> getMembers() {
      int var5 = 1031955695 ^ 571345388 ^ 1657915249;
      var5 = 47169106 ^ var5;
      Set var2 = this.members;
      return var2;
   }

   public long getCreatedAt() {
      int var5 = 777213264 ^ 520803137 ^ 1657915249;
      var5 = 1323235939 ^ var5;
      long var2 = this.createdAt;
      return var2;
   }

   public boolean isLeader(UUID var1) {
      int var8 = 1173711943 ^ 619155255 ^ 1657915249;
      var8 = 563431499 ^ var8;
      UUID var4 = this.leader;
      boolean var5 = var4.equals(var1);
      return var5;
   }

   public boolean isMember(UUID var1) {
      int var8 = 779437137 ^ 787715595 ^ 1657915249;
      var8 = 301891566 ^ var8;
      Set var4 = this.members;
      boolean var5 = var4.contains(var1);
      return var5;
   }

   public static int getMaxPlayers() {
      int var15 = 1077878493 ^ 2062938378 ^ 610672423;
      var15 = 1600695861 ^ var15;
      DonutSMPCore var0 = DonutSMPCore.getInstance();
      FileConfiguration var4 = var0.getConfig();
      String var1 = qznhmcelqo(fyzknycnugdjlgb(), var15);
      byte var2 = (byte)(1103388357 ^ var15);
      byte var5 = var4.getBoolean(var1, (boolean)var2);
      var15 = 792603614 ^ var15;
      if (var5 == (1861907739 ^ var15)) {
         var15 = 2119637457 ^ var15;
         byte var7 = (byte)(-279801035 ^ var15);
         return var7;
      } else {
         var15 = 1545147099 ^ var15;
         DonutSMPCore var8 = DonutSMPCore.getInstance();
         FileConfiguration var9 = var8.getConfig();
         String var11 = qznhmcelqo(ombkzzpqeuorcij(), var15);
         byte var12 = (byte)(853764082 ^ var15);
         int var10 = var9.getInt(var11, var12);
         return var10;
      }
   }

   public boolean isFull() {
      int var12 = 560598294 ^ 1465978294 ^ 1657915249;
      var12 = 1509834005 ^ var12;
      int var1 = getMaxPlayers();
      var12 = 1861051400 ^ var12;
      if (var1 <= (600415948 ^ var12)) {
         var12 = 1844942429 ^ var12;
         byte var5 = (byte)(1312688273 ^ var12);
         return (boolean)var5;
      } else {
         var12 = 885792884 ^ var12;
         Set var7 = this.members;
         int var8 = var7.size();
         byte var9;
         if (var8 >= var1) {
            var12 = 1684241250 ^ var12;
            var9 = (byte)(1936115163 ^ var12);
            var12 = girxltvlvqzkvhjp(var12, 216888232);
            return (boolean)var9;
         } else {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                  case 211498625:
                     var12 ^= 1603977063;
                  case 650001657:
                     var9 = (byte)(1218380255 ^ var12);
                     var12 = 924104621 ^ var12;
                     return (boolean)var9;
                  case 1117249917:
                     break;
                  case 1457838818:
                  default:
                     throw new IllegalAccessException();
               }
            }
         }
      }
   }

   public int getRemainingSlots() {
      int var14 = 1241519258 ^ 637787638 ^ 1657915249;
      var14 = 1212371706 ^ var14;
      int var1 = getMaxPlayers();
      var14 = 1646864341 ^ var14;
      if (var1 <= (616069938 ^ var14)) {
         var14 = 21504812 ^ var14;
         byte var6 = (byte)(-636508191 ^ var14);
         return var6;
      } else {
         var14 = 1429193934 ^ var14;
         byte var7 = (byte)(1905770492 ^ var14);
         Set var10 = this.members;
         int var11 = var10.size();
         int var9 = var1 - var11;
         int var8 = Math.max(var7, var9);
         return var8;
      }
   }

   public boolean addMember(UUID var1) {
      int var11 = 574630037 ^ 1313947894 ^ 1657915249;
      var11 = 1498979434 ^ var11;
      byte var4 = this.isFull();
      if (var4 != (1469592440 ^ var11)) {
         var11 = 880514223 ^ var11;
         byte var8 = (byte)(1675864023 ^ var11);
         return (boolean)var8;
      } else {
         var11 = 1648579021 ^ var11;
         Set var6 = this.members;
         boolean var7 = var6.add(var1);
         return var7;
      }
   }

   public boolean removeMember(UUID var1) {
      int var13 = 411010223 ^ 781494743 ^ 1657915249;
      var13 = 1543609510 ^ var13;
      UUID var4 = this.leader;
      byte var5 = var4.equals(var1);
      byte var9;
      if (var5 == (138114735 ^ var13)) {
         var13 = 441271445 ^ var13;
         Set var7 = this.members;
         byte var8 = var7.remove(var1);
         if (var8 != (309735994 ^ var13)) {
            var13 = 1930308437 ^ var13;
            var9 = (byte)(1635260782 ^ var13);
            var13 = girxltvlvqzkvhjp(var13, 1857341902);
            return (boolean)var9;
         }

         var13 = 1040352077 ^ var13;
      } else {
         label26:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var13)) {
               case 129480575:
                  var13 ^= 609208280;
                  break label26;
               case 556994551:
                  break;
               case 1382074368:
                  break label26;
               case 1895968280:
               default:
                  throw new IOException();
            }
         }
      }

      var9 = (byte)(745845111 ^ var13);
      var13 = 599286230 ^ var13;
      return (boolean)var9;
   }

   public boolean isPvpEnabled() {
      int var5 = 1106766794 ^ 1313380137 ^ 1657915249;
      var5 = 1265091844 ^ var5;
      boolean var2 = this.pvpEnabled;
      return var2;
   }

   public void setPvpEnabled(boolean var1) {
      int var6 = 589626379 ^ 719071590 ^ 1657915249;
      var6 = 883645289 ^ var6;
      this.pvpEnabled = var1;
      var6 = 211031731 ^ var6;
   }

   public boolean canInvite(UUID var1) {
      int var12 = 1339858268 ^ 1129796822 ^ 1657915249;
      var12 = 1023769657 ^ var12;
      byte var4 = this.isLeader(var1);
      byte var8;
      if (var4 == (1398764226 ^ var12)) {
         var12 = 1375096133 ^ var12;
         Set var6 = this.canInvite;
         byte var7 = var6.contains(var1);
         if (var7 == (44646279 ^ var12)) {
            var12 = girxltvlvqzkvhjp(var12, 2066691071);
            var8 = (byte)(2038828152 ^ var12);
            var12 = 1173607429 ^ var12;
            return (boolean)var8;
         }

         var12 = 1691723615 ^ var12;
      } else {
         var12 = 891546138 ^ var12;
      }

      var8 = (byte)(1719441625 ^ var12);
      var12 = 1510555813 ^ var12;
      return (boolean)var8;
   }

   public boolean canKick(UUID var1) {
      int var12 = 1305021086 ^ 1726369135 ^ 1657915249;
      var12 = 162240312 ^ var12;
      byte var4 = this.isLeader(var1);
      byte var8;
      if (var4 == (1079318456 ^ var12)) {
         var12 = 1433943016 ^ var12;
         Set var6 = this.canKick;
         byte var7 = var6.contains(var1);
         if (var7 == (355282000 ^ var12)) {
            var12 = 2093750552 ^ var12;
            var8 = (byte)(1776366920 ^ var12);
            var12 = 911793590 ^ var12;
            return (boolean)var8;
         }

         var12 = 936961137 ^ var12;
      } else {
         var12 = 1654710169 ^ var12;
      }

      var8 = (byte)(586532896 ^ var12);
      var12 = 2102141151 ^ var12;
      return (boolean)var8;
   }

   public boolean canTogglePvP(UUID var1) {
      int var12 = 1523459825 ^ 865803025 ^ 1657915249;
      var12 = 1337819072 ^ var12;
      byte var4 = this.isLeader(var1);
      byte var8;
      if (var4 == (1144620369 ^ var12)) {
         var12 = 187638255 ^ var12;
         Set var6 = this.canTogglePvP;
         byte var7 = var6.contains(var1);
         if (var7 == (1326884030 ^ var12)) {
            label25:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                  case 154898470:
                     var12 ^= 781112761;
                     break label25;
                  case 1331599811:
                  default:
                     throw new IOException();
                  case 1470380166:
                     break;
                  case 1836260580:
                     break label25;
               }
            }

            var8 = (byte)(1637380359 ^ var12);
            var12 = 531951790 ^ var12;
            return (boolean)var8;
         }

         var12 = 170126266 ^ var12;
      } else {
         var12 = girxltvlvqzkvhjp(var12, 17615445);
      }

      var8 = (byte)(1161121541 ^ var12);

      while(true) {
         switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
            case 102173730:
               var12 = 991547053 ^ var12;
               return (boolean)var8;
            case 258539195:
               break;
            case 837698287:
            default:
               throw new IOException();
            case 1272900496:
               return (boolean)var8;
         }
      }
   }

   public void toggleInvitePerm(UUID var1) {
      int var16 = 327199022 ^ 1828364878 ^ 1657915249;
      var16 = 1471476425 ^ var16;
      Set var4 = this.canInvite;
      byte var5 = var4.contains(var1);
      if (var5 != (1243561688 ^ var16)) {
         var16 = 1132098612 ^ var16;
         Set var7 = this.canInvite;
         var7.remove(var1);
         var16 = girxltvlvqzkvhjp(var16, 2140781146);
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 65793149:
               default:
                  throw new RuntimeException();
               case 120042043:
                  break;
               case 261931997:
                  var16 ^= 535911067;
               case 36788716:
                  Set var10 = this.canInvite;
                  var10.add(var1);
                  var16 = 588420341 ^ var16;
                  return;
            }
         }
      }
   }

   public void toggleKickPerm(UUID var1) {
      int var16 = 1718807159 ^ 1033930875 ^ 1657915249;
      var16 = 1367024630 ^ var16;
      Set var4 = this.canKick;
      byte var5 = var4.contains(var1);
      if (var5 == (1752729227 ^ var16)) {
         var16 = girxltvlvqzkvhjp(var16, 93974366);
         Set var10 = this.canKick;
         var10.add(var1);
         var16 = 954044241 ^ var16;
      } else {
         var16 = 1857137015 ^ var16;
         Set var7 = this.canKick;
         var7.remove(var1);

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 60452331:
               default:
                  throw new IllegalAccessException();
               case 106732085:
                  var16 = 1408616824 ^ var16;
                  return;
               case 1053735654:
                  return;
               case 1252586216:
            }
         }
      }
   }

   public void togglePvPPerm(UUID var1) {
      int var16 = 1744687839 ^ 1002293607 ^ 1657915249;
      var16 = 127003331 ^ var16;
      Set var4 = this.canTogglePvP;
      byte var5 = var4.contains(var1);
      if (var5 == (956315146 ^ var16)) {
         var16 = girxltvlvqzkvhjp(var16, 328997621);
         Set var10 = this.canTogglePvP;
         var10.add(var1);
         var16 = 764729890 ^ var16;
      } else {
         var16 = 1073923798 ^ var16;
         Set var7 = this.canTogglePvP;
         var7.remove(var1);

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 175492008:
                  var16 = 2114586113 ^ var16;
                  return;
               case 241480610:
                  break;
               case 307999925:
                  return;
               case 659309304:
               default:
                  throw new IllegalAccessException();
            }
         }
      }
   }

   public Location getTeamHome() {
      int var5 = 1326593831 ^ 223823749 ^ 1657915249;
      var5 = 579904482 ^ var5;
      Location var2 = this.teamHome;
      return var2;
   }

   public String getTeamHomeServer() {
      int var5 = 1956519023 ^ 1855395296 ^ 1657915249;
      var5 = 1694021653 ^ var5;
      String var2 = this.teamHomeServer;
      return var2;
   }

   public void setTeamHomeServer(String var1) {
      int var6 = 148376499 ^ 2014351865 ^ 1657915249;
      var6 = 1822568362 ^ var6;
      this.teamHomeServer = var1;
   }

   public void setTeamHome(Location var1) {
      int var42 = 547564233 ^ 846606483 ^ 1657915249;
      var42 = 289420021 ^ var42;
      this.teamHome = var1;
      var42 = 2088101663 ^ var42;
      if (var1 == null) {
         var42 = 1477263756 ^ var42;
         Object var19 = null;
         this.teamHomeServer = (String)var19;
         var42 = 1531220171 ^ var42;
         Object var20 = null;
         this.teamHomeWorld = (String)var20;
         var42 = 1911897091 ^ var42;
         double var21 = (double)0.0F;
         double var4 = (double)0.0F;
         double var6 = (double)0.0F;
         float var8 = 0.0F;
         float var9 = 0.0F;
         this.setTeamHomeCoords(var21, var4, var6, var8, var9);
         var42 = 1460529784 ^ var42;
      } else {
         var42 = 526578297 ^ var42;
         World var15 = var1.getWorld();
         if (var15 != null) {
            var42 = 1166172771 ^ var42;
            World var24 = var1.getWorld();
            String var25 = var24.getName();
            this.teamHomeWorld = var25;
            var42 = 193818795 ^ var42;
            double var27 = var1.getX();
            double var31 = var1.getY();
            double var34 = var1.getZ();
            float var37 = var1.getYaw();
            float var39 = var1.getPitch();
            this.setTeamHomeCoords(var27, var31, var34, var37, var39);
            var42 = 138723283 ^ var42;
            String var29 = currentServerId();
            this.teamHomeServer = var29;
            var42 = 1984634420 ^ var42;
         } else {
            var42 = girxltvlvqzkvhjp(var42, 805352239);
         }

      }
   }

   public void setTeamHomeCoords(double var1, double var3, double var5, float var7, float var8) {
      int var24 = 907991180 ^ 1001163580 ^ 1657915249;
      var24 = 1179231183 ^ var24;
      this.teamHomeX = var1;
      this.teamHomeY = var3;
      this.teamHomeZ = var5;
      var24 = 33423812 ^ var24;
      this.teamHomeYaw = var7;
      this.teamHomePitch = var8;
      var24 = 1761457737 ^ var24;
   }

   public String getTeamHomeWorld() {
      int var5 = 1788411023 ^ 1724555149 ^ 1657915249;
      var5 = 352492532 ^ var5;
      String var2 = this.teamHomeWorld;
      return var2;
   }

   public void setTeamHomeWorld(String var1) {
      int var6 = 644994105 ^ 829196456 ^ 1657915249;
      var6 = 772987080 ^ var6;
      this.teamHomeWorld = var1;
   }

   public double getTeamHomeX() {
      int var5 = 401593949 ^ 1264708913 ^ 1657915249;
      var5 = 470002960 ^ var5;
      double var2 = this.teamHomeX;
      return var2;
   }

   public double getTeamHomeY() {
      int var5 = 545892131 ^ 1261548104 ^ 1657915249;
      var5 = 309059962 ^ var5;
      double var2 = this.teamHomeY;
      return var2;
   }

   public double getTeamHomeZ() {
      int var5 = 1468880690 ^ 723694095 ^ 1657915249;
      var5 = 761008627 ^ var5;
      double var2 = this.teamHomeZ;
      return var2;
   }

   public float getTeamHomeYaw() {
      int var5 = 1214839063 ^ 990906423 ^ 1657915249;
      var5 = 715537116 ^ var5;
      float var2 = this.teamHomeYaw;
      return var2;
   }

   public float getTeamHomePitch() {
      int var5 = 1912595980 ^ 2059220633 ^ 1657915249;
      var5 = 12979141 ^ var5;
      float var2 = this.teamHomePitch;
      return var2;
   }

   public static String currentServerId() {
      int var10 = 584165424 ^ 1451999216 ^ 610672423;
      var10 = 189412766 ^ var10;

      try {
         DonutSMPCore var0 = DonutSMPCore.getInstance();
         FileConfiguration var4 = var0.getConfig();
         String var1 = qznhmcelqo(mtloufftstepdst(), var10);
         Object var2 = null;
         var10 = 725100757 ^ var10;
         String var5 = var4.getString(var1, (String)var2);
         var10 = 1011255369 ^ var10;
         return var5;
      } catch (Throwable var11) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var10)) {
            case -2106544797 -> var10 = girxltvlvqzkvhjp(var10, 642219482);
            case -609096758 -> var10 = 226448655 ^ var10;
            default -> throw new RuntimeException("Error in hash");
         }

         var10 = 708835846 ^ var10;
         Object var7 = null;
         return (String)var7;
      }
   }

   public boolean hasTeamHome() {
      int var8 = 14224286 ^ 1212169848 ^ 1657915249;
      var8 = 1313909251 ^ var8;
      Location var2 = this.teamHome;
      byte var5;
      if (var2 == null) {
         var8 = 807389418 ^ var8;
         String var4 = this.teamHomeWorld;
         if (var4 == null) {
            var8 = girxltvlvqzkvhjp(var8, 292819323);
            var5 = (byte)(1165197573 ^ var8);
            var8 = 1102570409 ^ var8;
            return (boolean)var5;
         }

         var8 = 1235583122 ^ var8;
      } else {
         var8 = 2042251384 ^ var8;
      }

      var5 = (byte)(497160429 ^ var8);

      while(true) {
         switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var8)) {
            case 157949291:
               var8 = 426144320 ^ var8;
               return (boolean)var5;
            case 597820503:
               return (boolean)var5;
            case 1602613457:
               break;
            case 1759660038:
            default:
               throw new IOException();
         }
      }
   }

   public boolean canSetHome(UUID var1) {
      int var12 = 1631478929 ^ 1552561485 ^ 1657915249;
      var12 = 1551858135 ^ var12;
      byte var4 = this.isLeader(var1);
      byte var8;
      if (var4 == (52096890 ^ var12)) {
         var12 = 851103442 ^ var12;
         Set var6 = this.canSetHome;
         byte var7 = var6.contains(var1);
         if (var7 == (832577960 ^ var12)) {
            label25:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                  case 2519189:
                     var12 ^= 725748754;
                     break label25;
                  case 392657367:
                     break;
                  case 656449452:
                  default:
                     throw new IllegalAccessException();
                  case 1688767304:
                     break label25;
               }
            }

            var8 = (byte)(451030458 ^ var12);
            var12 = 1153590477 ^ var12;
            return (boolean)var8;
         }

         var12 = 115747838 ^ var12;
      } else {
         label38:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
               case 48841624:
                  var12 ^= 878503212;
                  break label38;
               case 179236978:
                  break;
               case 1044352559:
               default:
                  throw new IllegalAccessException();
               case 2066775266:
                  break label38;
            }
         }
      }

      var8 = (byte)(927337047 ^ var12);
      var12 = girxltvlvqzkvhjp(var12, 1768309537);
      return (boolean)var8;
   }

   public void toggleHomePerm(UUID var1) {
      int var16 = 1411495058 ^ 308476886 ^ 1657915249;
      var16 = 1611733278 ^ var16;
      Set var4 = this.canSetHome;
      byte var5 = var4.contains(var1);
      if (var5 != (1149473067 ^ var16)) {
         var16 = 1138874807 ^ var16;
         Set var7 = this.canSetHome;
         var7.remove(var1);

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 102697133:
                  break;
               case 116138864:
                  var16 = 1070113202 ^ var16;
                  return;
               case 1042551962:
                  return;
               case 1566195413:
               default:
                  throw new IllegalAccessException();
            }
         }
      } else {
         label34:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 79605184:
                  var16 ^= 759211219;
                  break label34;
               case 1323393041:
                  break;
               case 1601829155:
               default:
                  throw new IllegalAccessException();
               case 2055126868:
                  break label34;
            }
         }

         Set var10 = this.canSetHome;
         var10.add(var1);
         var16 = 1365892310 ^ var16;
      }
   }

   public boolean canVisitHome(UUID var1) {
      int var12 = 1519963639 ^ 800578676 ^ 1657915249;
      var12 = 1858141974 ^ var12;
      byte var4 = this.isLeader(var1);
      byte var8;
      if (var4 == (2034117092 ^ var12)) {
         var12 = 1945155520 ^ var12;
         Set var6 = this.canVisitHome;
         byte var7 = var6.contains(var1);
         if (var7 == (181313060 ^ var12)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var12)) {
                  case 82860203:
                     var12 ^= 901425517;
                  case 1228217790:
                     var8 = (byte)(1064580937 ^ var12);
                     var12 = 1843782835 ^ var12;
                     return (boolean)var8;
                  case 292990738:
                  default:
                     throw new IllegalAccessException();
                  case 1553168768:
               }
            }
         }

         var12 = 1112297573 ^ var12;
      } else {
         var12 = girxltvlvqzkvhjp(var12, 834463653);
      }

      var8 = (byte)(1216532032 ^ var12);
      var12 = 437460411 ^ var12;
      return (boolean)var8;
   }

   public void toggleVisitHomePerm(UUID var1) {
      int var16 = 1133983354 ^ 1726286733 ^ 1657915249;
      var16 = 1771776530 ^ var16;
      Set var4 = this.canVisitHome;
      byte var5 = var4.contains(var1);
      if (var5 != (775475348 ^ var16)) {
         var16 = 1760311143 ^ var16;
         Set var7 = this.canVisitHome;
         var7.remove(var1);
         var16 = 1492534686 ^ var16;
      } else {
         var16 = 660282526 ^ var16;
         Set var10 = this.canVisitHome;
         var10.add(var1);
         var16 = 390164071 ^ var16;
      }

   }

   public boolean isTeamChatEnabled(UUID var1) {
      int var8 = 1718847276 ^ 1504906030 ^ 1657915249;
      var8 = 1538545957 ^ var8;
      Set var4 = this.teamChatEnabled;
      boolean var5 = var4.contains(var1);
      return var5;
   }

   public void toggleTeamChat(UUID var1) {
      int var16 = 77958489 ^ 1569772901 ^ 1657915249;
      var16 = 964649547 ^ var16;
      Set var4 = this.teamChatEnabled;
      byte var5 = var4.contains(var1);
      if (var5 == (43777286 ^ var16)) {
         var16 = 819593592 ^ var16;
         Set var10 = this.teamChatEnabled;
         var10.add(var1);
         var16 = 1982282270 ^ var16;
      } else {
         var16 = 585076388 ^ var16;
         Set var7 = this.teamChatEnabled;
         var7.remove(var1);

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 243564621:
                  var16 = 1679996354 ^ var16;
                  return;
               case 649508236:
                  break;
               case 762282439:
                  return;
               case 2007858827:
               default:
                  throw new RuntimeException();
            }
         }
      }
   }

   public Set<UUID> getCanInvite() {
      int var5 = 55844848 ^ 143686803 ^ 1657915249;
      var5 = 877340534 ^ var5;
      Set var2 = this.canInvite;
      return var2;
   }

   public Set<UUID> getCanKick() {
      int var5 = 1363830535 ^ 288221093 ^ 1657915249;
      var5 = 224945987 ^ var5;
      Set var2 = this.canKick;
      return var2;
   }

   public Set<UUID> getCanTogglePvP() {
      int var5 = 3895315 ^ 137442442 ^ 1657915249;
      var5 = 589300204 ^ var5;
      Set var2 = this.canTogglePvP;
      return var2;
   }

   public Set<UUID> getCanSetHome() {
      int var5 = 1164968161 ^ 1113548093 ^ 1657915249;
      var5 = 269095377 ^ var5;
      Set var2 = this.canSetHome;
      return var2;
   }

   public Set<UUID> getCanVisitHome() {
      int var5 = 1012740590 ^ 1218268623 ^ 1657915249;
      var5 = 1002094428 ^ var5;
      Set var2 = this.canVisitHome;
      return var2;
   }

   public Set<UUID> getTeamChatEnabled() {
      int var5 = 2120019077 ^ 20025143 ^ 1657915249;
      var5 = 2144179063 ^ var5;
      Set var2 = this.teamChatEnabled;
      return var2;
   }

   public static String qznhmcelqo(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = smpylnygvp;
         byte[] var34 = smpylnygvp;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   static {
      smpylnygvp = ftquihefyytaean();
   }

   private static byte[] ftquihefyytaean() {
      return new byte[]{27, 9, 27, 64, 63, 116, 9, 71, 116, 108, 18, 114, 28, 71, 25, 116, 89, 54, 76, 21, 109, 88, 50, 56, 108, 83, 16, 92, 87, 38, 125, 111, 56, 85, 2, 120, 42, 70, 38, 76, 118, 52, 36, 90, 106, 125, 64, 51, 59, 103, 110, 117, 108, 23, 34, 105, 1, 39, 74, 97, 101, 12, 113, 8, 7, 48, 31, 105, 23, 115, 96, 18, 70, 44, 122, 110, 91, 57, 39, 29, 121, 123, 100, 42, 104, 115, 101};
   }

   private static byte[] fyzknycnugdjlgb() {
      return new byte[]{-44, -57, 43, 7, 12, 41, 49, 21, 65, 54, 35, 48, 44, 90, 42, 33, 97, 96, 121, 79, 92, 11, 2, 110, 95, 25, 40, 66, 98, 125, 76, 55, 8, 11, 49, 41, 18, 1, 19, 85, 71, 96, 20, 7, 89, 36, 120, 98, 14, 60, 95, 33, 92, 64};
   }

   private static byte[] ombkzzpqeuorcij() {
      return new byte[]{-35, -61, 40, 3, 9, 37, 57, 21, 70, 57, 39, 50, 43, 95, 45, 41, 106, 97, 116, 77, 94, 13, 4, 105, 92, 18, 34, 73, 98, 121, 74, 48, 12, 8, 49, 35, 18, 7, 21, 85, 64, 109, 20, 8, 88, 61, 117, 45, 12, 33, 90, 41, 95, 68, 26, 37, 50, 117, 124, 39, 85, 76};
   }

   private static byte[] mtloufftstepdst() {
      return new byte[]{-44, -61, 40, 7, 11, 38, 60, 3, 64, 43, 35, 34, 47, 1, 45, 110, 108, 105, 120, 64};
   }

   private static int girxltvlvqzkvhjp(int var0, int var1) {
      return var1 ^ var0;
   }
}
