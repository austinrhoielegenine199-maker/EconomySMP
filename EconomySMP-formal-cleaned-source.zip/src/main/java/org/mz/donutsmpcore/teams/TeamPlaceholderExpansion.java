package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.clip.placeholderapi.expansion.Relational;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.oOo0KKoOoOK;

public class TeamPlaceholderExpansion extends PlaceholderExpansion implements Relational {
   private static byte[] ujpdgowukc;

   public @NotNull String getIdentifier() {
      int var4 = 254944734 ^ 992620929 ^ 2103744606;
      var4 = 914125841 ^ var4;
      String var1 = hafzltxhmk(ckiijcyquvvylxo(), var4);
      return var1;
   }

   public @NotNull String getAuthor() {
      int var4 = 1198521261 ^ 1543507202 ^ 2103744606;
      var4 = 233703720 ^ var4;
      String var1 = hafzltxhmk(hluofrqudonmsco(), var4);
      return var1;
   }

   public @NotNull String getVersion() {
      int var4 = 1118813675 ^ 2036856586 ^ 2103744606;
      var4 = 1490255890 ^ var4;
      String var1 = hafzltxhmk(ddctnhqgeehixsa(), var4);
      return var1;
   }

   public boolean persist() {
      int var4 = 331413301 ^ 44302080 ^ 2103744606;
      var4 = 2112100673 ^ var4;
      byte var1 = (byte)(300124459 ^ var4);
      return (boolean)var1;
   }

   public @Nullable String onPlaceholderRequest(Player var1, @NotNull String var2) {
      int var49 = 1444939134 ^ 1930369680 ^ 2103744606;
      var49 = 649186881 ^ var49;
      if (var1 == null) {
         var49 = 854971338 ^ var49;
         String var7 = hafzltxhmk(qnwyiozwkpalste(), var49);
         return var7;
      } else {
         var49 = 1672522867 ^ var49;
         String var4 = hafzltxhmk(noxsmqqmqoixubq(), var49);
         byte var9 = var2.equalsIgnoreCase(var4);
         if (var9 != (491447682 ^ var49)) {
            var49 = 538493858 ^ var49;
            TeamService2 var10 = TeamService2.getInstance();
            UUID var38 = var1.getUniqueId();
            TeamService var11 = var10.getTeamByPlayer(var38);
            var49 = 1601414682 ^ var49;
            if (var11 == null) {
               var49 = 1288005864 ^ var49;
               String var13 = hafzltxhmk(bjoxzawfmmgbsvz(), var49);
               return var13;
            } else {
               var49 = uxapmkmrsxjdkjck(var49, 1963018181);
               String var15 = var11.getDisplayName();
               return var15;
            }
         } else {
            var49 = 1721436859 ^ var49;
            String var39 = hafzltxhmk(cphowukyybxngey(), var49);
            byte var17 = var2.equalsIgnoreCase(var39);
            if (var17 != (2077355833 ^ var49)) {
               var49 = 878909285 ^ var49;
               TeamService2 var18 = TeamService2.getInstance();
               UUID var41 = var1.getUniqueId();
               TeamService var19 = var18.getTeamByPlayer(var41);
               var49 = 1863082120 ^ var49;
               String var22;
               if (var19 != null) {
                  var49 = 1682946663 ^ var49;
                  var22 = var19.getName();
                  var49 = 1998074958 ^ var49;
               } else {
                  var49 = uxapmkmrsxjdkjck(var49, 400829218);
                  var22 = hafzltxhmk(jectpmzvrphtise(), var49);
                  var49 = 78882059 ^ var49;
               }

               return var22;
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var49)) {
                     case 266781871:
                        var49 ^= 810381387;
                     case 588810920:
                        String var42 = hafzltxhmk(rnbsbgicxovfszg(), var49);
                        byte var24 = var2.equalsIgnoreCase(var42);
                        if (var24 == (1268555634 ^ var49)) {
                           var49 = 462632969 ^ var49;
                           Object var25 = null;
                           return (String)var25;
                        }

                        var49 = 623244848 ^ var49;
                        TeamService2 var26 = TeamService2.getInstance();
                        UUID var44 = var1.getUniqueId();
                        TeamService var27 = var26.getTeamByPlayer(var44);
                        var49 = 996508757 ^ var49;
                        if (var27 == null) {
                           var49 = 402912328 ^ var49;
                           String var36 = hafzltxhmk(bgprnotpmeksxrn(), var49);
                           return var36;
                        }

                        var49 = 582713285 ^ var49;
                        UUID var30 = var27.getLeader();
                        OfflinePlayer var31 = Bukkit.getOfflinePlayer(var30);
                        var49 = 89112330 ^ var49;
                        String var33 = var31.getName();
                        String var35;
                        if (var33 != null) {
                           var49 = 1661160618 ^ var49;
                           var35 = var31.getName();
                           var49 = 1287058387 ^ var49;
                        } else {
                           var49 = 1161691749 ^ var49;
                           var35 = hafzltxhmk(jweqbpjcwqonuxs(), var49);
                           var49 = 1787542812 ^ var49;
                        }

                        return var35;
                     case 1273346929:
                     default:
                        throw new RuntimeException();
                     case 1466693102:
                  }
               }
            }
         }
      }
   }

   public String onPlaceholderRequest(Player var1, Player var2, String var3) {
      int var41;
      label102: {
         var41 = 1603776909 ^ 808384720 ^ 2103744606;
         var41 = 1930010263 ^ var41;
         String var11;
         TeamService var23;
         if (var1 != null) {
            var41 = 1455771444 ^ var41;
            if (var2 == null) {
               var41 = 625473662 ^ var41;
               break label102;
            }

            var41 = 143261837 ^ var41;
            var11 = this.getRelationshipColor(var1, var2);
            var41 = 178441956 ^ var41;
            String var29 = hafzltxhmk(eowpkpieymzweyd(), var41);
            byte var13 = var3.equalsIgnoreCase(var29);
            if (var13 != (892980937 ^ var41)) {
               var41 = 1763522608 ^ var41;
               return var11;
            }

            label65:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var41)) {
                  case 119551388:
                     var41 ^= 1966293771;
                     break label65;
                  case 498006433:
                  default:
                     throw new IllegalAccessException();
                  case 933736315:
                     break;
                  case 2012054944:
                     break label65;
               }
            }

            String var30 = hafzltxhmk(mlpsglgnowhnymj(), var41);
            byte var16 = var3.equalsIgnoreCase(var30);
            if (var16 != (1074433474 ^ var41)) {
               var41 = 157542311 ^ var41;
               String var32 = var2.getName();
               String var18 = var11 + var32;
               return var18;
            }

            label54:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var41)) {
                  case 202650285:
                     var41 ^= 1459879762;
                     break label54;
                  case 775844041:
                  default:
                     throw new IllegalAccessException();
                  case 853794968:
                     break label54;
                  case 1236551361:
               }
            }

            String var33 = hafzltxhmk(pphbfrgovoxwubv(), var41);
            byte var20 = var3.equalsIgnoreCase(var33);
            if (var20 == (386495120 ^ var41)) {
               var41 = 1045568387 ^ var41;
               Object var21 = null;
               return (String)var21;
            }

            var41 = 1563468940 ^ var41;
            TeamService2 var22 = TeamService2.getInstance();
            UUID var35 = var2.getUniqueId();
            var23 = var22.getTeamByPlayer(var35);
            var41 = 707188339 ^ var41;
            if (var23 == null) {
               var41 = 1122402230 ^ var41;
               String var25 = hafzltxhmk(iecdlgnviymyskq(), var41);
               return var25;
            }

            label44:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var41)) {
                  case 148761749:
                  default:
                     throw new IllegalAccessException();
                  case 171733192:
                     var41 = 1382762576 ^ var41;
                     break label44;
                  case 1224289629:
                     break;
                  case 2117078114:
                     break label44;
               }
            }
         } else {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var41)) {
                  case 182495874:
                     break;
                  case 227228666:
                     var41 ^= 1937946442;
                  case 1673246255:
                     break label102;
                  case 2061135068:
                  default:
                     throw new IllegalAccessException();
               }
            }
         }

         String var37 = var23.getDisplayName();
         String var27 = var11 + var37;
         return var27;
      }

      String var28 = hafzltxhmk(fgmpyoankbgzvdt(), var41);
      return var28;
   }

   private String getRelationshipColor(Player var1, Player var2) {
      int var48 = 1656271722 ^ 878672580 ^ 2103744606;
      var48 = 1938240719 ^ var48;
      TeamService2 var3 = TeamService2.getInstance();
      UUID var36 = var1.getUniqueId();
      TeamService var11 = var3.getTeamByPlayer(var36);
      var48 = 1824276845 ^ var48;
      TeamService2 var12 = TeamService2.getInstance();
      UUID var38 = var2.getUniqueId();
      TeamService var13 = var12.getTeamByPlayer(var38);
      var48 = 982254973 ^ var48;
      DonutSMPCore var14 = DonutSMPCore.getInstance();
      FileConfiguration var15 = var14.getConfig();
      String var39 = hafzltxhmk(ddizyvcrjftawbi(), var48);
      String var5 = hafzltxhmk(bsczclpmfsorlzg(), var48);
      String var16 = var15.getString(var39, var5);
      var48 = 23516996 ^ var48;
      DonutSMPCore var17 = DonutSMPCore.getInstance();
      FileConfiguration var18 = var17.getConfig();
      String var40 = hafzltxhmk(qgacyjlybdoyleu(), var48);
      String var44 = hafzltxhmk(engnsvsakgumxjr(), var48);
      String var19 = var18.getString(var40, var44);
      var48 = 832464857 ^ var48;
      DonutSMPCore var20 = DonutSMPCore.getInstance();
      FileConfiguration var21 = var20.getConfig();
      String var41 = hafzltxhmk(vckvwirxuxvvtdi(), var48);
      String var45 = hafzltxhmk(ozisjwnnnhcrplm(), var48);
      String var22 = var21.getString(var41, var45);
      var48 = 555470598 ^ var48;
      if (var13 == null) {
         var48 = 344465991 ^ var48;
         String var25 = oOo0KKoOoOK.color(var22);
         return var25;
      } else {
         var48 = 1218479745 ^ var48;
         if (var11 == null) {
            var48 = 1164282464 ^ var48;
            String var35 = oOo0KKoOoOK.color(var19);
            return var35;
         } else {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var48)) {
                  case 158885265:
                     var48 ^= 193076216;
                  case 809364038:
                     String var28 = var11.getName();
                     String var43 = var13.getName();
                     byte var29 = var28.equals(var43);
                     if (var29 != (1559610317 ^ var48)) {
                        var48 = 1359551663 ^ var48;
                        String var31 = oOo0KKoOoOK.color(var16);
                        return var31;
                     }

                     var48 = uxapmkmrsxjdkjck(var48, 992643888);
                     String var33 = oOo0KKoOoOK.color(var19);
                     return var33;
                  case 392732592:
                     break;
                  case 694618165:
                  default:
                     throw new IOException();
               }
            }
         }
      }
   }

   public static String hafzltxhmk(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = ujpdgowukc;
         byte[] var34 = ujpdgowukc;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   static {
      ujpdgowukc = zahbluvlpinhlrg();
   }

   private static byte[] zahbluvlpinhlrg() {
      return new byte[]{24, 46, 103, 28, 86, 17, 10, 16, 29};
   }

   private static byte[] ckiijcyquvvylxo() {
      return new byte[]{-44, -32, 84, 72, 97, 72, 51, 71, 46, 91, 28, 34, 47, 5, 38, 83, 41, 86, 43, 125};
   }

   private static byte[] hluofrqudonmsco() {
      return new byte[]{-41, -23, 86, 97, 103, 123, 60, 4, 41, 122, 31, 11, 45, 51, 32, 119, 38, 96, 44, 80, 86, 119};
   }

   private static byte[] ddctnhqgeehixsa() {
      return new byte[]{-45, -32, 86, 27, 96, 15, 61, 17};
   }

   private static byte[] qnwyiozwkpalste() {
      return new byte[0];
   }

   private static byte[] bjoxzawfmmgbsvz() {
      return new byte[]{-47, -23, 81, 101, 99, 13, 61, 101};
   }

   private static byte[] bgprnotpmeksxrn() {
      return new byte[]{-41, -30, 87, 100, 98, 8, 60, 103};
   }

   private static byte[] rnbsbgicxovfszg() {
      return new byte[]{-41, -29, 81, 80, 99, 65, 63, 71, 46, 65, 31, 10, 42, 2, 36, 90, 37, 74, 43, 126, 86, 75, 96, 91};
   }

   private static byte[] cphowukyybxngey() {
      return new byte[]{-44, -31, 80, 95, 101, 65, 63, 73, 46, 70, 28, 8, 43, 19, 34, 94, 37, 82};
   }

   private static byte[] noxsmqqmqoixubq() {
      return new byte[]{-46, -24, 86, 92, 98, 67, 60, 73, 47, 65};
   }

   private static byte[] jweqbpjcwqonuxs() {
      return new byte[]{-33, -29, 83, 123, 102, 79, 50, 66, 46, 79, 28, 60, 46, 17, 33, 92};
   }

   private static byte[] jectpmzvrphtise() {
      return new byte[]{-33, -29, 95, 68, 111, 79, 59, 71, 45, 68};
   }

   private static byte[] fgmpyoankbgzvdt() {
      return new byte[0];
   }

   private static byte[] mlpsglgnowhnymj() {
      return new byte[]{-41, -31, 80, 92, 98, 71, 57, 69, 42, 65};
   }

   private static byte[] pphbfrgovoxwubv() {
      return new byte[]{-43, -23, 81, 92, 111, 65, 59, 67, 45, 70, 22, 14, 40, 1, 36, 90, 34, 64, 43, 115};
   }

   private static byte[] iecdlgnviymyskq() {
      return new byte[]{-45, -23, 81, 101, 97, 8, 63, 98};
   }

   private static byte[] eowpkpieymzweyd() {
      return new byte[]{-34, -24, 85, 81, 110, 68, 51, 66, 42, 77, 23, 10, 37, 13, 33, 92, 35, 70, 32, 120, 85, 87};
   }

   private static byte[] ddizyvcrjftawbi() {
      return new byte[]{-44, -30, 95, 90, 111, 67, 57, 72, 44, 71, 29, 114, 46, 12, 38, 86, 41, 64, 42, 114, 95, 92, 111, 85, 57, 7, 44, 71, 29, 58, 46, 2, 38, 91, 41, 73, 42, 111};
   }

   private static byte[] bsczclpmfsorlzg() {
      return new byte[]{-44, -30, 95, 8, 111, 71};
   }

   private static byte[] qgacyjlybdoyleu() {
      return new byte[]{-44, -28, 80, 88, 111, 65, 56, 70, 40, 71, 27, 125, 44, 12, 36, 87, 39, 68, 42, 116, 80, 94, 111, 87, 56, 9, 40, 79, 27, 62, 44, 10, 36, 85, 39, 81};
   }

   private static byte[] engnsvsakgumxjr() {
      return new byte[]{-44, -28, 80, 10, 111, 71};
   }

   private static byte[] vckvwirxuxvvtdi() {
      return new byte[]{-41, -31, 82, 91, 99, 77, 62, 65, 46, 65, 31, 122, 41, 6, 36, 92, 36, 65, 43, 117, 86, 94, 99, 81, 63, 7, 41, 70, 29, 60, 45, 75, 36, 77, 37, 65, 44, 127, 84, 69};
   }

   private static byte[] ozisjwnnnhcrplm() {
      return new byte[]{-41, -31, 82, 9, 99, 31};
   }

   private static int uxapmkmrsxjdkjck(int var0, int var1) {
      return var1 ^ var0;
   }
}
