package org.mz.donutsmpcore.teams;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class TeamListener implements Listener {
   private static byte[] ahdvctnztq;

   @EventHandler
   public void onTeamDamage(EntityDamageByEntityEvent var1) {
      int var40 = 369763450 ^ 986180331 ^ 965845342;
      var40 = 1693720101 ^ var40;
      Entity var11 = var1.getEntity();
      var40 = 1644307820 ^ var40;
      byte var13 = var11 instanceof Player;
      if (var13 != (329929862 ^ var40)) {
         var40 = 1766441006 ^ var40;
         Player var15 = (Player)var11;
         var40 = 1982725384 ^ var40;
         Entity var17 = var1.getDamager();
         var40 = 758620124 ^ var40;
         byte var19 = var17 instanceof Player;
         if (var19 == (570029692 ^ var40)) {
            var40 = epsvtmzycrjoeacs(var40, 1983289384);
         } else {
            var40 = 598392978 ^ var40;
            Player var21 = (Player)var17;
            var40 = 448008229 ^ var40;
            TeamService2 var22 = TeamService2.getInstance();
            var40 = 2024826927 ^ var40;
            UUID var33 = var15.getUniqueId();
            TeamService var24 = var22.getTeamByPlayer(var33);
            var40 = 1526701447 ^ var40;
            UUID var35 = var21.getUniqueId();
            TeamService var26 = var22.getTeamByPlayer(var35);
            var40 = 750472565 ^ var40;
            if (var24 != null) {
               var40 = 956760719 ^ var40;
               byte var29 = var24.equals(var26);
               if (var29 == (789879961 ^ var40)) {
                  var40 = 2027680461 ^ var40;
               } else {
                  var40 = 511508101 ^ var40;
                  byte var31 = var24.isPvpEnabled();
                  if (var31 == (828924444 ^ var40)) {
                     var40 = 594622686 ^ var40;
                     byte var37 = (byte)(303651523 ^ var40);
                     var1.setCancelled((boolean)var37);
                     var40 = 1171666070 ^ var40;
                  } else {
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var40)) {
                           case 263851902:
                              var40 = 1722223688 ^ var40;
                              return;
                           case 1217160302:
                              return;
                           case 1576970557:
                           default:
                              throw new RuntimeException();
                           case 2049102545:
                        }
                     }
                  }
               }
            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var40)) {
                     case 169211685:
                        return;
                     case 180753497:
                        var40 = 1104998466 ^ var40;
                        return;
                     case 1161233917:
                     default:
                        throw new RuntimeException();
                     case 1942369086:
                  }
               }
            }
         }
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var40)) {
               case 102371433:
                  var40 = 1147484882 ^ var40;
                  return;
               case 1154170216:
                  return;
               case 2031348610:
               default:
                  throw new RuntimeException();
               case 2120738589:
            }
         }
      }
   }

   public static String tuwksahaus(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = ahdvctnztq;
         byte[] var34 = ahdvctnztq;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   static {
      ahdvctnztq = lvhpdnrwtqwvrpz();
   }

   private static byte[] lvhpdnrwtqwvrpz() {
      return new byte[]{45, 118, 69, 74, 113, 76, 3, 10, 73, 51, 36, 29, 55, 66, 98, 89, 68, 33, 116, 61, 8, 42, 118, 7, 93, 91, 56, 30, 125, 91, 29, 66, 48, 101, 40, 98, 8, 103, 105, 22, 111, 5, 14, 51, 123, 55, 34, 118, 71, 5, 124, 61, 89, 20, 123, 80, 35, 90, 33, 35, 10, 70, 30, 81, 47, 71, 69, 60, 74, 50, 43, 7, 108, 49, 3, 13, 22, 40, 78, 99, 51, 81, 93, 55, 65, 105, 27, 107, 65, 109, 6, 92, 61, 37, 29, 105, 8, 51, 97, 39, 105, 63, 73, 100, 41, 76, 48, 118, 1, 35, 11, 111, 88, 80, 31, 52, 11};
   }

   private static int epsvtmzycrjoeacs(int var0, int var1) {
      return var0 ^ var1;
   }
}
