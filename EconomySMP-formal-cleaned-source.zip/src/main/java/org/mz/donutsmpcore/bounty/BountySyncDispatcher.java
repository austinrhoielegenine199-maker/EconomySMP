package org.mz.donutsmpcore.bounty;

import java.util.UUID;

public interface BountySyncDispatcher {
   void publishBountyChanged(UUID var1, String var2, double var3, String var5, double var6);

   void publishBountyKill(String var1, String var2, double var3);
}
