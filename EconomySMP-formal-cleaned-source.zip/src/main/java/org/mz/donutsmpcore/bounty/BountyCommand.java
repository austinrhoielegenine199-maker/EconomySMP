package org.mz.donutsmpcore.bounty;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.mz.donutsmpcore.crossserver.CrossServerPlayerTracker;

public class BountyCommand implements CommandExecutor, TabCompleter {

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
   }

   private double parseFormattedAmount(String var1) throws NumberFormatException {
      int var69 = 1690217387 ^ 737860925 ^ 1072436901;
      var69 = 1396085929 ^ var69;
      String var8 = var1.toUpperCase();
      String var3 = ecdmgvxvkj(wxbzjqzplcdxiyj(), xizccefxpebvtre(), var69);
      String var4 = ecdmgvxvkj(obgmzibvjoggbww(), xizccefxpebvtre(), var69);
      String var9 = var8.replace(var3, var4);
      String var66 = var9;
      var69 = 854551364 ^ var69;
      double var10 = (double)1.0F;
      double var6 = var10;
      var69 = 1653104399 ^ var69;
      String var41 = ecdmgvxvkj(njamwjlvjoxattu(), xizccefxpebvtre(), var69);
      byte var13 = var9.endsWith(var41);
      if (var13 == (1945747665 ^ var69)) {
         var69 = yidypksadyndycxb(var69, 1112923203);
         String var42 = ecdmgvxvkj(gbqmhwvuajsfrco(), xizccefxpebvtre(), var69);
         byte var15 = var9.endsWith(var42);
         if (var15 != (833363090 ^ var69)) {
            var69 = 504837629 ^ var69;
            double var16 = (double)1000000.0F;
            var6 = var16;
            var69 = 85951138 ^ var69;
            byte var43 = (byte)(715434957 ^ var69);
            int var50 = var9.length();
            byte var5 = (byte)(715434956 ^ var69);
            int var51 = var50 - var5;
            String var19 = var9.substring(var43, var51);
            var66 = var19;
            var69 = 1719604083 ^ var69;
         } else {
            var69 = yidypksadyndycxb(var69, 443182466);
            String var44 = ecdmgvxvkj(iyaarnuvbcaxmej(), xizccefxpebvtre(), var69);
            byte var26 = var9.endsWith(var44);
            if (var26 != (734425360 ^ var69)) {
               var69 = 268412144 ^ var69;
               double var27 = (double)1.0E9F;
               var6 = var27;
               var69 = 495093685 ^ var69;
               byte var45 = (byte)(968577621 ^ var69);
               int var55 = var9.length();
               byte var63 = (byte)(968577620 ^ var69);
               int var56 = var55 - var63;
               String var30 = var9.substring(var45, var56);
               var66 = var30;

               label36:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var69)) {
                     case 265999935:
                        var69 = 1969285867 ^ var69;
                        break label36;
                     case 503479221:
                     default:
                        throw new IllegalAccessException();
                     case 538989289:
                        break;
                     case 1692199131:
                        break label36;
                  }
               }
            } else {
               var69 = yidypksadyndycxb(var69, 1614244900);
               String var46 = ecdmgvxvkj(yrfbxmlpwhnffid(), xizccefxpebvtre(), var69);
               byte var32 = var9.endsWith(var46);
               if (var32 != (1274092852 ^ var69)) {
                  var69 = 194073482 ^ var69;
                  double var33 = 1.0E12;
                  var6 = var33;
                  var69 = 1412786684 ^ var69;
                  byte var47 = (byte)(341124930 ^ var69);
                  int var58 = var9.length();
                  byte var64 = (byte)(341124931 ^ var69);
                  int var59 = var58 - var64;
                  String var36 = var9.substring(var47, var59);
                  var66 = var36;
                  var69 = 1485742076 ^ var69;
               } else {
                  label52:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var69)) {
                        case 52650853:
                           var69 = 120235402 ^ var69;
                           break label52;
                        case 99531490:
                           break;
                        case 416771699:
                        default:
                           throw new IllegalAccessException();
                        case 1178968965:
                           break label52;
                     }
                  }
               }
            }
         }
      } else {
         var69 = 1224510677 ^ var69;
         double var37 = (double)1000.0F;
         var6 = var37;
         var69 = 864185975 ^ var69;
         byte var48 = (byte)(143073907 ^ var69);
         int var61 = var9.length();
         byte var65 = (byte)(143073906 ^ var69);
         int var62 = var61 - var65;
         String var40 = var9.substring(var48, var62);
         var66 = var40;

         label69:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var69)) {
               case 8772153:
                  var69 = 1146919629 ^ var69;
               case 232877169:
                  break label69;
               case 719181496:
                  break;
               case 1602864734:
               default:
                  throw new IllegalAccessException();
            }
         }
      }

      double var21 = Double.parseDouble(var66);
      double var23 = var21 * var6;
      return var23;
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      int var57 = 799316269 ^ 817817978 ^ 1072436901;
      var57 = 359157641 ^ var57;
      byte var10 = var1 instanceof Player;
      if (var10 == (899557755 ^ var57)) {
         var57 = 70427617 ^ var57;
         List var11 = Collections.emptyList();
         return var11;
      } else {
         var57 = 1258213032 ^ var57;
         int var13 = var4.length;
         byte var6 = (byte)(2137057234 ^ var57);
         if (var13 == var6) {
            var57 = 153394865 ^ var57;
            ArrayList var30 = new ArrayList();
            var57 = 364882449 ^ var57;
            String var48 = ecdmgvxvkj(uvbtnikdyebsdod(), xizccefxpebvtre(), var57);
            var30.add(var48);
            var57 = 1084362248 ^ var57;
            List var49 = networkNames();
            var30.addAll(var49);
            var57 = 563741213 ^ var57;
            byte var54 = (byte)(46391142 ^ var57);
            String var51 = var4[var54];
            List var36 = match(var30, var51);
            return var36;
         } else {
            var57 = 176945357 ^ var57;
            int var15 = var4.length;
            byte var37 = (byte)(1978343196 ^ var57);
            if (var15 == var37) {
               var57 = 1525737554 ^ var57;
               byte var38 = (byte)(790361932 ^ var57);
               String var17 = var4[var38];
               String var39 = ecdmgvxvkj(tmdtbwmpphtztaz(), xizccefxpebvtre(), var57);
               byte var18 = var17.equalsIgnoreCase(var39);
               if (var18 != (790361932 ^ var57)) {
                  var57 = 1235697196 ^ var57;
                  List var19 = networkNames();
                  byte var7 = (byte)(1723648353 ^ var57);
                  String var41 = var4[var7];
                  List var20 = match(var19, var41);
                  return var20;
               }

               var57 = 150011938 ^ var57;
            } else {
               label62:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var57)) {
                     case 74971553:
                        var57 ^= 1375856752;
                     case 187152138:
                        break label62;
                     case 339690474:
                        break;
                     case 734741876:
                     default:
                        throw new IOException();
                  }
               }
            }

            int var22 = var4.length;
            byte var42 = (byte)(669710189 ^ var57);
            if (var22 == var42) {
               var57 = 1010018685 ^ var57;
               byte var43 = (byte)(467230227 ^ var57);
               String var24 = var4[var43];
               String var44 = ecdmgvxvkj(vbleavxlhsayqki(), xizccefxpebvtre(), var57);
               byte var25 = var24.equalsIgnoreCase(var44);
               if (var25 != (467230227 ^ var57)) {
                  var57 = 1738042952 ^ var57;
                  String var26 = ecdmgvxvkj(fjqxpocddabclze(), xizccefxpebvtre(), var57);
                  String var45 = ecdmgvxvkj(iebqfbreyolnccd(), xizccefxpebvtre(), var57);
                  String var52 = ecdmgvxvkj(tbfuvjooupznfzs(), xizccefxpebvtre(), var57);
                  String var8 = ecdmgvxvkj(lrsluqveyadinjx(), xizccefxpebvtre(), var57);
                  List var27 = List.of(var26, var45, var52, var8);
                  byte var53 = (byte)(2084647001 ^ var57);
                  String var47 = var4[var53];
                  List var28 = match(var27, var47);
                  return var28;
               }

               label38:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var57)) {
                     case 99958173:
                        var57 = 287880764 ^ var57;
                        break label38;
                     case 263930561:
                        break;
                     case 1031219105:
                     default:
                        throw new IOException();
                     case 1875123226:
                        break label38;
                  }
               }
            } else {
               label51:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var57)) {
                     case 204731123:
                        break label51;
                     case 223811727:
                        var57 = 756752193 ^ var57;
                        break label51;
                     case 842502151:
                        break;
                     case 1590327007:
                     default:
                        throw new IOException();
                  }
               }
            }

            List var29 = Collections.emptyList();
            return var29;
         }
      }
   }

   private static List<String> networkNames() {
      int var33 = 138059123 ^ 263212856 ^ 96993339;
      var33 = 779922326 ^ var33;
      LinkedHashSet var0 = new LinkedHashSet();
      LinkedHashSet var2 = var0;
      var33 = 637512025 ^ var33;
      Collection var5 = Bukkit.getOnlinePlayers();
      Iterator var6 = var5.iterator();
      Iterator var3 = var6;
      var33 = 1383814700 ^ var33;

      while(true) {
         byte var8 = var3.hasNext();
         if (var8 == (1538950803 ^ var33)) {
            label114: {
               label85:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var33)) {
                     case 28917510:
                        var33 ^= 1073102436;
                        break;
                     case 958507933:
                        continue;
                     case 1712360423:
                        break;
                     case 1798589759:
                     default:
                        throw new IOException();
                  }

                  label82: {
                     label98: {
                        try {
                           CrossServerPlayerTracker var14 = CrossServerPlayerTracker.getInstance();
                           var33 = 1941548770 ^ var33;
                           if (var14 != null) {
                              var33 = 405564717 ^ var33;
                              byte var17 = var14.isConnected();
                              if (var17 == (265911096 ^ var33)) {
                                 break label82;
                              }

                              var33 = 1354482800 ^ var33;
                              List var19 = var14.getAllOnlineNames();
                              var33 = 727195709 ^ var33;
                              if (var19 != null) {
                                 var33 = 131442751 ^ var33;
                                 var2.addAll(var19);
                                 var33 = 139967889 ^ var33;
                                 break;
                              }
                              break label98;
                           }
                        } catch (Throwable var34) {
                           switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var33)) {
                              case -1619412397 -> var33 = yidypksadyndycxb(var33, 1609765355);
                              case -1579877461 -> var33 = 1478932948 ^ var33;
                              case -1079463768 -> var33 = 1005138100 ^ var33;
                              case -82445758 -> var33 = 1937676777 ^ var33;
                              case 577095611 -> var33 = yidypksadyndycxb(var33, 1213242966);
                              case 2127288768 -> var33 = yidypksadyndycxb(var33, 600137113);
                              default -> throw new IllegalAccessException("Error in hash");
                           }

                           var33 = 1869819587 ^ var33;
                           break label114;
                        }

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var33)) {
                              case 241880381:
                                 var33 ^= 1817025742;
                                 break label85;
                              case 1895463848:
                                 break;
                              case 1911795841:
                              default:
                                 throw new IOException();
                              case 2049963602:
                                 break label85;
                           }
                        }
                     }

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var33)) {
                           case 20046024:
                              var33 ^= 260183470;
                           case 267475044:
                              break label85;
                           case 991428662:
                           default:
                              throw new IOException();
                           case 2010343010:
                        }
                     }
                  }

                  var33 = 1952575971 ^ var33;
                  break;
               }

               var33 = yidypksadyndycxb(var33, 953647801);
            }

            ArrayList var23 = new ArrayList(var2);
            return var23;
         }

         var33 = 870074027 ^ var33;
         Object var10 = var3.next();
         Player var11 = (Player)var10;
         var33 = 1631839709 ^ var33;
         String var26 = var11.getName();
         boolean var13 = var2.add(var26);
         var33 = 64333935 ^ var33;
         var33 = yidypksadyndycxb(var33, 1363807001);
      }
   }

   private static List<String> match(List<String> var0, String var1) {
      int var27 = 52662011 ^ 701437233 ^ 96993339;
      var27 = 1533464352 ^ var27;
      String var8;
      if (var1 == null) {
         var27 = 859279484 ^ var27;
         var8 = ecdmgvxvkj(rioafomgfwfzkfb(), xizccefxpebvtre(), var27);

         label72:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var27)) {
               case 175401594:
                  var27 ^= 233272107;
                  break label72;
               case 764769622:
               default:
                  throw new IOException();
               case 846160633:
                  break label72;
               case 964673978:
            }
         }
      } else {
         label62:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var27)) {
               case 21032982:
                  var27 ^= 497556558;
               case 700517014:
                  break label62;
               case 920549781:
               default:
                  throw new IOException();
               case 1438296950:
            }
         }

         var8 = var1.toLowerCase();
         var27 = 595132185 ^ var27;
      }

      String var3 = var8;
      var27 = 812706898 ^ var27;
      ArrayList var9 = new ArrayList();
      ArrayList var4 = var9;
      var27 = 450654844 ^ var27;
      Iterator var11 = var0.iterator();
      Iterator var5 = var11;
      var27 = 1914381862 ^ var27;

      while(true) {
         byte var13 = var5.hasNext();
         if (var13 == (304418702 ^ var27)) {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var27)) {
                  case 18066215:
                     break;
                  case 52943878:
                     var27 = 217673060 ^ var27;
                     return var4;
                  case 962955695:
                     return var4;
                  case 1701986026:
                  default:
                     throw new IOException();
               }
            }
         }

         var27 = 1550411306 ^ var27;
         Object var16 = var5.next();
         String var17 = (String)var16;
         var27 = 1095576824 ^ var27;
         String var19 = var17.toLowerCase();
         byte var20 = var19.startsWith(var3);
         if (var20 != (251741532 ^ var27)) {
            var27 = 1267284080 ^ var27;
            var4.add(var17);
            var27 = 799007679 ^ var27;
         } else {
            label48:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var27)) {
                  case 219314531:
                     var27 ^= 1679219663;
                     break label48;
                  case 666455157:
                  default:
                     throw new IOException();
                  case 766312279:
                     break;
                  case 1767843268:
                     break label48;
               }
            }
         }

         var27 = yidypksadyndycxb(var27, 2033357085);
      }
   }

   public static String ecdmgvxvkj(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] xizccefxpebvtre() {
      return new byte[]{53, 44, 39, 116, 19, 10, 108, 55, 72, 26, 25, 12, 12, 57, 64, 87, 48, 20, 106, 7, 111, 52, 72, 79, 16, 79, 17, 92, 121, 119, 14, 104, 90, 52, 105, 84, 25, 71, 112, 79, 97, 38, 29, 113, 26, 10, 73, 87, 19, 60, 7, 121, 15, 84, 127, 73, 98, 59, 18, 31, 73, 19, 70, 118, 34, 26, 19, 18, 91, 10};
   }

   private static byte[] rioafomgfwfzkfb() {
      return new byte[0];
   }

   private static byte[] phturvtqeydukvj() {
      return new byte[]{-14, -27, 23, 47, 33, 93, 90, 113, 123, 77, 47, 72, 53, 114, 120, 79, 3, 70, 83, 92, 95, 98, 122, 2, 38, 18, 34, 17, 79, 106, 55, 32, 98, 103, 90, 21, 32, 30};
   }

   private static byte[] dzwaymfzontcegp() {
      return new byte[]{-6, -21, 30, 46, 37, 81, 84, 114, 120, 67, 40, 64, 53, 120, 118, 77, 8, 87, 90, 85, 94, 96, 113, 17, 38, 86, 41, 14, 73, 47, 63, 37, 99, 98, 95, 20, 33, 14};
   }

   private static byte[] xdvevkocjerotbv() {
      return new byte[]{-6, -21, 21, 37, 36, 93, 95, 106};
   }

   private static byte[] klugjbvyastkmbl() {
      return new byte[]{-4, -21, 16, 33, 39, 88, 89, 107, 127, 72, 33, 73, 62, 108, 119, 14, 2, 13, 93, 86, 88, 104, 124, 14, 37, 28, 38, 7, 65, 41, 60, 56, 109, 44, 91, 19, 46, 19, 71, 28, 85, 104, 40, 38, 45, 79};
   }

   private static byte[] vzlvzfjovjvqxxc() {
      return new byte[]{-6, -29, 23, 37, 36, 92, 90, 122, 124, 70, 40, 72, 60, 115, 119, 64, 6, 69, 94, 91, 94, 114, 120, 29, 39, 26, 39, 13, 77, 33, 63, 117, 106, 102, 94, 0, 47, 16, 68, 8, 80, 120, 45, 54};
   }

   private static byte[] utfdydznmeplekn() {
      return new byte[]{-7, -30, 21, 34, 34, 84, 89, 112, 121, 67, 43, 73, 62, 116, 113, 72, 5, 72, 91, 95, 93, 40, 122, 25, 33, 17, 36, 27, 72, 46, 60, 45, 104, 121};
   }

   private static byte[] daqjliicplrbxyi() {
      return new byte[]{-6, -25, 30, 46, 42, 85, 95, 118, 122, 76, 40, 76, 53, 120, 121, 73, 3, 85, 88, 76, 94, 97, 113, 16, 41, 26};
   }

   private static byte[] ofzvqcsevyumfiz() {
      return new byte[]{-13, -26, 18, 36, 34, 86, 90, 107, 126, 71, 44, 75, 59, 105, 121, 13, 2, 12, 82, 91, 90, 109, 121, 0, 38, 28, 39, 8, 76, 43, 57, 61, 99, 47, 91, 18, 33, 30, 69, 25, 80, 102, 43, 38, 44, 64};
   }

   private static byte[] zbagszggpflitks() {
      return new byte[]{-7, -30, 23, 102, 33, 88, 84, 78, 123, 67, 43, 81, 60, 116, 114, 70, 8, 82, 89, 92, 93, 100, 120, 2, 34, 27, 41, 24, 74, 51, 60, 121, 106, 99, 91, 4, 33, 31, 67, 88, 83, 98, 45, 54, 40, 94, 113, 65, 32, 127, 53, 32, 63, 9, 77, 11, 90, 45, 33, 75, 123, 77, 118, 47, 16, 70, 43, 69, 104, 83, 7, 121, 23, 97};
   }

   private static byte[] lepdcwkidylpvlf() {
      return new byte[]{-6, -31, 17, 33, 36, 84, 91, 114, 121, 71, 40, 74, 58, 119, 119, 72, 7, 72, 91, 91, 94, 105, 126, 19, 39, 11, 38, 28};
   }

   private static byte[] icyjphycoepdelm() {
      return new byte[]{-6, -31, 17, 96, 36, 11, 91, 55, 121, 104, 40, 8, 58, 72, 119, 32, 7, 1, 91, 68, 94, 106, 126, 25, 39, 7, 38, 9, 72, 54, 63, 127, 108, 35, 94, 70, 46, 54, 65, 61, 80, 85, 43, 7, 45, 122, 126, 38, 34, 103, 54, 42, 57, 16, 72, 88, 85, 106, 35, 12, 120, 67, 112, 46, 21, 94, 36, 76, 106, 77, 4, 103, 17, 99, 36, 84, 91, 97, 121, 9, 40, 29, 58, 72, 119, 32, 7, 20, 91, 4, 94, 54, 126, 72, 39, 91, 38, 13, 72, 41, 63, 53, 108, 118, 94, 11, 46, 3, 65, 89, 80, 55, 43, 7, 45, 122, 126, 38, 34, 78, 54, 10, 57, 34, 72, 86};
   }

   private static byte[] geobycfwuurchck() {
      return new byte[]{-6, -31, 17, 102, 36, 75, 91, 107, 121, 72, 40, 71, 58, 107, 119, 20, 7, 1};
   }

   private static byte[] ogyxshnvjrciyhe() {
      return new byte[]{-6, -31, 17, 102, 36, 90, 91, 106, 121, 70, 40, 75, 58, 96, 119, 18, 7, 1};
   }

   private static byte[] mxgattjoxggqfuk() {
      return new byte[]{-6, -29, 17, 35, 38, 93, 92, 122, 112, 65, 40, 72, 58, 117, 117, 65, 0, 64, 82, 93, 94, 107, 126, 17, 37, 2, 33, 20, 65, 111, 63, 57, 108, 98, 92, 24, 41, 22, 72, 21, 80, 120, 43, 38, 47, 83, 121, 29};
   }

   private static byte[] vfkzljmyatgqker() {
      return new byte[]{-6, -29, 17, 98, 38, 2, 92, 63, 112, 110, 40, 10, 58, 74, 117, 41, 0, 9, 82, 66, 94, 104, 126, 27, 37, 14, 33, 1, 65, 48, 63, 125, 108, 33, 92, 79, 41, 62, 72, 59, 80, 87, 43, 5, 47, 115, 121, 46, 43, 97, 54, 40, 57, 18, 74, 81, 82, 98, 42, 10, 120, 65, 112, 44, 23, 87, 35, 68, 99, 75, 4, 101, 17, 97, 38, 93, 92, 105, 112, 15, 40, 31, 58, 74, 117, 41, 0, 28, 82, 2, 94, 52, 126, 74, 37, 82, 33, 5, 65, 47, 63, 55, 108, 116, 92, 2, 41, 11, 72, 95, 80, 53, 43, 5, 47, 115, 121, 46, 43, 72, 54, 8, 57, 32, 74, 95};
   }

   private static byte[] izpqpxjlfinbumg() {
      return new byte[]{-6, -29, 17, 100, 38, 66, 92, 99, 112, 78, 40, 69, 58, 105, 117, 29, 0, 9};
   }

   private static byte[] friobptqogowofn() {
      return new byte[]{-6, -29, 17, 100, 38, 83, 92, 98, 112, 64, 40, 73, 58, 98, 117, 27, 0, 9};
   }

   private static byte[] gbqmhwvuajsfrco() {
      return new byte[]{-13, -32, 20, 10};
   }

   private static byte[] yrfbxmlpwhnffid() {
      return new byte[]{-6, -31, 16, 20};
   }

   private static byte[] wxbzjqzplcdxiyj() {
      return new byte[]{-2, -22, 16, 110};
   }

   private static byte[] obgmzibvjoggbww() {
      return new byte[0];
   }

   private static byte[] njamwjlvjoxattu() {
      return new byte[]{-6, -22, 19, 10};
   }

   private static byte[] iyaarnuvbcaxmej() {
      return new byte[]{-4, -32, 19, 2};
   }

   private static byte[] tmdtbwmpphtztaz() {
      return new byte[]{-4, -22, 23, 38, 37, 95, 85, 96};
   }

   private static byte[] uvbtnikdyebsdod() {
      return new byte[]{-6, -27, 16, 34, 39, 90, 84, 99};
   }

   private static byte[] vbleavxlhsayqki() {
      return new byte[]{-1, -27, 16, 39, 32, 94, 94, 97};
   }

   private static byte[] fjqxpocddabclze() {
      return new byte[]{-7, -29, 31, 113, 37, 14, 91, 55};
   }

   private static byte[] iebqfbreyolnccd() {
      return new byte[]{-7, -29, 31, 113, 37, 14, 91, 55, 120, 25};
   }

   private static byte[] tbfuvjooupznfzs() {
      return new byte[]{-7, -29, 31, 113, 37, 14, 91, 55, 120, 25, 43, 12};
   }

   private static byte[] lrsluqveyadinjx() {
      return new byte[]{-7, -29, 31, 113, 37, 14, 91, 55, 120, 25, 43, 12, 52, 61};
   }

   private static int yidypksadyndycxb(int var0, int var1) {
      return var1 ^ var0;
   }

   static {
   }
}
