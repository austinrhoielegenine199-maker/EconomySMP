package org.mz.donutsmpcore.bounty;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.mz.donutsmpcore.DonutSMPCore;
import org.mz.donutsmpcore.libs.signgui.SignGUI;
import org.mz.donutsmpcore.libs.signgui.SignGUIBuilder;
import org.mz.donutsmpcore.libs.signgui.SignGUIFinishHandler;
import skido.KKo0KoOoOK;
import skido.KKoOoOo0oOK;
import skido.KoOKKo0K;
import skido.KoOo0Ko0oOK;
import skido.o0KoOKKo0K;
import skido.o0KoOo0KoOK;
import skido.o0KoOo0o0oOK;
import skido.o0oOKKoOoOK;
import skido.o0oOKo0oOK;
import skido.oOo0KKoOoOK;

public class BountyGUI extends KoOKKo0K {
   private int page;
   private K sortType;
   private String searchQuery;
   private List<o0oOoOKoOoOK.K> currentBounties;
   private static final o0KoOo0o0oOK GUI;
   private static final List<Integer> DEFAULT_CONTENT;

   public BountyGUI(Player var1) {
      o0KoOo0o0oOK var4 = GUI;
      byte var5 = 54;
      int var17 = var4.size(var5);
      o0KoOo0o0oOK var18 = GUI;
      String var6 = "ʙᴏᴜɴᴛɪᴇꜱ (Page %page%)";
      byte var7 = 2;
      Object[] var20 = new Object[var7];
      byte var8 = 0;
      String var9 = "%page%";
      var20[var8] = var9;
      byte var21 = 1;
      String var22 = "1";
      var20[var21] = var22;
      String var19 = var18.title(var6, var20);
      super(var1, var17, var19);
      byte var14 = 0;
      this.page = var14;
      K var15 = BountyGUI.K.AMOUNT;
      this.sortType = var15;
      Object var16 = null;
      this.searchQuery = (String)var16;
      this.loadBounties();
   }

   public BountyGUI(Player var1, int var2, K var3, String var4) {
      o0KoOo0o0oOK var7 = GUI;
      byte var8 = 54;
      int var27 = var7.size(var8);
      o0KoOo0o0oOK var28 = GUI;
      String var9 = "ʙᴏᴜɴᴛɪᴇꜱ (Page %page%)";
      byte var10 = 2;
      Object[] var30 = new Object[var10];
      byte var11 = 0;
      String var12 = "%page%";
      var30[var11] = var12;
      byte var31 = 1;
      byte var13 = 1;
      int var33 = var2 + var13;
      String var34 = String.valueOf(var33);
      var30[var31] = var34;
      String var29 = var28.title(var9, var30);
      super(var1, var27, var29);
      byte var21 = 0;
      this.page = var21;
      K var22 = BountyGUI.K.AMOUNT;
      this.sortType = var22;
      Object var23 = null;
      this.searchQuery = (String)var23;
      this.page = var2;
      this.sortType = var3;
      this.searchQuery = var4;
      this.loadBounties();
   }

   private void loadBounties() {
      int var22 = 1842210139 ^ 1575012094 ^ 2038154;
      var22 = 308503908 ^ var22;
      String var4 = this.searchQuery;
      if (var4 != null) {
         var22 = 1691262510 ^ var22;
         String var6 = this.searchQuery;
         byte var7 = var6.isEmpty();
         if (var7 == (1184874853 ^ var22)) {
            var22 = 1666954716 ^ var22;
            o0oOoOKoOoOK var2 = o0oOoOKoOoOK.getInstance();
            String var19 = this.searchQuery;
            List var13 = var2.searchBounties(var19);
            this.currentBounties = var13;

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var22)) {
                  case 153913314:
                     var22 = 175476777 ^ var22;
                     return;
                  case 484301473:
                     break;
                  case 1804113694:
                  default:
                     throw new IllegalAccessException();
                  case 1956721993:
                     return;
               }
            }
         }

         var22 = 585842457 ^ var22;
      } else {
         var22 = 1176871223 ^ var22;
      }

      K var10 = this.sortType;
      K var14 = BountyGUI.K.RECENT;
      if (var10 != var14) {
         var22 = brerezurgfltkvqm(var22, 287259793);
         o0oOoOKoOoOK var15 = o0oOoOKoOoOK.getInstance();
         List var16 = var15.getBountiesSortedByAmount();
         this.currentBounties = var16;
         var22 = 1524246141 ^ var22;
      } else {
         var22 = 1964982388 ^ var22;
         o0oOoOKoOoOK var17 = o0oOoOKoOoOK.getInstance();
         List var18 = var17.getBountiesSortedByRecent();
         this.currentBounties = var18;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var22)) {
               case 29413700:
                  var22 = 1054497432 ^ var22;
                  return;
               case 773324424:
                  return;
               case 814902544:
               default:
                  throw new IllegalAccessException();
               case 1043259516:
            }
         }
      }
   }

   public void decorate() {
      int var267 = 226303474 ^ 1023919731 ^ 2038154;
      var267 = 260768754 ^ var267;
      ArrayList var1 = new ArrayList();
      ArrayList var9 = var1;
      var267 = 340534936 ^ var267;
      o0KoOo0o0oOK var19 = GUI;
      String var106 = cvgptbzqfg(oqazfvkbgpmzwqt(), zvoxrnzkiwzsetj(), var267);
      List var2 = DEFAULT_CONTENT;
      List var20 = var19.slots(var106, var2);
      Iterator var21 = var20.iterator();
      Iterator var10 = var21;
      var267 = 1869512198 ^ var267;

      while(true) {
         byte var23 = var10.hasNext();
         if (var23 == (1154259303 ^ var267)) {
            var267 = 1038095299 ^ var267;
            byte var24 = (byte)(2032962213 ^ var267);
            int var108 = var9.size();
            int var25 = Math.max(var24, var108);
            var267 = 703325259 ^ var267;
            int var27 = this.page;
            int var28 = var27 * var25;
            int var11 = var28;
            var267 = 1684849858 ^ var267;
            int var111 = var9.size();
            int var30 = var28 + var111;
            List var113 = this.currentBounties;
            int var114 = var113.size();
            int var31 = Math.min(var30, var114);
            int var12 = var31;
            var267 = 2040806754 ^ var267;
            int var13 = var28;
            var267 = 328881975 ^ var267;

            label132:
            while(true) {
               if (var13 < var12) {
                  var267 = 181674169 ^ var267;
                  int var135 = var13 - var11;
                  Object var78 = var9.get(var135);
                  Integer var79 = (Integer)var78;
                  int var80 = var79;
                  var267 = 1968271663 ^ var267;
                  List var82 = this.currentBounties;
                  Object var83 = var82.get(var13);
                  o0oOoOKoOoOK.K var84 = (o0oOoOKoOoOK.K)var83;
                  var267 = 466213921 ^ var267;
                  Material var167 = Material.PLAYER_HEAD;
                  ItemStack var85 = new ItemStack(var167);
                  ItemStack var263 = var85;
                  var267 = 1118092785 ^ var267;
                  ItemMeta var87 = var85.getItemMeta();
                  SkullMeta var88 = (SkullMeta)var87;
                  var267 = 1826854026 ^ var267;
                  if (var88 != null) {
                     var267 = 512247321 ^ var267;
                     o0oOKo0oOK var90 = o0oOKo0oOK.getInstance();
                     UUID var169 = var84.getUuid();
                     var90.apply(var88, var169);
                     var267 = 1332267846 ^ var267;
                     var85.setItemMeta(var88);
                     var267 = 1031001060 ^ var267;
                     o0KoOo0o0oOK var93 = GUI;
                     String var170 = cvgptbzqfg(zzoldywzbwecuxd(), zvoxrnzkiwzsetj(), var267);
                     String var196 = cvgptbzqfg(hpxyjbhfvuqgqko(), zvoxrnzkiwzsetj(), var267);
                     String var218 = cvgptbzqfg(iacybpwyftfvjmy(), zvoxrnzkiwzsetj(), var267);
                     List var219 = List.of(var218);
                     byte var227 = (byte)(2014132747 ^ var267);
                     Object[] var228 = new Object[var227];
                     byte var241 = (byte)(2014132751 ^ var267);
                     String var248 = cvgptbzqfg(ryarrhaqoiohsor(), zvoxrnzkiwzsetj(), var267);
                     var228[var241] = var248;
                     byte var242 = (byte)(2014132750 ^ var267);
                     var267 = 184360103 ^ var267;
                     String var250 = var84.getPlayerName();
                     String var251 = String.valueOf(var250);
                     var228[var242] = var251;
                     byte var243 = (byte)(1928341162 ^ var267);
                     String var252 = cvgptbzqfg(agolubabgjazdke(), zvoxrnzkiwzsetj(), var267);
                     var228[var243] = var252;
                     byte var244 = (byte)(1928341163 ^ var267);
                     double var254 = var84.getAmount();
                     String var256 = oOo0KKoOoOK.formatPrice(var254);
                     var228[var244] = var256;
                     var267 = 1995583257 ^ var267;
                     ItemStack var94 = var93.apply(var85, var170, var196, var219, var228);
                     var263 = var94;
                     var267 = 2001275840 ^ var267;
                  } else {
                     var267 = 1742038725 ^ var267;
                  }

                  o0KoOKKo0K var171 = new o0KoOKKo0K();
                  o0KoOKKo0K var172 = var171.item(var263);
                  Consumer var199 = (var1x) -> {
                     int var12 = 701188228 ^ 109741265 ^ 2038154;
                     var12 = 500569780 ^ var12;
                     byte var3 = (byte)(847823722 ^ var12);
                     var1x.setCancelled((boolean)var3);
                     var12 = 870450696 ^ var12;
                     Player var8 = this.player;
                     String var9 = cvgptbzqfg(xarbjhexrmyepho(), zvoxrnzkiwzsetj(), var12);
                     Sound var4 = Sound.UI_BUTTON_CLICK;
                     float var5 = 1.0F;
                     float var6 = 1.0F;
                     KKo0KoOoOK.play(var8, var9, var4, var5, var6);
                     var12 = 290359916 ^ var12;
                  };
                  o0KoOKKo0K var173 = var172.consumer(var199);
                  this.addButton(var80, var173);
                  var267 = 454311720 ^ var267;
                  var13 += 1751072088 ^ var267;

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var267)) {
                        case 10080589:
                           continue label132;
                        case 171503235:
                           var267 ^= 919272737;
                           continue label132;
                        case 1169550850:
                           break;
                        case 1265305715:
                        default:
                           throw new RuntimeException();
                     }
                  }
               }

               var267 = brerezurgfltkvqm(var267, 698510210);
               List var35 = this.currentBounties;
               int var36 = var35.size();
               double var37 = (double)var36;
               double var147 = (double)var25;
               double var39 = var37 / var147;
               double var41 = Math.ceil(var39);
               int var43 = (int)var41;
               var267 = 1502863593 ^ var267;
               K var45 = this.sortType;
               K var116 = BountyGUI.K.RECENT;
               String var105;
               if (var45 == var116) {
                  var267 = 1260802848 ^ var267;
                  o0KoOo0o0oOK var46 = GUI;
                  String var117 = cvgptbzqfg(dqxcfrccpydohdy(), zvoxrnzkiwzsetj(), var267);
                  String var149 = cvgptbzqfg(eomdhhowjpbveqe(), zvoxrnzkiwzsetj(), var267);
                  var105 = var46.raw(var117, var149);
                  var267 = 615804712 ^ var267;
               } else {
                  var267 = 1906041662 ^ var267;
                  o0KoOo0o0oOK var76 = GUI;
                  String var133 = cvgptbzqfg(zyzxfebzfltpbvd(), zvoxrnzkiwzsetj(), var267);
                  String var165 = cvgptbzqfg(ckofobclpiwcqni(), zvoxrnzkiwzsetj(), var267);
                  var105 = var76.raw(var133, var165);
                  var267 = 503963446 ^ var267;
               }

               var267 = 1317619282 ^ var267;
               byte var47 = (byte)(264188239 ^ var267);
               Object[] var48 = new Object[var47];
               byte var150 = (byte)(264188233 ^ var267);
               String var3 = cvgptbzqfg(vtwnidpsnsqhfyu(), zvoxrnzkiwzsetj(), var267);
               var48[var150] = var3;
               byte var151 = (byte)(264188232 ^ var267);
               int var175 = this.page;
               byte var4 = (byte)(264188232 ^ var267);
               int var176 = var175 + var4;
               String var177 = String.valueOf(var176);
               var48[var151] = var177;
               byte var152 = (byte)(264188235 ^ var267);
               String var178 = cvgptbzqfg(ijonzdrmdeosjmi(), zvoxrnzkiwzsetj(), var267);
               var48[var152] = var178;
               byte var153 = (byte)(264188234 ^ var267);
               byte var179 = (byte)(264188232 ^ var267);
               int var180 = Math.max(var179, var43);
               String var181 = String.valueOf(var180);
               var48[var153] = var181;
               byte var154 = (byte)(264188237 ^ var267);
               String var182 = cvgptbzqfg(gmxircrmvbzvycy(), zvoxrnzkiwzsetj(), var267);
               var48[var154] = var182;
               byte var155 = (byte)(264188236 ^ var267);
               var48[var155] = var105;
               var267 = 1862872830 ^ var267;
               int var50 = this.page;
               byte var51;
               if (var50 > (1622548407 ^ var267)) {
                  var267 = 2037886376 ^ var267;
                  var51 = (byte)(432124446 ^ var267);
                  var267 = 523907241 ^ var267;
               } else {
                  var267 = brerezurgfltkvqm(var267, 1658370595);
                  var51 = (byte)(40805780 ^ var267);
                  var267 = 76883746 ^ var267;
               }

               label124: {
                  var267 = 1368189635 ^ var267;
                  if (var51 == (1467443317 ^ var267)) {
                     var267 = 2041764277 ^ var267;
                     byte var53 = o0KoOo0KoOK.always();
                     if (var53 == (784708032 ^ var267)) {
                        var267 = 205630755 ^ var267;
                        break label124;
                     }

                     var267 = 581707260 ^ var267;
                  } else {
                     var267 = brerezurgfltkvqm(var267, 1528757321);
                  }

                  String var118 = cvgptbzqfg(urccppmqypickvw(), zvoxrnzkiwzsetj(), var267);
                  byte var156 = (byte)(208245777 ^ var267);
                  o0KoOo0o0oOK var184 = GUI;
                  String var201 = cvgptbzqfg(bbfohabazbvbdsp(), zvoxrnzkiwzsetj(), var267);
                  Material var5 = Material.ARROW;
                  String var6 = cvgptbzqfg(htdkfuwgjbyvcyq(), zvoxrnzkiwzsetj(), var267);
                  String var7 = cvgptbzqfg(vlxhpzoqiejhtob(), zvoxrnzkiwzsetj(), var267);
                  List var233 = List.of(var7);
                  ItemStack var185 = var184.item(var201, var5, var6, var233, var48);
                  Consumer var203 = (var2x) -> {
                     int var27 = 202246264 ^ 1873320048 ^ 2038154;
                     var27 = 1623180080 ^ var27;
                     byte var4 = (byte)(50743987 ^ var27);
                     var2x.setCancelled((boolean)var4);
                     var27 = 918746223 ^ var27;
                     if (var51 == (902086365 ^ var27)) {
                        var27 = 131348315 ^ var27;
                        Player var14 = this.player;
                        o0KoOo0KoOK.edge(var14);
                     } else {
                        var27 = brerezurgfltkvqm(var27, 205676815);
                        Player var11 = this.player;
                        String var15 = cvgptbzqfg(wurvbhodexakqts(), zvoxrnzkiwzsetj(), var27);
                        Sound var5 = Sound.UI_BUTTON_CLICK;
                        float var6 = 1.0F;
                        float var7 = 1.0F;
                        KKo0KoOoOK.play(var11, var15, var5, var6, var7);
                        var27 = 1218777597 ^ var27;
                        Player var17 = this.player;
                        int var19 = this.page;
                        byte var21 = (byte)(1898171950 ^ var27);
                        int var20 = var19 - var21;
                        K var23 = this.sortType;
                        String var24 = this.searchQuery;
                        BountyGUI var12 = new BountyGUI(var17, var20, var23, var24);
                        var12.open();
                        var27 = 401273907 ^ var27;
                     }
                  };
                  this.button(var118, var156, var185, var203);
                  var267 = 787319007 ^ var267;
               }

               String var119 = cvgptbzqfg(fimtcwpejczxznh(), zvoxrnzkiwzsetj(), var267);
               byte var157 = (byte)(579083475 ^ var267);
               o0KoOo0o0oOK var186 = GUI;
               String var204 = cvgptbzqfg(reqmrtodtneiole(), zvoxrnzkiwzsetj(), var267);
               Material var221 = Material.HOPPER;
               String var229 = cvgptbzqfg(geugkgxhsmkymyv(), zvoxrnzkiwzsetj(), var267);
               String var234 = cvgptbzqfg(pseuvgtibgqtjfc(), zvoxrnzkiwzsetj(), var267);
               List var235 = List.of(var234);
               ItemStack var187 = var186.item(var204, var221, var229, var235, var48);
               Consumer var206 = (var1x) -> {
                  int var21 = 157098929 ^ 426098336 ^ 2038154;
                  var21 = 1083390732 ^ var21;
                  byte var3 = (byte)(1354022806 ^ var21);
                  var1x.setCancelled((boolean)var3);
                  var21 = 471809274 ^ var21;
                  Player var10 = this.player;
                  String var15 = cvgptbzqfg(hzauwltlfaavmit(), zvoxrnzkiwzsetj(), var21);
                  KKo0KoOoOK.filter(var10, var15);
                  var21 = 1009397832 ^ var21;
                  K var12 = this.sortType;
                  K var16 = BountyGUI.K.AMOUNT;
                  K var14;
                  if (var12 == var16) {
                     var21 = 1308567984 ^ var21;
                     var14 = BountyGUI.K.RECENT;

                     label23:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var21)) {
                           case 119895806:
                              var21 ^= 1852936079;
                              break label23;
                           case 951573284:
                              break;
                           case 1634483618:
                              break label23;
                           case 2088460542:
                           default:
                              throw new IOException();
                        }
                     }
                  } else {
                     label34:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var21)) {
                           case 167459734:
                              var21 ^= 525571471;
                           case 1221420548:
                              break label34;
                           case 1458929878:
                           default:
                              throw new IOException();
                           case 1585790662:
                        }
                     }

                     var14 = BountyGUI.K.AMOUNT;
                     var21 = 1021129648 ^ var21;
                  }

                  var21 = 1326590248 ^ var21;
                  Player var17 = this.player;
                  byte var5 = (byte)(471678002 ^ var21);
                  String var18 = this.searchQuery;
                  BountyGUI var13 = new BountyGUI(var17, var5, var14, var18);
                  var13.open();
                  var21 = 6123761 ^ var21;
               };
               this.button(var119, var157, var187, var206);
               var267 = 965936535 ^ var267;
               o0KoOo0o0oOK var56 = GUI;
               String var120 = cvgptbzqfg(vpyzdnqikxvvfth(), zvoxrnzkiwzsetj(), var267);
               Material var158 = Material.SKELETON_SKULL;
               String var188 = cvgptbzqfg(fkzymegzrrtwjww(), zvoxrnzkiwzsetj(), var267);
               String var207 = cvgptbzqfg(axrxvlwlasyysom(), zvoxrnzkiwzsetj(), var267);
               String var222 = cvgptbzqfg(egriadpipkrujly(), zvoxrnzkiwzsetj(), var267);
               String var230 = cvgptbzqfg(lxkqgqegvaufyqx(), zvoxrnzkiwzsetj(), var267);
               String var236 = cvgptbzqfg(keyorymaamvyaij(), zvoxrnzkiwzsetj(), var267);
               var267 = 222801696 ^ var267;
               List var208 = List.of(var207, var222, var230, var236);
               var267 = 1898866265 ^ var267;
               ItemStack var57 = var56.item(var120, var158, var188, var208, var48);
               var267 = 80120302 ^ var267;
               ItemMeta var59 = var57.getItemMeta();
               var267 = 515041280 ^ var267;
               if (var59 != null) {
                  var267 ^= 7831013;
                  o0KoOo0o0oOK var61 = GUI;
                  String var121 = cvgptbzqfg(wfvshvbmstyitev(), zvoxrnzkiwzsetj(), var267);
                  byte var159 = (byte)(2105396231 ^ var267);
                  byte var62 = var61.bool(var121, (boolean)var159);
                  if (var62 != (2105396230 ^ var267)) {
                     var267 = 581805465 ^ var267;
                     Enchantment var122 = o0oOKKoOoOK.UNBREAKING;
                     byte var160 = (byte)(1607494046 ^ var267);
                     byte var189 = (byte)(1607494046 ^ var267);
                     var59.addEnchant(var122, var160, (boolean)var189);
                     var267 = 1177634970 ^ var267;
                     byte var123 = (byte)(434184452 ^ var267);
                     ItemFlag[] var124 = new ItemFlag[var123];
                     byte var190 = (byte)(434184453 ^ var267);
                     ItemFlag var209 = ItemFlag.HIDE_ENCHANTS;
                     var124[var190] = var209;
                     var59.addItemFlags(var124);
                     var267 = 2103841680 ^ var267;
                     var57.setItemMeta(var59);
                     var267 = 1914322235 ^ var267;
                  } else {
                     label107:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var267)) {
                           case 52676150:
                              var267 ^= 1809892264;
                              break label107;
                           case 796900943:
                           default:
                              throw new RuntimeException();
                           case 1529644870:
                              break label107;
                           case 1823906254:
                        }
                     }
                  }
               } else {
                  label117:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var267)) {
                        case 11505033:
                        default:
                           throw new RuntimeException();
                        case 38061485:
                           var267 ^= 1805106765;
                           break label117;
                        case 602952164:
                           break;
                        case 1134067355:
                           break label117;
                     }
                  }
               }

               String var126 = cvgptbzqfg(bijsylpdsqrtyea(), zvoxrnzkiwzsetj(), var267);
               byte var161 = (byte)(379391903 ^ var267);
               Consumer var211 = (var1x) -> {
                  int var21 = 49541767 ^ 1098682543 ^ 2038154;
                  var21 = 282823438 ^ var21;
                  byte var3 = (byte)(1397485741 ^ var21);
                  var1x.setCancelled((boolean)var3);
                  var21 = 733485014 ^ var21;
                  Player var9 = this.player;
                  String var11 = cvgptbzqfg(eucugufnubeplyr(), zvoxrnzkiwzsetj(), var21);
                  Sound var4 = Sound.UI_BUTTON_CLICK;
                  float var5 = 1.0F;
                  float var6 = 1.0F;
                  KKo0KoOoOK.play(var9, var11, var4, var5, var6);
                  var21 = 2134364988 ^ var21;
                  Player var13 = this.player;
                  int var15 = this.page;
                  K var17 = this.sortType;
                  String var18 = this.searchQuery;
                  BountyGUI var10 = new BountyGUI(var13, var15, var17, var18);
                  var10.open();
                  var21 = 291874378 ^ var21;
               };
               this.button(var126, var161, var57, var211);
               var267 = 1076727049 ^ var267;
               String var127 = cvgptbzqfg(nutaxvtqybnkphf(), zvoxrnzkiwzsetj(), var267);
               byte var162 = (byte)(1454408341 ^ var267);
               o0KoOo0o0oOK var192 = GUI;
               String var212 = cvgptbzqfg(sobuckeotwxpfpg(), zvoxrnzkiwzsetj(), var267);
               Material var224 = Material.OAK_SIGN;
               String var231 = cvgptbzqfg(dnmbcmwburzsime(), zvoxrnzkiwzsetj(), var267);
               String var237 = cvgptbzqfg(jyejdsfjltjvpxs(), zvoxrnzkiwzsetj(), var267);
               List var238 = List.of(var237);
               ItemStack var193 = var192.item(var212, var224, var231, var238, var48);
               Consumer var214 = (var1x) -> {
                  int var13 = 1575151762 ^ 903155000 ^ 2038154;
                  var13 = 390500648 ^ var13;
                  byte var3 = (byte)(2137943305 ^ var13);
                  var1x.setCancelled((boolean)var3);
                  var13 = 990172119 ^ var13;
                  Player var8 = this.player;
                  String var10 = cvgptbzqfg(jwtojfnnxfszzxp(), zvoxrnzkiwzsetj(), var13);
                  Sound var4 = Sound.UI_BUTTON_CLICK;
                  float var5 = 1.0F;
                  float var6 = 1.0F;
                  KKo0KoOoOK.play(var8, var10, var4, var5, var6);
                  var13 = 243859767 ^ var13;
                  this.openSearchSign();
                  var13 = 1262627180 ^ var13;
               };
               this.button(var127, var162, var193, var214);
               var267 = 1756409282 ^ var267;
               int var71 = this.page;
               byte var163 = (byte)(1040199524 ^ var267);
               int var129 = var43 - var163;
               byte var104;
               if (var71 < var129) {
                  var267 = 659820855 ^ var267;
                  var104 = (byte)(424951379 ^ var267);
                  var267 = brerezurgfltkvqm(var267, 712694824);
               } else {
                  label95:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var267)) {
                        case 136340947:
                           var267 ^= 1195285873;
                           break label95;
                        case 817223776:
                        default:
                           throw new RuntimeException();
                        case 1408512807:
                           break;
                        case 1621048672:
                           break label95;
                     }
                  }

                  var104 = (byte)(2034151956 ^ var267);
                  var267 = 1242583150 ^ var267;
               }

               label70: {
                  var267 = 207664247 ^ var267;
                  if (var104 == (1062098445 ^ var267)) {
                     var267 = 904328822 ^ var267;
                     byte var73 = o0KoOo0KoOK.always();
                     if (var73 == (178823291 ^ var267)) {
                        var267 = brerezurgfltkvqm(var267, 759705988);
                        break label70;
                     }

                     var267 = 120127495 ^ var267;
                  } else {
                     var267 = 852489841 ^ var267;
                  }

                  String var130 = cvgptbzqfg(fkzxfrdlabnzzxd(), zvoxrnzkiwzsetj(), var267);
                  byte var164 = (byte)(226598985 ^ var267);
                  o0KoOo0o0oOK var194 = GUI;
                  String var215 = cvgptbzqfg(mprpyeriukiiufy(), zvoxrnzkiwzsetj(), var267);
                  Material var225 = Material.ARROW;
                  String var232 = cvgptbzqfg(zuvhzafncovkooq(), zvoxrnzkiwzsetj(), var267);
                  String var239 = cvgptbzqfg(eazvbmlbljwyedk(), zvoxrnzkiwzsetj(), var267);
                  List var240 = List.of(var239);
                  ItemStack var195 = var194.item(var215, var225, var232, var240, var48);
                  Consumer var217 = (var2x) -> {
                     int var27 = 308813464 ^ 1594100701 ^ 2038154;
                     var27 = 432606189 ^ var27;
                     byte var4 = (byte)(1421477667 ^ var27);
                     var2x.setCancelled((boolean)var4);
                     var27 = 1308898387 ^ var27;
                     if (var104 == (448672625 ^ var27)) {
                        var27 = 278902263 ^ var27;
                        Player var11 = this.player;
                        o0KoOo0KoOK.edge(var11);
                     } else {
                        var27 = 800072528 ^ var27;
                        Player var13 = this.player;
                        String var15 = cvgptbzqfg(nrlmsvkyqnwffjj(), zvoxrnzkiwzsetj(), var27);
                        Sound var5 = Sound.UI_BUTTON_CLICK;
                        float var6 = 1.0F;
                        float var7 = 1.0F;
                        KKo0KoOoOK.play(var13, var15, var5, var6, var7);
                        var27 = 621339656 ^ var27;
                        Player var17 = this.player;
                        int var19 = this.page;
                        byte var21 = (byte)(268891176 ^ var27);
                        int var20 = var19 + var21;
                        K var23 = this.sortType;
                        String var24 = this.searchQuery;
                        BountyGUI var14 = new BountyGUI(var17, var20, var23, var24);
                        var14.open();
                        var27 = 602722286 ^ var27;
                     }
                  };
                  this.button(var130, var164, var195, var217);
                  var267 = 711012739 ^ var267;
               }

               o0KoOo0o0oOK var75 = GUI;
               Inventory var132 = this.inventory;
               var75.fill(var132);
               var267 = 859060161 ^ var267;
               return;
            }
         }

         var267 = 1647872889 ^ var267;
         Object var97 = var10.next();
         Integer var98 = (Integer)var97;
         int var99 = var98;
         var267 = 1630010229 ^ var267;
         if (var99 >= (1205070187 ^ var267)) {
            var267 = 1397941952 ^ var267;
            Inventory var142 = this.inventory;
            int var143 = var142.getSize();
            if (var99 < var143) {
               var267 = 505235497 ^ var267;
               Integer var145 = var99;
               boolean var103 = var9.add(var145);
               var267 = 1708504263 ^ var267;
            } else {
               var267 = 2076769518 ^ var267;
            }
         } else {
            var267 = 681187886 ^ var267;
         }

         var267 = brerezurgfltkvqm(var267, 730163746);
      }
   }

   private void button(String var1, int var2, ItemStack var3, Consumer<InventoryClickEvent> var4) {
      int var29 = 1073701162 ^ 583674406 ^ 2038154;
      var29 = 954219353 ^ var29;
      o0KoOo0o0oOK var5 = GUI;
      String var15 = "buttons." + var1 + ".enabled";
      byte var7 = (byte)(634022366 ^ var29);
      byte var9 = var5.bool(var15, (boolean)var7);
      if (var9 == (634022367 ^ var29)) {
         var29 = 933018503 ^ var29;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var29)) {
               case 154667242:
                  var29 ^= 795555852;
               case 1435107300:
                  o0KoOo0o0oOK var10 = GUI;
                  int var11 = var10.slot(var1, var2);
                  var29 = 1149540011 ^ var29;
                  if (var11 >= (1311098744 ^ var29)) {
                     var29 = 354450159 ^ var29;
                     Inventory var18 = this.inventory;
                     int var19 = var18.getSize();
                     if (var11 < var19) {
                        var29 = brerezurgfltkvqm(var29, 679186190);
                        o0KoOKKo0K var22 = new o0KoOKKo0K();
                        o0KoOKKo0K var23 = var22.item(var3);
                        o0KoOKKo0K var24 = var23.consumer(var4);
                        this.addButton(var11, var24);
                        var29 = 356080631 ^ var29;
                        return;
                     }

                     var29 = 394638535 ^ var29;
                  } else {
                     var29 = 44420648 ^ var29;
                  }

                  return;
               case 481214210:
                  break;
               case 1568158350:
               default:
                  throw new RuntimeException();
            }
         }
      }
   }

   private void openSearchSign() {
      int var47 = 762900213 ^ 1369699292 ^ 2038154;
      var47 = 2091415978 ^ var47;
      Player var9 = this.player;
      var9.closeInventory();
      var47 = 1161803318 ^ var47;

      try {
         SignGUIBuilder var10 = SignGUI.builder();
         o0KoOo0o0oOK var2 = GUI;
         String var3 = cvgptbzqfg(gmvgpnfruimgevp(), zvoxrnzkiwzsetj(), var47);
         String var4 = cvgptbzqfg(vqvbotrgtzbocmm(), zvoxrnzkiwzsetj(), var47);
         String var5 = cvgptbzqfg(xvwpihvlymlcvcd(), zvoxrnzkiwzsetj(), var47);
         String var6 = cvgptbzqfg(yhluaifdywuvocg(), zvoxrnzkiwzsetj(), var47);
         String var7 = cvgptbzqfg(yuvmguvrvdmwrwf(), zvoxrnzkiwzsetj(), var47);
         var47 = 1018276208 ^ var47;
         List var37 = List.of(var4, var5, var6, var7);
         byte var40 = (byte)(2044879439 ^ var47);
         Object[] var41 = new Object[var40];
         List var20 = var2.lines(var3, var37, var41);
         byte var32 = (byte)(2044879439 ^ var47);
         String[] var33 = new String[var32];
         Object[] var21 = var20.toArray(var33);
         String[] var22 = (String[])var21;
         SignGUIBuilder var11 = var10.setLines(var22);
         o0KoOo0o0oOK var23 = GUI;
         String var34 = cvgptbzqfg(wovknzasnvlfbte(), zvoxrnzkiwzsetj(), var47);
         Material var38 = Material.OAK_SIGN;
         var47 = 254129934 ^ var47;
         Material var24 = var23.material(var34, var38);
         SignGUIBuilder var12 = var11.setType(var24);
         SignGUIFinishHandler var26 = (var1, var2x) -> {
            int var29 = 1854801387 ^ 1581828903 ^ 2038154;
            var29 = 1438254696 ^ var29;
            byte var4 = (byte)(1701040430 ^ var29);
            String var9 = var2x.getLineWithoutColor(var4);
            String var10 = var9.trim();
            var29 = 1370830833 ^ var29;
            byte var12 = var10.isEmpty();
            if (var12 == (886499039 ^ var29)) {
               var29 = 1398069363 ^ var29;
               KKoOoOo0oOK var16 = KKoOoOo0oOK.getInstance();
               Player var21 = this.player;
               Runnable var24 = () -> {
                  int var11 = 1474186575 ^ 1242169367 ^ 2038154;
                  var11 = 1422680759 ^ var11;
                  Player var7 = this.player;
                  byte var4 = (byte)(1225209445 ^ var11);
                  K var8 = this.sortType;
                  BountyGUI var2 = new BountyGUI(var7, var4, var8, var10);
                  var2.open();
               };
               long var26 = 1L;
               var16.runAtEntityLater(var21, var24, var26);
               var29 = 1142714748 ^ var29;
            } else {
               var29 = 1668430500 ^ var29;
               KKoOoOo0oOK var13 = KKoOoOo0oOK.getInstance();
               Player var19 = this.player;
               Runnable var22 = () -> {
                  int var10 = 159469129 ^ 980866089 ^ 2038154;
                  var10 = 1811832198 ^ var10;
                  Player var6 = this.player;
                  byte var3 = (byte)(1477893740 ^ var10);
                  K var7 = this.sortType;
                  Object var5 = null;
                  BountyGUI var1 = new BountyGUI(var6, var3, var7, (String)var5);
                  var1.open();
               };
               long var6 = 1L;
               var13.runAtEntityLater(var19, var22, var6);

               label21:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var29)) {
                     case 164576394:
                        var29 = 1949995947 ^ var29;
                     case 721275435:
                        break label21;
                     case 1197535517:
                     default:
                        throw new IllegalAccessException();
                     case 1450313187:
                  }
               }
            }

            List var15 = Collections.emptyList();
            return var15;
         };
         var47 = 990476617 ^ var47;
         SignGUIBuilder var13 = var12.setHandler(var26);
         var47 = 328610915 ^ var47;
         DonutSMPCore var27 = DonutSMPCore.getInstance();
         SignGUIBuilder var14 = var13.callHandlerSynchronously(var27);
         var47 = 975661949 ^ var47;
         SignGUI var15 = var14.build();
         Player var29 = this.player;
         var47 = 840278006 ^ var47;
         var15.open(var29);
         var47 = 236839844 ^ var47;
      } catch (Exception var48) {
         switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var47)) {
            case -1286379774 -> var47 = 327051840 ^ var47;
            case -1237407221 -> var47 = 869520353 ^ var47;
            case -820833669 -> var47 = 1022780655 ^ var47;
            case -221985958 -> var47 = 458006219 ^ var47;
            case 603953331 -> var47 = 560723382 ^ var47;
            case 715020794 -> var47 = 4705695 ^ var47;
            case 1853186114 -> var47 = brerezurgfltkvqm(var47, 148548264);
            default -> throw new IOException("Error in hash");
         }

         var47 = 1186736285 ^ var47;
         Player var18 = this.player;
         String var30 = cvgptbzqfg(iwyconsgeirxwzm(), zvoxrnzkiwzsetj(), var47);
         String var31 = KoOo0Ko0oOK.get(var30);
         var18.sendMessage(var31);
         var47 = 617315438 ^ var47;
         Player var36 = this.player;
         byte var39 = (byte)(660820563 ^ var47);
         K var43 = this.sortType;
         Object var44 = null;
         BountyGUI var19 = new BountyGUI(var36, var39, var43, (String)var44);
         var19.open();
         var47 = 1174572448 ^ var47;
         return;
      }

      while(true) {
         switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var47)) {
            case 31624383:
               break;
            case 191364580:
               var47 = 957763767 ^ var47;
               return;
            case 481533203:
            default:
               throw new RuntimeException();
            case 1626328286:
               return;
         }
      }
   }

   static {
      int var9 = 1828872955 ^ 2000886561 ^ Integer.parseInt("1467198533");
      var9 = 2023741690 ^ var9;
      String var0 = cvgptbzqfg(fmghirewkuwlynf(), zvoxrnzkiwzsetj(), var9);
      o0KoOo0o0oOK var2 = o0KoOo0o0oOK.of(var0);
      GUI = var2;
      var9 = 1328557924 ^ var9;
      byte var3 = (byte)(2057118209 ^ var9);
      byte var1 = (byte)(2057118252 ^ var9);
      IntStream var4 = IntStream.range(var3, var1);
      Stream var5 = var4.boxed();
      List var6 = var5.toList();
      DEFAULT_CONTENT = var6;
   }

   public static String cvgptbzqfg(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] zvoxrnzkiwzsetj() {
      return new byte[]{81, 53, 91, 30, 109, 114, 19, 94, 15, 22, 6, 5, 47, 57, 10, 99, 83, 60, 4, 4, 15, 96, 67, 95, 41, 22, 85, 57, 1, 112, 36, 43, 110, 27, 100, 3, 57, 53, 66, 84, 2, 59};
   }

   private static byte[] fmghirewkuwlynf() {
      return new byte[]{-106, -6, 107, 76, 94, 52, 37, 7, 58, 92, 54, 26, 26, 104, 57, 58, 99, 124, 61, 90, 63, 33, 112, 21, 31, 9, 96, 98, 49, 47, 17, 109, 93, 67, 84, 66, 0, 124, 114, 6, 49, 125, 103, 108};
   }

   private static byte[] nrlmsvkyqnwffjj() {
      return new byte[]{-105, -13, 107, 77, 92, 41, 35, 19, 62, 64, 63, 65, 30, 113, 62, 125, 107, 111, 60, 82, 63, 36, 114, 5, 25, 90, 100, 120, 56, 39, 21, 111, 90, 66, 92, 28, 1, 111, 114, 9, 51, 102, 97, 110, 106, 77, 84, 116};
   }

   private static byte[] jwtojfnnxfszzxp() {
      return new byte[]{-98, -5, 111, 75, 85, 41, 37, 24, 57, 79, 55, 64, 27, 119, 50, 121, 101, 109, 50, 92, 62, 36, 119, 6, 17, 86, 99, 115, 55, 32, 21, 111, 90, 69, 92, 25, 15, 101, 116, 15, 51, 99, 101, 97, 99, 65, 91, 116};
   }

   private static byte[] eucugufnubeplyr() {
      return new byte[]{-99, -6, 105, 69, 95, 40, 35, 31, 61, 78, 52, 65, 29, 121, 56, 120, 99, 106, 54, 93, 61, 37, 113, 8, 27, 87, 101, 116, 51, 33, 22, 110, 92, 75, 86, 24, 9, 98, 112, 14, 48, 98, 99, 111, 105, 64, 93, 114};
   }

   private static byte[] hzauwltlfaavmit() {
      return new byte[]{-98, -8, 99, 74, 94, 45, 43, 28, 62, 79, 55, 67, 23, 118, 57, 125, 107, 120, 53, 92, 62, 32, 123, 29};
   }

   private static byte[] wurvbhodexakqts() {
      return new byte[]{-106, -4, 110, 77, 89, 45, 39, 24, 59, 65, 48, 68, 30, 116, 58, 121, 96, 106, 61, 93, 58, 36, 119, 1, 29, 81, 97, 121, 55, 34, 21, 106, 94, 70, 87, 25, 0, 96, 119, 9, 54, 98, 101, 101, 111, 76, 91, 117};
   }

   private static byte[] xarbjhexrmyepho() {
      return new byte[]{-99, -7, 108, 75, 89, 40, 37, 24, 61, 75, 49, 70, 27, 117, 60, 126, 97, 109, 51, 92, 59, 32, 117, 2, 27, 81, 98, 119, 53, 34, 18, 109, 92, 65, 83, 26, 13, 99, 116, 11, 48, 97, 102, 97, 111, 64};
   }

   private static byte[] fkzxfrdlabnzzxd() {
      return new byte[]{-99, -8, 109, 69, 84, 46, 35, 21, 57, 80, 52, 30, 26, 112, 51, 50, 96, 109, 54, 83};
   }

   private static byte[] mprpyeriukiiufy() {
      return new byte[]{-99, -8, 109, 69, 84, 46, 35, 21, 57, 80, 52, 30, 26, 112, 51, 50, 96, 109, 54, 83};
   }

   private static byte[] zuvhzafncovkooq() {
      return new byte[]{-99, -8, 109, 8, 84, 123, 35, 93, 57, 98, 52, 112, 26, 56, 51, 107, 98, 126, 43, 49, 57, 45, 103, 125};
   }

   private static byte[] eazvbmlbljwyedk() {
      return new byte[]{-99, -8, 109, 8, 84, 13, 35, 43, 57, 98, 52, 117, 26, 70, 51, 21, 96, 73, 54, 90, 57, 60, 122, 5, 25, 78, 99, 43, 51, 50, 17, 125, 87, 11, 87, 82, 11, 104, 116, 65, 59, 118, 97, 105, 109, 12, 95, 48, 38, 15, 54, 67, 53, 19, 29, 101, 60, 51, 106, 125, 52, 67, 57, 114, 113, 25, 28, 78, 108, 110, 50, 35};
   }

   private static byte[] zyzxfebzfltpbvd() {
      return new byte[]{-98, -1, 98, 85, 93, 45, 36, 31, 59, 83, 55, 29, 22, 117, 58, 42, 100, 127, 48, 80, 62, 38, 122, 73, 25, 71, 98, 103, 53, 46, 21, 107, 87, 77, 84, 71};
   }

   private static byte[] ckofobclpiwcqni() {
      return new byte[]{-98, -1, 98, 103, 93, 47, 36, 2, 59, 82, 55, 94, 22, 117};
   }

   private static byte[] vtwnidpsnsqhfyu() {
      return new byte[]{-99, -4, 111, 10, 85, 58, 33, 12, 60, 67, 48, 84, 30, 36};
   }

   private static byte[] ijonzdrmdeosjmi() {
      return new byte[]{-99, -4, 111, 10, 85, 58, 33, 12, 60, 67, 48, 84, 30, 114, 50, 116};
   }

   private static byte[] gmxircrmvbzvycy() {
      return new byte[]{-99, -4, 111, 10, 85, 57, 33, 2, 60, 86, 48, 69, 30, 36};
   }

   private static byte[] wfvshvbmstyitev() {
      return new byte[]{-99, -5, 107, 73, 94, 62, 37, 24, 60, 82, 52, 91, 31, 98, 57, 41, 101, 32, 55, 70, 61, 52, 115, 12, 26, 93, 99, 110, 50, 51, 22, 114, 94, 0, 87, 93, 15, 107, 113, 11, 48, 125};
   }

   private static byte[] dqxcfrccpydohdy() {
      return new byte[]{-98, -3, 107, 94, 93, 47, 39, 26, 54, 83, 55, 31, 31, 126, 58, 40, 103, 122, 61, 80, 62, 36, 115, 66, 25, 86, 97, 106, 56, 34, 21, 121, 94, 70, 84, 69};
   }

   private static byte[] eomdhhowjpbveqe() {
      return new byte[]{-98, -3, 107, 127, 93, 37, 39, 11, 54, 66, 55, 92, 31, 126, 58, 61, 103, 115, 61, 21, 62, 4, 115, 9, 25, 80};
   }

   private static byte[] bijsylpdsqrtyea() {
      return new byte[]{-100, -3, 98, 95, 84, 38, 42, 9, 55, 87, 49, 89, 28, 115, 59, 50};
   }

   private static byte[] urccppmqypickvw() {
      return new byte[]{-99, -6, 99, 92, 89, 53, 43, 9, 63, 82, 54, 84, 29, 98, 63, 46, 97, 127, 54, 25, 55, 34, 119, 11, 17, 67, 101, 110};
   }

   private static byte[] bbfohabazbvbdsp() {
      return new byte[]{-99, -6, 99, 92, 89, 53, 43, 9, 63, 82, 54, 84, 29, 98, 63, 46, 97, 127, 54, 25, 55, 34, 119, 11, 17, 67, 101, 110};
   }

   private static byte[] htdkfuwgjbyvcyq() {
      return new byte[]{-99, -6, 99, 15, 89, 119, 43, 92, 63, 98, 54, 126, 29, 53, 63, 99, 99, -107, 43, 52, 42, 86, 106, 97};
   }

   private static byte[] vlxhpzoqiejhtob() {
      return new byte[]{-99, -6, 99, 15, 89, 1, 43, 42, 63, 98, 54, 123, 29, 75, 63, 29, 97, 79, 54, 88, 55, 59, 119, 9, 17, 79, 101, 43, 49, 60, 22, 112, 91, 3, 86, 84, 11, 106, 122, 70, 54, 122, 105, 104, 107, 12, 93, 62, 33, 2, 58, 75, 52, 21, 29, 121, 50, 35, 103, 108, 60, 64, 63, 59, 115, 8, 27, 87, 96, 114, 51, 96, 22, 107, 86, 72, 80, 81, 1, 98};
   }

   private static byte[] nutaxvtqybnkphf() {
      return new byte[]{-98, -2, 110, 89, 89, 39, 43, 12, 58, 93, 55, 82, 26, 101};
   }

   private static byte[] sobuckeotwxpfpg() {
      return new byte[]{-98, -2, 110, 89, 89, 39, 43, 12, 58, 93, 55, 82, 26, 101};
   }

   private static byte[] dnmbcmwburzsime() {
      return new byte[]{-98, -2, 110, 9, 89, 114, 43, 93, 58, 105, 55, 114, 26, 53, 62, 107, -52, 62, 44, 58, 35, 84, 116, -21, 0, 34, 111, -106};
   }

   private static byte[] jyejdsfjltjvpxs() {
      return new byte[]{-98, -2, 110, 9, 89, 4, 43, 43, 58, 105, 55, 119, 26, 75, 62, 21, 107, 76, 49, 81, 62, 61, 118, 8, 29, 77, 109, 42, 52, 61, 21, 112, 91, 15, 80, 64, 1, 99, 119, 12, 51, 125, 100, 98, 111, 70};
   }

   private static byte[] vpyzdnqikxvvfth() {
      return new byte[]{-101, -1, 111, 88, 84, 47, 37, 15, 57, 80, 51, 84, 27, 115, 50, 61};
   }

   private static byte[] fkzymegzrrtwjww() {
      return new byte[]{-101, -1, 111, 9, 84, 122, 37, 89, 57, 100, 51, 114, 27, 56, 50, 109, 102, -109, 45, 62, 38, 72, 120, 19, 2, 58, 97, 103, 41, 67, -73, 35};
   }

   private static byte[] axrxvlwlasyysom() {
      return new byte[]{-101, -1, 111, 9, 84, 12, 37, 47, 57, 100, 51, 119, 27, 70, 50, 19, 100, 73, 48, 93, 59, 61, 122, 4, 31, 74, 99, 45, 52, 48, 16, 125, 86, 13, 83, 71, 13, 101, 118, 6, 59, 113, 103, 103, 109, 89, 88, 46};
   }

   private static byte[] egriadpipkrujly() {
      return new byte[0];
   }

   private static byte[] lxkqgqegvaufyqx() {
      return new byte[]{-101, -1, 111, 9, 84, 11, 37, 40, 57, 99, 51, 112, 27, 65, 50, 20, 100, 89, 48, 84, 59, 32, 122, 71, 31, 64, 99, 45, 52, 38, 16, 125, 86, 88, 83, 91, 13, 116, 118, 25, 59, 35, 103, 119, 109, 89, 88, 47, 39, 9, 55, 71, 49, 19, 27, 120, 62, 63, 106, 109, 50, 64, 57, 110};
   }

   private static byte[] keyorymaamvyaij() {
      return new byte[]{-101, -1, 111, 9, 84, 11, 37, 40, 57, 99, 51, 112, 27, 65, 50, 20, 100, 44, 48, 94, 59, 123, 122, 5, 31, 78, 99, 120, 52, 42, 16, 102, 86, 84, 83, 21, 13, 97, 118, 4, 59, 103, 103, 34, 109, 2, 88, 54, 39, 11, 55, 65, 49, 74, 27, 105, 62, 37, 106, 45, 50, 19, 57, 124, 118, 10, 29, 66, 109, 96, 54, 51, 16, 112, 90, 91, 93, 18};
   }

   private static byte[] agolubabgjazdke() {
      return new byte[]{-98, -13, 105, 3, 94, 39, 34, 2, 57, 73, 55, 73, 29, 111, 57, 35, 98, 40};
   }

   private static byte[] fimtcwpejczxznh() {
      return new byte[]{-102, -3, 98, 93, 85, 46, 39, 21, 62, 87};
   }

   private static byte[] reqmrtodtneiole() {
      return new byte[]{-102, -3, 98, 93, 85, 46, 39, 21, 62, 87};
   }

   private static byte[] geugkgxhsmkymyv() {
      return new byte[]{-102, -3, 98, 13, 85, 113, 39, 87, 62, 101, 49, 127, 31, 57, 57, 111, -51, 60, 44, 60, 52, -48, 102, 119};
   }

   private static byte[] pseuvgtibgqtjfc() {
      return new byte[]{-102, -3, 98, 13, 85, 7, 39, 33, 62, 101, 49, 122, 31, 71, 57, 17, 106, 78, 49, 95, 54, 57, 123, 15, 29, 68, 100, 44, 54, 61, 20, 124, 93, 15, 93, 65, 12, 109, 123, 22, 58, 124, 101, 44, 106, 3, 90, 110, 35, 21, 60, 77, 63, 70, 26, 122, 51, 118};
   }

   private static byte[] oqazfvkbgpmzwqt() {
      return new byte[]{-104, -7, 105, 77, 84, 43, 32, 5, 60, 85, 53, 82, 31, 110, 60, 36, 102, 34, 51, 68, 61, 60, 122, 6, 26, 87, 102, 125};
   }

   private static byte[] zzoldywzbwecuxd() {
      return new byte[]{-99, -6, 106, 79, 92, 47, 33, 29, 58, 85, 52, 76};
   }

   private static byte[] hpxyjbhfvuqgqko() {
      return new byte[]{-99, -6, 106, 9, 92, 113, 33, 89, 58, 97, 52, 118, 30, 53, 59, 104, 97, 46, 49, 69, 61, 60, 114, 10, 24, 92, 103, 107, 52, 51, 22, 62};
   }

   private static byte[] iacybpwyftfvjmy() {
      return new byte[]{-99, -6, 106, 9, 92, 7, 33, 47, 58, 97, 52, 115, 30, 75, 59, 22, 97, 73, 49, 90, 61, 37, 114, 5, 24, 81, 103, 119, 52, 123, 22, 59, 95, 12, 85, 113, 11, 67, 119, 36, 48, 74, 96, 64, 106, 108, 95, 96, 38, 14, 61, 75, 55, 94, 30, 127, 56, 58, 102, 121, 54, 17};
   }

   private static byte[] ryarrhaqoiohsor() {
      return new byte[]{-99, -6, 106, 15, 92, 49, 33, 5, 58, 70, 52, 76, 30, 104, 59, 34, 97, 46};
   }

   private static byte[] wovknzasnvlfbte() {
      return new byte[]{-99, -6, 111, 89, 85, 32, 42, 11, 60, 93, 52, 86, 27, 101, 50, 121, 106, 123, 55, 84, 61, 55, 119, 5, 17, 15, 108, 96, 50, 40, 22, 111, 90, 74, 92, 70, 0, 104, 113, 12, 48, 103};
   }

   private static byte[] iwyconsgeirxwzm() {
      return new byte[]{-103, -5, 104, 73, 94, 40, 32, 24, 57, 73, 53, 68, 28, 117, 57, 126, 101, 126, 55, 84, 60, 52, 112, 30, 31, 68, 102, 100, 50, 104, 23, 109, 88, 68, 87, 87, 10, 118, 113, 6, 52, 99, 98, 108, 104, 74, 94, 35, 37, 3, 60, 70};
   }

   private static byte[] gmvgpnfruimgevp() {
      return new byte[]{-98, -5, 109, 94, 92, 38, 42, 11, 61, 87, 55, 87, 25, 98, 59, 127, 106, 123, 54, 94, 62, 54, 117, 2, 24, 9, 108, 97, 51, 42, 21, 116, 88, 77, 85, 65};
   }

   private static byte[] vqvbotrgtzbocmm() {
      return new byte[0];
   }

   private static byte[] xvwpihvlymlcvcd() {
      return new byte[]{-98, -5, 76, -68, 125, -46, 11, -5, 28, -76, 22, -91, 56, -101, 26, -61, 75, -103, 23, -90, 31, -64, 84, -3, 57, -74};
   }

   private static byte[] yhluaifdywuvocg() {
      return new byte[]{-98, -5, 109, 126, 92, 38, 42, 11, 61, 87, 55, 87, 25, 98};
   }

   private static byte[] yuvmguvrvdmwrwf() {
      return new byte[0];
   }

   private static int brerezurgfltkvqm(int var0, int var1) {
      return var1 ^ var0;
   }

   public static enum K {
      AMOUNT,
      RECENT;

      private final String display;
      private static byte[] puqfuwhvhw;

      private K(final String var3) {
         this.display = var3;
      }

      public String getDisplay() {
         int var5 = 1513166061 ^ 1719561307 ^ 258287642;
         var5 = 303859520 ^ var5;
         String var2 = this.display;
         return var2;
      }

      private static K[] $values() {
         int var8 = 1696445279 ^ 951105332 ^ 1620017027;
         var8 = 200831272 ^ var8;
         byte var0 = (byte)(920259266 ^ var8);
         K[] var3 = new K[var0];
         byte var1 = (byte)(920259264 ^ var8);
         K var2 = AMOUNT;
         var3[var1] = var2;
         byte var4 = (byte)(920259265 ^ var8);
         K var5 = RECENT;
         var3[var4] = var5;
         return var3;
      }

      static {
         int var11 = 2045037365 ^ 352491784 ^ Integer.parseInt("884288942");
         puqfuwhvhw = yiwkthjohnynxlq();
         var11 = 241406370 ^ var11;
         String var1 = xlhxokzzhj(rtarfpwwtktymoo(), var11);
         byte var2 = (byte)(1446047281 ^ var11);
         String var3 = xlhxokzzhj(pwsxfaeexwjpuac(), var11);
         K var0 = new K(var1, var2, var3);
         AMOUNT = var0;
         var11 = 2014806114 ^ var11;
         String var6 = xlhxokzzhj(elvyugfkggccuru(), var11);
         byte var7 = (byte)(774336082 ^ var11);
         String var8 = xlhxokzzhj(danvplvnqfaiztt(), var11);
         K var4 = new K(var6, var7, var8);
         RECENT = var4;
         var11 = 272185896 ^ var11;
         K[] var5 = $values();
      }

      public static String xlhxokzzhj(byte[] var0, int var1) {
         String var10 = Integer.toString(var1);
         byte[] var11 = var10.getBytes();
         byte[] var8 = var11;
         byte var12 = 0;
         int var9 = var12;

         while(true) {
            int var17 = var0.length;
            if (var9 >= var17) {
               Charset var5 = StandardCharsets.UTF_16;
               String var14 = new String(var0, var5);
               return var14;
            }

            byte var20 = var0[var9];
            int var33 = var8.length;
            int var30 = var9 % var33;
            byte var27 = var8[var30];
            int var21 = var20 ^ var27;
            byte var22 = (byte)var21;
            var0[var9] = var22;
            byte var23 = var0[var9];
            byte[] var28 = puqfuwhvhw;
            byte[] var34 = puqfuwhvhw;
            int var35 = var34.length;
            int var32 = var9 % var35;
            byte var29 = var28[var32];
            int var24 = var23 ^ var29;
            byte var25 = (byte)var24;
            var0[var9] = var25;
            ++var9;
         }
      }

      private static byte[] yiwkthjohnynxlq() {
         return new byte[]{96, 32, 71, 87, 67, 84, 61, 113, 13, 66, 123, 84, 27, 6, 85, 32, 93, 4, 71, 42, 48, 125, 121, 108, 17, 1, 53, 21, 98, 4, 126, 101, 106, 12, 107, 20, 96, 14, 31, 79, 86, 99, 5, 121, 78, 47, 63, 32, 126, 34, 12, 96, 28, 55, 43, 17, 81, 32, 20, 11, 85, 25, 61, 127, 33, 64, 51, 79, 98, 104, 58, 15, 16, 56, 81, 97, 78, 66, 31, 81, 54};
      }

      private static byte[] elvyugfkggccuru() {
         return new byte[]{-87, -24, 115, 54, 112, 39, 13, 10, 62, 48, 76, 46, 40, 97};
      }

      private static byte[] danvplvnqfaiztt() {
         return new byte[]{-87, -24, 115, 54, 112, 7, 13, 42, 62, 16, 76, 14, 40, 65, 99, 124, 101, 78, 112, 61, 4, 29, 74, 63, 33, 77};
      }

      private static byte[] rtarfpwwtktymoo() {
         return new byte[]{-81, -21, 115, 32, 115, 45, 10, 12, 53, 38, 74, 46, 47, 100};
      }

      private static byte[] pwsxfaeexwjpuac() {
         return new byte[]{-81, -21, 115, 32, 115, 13, 10, 44, 53, 6, 74, 14, 47, 68};
      }
   }
}
