package org.mz.donutsmpcore.bounty;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class BountyListener implements Listener {

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onPlayerDeath(PlayerDeathEvent var1) {
   }

   public static String bmltfcgwvn(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] ddggzlthfdwrisc() {
      return new byte[]{51, 104, 50, 22, 55, 47, 30, 117, 59, 77, 1, 109, 55, 78, 25, 100, 106, 125, 6, 86, 68, 28, 124, 109, 77, 79, 82, 39, 33, 72, 121, 14, 15, 127, 57, 32, 61, 33, 88, 81, 85, 14, 11, 5, 80, 59, 76, 47, 6, 51, 116, 9, 123, 125, 118, 101, 125, 127, 20, 13, 100, 28, 56, 40, 108, 13, 88, 32, 42, 17, 127, 19, 74, 52};
   }

   private static byte[] rbqqutjhqjuesyo() {
      return new byte[]{-5, -89, 11, 84, 2, 117, 41, 38, 12, 21, 49, 59, 0, 12, 45, 61};
   }

   private static int gndcxcufqdkavnum(int var0, int var1) {
      return var1 ^ var0;
   }

   static {
   }
}
