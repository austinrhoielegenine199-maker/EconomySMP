package org.mz.donutsmpcore.bounty;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Iterator;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.oOo0KKoOoOK;

public final class BountySyncBridge {
   private static volatile BountySyncDispatcher dispatcher;

   private BountySyncBridge() {
   }

   public static void setDispatcher(BountySyncDispatcher var0) {
      int var13 = 195926384 ^ 157002323 ^ 1706307907;
      var13 = 1042720629 ^ var13;
      dispatcher = var0;
      var13 = 2098068685 ^ var13;

      label44: {
         try {
            if (var0 != null) {
               var13 = 245819208 ^ var13;
               DonutSMPCore var5 = DonutSMPCore.getInstance();
               Logger var6 = var5.getLogger();
               var13 = 1935708584 ^ var13;
               Class var8 = var0.getClass();
               String var9 = var8.getSimpleName();
               String var10 = "Bounty cross-server dispatcher installed by " + var9 + ".";
               var13 = 409439254 ^ var13;
               var6.info(var10);
               var13 = 1550946150 ^ var13;
               break label44;
            }
         } catch (Throwable var14) {
            switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var13)) {
               case -847676990 -> var13 = 1657679349 ^ var13;
               case 239409522 -> var13 = 2057937379 ^ var13;
               case 592105153 -> var13 = 520641301 ^ var13;
               case 1451095169 -> var13 = jtzbdptybmnhquto(var13, 296664157);
               default -> throw new IOException("Error in hash");
            }

            var13 = 42599745 ^ var13;
            return;
         }

         var13 = jtzbdptybmnhquto(var13, 969962896);
      }

      while(true) {
         switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var13)) {
            case 160880754:
               var13 = 609364932 ^ var13;
               return;
            case 698819257:
            default:
               throw new IllegalAccessException();
            case 1000849665:
               break;
            case 1168306486:
               return;
         }
      }
   }

   public static boolean hasDispatcher() {
      int var4 = 866040436 ^ 117200163 ^ 1706307907;
      var4 = 851952176 ^ var4;
      BountySyncDispatcher var0 = dispatcher;
      byte var1;
      if (var0 == null) {
         var4 = jtzbdptybmnhquto(var4, 982237072);
         var1 = (byte)(1486529460 ^ var4);
         var4 = 1420784812 ^ var4;
         return (boolean)var1;
      } else {
         var4 = 1595322909 ^ var4;
         var1 = (byte)(1023913528 ^ var4);

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var4)) {
               case 104782985:
                  var4 = 825391393 ^ var4;
                  return (boolean)var1;
               case 418133511:
                  return (boolean)var1;
               case 453690963:
               default:
                  throw new RuntimeException();
               case 1919610583:
            }
         }
      }
   }

   public static void publishBountyChanged(UUID var0, String var1, double var2, String var4, double var5) {
      int var29 = 1701600710 ^ 1862177854 ^ 1706307907;
      var29 = 1018940029 ^ var29;
      BountySyncDispatcher var7 = dispatcher;
      BountySyncDispatcher var15 = var7;
      var29 = 1986413998 ^ var29;
      if (var7 == null) {
         var29 = 2106030838 ^ var29;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var29)) {
               case 128390050:
                  var29 ^= 2111142827;
               case 1862268655:
                  try {
                     var15.publishBountyChanged(var0, var1, var2, var4, var5);
                     var29 = 1549990210 ^ var29;
                  } catch (Throwable var31) {
                     switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var29)) {
                        case -915380710:
                           var29 = 1934272402 ^ var29;
                           Throwable var16 = var31;
                           var29 = 344624712 ^ var29;

                           try {
                              DonutSMPCore var21 = DonutSMPCore.getInstance();
                              Logger var22 = var21.getLogger();
                              String var25 = var16.getMessage();
                              String var26 = "[Bounty] publishBountyChanged failed: " + var25;
                              var22.warning(var26);
                              var29 = 1609046069 ^ var29;
                           } catch (Throwable var30) {
                              switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var29)) {
                                 case -143578935:
                                    var29 = jtzbdptybmnhquto(var29, 1708899880);
                                    var29 = 1657870957 ^ var29;
                                    return;
                                 default:
                                    throw new IllegalAccessException("Error in hash");
                              }
                           }

                           var29 = 1491254384 ^ var29;
                           return;
                        default:
                           throw new IllegalAccessException("Error in hash");
                     }
                  }

                  var29 = 1017672925 ^ var29;
                  return;
               case 1217966755:
                  break;
               case 1975734806:
               default:
                  throw new IOException();
            }
         }
      }
   }

   public static void publishBountyKill(String var0, String var1, double var2) {
      int var23 = 1658481376 ^ 352266469 ^ 1706307907;
      var23 = 1782829068 ^ var23;
      BountySyncDispatcher var4 = dispatcher;
      BountySyncDispatcher var9 = var4;
      var23 = 1429364551 ^ var23;
      if (var4 == null) {
         var23 = 554252327 ^ var23;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var23)) {
               case 116638905:
                  var23 ^= 393059779;
               case 1350076879:
                  try {
                     var9.publishBountyKill(var0, var1, var2);
                     var23 = 330220165 ^ var23;
                     break;
                  } catch (Throwable var25) {
                     switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var23)) {
                        case -596963727:
                           var23 = jtzbdptybmnhquto(var23, 869040794);
                           Throwable var10 = var25;
                           var23 = 2127911821 ^ var23;

                           try {
                              DonutSMPCore var15 = DonutSMPCore.getInstance();
                              Logger var16 = var15.getLogger();
                              String var19 = var10.getMessage();
                              String var20 = "[Bounty] publishBountyKill failed: " + var19;
                              var16.warning(var20);
                              var23 = 1067538388 ^ var23;
                           } catch (Throwable var24) {
                              switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var23)) {
                                 case -1264204085:
                                    var23 = 1244097914 ^ var23;
                                    var23 = 2012970622 ^ var23;
                                    return;
                                 default:
                                    throw new IllegalAccessException("Error in hash");
                              }
                           }

                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var23)) {
                                 case 89698881:
                                    return;
                                 case 232273436:
                                    var23 = 41764048 ^ var23;
                                    return;
                                 case 850944168:
                                 default:
                                    throw new IOException();
                                 case 2104453348:
                              }
                           }
                        default:
                           throw new RuntimeException("Error in hash");
                     }
                  }
               case 1372942012:
                  continue;
               case 1807052478:
               default:
                  throw new IOException();
            }

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var23)) {
                  case 230779415:
                  default:
                     throw new IOException();
                  case 231023682:
                     var23 = 1667958934 ^ var23;
                     return;
                  case 590708315:
                     return;
                  case 833054966:
               }
            }
         }
      }
   }

   public static void onIncomingBountyChanged(UUID var0, String var1, double var2, String var4, double var5) {
   }

   public static void onIncomingBountyKill(String var0, String var1, double var2) {
      String var25;
      int var34;
      label69: {
         var34 = 253297568 ^ 2145843713 ^ 1706307907;
         var34 = 711501430 ^ var34;
         var34 = 186757524 ^ var34;
         if (var1 != null) {
            var34 = 317336888 ^ var34;
            byte var21 = var1.isEmpty();
            if (var21 == (652800568 ^ var34)) {
               label49:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var34)) {
                     case 191067044:
                        var34 ^= 1674213565;
                     case 386869664:
                        break label49;
                     case 1156951212:
                        break;
                     case 1976863262:
                     default:
                        throw new IOException();
                  }
               }

               var25 = var1;
               var34 = 977369019 ^ var34;
               break label69;
            }

            var34 = 962868348 ^ var34;
         } else {
            var34 = 730732868 ^ var34;
         }

         var25 = nlrvidyryf(ohqhzwhcnvlirzi(), axeoohvnzweuieb(), var34);

         label59:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var34)) {
               case 101668226:
                  break label59;
               case 220258223:
                  var34 ^= 1626291066;
                  break label59;
               case 561611486:
                  break;
               case 1260542703:
               default:
                  throw new IOException();
            }
         }
      }

      String var9 = "#FF0000☠ " + var0 + " was slain by " + var25;
      String var6 = var9;
      var34 = 195232797 ^ var34;
      Collection var10 = Bukkit.getOnlinePlayers();
      Iterator var11 = var10.iterator();
      Iterator var7 = var11;
      var34 = 674262058 ^ var34;

      while(true) {
         byte var13 = var7.hasNext();
         if (var13 == (1559270665 ^ var34)) {
            var34 = jtzbdptybmnhquto(var34, 1375665735);

            try {
               o0oOoOKoOoOK var18 = o0oOoOKoOoOK.getInstance();
               var18.dropBountyByName(var0);
               var34 = 1408978301 ^ var34;
            } catch (Throwable var30) {
               switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var34)) {
                  case 1752390256:
                     var34 = jtzbdptybmnhquto(var34, 1461496637);
                     var34 = 1306441462 ^ var34;
                     return;
                  default:
                     throw new IOException("Error in hash");
               }
            }

            var34 = 1228492982 ^ var34;
            return;
         }

         var34 = 1381723096 ^ var34;
         Object var15 = var7.next();
         Player var16 = (Player)var15;
         var34 = 1908742888 ^ var34;
         String var23 = oOo0KKoOoOK.color(var6);
         var16.sendMessage(var23);
         var34 = 1156144433 ^ var34;
         var34 = jtzbdptybmnhquto(var34, 1735863297);
      }
   }

   public static String nlrvidyryf(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] axeoohvnzweuieb() {
      return new byte[]{72, 60, 87, 1, 28, 88, 117, 30, 81, 69, 6, 31, 81, 31, 4, 78, 2, 32, 99, 10, 46, 116, 111, 81, 103, 97, 89, 80, 122, 30, 27, 120, 73, 96, 95, 36, 61, 114, 49, 50, 102, 30, 46, 49, 23, 11, 21, 53, 57, 76, 78, 121, 56, 30, 85, 32, 1, 85, 90, 125, 92, 119, 91, 57, 75, 61, 89, 10, 53, 46, 7, 45, 122, 80, 24, 108, 122, 36, 74, 52, 38, 27, 16, 77, 107, 104, 121, 73, 116, 58, 89, 126, 26, 7, 121, 46, 53, 72, 80, 63, 93, 8, 13, 106, 3, 41, 43, 63, 127, 90, 3, 35, 39, 106, 126, 47, 21};
   }

   private static byte[] ohqhzwhcnvlirzi() {
      return new byte[]{-125, -15, 110, 71, 45, 15, 65, 76, 99, 30, 52, 73, 98, 89, 61, 20};
   }

   private static int jtzbdptybmnhquto(int var0, int var1) {
      return var0 ^ var1;
   }

   static {
   }
}
