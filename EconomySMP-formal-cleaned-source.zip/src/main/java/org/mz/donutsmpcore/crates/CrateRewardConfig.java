package org.mz.donutsmpcore.crates;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimMaterial;
import org.bukkit.inventory.meta.trim.TrimPattern;
import org.bukkit.potion.PotionType;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.o0oOKKoOoOK;
import skido.oOo0KKoOoOK;

public class CrateRewardConfig {
   private final File file;
   private FileConfiguration config;

   public CrateRewardConfig(String crateType) {
      File folder = new File(DonutSMPCore.getInstance().getDataFolder(), "rewards");
      if (!folder.exists()) {
         folder.mkdirs();
      }

      this.file = new File(folder, crateType.toLowerCase() + "craterewards.yml");
      this.config = YamlConfiguration.loadConfiguration(this.file);
      if (!this.file.exists()) {
         this.saveDefaultConfig();
      }

   }

   private void saveDefaultConfig() {
      Map<String, Object> defaultMap = new HashMap();
      switch (this.file.getName().toLowerCase()) {
         case "core/rewards/commoncraterewards.yml":
            this.createDefaultCommonConfig(defaultMap);
            break;
         case "core/rewards/primecraterewards.yml":
            this.createDefaultPrimeConfig(defaultMap);
            break;
         case "core/rewards/crimsoncraterewards.yml":
            this.createDefaultCrimsonConfig(defaultMap);
            break;
         case "core/rewards/amethystcraterewards.yml":
            this.createDefaultAmethystConfig(defaultMap);
            break;
         case "core/rewards/goldcraterewards.yml":
            this.createDefaultGoldConfig(defaultMap);
            break;
         default:
            Bukkit.getLogger().warning("No default config defined for " + this.file.getName() + ", creating empty file.");
            return;
      }

      this.config.options().copyDefaults(true);
      this.config.addDefaults(defaultMap);

      try {
         this.config.save(this.file);
         DonutSMPCore.getInstance().getLogger().info("Generated default rewards file: " + this.file.getName());
      } catch (IOException e) {
         e.printStackTrace();
      }

   }

   private void createDefaultCommonConfig(Map<String, Object> map) {
      map.put("items", new HashMap<String, Map<String, Object>>() {
         {
            for(int i = 0; i <= 26; ++i) {
               String key = String.valueOf(i);
               if (i >= 10 && i <= 16) {
                  switch (i) {
                     case 10:
                        this.put(key, Map.of("material", "DIAMOND_HELMET", "display-name", "&fDiamond Helmet", "enchants", List.of("AQUA_AFFINITY:1", "PROTECTION:1", "RESPIRATION:2"), "flags", List.of("HIDE_ENCHANTS")));
                        break;
                     case 11:
                        this.put(key, Map.of("material", "DIAMOND_CHESTPLATE", "display-name", "&fDiamond Chestplate", "enchants", List.of("PROTECTION:1"), "flags", List.of("HIDE_ENCHANTS")));
                        break;
                     case 12:
                        this.put(key, Map.of("material", "DIAMOND_LEGGINGS", "display-name", "&fDiamond Leggings", "enchants", List.of("PROTECTION:1", "SWIFT_SNEAK:2"), "flags", List.of("HIDE_ENCHANTS")));
                        break;
                     case 13:
                        this.put(key, Map.of("material", "DIAMOND_BOOTS", "display-name", "&fDiamond Boots", "enchants", List.of("FEATHER_FALLING:4", "DEPTH_STRIDER:2", "PROTECTION:1"), "flags", List.of("HIDE_ENCHANTS")));
                        break;
                     case 14:
                        this.put(key, Map.of("material", "DIAMOND_SWORD", "display-name", "&fDiamond Sword", "enchants", List.of("SHARPNESS:1", "LOOTING:2"), "flags", List.of("HIDE_ENCHANTS")));
                        break;
                     case 15:
                        this.put(key, Map.of("material", "DIAMOND_PICKAXE", "display-name", "&fDiamond Pickaxe", "enchants", List.of("EFFICIENCY:2", "FORTUNE:1"), "flags", List.of("HIDE_ENCHANTS")));
                        break;
                     case 16:
                        this.put(key, Map.of("material", "DIAMOND_SHOVEL", "display-name", "&fDiamond Shovel", "enchants", List.of("EFFICIENCY:3"), "flags", List.of("HIDE_ENCHANTS")));
                  }
               } else {
                  this.put(key, Map.of("material", "GRAY_STAINED_GLASS_PANE", "display-name", " ", "lore", List.of("#AAAAAAWith a ᴋᴇʏᴀʟʟ ᴋᴇʏ you can choose", "#AAAAAAwhich of the 7 you want.")));
               }
            }

         }
      });
   }

   public ItemStack getItem(int slot) {
      String path = "items." + slot;
      if (!this.config.contains(path)) {
         return null;
      } else {
         String materialStr = this.config.getString(path + ".material");
         if (materialStr == null) {
            return null;
         } else {
            Material material = Material.matchMaterial(materialStr);
            if (material == null) {
               return null;
            } else {
               ItemStack item = new ItemStack(material);
               ItemMeta meta = item.getItemMeta();
               if (meta == null) {
                  return item;
               } else {
                  String displayName = this.config.getString(path + ".display-name");
                  if (displayName != null) {
                     meta.setDisplayName(oOo0KKoOoOK.color(displayName));
                  }

                  List<String> lore = this.config.getStringList(path + ".lore");
                  if (!lore.isEmpty()) {
                     meta.setLore(lore.stream().map(oOo0KKoOoOK::color).toList());
                  }

                  for(String enchantStr : this.config.getStringList(path + ".enchants")) {
                     String[] parts = enchantStr.split(":");
                     if (parts.length == 2) {
                        Enchantment ench = Enchantment.getByName(parts[0].toUpperCase());
                        if (ench != null) {
                           try {
                              int level = Integer.parseInt(parts[1]);
                              meta.addEnchant(ench, level, true);
                           } catch (NumberFormatException var19) {
                           }
                        }
                     }
                  }

                  for(String flag : this.config.getStringList(path + ".flags")) {
                     try {
                        meta.addItemFlags(new ItemFlag[]{ItemFlag.valueOf(flag)});
                     } catch (IllegalArgumentException var18) {
                     }
                  }

                  boolean applyTrim = this.config.getBoolean(path + ".apply-trim", false);
                  String trimPatternStr = this.config.getString(path + ".trim-pattern");
                  String trimMaterialStr = this.config.getString(path + ".trim-material");
                  if (trimPatternStr != null || trimMaterialStr != null || applyTrim) {
                     this.applyConfiguredTrim(meta, trimPatternStr, trimMaterialStr);
                  }

                  String potionType = this.config.getString(path + ".potion-type");
                  if (potionType != null && meta instanceof PotionMeta) {
                     PotionMeta potionMeta = (PotionMeta)meta;

                     try {
                        o0oOKKoOoOK.setBasePotionType(potionMeta, PotionType.valueOf(potionType.toUpperCase()));
                     } catch (IllegalArgumentException var17) {
                     }
                  }

                  item.setItemMeta(meta);
                  return item;
               }
            }
         }
      }
   }

   public String getCommand(int slot) {
      String path = "items." + slot + ".command";
      return this.config.getString(path);
   }

   private void applyConfiguredTrim(ItemMeta meta, String patternStr, String materialStr) {
      if (meta instanceof ArmorMeta armorMeta) {
         TrimPattern pattern = resolveTrimPattern(patternStr != null ? patternStr : "snout");
         if (pattern == null) {
            Bukkit.getLogger().warning("[Crates] Unknown trim pattern: " + patternStr + ", falling back to SNOUT");
            pattern = TrimPattern.SNOUT;
         }

         TrimMaterial material = resolveTrimMaterial(materialStr != null ? materialStr : "redstone");
         if (material == null) {
            Bukkit.getLogger().warning("[Crates] Unknown trim material: " + materialStr + ", falling back to REDSTONE");
            material = TrimMaterial.REDSTONE;
         }

         armorMeta.setTrim(new ArmorTrim(material, pattern));
      }
   }

   private static TrimPattern resolveTrimPattern(String name) {
      if (name != null && !name.isEmpty()) {
         try {
            return (TrimPattern)Registry.TRIM_PATTERN.get(NamespacedKey.minecraft(name.toLowerCase().trim()));
         } catch (Exception var5) {
            try {
               for(TrimPattern p : Registry.TRIM_PATTERN) {
                  if (p.getKey().getKey().equalsIgnoreCase(name.trim())) {
                     return p;
                  }
               }
            } catch (Exception var4) {
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private static TrimMaterial resolveTrimMaterial(String name) {
      if (name != null && !name.isEmpty()) {
         try {
            return (TrimMaterial)Registry.TRIM_MATERIAL.get(NamespacedKey.minecraft(name.toLowerCase().trim()));
         } catch (Exception var5) {
            try {
               for(TrimMaterial m : Registry.TRIM_MATERIAL) {
                  if (m.getKey().getKey().equalsIgnoreCase(name.trim())) {
                     return m;
                  }
               }
            } catch (Exception var4) {
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private void createDefaultPrimeConfig(Map<String, Object> map) {
      Map<String, Object> items = new HashMap();

      for(int i = 10; i <= 16; ++i) {
         String slot = String.valueOf(i);
         switch (i) {
            case 10:
               items.put(slot, Map.of("material", "NETHERITE_HELMET", "display-name", "&9Prime Netherite Helmet", "enchants", List.of("AQUA_AFFINITY:1", "PROTECTION:4", "RESPIRATION:3", "UNBREAKING:3", "MENDING:1")));
               break;
            case 11:
               items.put(slot, Map.of("material", "NETHERITE_CHESTPLATE", "display-name", "&9Prime Netherite Chestplate", "enchants", List.of("PROTECTION:4", "UNBREAKING:3", "MENDING:1")));
               break;
            case 12:
               items.put(slot, Map.of("material", "NETHERITE_LEGGINGS", "display-name", "&9Prime Netherite Leggings", "enchants", List.of("SWIFT_SNEAK:3", "BLAST_PROTECTION:4", "UNBREAKING:3", "MENDING:1")));
               break;
            case 13:
               items.put(slot, Map.of("material", "NETHERITE_BOOTS", "display-name", "&9Prime Netherite Boots", "enchants", List.of("DEPTH_STRIDER:3", "FEATHER_FALLING:4", "PROTECTION:4", "SOUL_SPEED:3", "UNBREAKING:3", "MENDING:1")));
               break;
            case 14:
               items.put(slot, Map.of("material", "NETHERITE_SWORD", "display-name", "&9Prime Netherite Sword", "enchants", List.of("LOOTING:3", "KNOCKBACK:1", "SHARPNESS:5", "SWEEPING_EDGE:3", "UNBREAKING:3", "MENDING:1")));
               break;
            case 15:
               items.put(slot, Map.of("material", "CROSSBOW", "display-name", "&9Prime Crossbow", "enchants", List.of("MULTISHOT:1", "QUICK_CHARGE:3", "UNBREAKING:3", "MENDING:1")));
               break;
            case 16:
               items.put(slot, Map.of("material", "TRIDENT", "display-name", "&9Prime Trident", "enchants", List.of("RIPTIDE:3", "UNBREAKING:3", "MENDING:1")));
         }
      }

      map.put("items", items);
   }

   private void createDefaultCrimsonConfig(Map<String, Object> map) {
      Map<String, Object> items = new HashMap();

      for(int i = 10; i <= 16; ++i) {
         String slot = String.valueOf(i);
         switch (i) {
            case 10:
               items.put(slot, Map.ofEntries(Map.entry("material", "NETHERITE_HELMET"), Map.entry("display-name", "&cCrimson Netherite Helmet"), Map.entry("enchants", List.of("AQUA_AFFINITY:1", "PROTECTION:4", "RESPIRATION:3", "THORNS:3", "UNBREAKING:3", "MENDING:1")), Map.entry("trim-pattern", "snout"), Map.entry("trim-material", "redstone")));
               break;
            case 11:
               items.put(slot, Map.ofEntries(Map.entry("material", "NETHERITE_CHESTPLATE"), Map.entry("display-name", "&cCrimson Netherite Chestplate"), Map.entry("enchants", List.of("PROTECTION:4", "THORNS:3", "UNBREAKING:3", "MENDING:1")), Map.entry("trim-pattern", "snout"), Map.entry("trim-material", "redstone")));
               break;
            case 12:
               items.put(slot, Map.ofEntries(Map.entry("material", "NETHERITE_LEGGINGS"), Map.entry("display-name", "&cCrimson Netherite Leggings"), Map.entry("enchants", List.of("SWIFT_SNEAK:3", "PROTECTION:4", "THORNS:3", "UNBREAKING:3", "MENDING:1")), Map.entry("trim-pattern", "snout"), Map.entry("trim-material", "redstone")));
               break;
            case 13:
               items.put(slot, Map.ofEntries(Map.entry("material", "NETHERITE_BOOTS"), Map.entry("display-name", "&cCrimson Netherite Boots"), Map.entry("enchants", List.of("DEPTH_STRIDER:3", "FEATHER_FALLING:4", "PROTECTION:4", "SOUL_SPEED:3", "THORNS:3", "UNBREAKING:3", "MENDING:1")), Map.entry("trim-pattern", "snout"), Map.entry("trim-material", "redstone")));
               break;
            case 14:
               items.put(slot, Map.of("material", "NETHERITE_SWORD", "display-name", "&cCrimson Netherite Sword", "enchants", List.of("KNOCKBACK:2", "FIRE_ASPECT:2", "SHARPNESS:5", "SWEEPING_EDGE:3", "LOOTING:3", "UNBREAKING:3", "MENDING:1")));
               break;
            case 15:
               items.put(slot, Map.of("material", "NETHERITE_AXE", "display-name", "&cCrimson Netherite Axe", "enchants", List.of("EFFICIENCY:5", "SILK_TOUCH:1", "SHARPNESS:5", "UNBREAKING:3", "MENDING:1")));
               break;
            case 16:
               items.put(slot, Map.of("material", "NETHERITE_PICKAXE", "display-name", "&cCrimson Netherite Pickaxe", "enchants", List.of("EFFICIENCY:5", "SILK_TOUCH:1", "UNBREAKING:3", "MENDING:1")));
         }
      }

      map.put("items", items);
   }

   private void createDefaultAmethystConfig(Map<String, Object> map) {
      Map<String, Object> items = new HashMap();

      for(int i = 0; i <= 26; ++i) {
         String slot = String.valueOf(i);
         if (i >= 10 && i <= 15) {
            switch (i) {
               case 10:
                  items.put(slot, Map.ofEntries(Map.entry("material", "NETHERITE_AXE"), Map.entry("display-name", "#A503FCᴀᴍᴇᴛʜʏsᴛ ᴀxᴇ"), Map.entry("lore", List.of("#AAAAAABreaks Trees Instantly", "#555555Self Destruct:", "#5555552d 23h 59m")), Map.entry("enchants", List.of("SILK_TOUCH:1", "UNBREAKING:3", "MENDING:1", "EFFICIENCY:5")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% amethyst-axe")));
                  break;
               case 11:
                  items.put(slot, Map.ofEntries(Map.entry("material", "NETHERITE_AXE"), Map.entry("display-name", "#A503FCᴀᴍᴇᴛʜʏsᴛ sᴇʟʟ ᴀxᴇ"), Map.entry("lore", List.of("#AAAAAAInstantly Sells All Items in A Chest", "#555555Self Destruct:", "#5555552d 23h 59m")), Map.entry("enchants", List.of("MENDING:1", "UNBREAKING:3", "EFFICIENCY:5")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% amethyst-sell-axe")));
                  break;
               case 12:
                  items.put(slot, Map.ofEntries(Map.entry("material", "NETHERITE_PICKAXE"), Map.entry("display-name", "#A503FCᴀᴍᴇᴛʜʏsᴛ ᴘɪᴄᴋᴀxᴇ"), Map.entry("lore", List.of("#AAAAAABreaks 9 Blocks at Once", "#555555Self Destruct:", "#5555552d 23h 59m")), Map.entry("enchants", List.of("MENDING:1", "UNBREAKING:3", "EFFICIENCY:5")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% amethyst-pickaxe")));
                  break;
               case 13:
                  items.put(slot, Map.ofEntries(Map.entry("material", "NETHERITE_SHOVEL"), Map.entry("display-name", "#A503FCᴀᴍᴇᴛʜʏsᴛ sʜᴏᴠᴇʟ"), Map.entry("lore", List.of("#AAAAAA9 Blocks Per Break", "#555555Self Destruct:", "#5555552d 23h 59m")), Map.entry("enchants", List.of("MENDING:1", "UNBREAKING:3", "EFFICIENCY:5")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% amethyst-shovel")));
                  break;
               case 14:
                  items.put(slot, Map.ofEntries(Map.entry("material", "POTION"), Map.entry("display-name", "#A503FCsʜᴀʀᴅ ʙᴏᴏsᴛᴇʀ"), Map.entry("lore", List.of("&74x Shard Production for 24 hours")), Map.entry("potion-type", "WATER"), Map.entry("enchants", List.of("UNBREAKING:1")), Map.entry("flags", List.of("HIDE_ENCHANTS", "HIDE_ADDITIONAL_TOOLTIP")), Map.entry("command", "donutsmpcore give %player% shard-booster")));
                  break;
               case 15:
                  items.put(slot, Map.ofEntries(Map.entry("material", "BUCKET"), Map.entry("display-name", "#A503FCᴀᴍᴇᴛʜʏsᴛ ʙᴜᴄᴋᴇᴛ"), Map.entry("lore", List.of("#AAAAAADrains 27 Water At Once", "#555555Self Destruct:", "#5555552d 23h 59m")), Map.entry("enchants", List.of("UNBREAKING:1")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% amethyst-bucket")));
            }
         } else {
            items.put(slot, Map.of("material", "GRAY_STAINED_GLASS_PANE", "display-name", " ", "lore", List.of("#AAAAAAWith a ᴀᴍᴇᴛʜʏsᴛ ᴋᴇʏ you can choose", "#AAAAAAwhich of the 6 you want.")));
         }
      }

      map.put("items", items);
   }

   private void createDefaultGoldConfig(Map<String, Object> map) {
      Map<String, Object> items = new HashMap();

      for(int i = 0; i <= 26; ++i) {
         String slot = String.valueOf(i);
         if (i >= 10 && i <= 16) {
            switch (i) {
               case 10:
                  items.put(slot, Map.ofEntries(Map.entry("material", "SPAWNER"), Map.entry("display-name", "#FF55FFCow Spawner"), Map.entry("enchants", List.of("MENDING:1")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% cow-spawner")));
                  break;
               case 11:
                  items.put(slot, Map.ofEntries(Map.entry("material", "SPAWNER"), Map.entry("display-name", "#FF55FFSpider Spawner"), Map.entry("enchants", List.of("MENDING:1")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% spider-spawner")));
                  break;
               case 12:
                  items.put(slot, Map.ofEntries(Map.entry("material", "SPAWNER"), Map.entry("display-name", "#FF55FFZombie Pigman Spawner"), Map.entry("enchants", List.of("MENDING:1")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% zombie-pigman-spawner")));
                  break;
               case 13:
                  items.put(slot, Map.ofEntries(Map.entry("material", "SPAWNER"), Map.entry("display-name", "#FF55FFSkeleton Spawner"), Map.entry("enchants", List.of("MENDING:1")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% skeleton-spawner")));
                  break;
               case 14:
                  items.put(slot, Map.ofEntries(Map.entry("material", "SPAWNER"), Map.entry("display-name", "#FF55FFBlaze Spawner"), Map.entry("enchants", List.of("MENDING:1")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% blaze-spawner")));
                  break;
               case 15:
                  items.put(slot, Map.ofEntries(Map.entry("material", "SPAWNER"), Map.entry("display-name", "#FF55FFCreeper Spawner"), Map.entry("enchants", List.of("MENDING:1")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% creeper-spawner")));
                  break;
               case 16:
                  items.put(slot, Map.ofEntries(Map.entry("material", "SPAWNER"), Map.entry("display-name", "#FF55FFIron Golem Spawner"), Map.entry("enchants", List.of("UNBREAKING:1")), Map.entry("flags", List.of("HIDE_ENCHANTS")), Map.entry("command", "donutsmpcore give %player% iron-golem-spawner")));
            }
         } else {
            items.put(slot, Map.of("material", "GRAY_STAINED_GLASS_PANE", "display-name", " ", "lore", List.of("#AAAAAAWith a ɢᴏʟᴅ ᴋᴇʏ you can choose", "#AAAAAAwhich of the 7 you want.")));
         }
      }

      map.put("items", items);
   }
}
