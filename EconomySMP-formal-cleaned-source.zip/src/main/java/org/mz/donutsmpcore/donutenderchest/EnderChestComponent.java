package org.mz.donutsmpcore.donutenderchest;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import org.mz.donutsmpcore.DonutSMPCore;
import skido.oOo0KKoOoOK;
import skido.oOoOo0KKoOK;

public class EnderChestComponent {
   private static EnderChestComponent instance;
   public static final int EXTRA_SLOTS = 27;
   public static final int TOTAL_SIZE = 54;
   public static final int VANILLA_SIZE = 27;
   private final Map<UUID, Inventory> openChests;
   private final Map<UUID, Location> chestBlocks;
   private static byte[] bauqerkuds;

   private EnderChestComponent() {
      ConcurrentHashMap var2 = new ConcurrentHashMap();
      this.openChests = var2;
      ConcurrentHashMap var5 = new ConcurrentHashMap();
      this.chestBlocks = var5;
   }

   public static EnderChestComponent getInstance() {
      int var5 = 919274779 ^ 1786705775 ^ 1455863621;
      var5 = 1275420 ^ var5;
      EnderChestComponent var0 = instance;
      if (var0 == null) {
         var5 = 1706930731 ^ var5;
         EnderChestComponent var1 = new EnderChestComponent();
         instance = var1;
         var5 = 868723924 ^ var5;
      } else {
         var5 = quvzakhjalouinli(var5, 1450843903);
      }

      EnderChestComponent var2 = instance;
      return var2;
   }

   public boolean isEnabled() {
      int var8 = 475823677 ^ 1064850229 ^ 673084569;
      var8 = 372384432 ^ var8;
      DonutSMPCore var1 = DonutSMPCore.getInstance();
      FileConfiguration var4 = var1.getConfig();
      String var2 = tghwtuczyw(kuewhhewrshurhj(), var8);
      byte var3 = (byte)(487095073 ^ var8);
      boolean var5 = var4.getBoolean(var2, (boolean)var3);
      return var5;
   }

   public String getTitle() {
      int var11 = 1720686361 ^ 421727719 ^ 673084569;
      var11 = 1487374342 ^ var11;
      DonutSMPCore var1 = DonutSMPCore.getInstance();
      FileConfiguration var5 = var1.getConfig();
      String var2 = tghwtuczyw(xplrwdbrskrtkvy(), var11);
      String var3 = tghwtuczyw(ashcqydrdeyzmno(), var11);
      String var6 = var5.getString(var2, var3);
      var11 = 1129585814 ^ var11;
      String var8 = oOo0KKoOoOK.color(var6);
      return var8;
   }

   public boolean isPermissionRequired() {
      int var8 = 1107897907 ^ 2027635338 ^ 673084569;
      var8 = 234939454 ^ var8;
      DonutSMPCore var1 = DonutSMPCore.getInstance();
      FileConfiguration var4 = var1.getConfig();
      String var2 = tghwtuczyw(kojttznvsykrnaj(), var8);
      byte var3 = (byte)(483195934 ^ var8);
      var8 = 82677379 ^ var8;
      boolean var5 = var4.getBoolean(var2, (boolean)var3);
      var8 = 1862614939 ^ var8;
      return var5;
   }

   public String getPermission() {
      int var8 = 847943356 ^ 835020265 ^ 673084569;
      var8 = 1941045286 ^ var8;
      DonutSMPCore var1 = DonutSMPCore.getInstance();
      FileConfiguration var4 = var1.getConfig();
      String var2 = tghwtuczyw(mxgfnwevallqrvi(), var8);
      String var3 = tghwtuczyw(btszyvbafofjfbo(), var8);
      var8 = 146589374 ^ var8;
      String var5 = var4.getString(var2, var3);
      var8 = 146460420 ^ var8;
      return var5;
   }

   public boolean interceptCommandOpens() {
      int var8 = 2039926042 ^ 2033367621 ^ 673084569;
      var8 = 1006060591 ^ var8;
      DonutSMPCore var1 = DonutSMPCore.getInstance();
      FileConfiguration var4 = var1.getConfig();
      String var2 = tghwtuczyw(oidxjjmabqivygl(), var8);
      byte var3 = (byte)(323831784 ^ var8);
      var8 = 1590397840 ^ var8;
      boolean var5 = var4.getBoolean(var2, (boolean)var3);
      var8 = 2142682326 ^ var8;
      return var5;
   }

   public boolean isCrossServerEnabled() {
      int var14 = 15339498 ^ 1860161155 ^ 673084569;
      var14 = 2061874540 ^ var14;
      DonutSMPCore var1 = DonutSMPCore.getInstance();
      FileConfiguration var4 = var1.getConfig();
      String var2 = tghwtuczyw(ensjxmnfbwpeepq(), var14);
      byte var3 = (byte)(1020133532 ^ var14);
      var14 = 117671441 ^ var14;
      byte var5 = var4.getBoolean(var2, (boolean)var3);
      byte var9;
      if (var5 != (1003325069 ^ var14)) {
         var14 = 514447411 ^ var14;
         DonutSMPCore var6 = DonutSMPCore.getInstance();
         FileConfiguration var7 = var6.getConfig();
         String var10 = tghwtuczyw(sdxcdzheetrcsnj(), var14);
         byte var11 = (byte)(627334846 ^ var14);
         var14 = 236557094 ^ var14;
         byte var8 = var7.getBoolean(var10, (boolean)var11);
         if (var8 != (729664920 ^ var14)) {
            var14 = 1669180286 ^ var14;
            var9 = (byte)(1207985895 ^ var14);
            var14 = quvzakhjalouinli(var14, 1700920883);
            return (boolean)var9;
         }

         label26:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var14)) {
               case 71537963:
                  var14 ^= 326156177;
               case 1100841617:
                  break label26;
               case 1129085212:
                  break;
               case 1135907903:
               default:
                  throw new RuntimeException();
            }
         }
      } else {
         label36:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var14)) {
               case 64884604:
                  var14 ^= 62977156;
                  break label36;
               case 153868377:
                  break;
               case 390050206:
                  break label36;
               case 678879882:
               default:
                  throw new RuntimeException();
            }
         }
      }

      var9 = (byte)(940405257 ^ var14);
      var14 = 359459548 ^ var14;
      return (boolean)var9;
   }

   public boolean hasEnderChestAccess(Player var1) {
      int var11 = 173159801 ^ 1217139064 ^ 673084569;
      var11 = 275913531 ^ var11;
      byte var4 = this.isPermissionRequired();
      if (var4 == (2058505123 ^ var11)) {
         var11 = 1201719951 ^ var11;
         byte var7 = (byte)(1024622893 ^ var11);
         return (boolean)var7;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var11)) {
               case 158572662:
               default:
                  throw new RuntimeException();
               case 230230073:
                  var11 = 1665313634 ^ var11;
               case 1456792005:
                  String var8 = this.getPermission();
                  boolean var6 = var1.hasPermission(var8);
                  return var6;
               case 758437670:
            }
         }
      }
   }

   public void trackOpen(UUID var1, Inventory var2, Location var3) {
      int var18 = 2036930273 ^ 2018103151 ^ 673084569;
      var18 = 642352280 ^ var18;
      Map var7 = this.openChests;
      var7.put(var1, var2);
      var18 = 1523826820 ^ var18;
      if (var3 != null) {
         var18 = 832518251 ^ var18;
         Map var11 = this.chestBlocks;
         Location var15 = var3.clone();
         var11.put(var1, var15);
         var18 = 1820235584 ^ var18;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var18)) {
               case 99604001:
                  var18 = 1575071531 ^ var18;
                  return;
               case 477180026:
                  return;
               case 1936499159:
                  break;
               case 2124217111:
               default:
                  throw new IOException();
            }
         }
      }
   }

   public void untrackOpen(UUID var1) {
      int var12 = 199553989 ^ 711745872 ^ 673084569;
      var12 = 897272389 ^ var12;
      Map var4 = this.openChests;
      var4.remove(var1);
      var12 = 1385090209 ^ var12;
      Map var7 = this.chestBlocks;
      var7.remove(var1);
      var12 = 1036944868 ^ var12;
   }

   public boolean hasOpenChest(UUID var1) {
      int var8 = 418523136 ^ 821036551 ^ 673084569;
      var8 = 1711822217 ^ var8;
      Map var4 = this.openChests;
      boolean var5 = var4.containsKey(var1);
      return var5;
   }

   public Inventory getOpenChest(UUID var1) {
      int var9 = 1757290789 ^ 1984125616 ^ 673084569;
      var9 = 1789298054 ^ var9;
      Map var4 = this.openChests;
      Object var5 = var4.get(var1);
      Inventory var6 = (Inventory)var5;
      return var6;
   }

   public Location getChestBlock(UUID var1) {
      int var9 = 1587925198 ^ 2002515820 ^ 673084569;
      var9 = 2017991366 ^ var9;
      Map var4 = this.chestBlocks;
      Object var5 = var4.get(var1);
      Location var6 = (Location)var5;
      return var6;
   }

   public Map<UUID, Inventory> getOpenChests() {
      int var5 = 1940547917 ^ 1844037855 ^ 673084569;
      var5 = 220193469 ^ var5;
      Map var2 = this.openChests;
      return var2;
   }

   public ItemStack[] loadExtraItemsSync(UUID param1) {
   }

   public void saveExtraItemsSync(UUID param1, ItemStack[] param2) {
   }

   public ItemStack[] loadVanillaItemsSync(UUID param1) {
   }

   public void saveVanillaItemsSync(UUID param1, ItemStack[] param2) {
   }

   public static String serializeItems(ItemStack[] var0) {
      int var38 = 2029237238 ^ 664971099 ^ 1455863621;
      var38 = 1678812337 ^ var38;

      Exception var10000;
      label67: {
         ByteArrayOutputStream var3;
         BukkitObjectOutputStream var4;
         ItemStack[] var5;
         int var6;
         int var7;
         try {
            ByteArrayOutputStream var1 = new ByteArrayOutputStream();
            var3 = var1;
            var38 = 2099086984 ^ var38;
            BukkitObjectOutputStream var9 = new BukkitObjectOutputStream(var1);
            var4 = var9;
            var38 = 1083943119 ^ var38;
            int var26 = var0.length;
            var9.writeInt(var26);
            var38 = 1489744186 ^ var38;
            var5 = var0;
            int var13 = var0.length;
            var6 = var13;
            byte var14 = (byte)(147494948 ^ var38);
            var7 = var14;
            var38 = 1149113383 ^ var38;
         } catch (Exception var40) {
            var10000 = var40;
            boolean var10001 = false;
            break label67;
         }

         label59:
         while(true) {
            try {
               if (var7 >= var6) {
                  break;
               }

               int var46 = 683570444 ^ var38;
               ItemStack var17 = var5[var7];
               int var47 = 1144552680 ^ var46;
               var4.writeObject(var17);
               var38 = 1328391381 ^ var47;
               var7 += 1864311091 ^ var38;
            } catch (Exception var41) {
               var10000 = var41;
               boolean var53 = false;
               break label67;
            }

            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var38)) {
                  case 122437455:
                     var38 ^= 598453553;
                  case 125386368:
                     continue label59;
                  case 1846778009:
                  default:
                     throw new IllegalAccessException();
                  case 2116635947:
               }
            }
         }

         var38 ^= 2024284709;

         try {
            var4.close();
            var38 = 853976131 ^ var38;
            Base64.Encoder var23 = Base64.getEncoder();
            byte[] var34 = var3.toByteArray();
            String var24 = var23.encodeToString(var34);
            var38 = 2098063065 ^ var38;
            return var24;
         } catch (Exception var39) {
            var10000 = var39;
            boolean var54 = false;
         }
      }

      switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var38)) {
         case -2146875150 -> var38 = quvzakhjalouinli(var38, 32181039);
         case -2066477432 -> var38 = quvzakhjalouinli(var38, 1097901024);
         case -1595576015 -> var38 = quvzakhjalouinli(var38, 1710656535);
         case 26488633 -> var38 = quvzakhjalouinli(var38, 1910024150);
         case 542623867 -> var38 = quvzakhjalouinli(var38, 903928638);
         case 936399656 -> var38 = 1460676692 ^ var38;
         case 1179959584 -> var38 = 1495317013 ^ var38;
         case 1705271322 -> var38 = 492744242 ^ var38;
         case 1815624395 -> var38 = 1013785960 ^ var38;
         case 2029586835 -> var38 = 1056244483 ^ var38;
         default -> throw new RuntimeException("Error in hash");
      }

      Exception var19 = var10000;
      var38 = 1795123240 ^ var38;
      Logger var20 = Bukkit.getLogger();
      String var31 = var19.getMessage();
      String var32 = "[DonutEnderChest] Failed to serialize items: " + var31;
      var20.severe(var32);
      var38 = 811003023 ^ var38;
      String var21 = tghwtuczyw(yjjhjtraubouecv(), var38);
      return var21;
   }

   public static ItemStack[] deserializeItems(String var0) {
      int var36 = 1042545973 ^ 305078108 ^ 1455863621;
      var36 = 1925188415 ^ var36;

      Exception var10000;
      label60: {
         BukkitObjectInputStream var5;
         int var6;
         ItemStack[] var7;
         int var8;
         try {
            Base64.Decoder var2 = Base64.getDecoder();
            byte[] var28 = var2.decode(var0);
            ByteArrayInputStream var1 = new ByteArrayInputStream(var28);
            var36 = 296733397 ^ var36;
            BukkitObjectInputStream var9 = new BukkitObjectInputStream(var1);
            var5 = var9;
            var36 = 2122046963 ^ var36;
            int var11 = var9.readInt();
            var6 = var11;
            var36 = 1440885773 ^ var36;
            ItemStack[] var13 = new ItemStack[var11];
            var7 = var13;
            var36 = 1751358410 ^ var36;
            byte var14 = (byte)(1516240626 ^ var36);
            var8 = var14;
            var36 = 835526044 ^ var36;
         } catch (Exception var38) {
            var10000 = var38;
            boolean var10001 = false;
            break label60;
         }

         while(true) {
            try {
               if (var8 >= var6) {
                  break;
               }

               int var45 = 1981744284 ^ var36;
               Object var31 = var5.readObject();
               ItemStack var32 = (ItemStack)var31;
               var7[var8] = var32;
               var36 = 1959800421 ^ var45;
               var8 += 1767754134 ^ var36;
            } catch (Exception var39) {
               var10000 = var39;
               boolean var52 = false;
               break label60;
            }

            var36 = quvzakhjalouinli(var36, 47131385);
         }

         label46:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var36)) {
               case 7140151:
                  var36 ^= 654400054;
               case 360198408:
                  try {
                     var5.close();
                     var36 = 1068397207 ^ var36;
                     var36 = 788515842 ^ var36;
                     return var7;
                  } catch (Exception var37) {
                     var10000 = var37;
                     boolean var53 = false;
                     break label46;
                  }
               case 331383973:
               default:
                  throw new RuntimeException();
               case 1041901760:
            }
         }
      }

      switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var36)) {
         case -1847383615 -> var36 = 1979365775 ^ var36;
         case -1712431493 -> var36 = 888870776 ^ var36;
         case -852711888 -> var36 = 1583564913 ^ var36;
         case -754976878 -> var36 = quvzakhjalouinli(var36, 496575045);
         case -328253552 -> var36 = 1514879813 ^ var36;
         case 1056065963 -> var36 = quvzakhjalouinli(var36, 538482050);
         case 1079177368 -> var36 = quvzakhjalouinli(var36, 1338802852);
         case 1257131195 -> var36 = 781915424 ^ var36;
         case 1553406835 -> var36 = quvzakhjalouinli(var36, 743718873);
         case 1688062658 -> var36 = quvzakhjalouinli(var36, 190146031);
         default -> throw new IOException("Error in hash");
      }

      Exception var17 = var10000;
      var36 = 391384347 ^ var36;
      Logger var18 = Bukkit.getLogger();
      String var26 = var17.getMessage();
      String var27 = "[DonutEnderChest] Failed to deserialize items: " + var26;
      var18.severe(var27);
      var36 = 996856920 ^ var36;
      byte var19 = (byte)(1811416559 ^ var36);
      ItemStack[] var20 = new ItemStack[var19];
      return var20;
   }

   public void shutdown() {
      int var120 = 1403159692 ^ 1412562448 ^ 673084569;
      var120 = 1405294893 ^ var120;
      Map var15 = this.openChests;
      byte var16 = var15.isEmpty();
      if (var16 != (2085492520 ^ var120)) {
         var120 = 1795718 ^ var120;
      } else {
         byte var79;
         label252: {
            var120 = quvzakhjalouinli(var120, 2007608674);
            Logger var17 = Bukkit.getLogger();
            Map var80 = this.openChests;
            int var81 = var80.size();
            String var82 = "[DonutEnderChest] Saving " + var81 + " open ender chest(s)...";
            var17.info(var82);
            var120 = 963344981 ^ var120;
            byte var19 = this.isCrossServerEnabled();
            if (var19 != (848085023 ^ var120)) {
               var120 = 2012430970 ^ var120;
               oOoOo0KKoOK var20 = oOoOo0KKoOK.getInstance();
               if (var20 != null) {
                  var120 = 1521835865 ^ var120;
                  oOoOo0KKoOK var21 = oOoOo0KKoOK.getInstance();
                  byte var22 = var21.isConnected();
                  if (var22 != (533388604 ^ var120)) {
                     var120 = 1678757183 ^ var120;
                     var79 = (byte)(2076512258 ^ var120);
                     var120 = quvzakhjalouinli(var120, 860495527);
                     break label252;
                  }

                  var120 = quvzakhjalouinli(var120, 1973468388);
               } else {
                  var120 = quvzakhjalouinli(var120, 789963709);
               }
            } else {
               label250:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var120)) {
                     case 32540336:
                        var120 ^= 1491509703;
                        break label250;
                     case 277515114:
                     default:
                        throw new IllegalAccessException();
                     case 328012655:
                        break;
                     case 1976713997:
                        break label250;
                  }
               }
            }

            var79 = (byte)(1785356760 ^ var120);
            var120 = 585461628 ^ var120;
         }

         byte var6 = var79;
         var120 = 1172979864 ^ var120;
         Map var24 = this.openChests;
         Set var25 = var24.entrySet();
         Iterator var26 = var25.iterator();
         Iterator var7 = var26;
         var120 = 169204514 ^ var120;

         label235:
         while(true) {
            byte var28 = var7.hasNext();
            if (var28 == (124818718 ^ var120)) {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var120)) {
                     case 117017788:
                        var120 ^= 751619619;
                     case 407291076:
                        break label235;
                     case 538467608:
                     default:
                        throw new IllegalAccessException();
                     case 1823648647:
                  }
               }
            }

            var120 = 1462121322 ^ var120;
            Object var35 = var7.next();
            Map.Entry var36 = (Map.Entry)var35;
            var120 = 1796439852 ^ var120;
            Object var38 = var36.getKey();
            UUID var39 = (UUID)var38;
            UUID var9 = var39;
            var120 = 83423868 ^ var120;
            Object var41 = var36.getValue();
            Inventory var42 = (Inventory)var41;
            Inventory var10 = var42;
            var120 = 1184689327 ^ var120;

            label232: {
               label260: {
                  Exception var10000;
                  label230: {
                     ItemStack[] var11;
                     int var12;
                     try {
                        byte var43 = (byte)(2032256912 ^ var120);
                        ItemStack[] var44 = new ItemStack[var43];
                        var11 = var44;
                        var120 = 169825980 ^ var120;
                        byte var45 = (byte)(1933480247 ^ var120);
                        var12 = var45;
                        var120 = 779044244 ^ var120;
                     } catch (Exception var129) {
                        var10000 = var129;
                        boolean var10001 = false;
                        break label230;
                     }

                     label229:
                     while(true) {
                        label261: {
                           try {
                              byte var84 = (byte)(1565643960 ^ var120);
                              if (var12 < var84) {
                                 int var166 = 1157186219 ^ var120;
                                 ItemStack var98 = var10.getItem(var12);
                                 var11[var12] = var98;
                                 var120 = 1364114500 ^ var166;
                                 var12 += 1223043661 ^ var120;
                                 break label261;
                              }
                           } catch (Exception var130) {
                              var10000 = var130;
                              boolean var172 = false;
                              break;
                           }

                           var120 ^= 153307413;

                           label262: {
                              label215: {
                                 label214: {
                                    label263: {
                                       label264: {
                                          Inventory var13;
                                          int var14;
                                          try {
                                             if (var6 == (1416797622 ^ var120)) {
                                                break label264;
                                             }

                                             var120 = 1314690863 ^ var120;
                                             this.saveVanillaItemsSync(var9, var11);
                                             var120 = 64235356 ^ var120;
                                             Player var53 = Bukkit.getPlayer(var9);
                                             var120 = 203681018 ^ var120;
                                             if (var53 == null) {
                                                break label214;
                                             }

                                             var120 = 69830861 ^ var120;
                                             byte var56 = var53.isOnline();
                                             if (var56 == (300960242 ^ var120)) {
                                                break label263;
                                             }

                                             var120 = 200115771 ^ var120;
                                             Inventory var58 = var53.getEnderChest();
                                             var13 = var58;
                                             var120 = 1547354394 ^ var120;
                                             byte var59 = (byte)(1176964819 ^ var120);
                                             var14 = var59;
                                             var120 = 1337875500 ^ var120;
                                          } catch (Exception var128) {
                                             var10000 = var128;
                                             boolean var173 = false;
                                             break;
                                          }

                                          label200:
                                          while(true) {
                                             try {
                                                byte var90 = (byte)(161043172 ^ var120);
                                                if (var14 >= var90) {
                                                   break;
                                                }

                                                int var151 = 609256322 ^ var120;
                                                Object var102 = null;
                                                var13.setItem(var14, (ItemStack)var102);
                                                var120 = 997594866 ^ var151;
                                                var14 += 381667214 ^ var120;
                                             } catch (Exception var127) {
                                                var10000 = var127;
                                                boolean var174 = false;
                                                break label229;
                                             }

                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var120)) {
                                                   case 202605594:
                                                      var120 ^= 522622320;
                                                      continue label200;
                                                   case 358643994:
                                                   default:
                                                      throw new IllegalAccessException();
                                                   case 674752385:
                                                      break;
                                                   case 1642363393:
                                                      continue label200;
                                                }
                                             }
                                          }

                                          var120 ^= 959240191;
                                          break label215;
                                       }

                                       label178:
                                       while(true) {
                                          switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var120)) {
                                             case 60704226:
                                                var120 ^= 503929249;
                                                break label178;
                                             case 716847909:
                                             default:
                                                throw new IllegalAccessException();
                                             case 972637902:
                                                break;
                                             case 1028408487:
                                                break label178;
                                          }
                                       }

                                       label168: {
                                          label267: {
                                             Inventory var116;
                                             int var117;
                                             try {
                                                Player var70 = Bukkit.getPlayer(var9);
                                                var120 = 1117633988 ^ var120;
                                                if (var70 == null) {
                                                   break label267;
                                                }

                                                var120 = 1733694362 ^ var120;
                                                byte var73 = var70.isOnline();
                                                if (var73 == (1873832521 ^ var120)) {
                                                   break label168;
                                                }

                                                var120 = 740382180 ^ var120;
                                                Inventory var75 = var70.getEnderChest();
                                                var116 = var75;
                                                var120 = 1209039351 ^ var120;
                                                byte var76 = (byte)(193021530 ^ var120);
                                                var117 = var76;
                                                var120 = 1509749932 ^ var120;
                                             } catch (Exception var126) {
                                                var10000 = var126;
                                                boolean var176 = false;
                                                break;
                                             }

                                             while(true) {
                                                try {
                                                   byte var96 = (byte)(1383969517 ^ var120);
                                                   if (var117 >= var96) {
                                                      break;
                                                   }

                                                   int var157 = 441436430 ^ var120;
                                                   ItemStack var107 = var11[var117];
                                                   var116.setItem(var117, var107);
                                                   var120 = 1948365896 ^ var157;
                                                   var117 += 1007931313 ^ var120;
                                                } catch (Exception var125) {
                                                   var10000 = var125;
                                                   boolean var177 = false;
                                                   break label229;
                                                }

                                                var120 = 1852734790 ^ var120;
                                             }

                                             while(true) {
                                                switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var120)) {
                                                   case 187616388:
                                                      break;
                                                   case 265541825:
                                                      var120 ^= 865483813;
                                                   case 516681470:
                                                      break label262;
                                                   case 2032276762:
                                                   default:
                                                      throw new IllegalAccessException();
                                                }
                                             }
                                          }

                                          var120 = quvzakhjalouinli(var120, 1762522880);
                                          break label262;
                                       }

                                       var120 = quvzakhjalouinli(var120, 240903322);
                                       break label262;
                                    }

                                    var120 = quvzakhjalouinli(var120, 558222578);
                                    break label215;
                                 }

                                 var120 = quvzakhjalouinli(var120, 627852351);
                              }

                              try {
                                 oOoOo0KKoOK var62 = oOoOo0KKoOK.getInstance();
                                 var62.releaseLock(var9);
                                 var120 = 2083235632 ^ var120;
                              } catch (Exception var124) {
                                 var10000 = var124;
                                 boolean var175 = false;
                                 break;
                              }

                              var120 = quvzakhjalouinli(var120, 762686691);
                           }

                           ItemStack[] var113;
                           int var115;
                           try {
                              byte var63 = (byte)(1642827464 ^ var120);
                              ItemStack[] var64 = new ItemStack[var63];
                              var113 = var64;
                              var120 = 357954512 ^ var120;
                              byte var65 = (byte)(1958640899 ^ var120);
                              var115 = var65;
                              var120 = 1069318657 ^ var120;
                           } catch (Exception var122) {
                              var10000 = var122;
                              boolean var178 = false;
                              break;
                           }

                           while(true) {
                              try {
                                 byte var93 = (byte)(1258487577 ^ var120);
                                 if (var115 >= var93) {
                                    break;
                                 }

                                 int var160 = 329910395 ^ var120;
                                 byte var5 = (byte)(1487468386 ^ var160);
                                 int var109 = var115 + var5;
                                 ItemStack var104 = var10.getItem(var109);
                                 var113[var115] = var104;
                                 var120 = 370983251 ^ var160;
                                 var115 += 1320433195 ^ var120;
                              } catch (Exception var123) {
                                 var10000 = var123;
                                 boolean var179 = false;
                                 break label229;
                              }

                              var120 = 95865128 ^ var120;
                           }

                           var120 ^= 733952636;

                           try {
                              this.saveExtraItemsSync(var9, var113);
                              var120 = 283570335 ^ var120;
                              break label260;
                           } catch (Exception var121) {
                              var10000 = var121;
                              boolean var180 = false;
                              break;
                           }
                        }

                        var120 = 364379887 ^ var120;
                     }
                  }

                  switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var120)) {
                     case -2052315135 -> var120 = 669687382 ^ var120;
                     case -1887285360 -> var120 = quvzakhjalouinli(var120, 112153252);
                     case -1813145678 -> var120 = 1159899552 ^ var120;
                     case -1712027205 -> var120 = quvzakhjalouinli(var120, 1684114017);
                     case -1550520910 -> var120 = 1127057120 ^ var120;
                     case -1510741989 -> var120 = 1675716181 ^ var120;
                     case -1362228744 -> var120 = 42392169 ^ var120;
                     case -1241629576 -> var120 = 31513817 ^ var120;
                     case -985154614 -> var120 = 1341647919 ^ var120;
                     case -921813925 -> var120 = 1853807837 ^ var120;
                     case -851136448 -> var120 = 251104606 ^ var120;
                     case -808358360 -> var120 = quvzakhjalouinli(var120, 245708435);
                     case -789676472 -> var120 = 222483615 ^ var120;
                     case -781167416 -> var120 = quvzakhjalouinli(var120, 225513935);
                     case -526484095 -> var120 = quvzakhjalouinli(var120, 726455526);
                     case -359750374 -> var120 = 1242484725 ^ var120;
                     case 99494899 -> var120 = 2011356712 ^ var120;
                     case 257717915 -> var120 = quvzakhjalouinli(var120, 1991546245);
                     case 478805354 -> var120 = 1422796027 ^ var120;
                     case 825783962 -> var120 = 1366824325 ^ var120;
                     case 1100210114 -> var120 = 1601003694 ^ var120;
                     case 1194414690 -> var120 = 1605972250 ^ var120;
                     case 1194577560 -> var120 = 532243077 ^ var120;
                     case 1288345592 -> var120 = 516311465 ^ var120;
                     case 1407066298 -> var120 = 1562697537 ^ var120;
                     case 1477965842 -> var120 = quvzakhjalouinli(var120, 1549657172);
                     case 1544172240 -> var120 = 484334860 ^ var120;
                     case 1693520258 -> var120 = 1539389798 ^ var120;
                     case 1850641385 -> var120 = 982960683 ^ var120;
                     case 1973530962 -> var120 = 1508584828 ^ var120;
                     case 2105758283 -> var120 = 2028957983 ^ var120;
                     default -> throw new RuntimeException("Error in hash");
                  }

                  Exception var48 = var10000;
                  var120 = 1790412134 ^ var120;
                  Logger var49 = Bukkit.getLogger();
                  String var87 = String.valueOf(var39);
                  String var100 = var48.getMessage();
                  String var88 = "[DonutEnderChest] Failed to save ender chest for " + var87 + " during shutdown: " + var100;
                  var49.severe(var88);
                  var120 = 814419101 ^ var120;
                  break label232;
               }

               var120 = 1027123020 ^ var120;
            }

            var120 = quvzakhjalouinli(var120, 1242761139);
         }

         Map var30 = this.openChests;
         var30.clear();
         var120 = 1743372977 ^ var120;
         Map var32 = this.chestBlocks;
         var32.clear();
         var120 = 2133984058 ^ var120;
         Logger var33 = Bukkit.getLogger();
         String var83 = tghwtuczyw(efwexxbbxpgmwpo(), var120);
         var33.info(var83);
         var120 = 1303569664 ^ var120;
      }
   }

   public static String getCreateTableSQL() {
      int var3 = 1420016547 ^ 725225130 ^ 1455863621;
      var3 = 1154688318 ^ var3;
      String var0 = tghwtuczyw(ggahednwvqyfcbe(), var3);
      return var0;
   }

   public static String tghwtuczyw(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = bauqerkuds;
         byte[] var34 = bauqerkuds;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   static {
      bauqerkuds = xefnzycyldeacnx();
   }

   private static byte[] xefnzycyldeacnx() {
      return new byte[]{127, 40, 24, 92, 51, 14, 67, 21, 24, 11, 41, 17, 122, 119, 9, 85, 37, 57, 68, 16, 46, 51, 121, 34, 45, 118, 32, 42, 19, 66, 124, 10, 100, 19, 52, 93, 48, 91, 3, 5, 61, 5, 36, 39, 50, 101, 31, 101, 105, 108, 74, 99, 54, 113, 103, 29, 22, 117, 99, 99, 19, 59};
   }

   private static byte[] yjjhjtraubouecv() {
      return new byte[0];
   }

   private static byte[] ggahednwvqyfcbe() {
      return new byte[]{-80, -17, 43, 40, 10, 108, 114, 102, 32, 120, 24, 125, 73, 5, 48, 69, 20, 91, 124, 99, 31, 73, 74, 89, 20, 3, 17, 60, 43, 57, 77, 116, 87, 4, 13, 35, 1, 34, 59, 99, 12, 29, 23, 85, 11, 13, 46, 26, 81, 13, 123, 15, 5, 21, 94, 13, 39, 39, 91, 62, 34, 109, 76, 106, 33, 24, 2, 103, 123, 66, 41, 93, 26, 66, 67, 34, 56, 17, 29, 104, 117, 64, 29, 97, 64, 97, 28, 52, 24, 56, 34, 82, 79, 72, 93, 86, 5, 2, 8, 13, 50, 29, 14, 100, 29, 86, 3, 1, 39, 20, 88, 28, 121, 21, 15, 19, 86, 3, 46, 116, 82, 109, 32, 37, 70, 56, 41, 58, 11, 110, 114, 100, 43, 113, 16, 96, 75, 19, 49, 62, 20, 33, 119, 108, 23, 70, 72, 77, 21, 104, 17, 50, 32, 16, 69, 66, 85, 81, 12, 29, 1, 2, 48, 109, 4, 92, 21, 101, 10, 50, 46, 48, 90, 40, 115, 115, 7, 10, 95, 106, 39, 9, 80, 29, 42, 94, 78, 83, 32, 58, 2, 115, 112, 122, 33, 111, 24, 7, 66, 11, 56, 34, 22, 90, 125, 0, 31, 75, 65, 69, 28, 2, 19, 81, 42, 94, 77, 28, 92, 87, 5, 4, 3, 2, 58, 92, 12, 95, 28, 121, 3, 60, 44, 13, 80, 53, 123, 33, 14, 38, 86, 72, 37, 49, 90, 115, 34, 64, 71, 95, 41, 32, 0, 112, 122, 112, 41, 112, 17, 119, 75, 10, 58, 58, 28, 93, 117, 6, 22, 79, 72, 79, 30, 13, 25, 86, 34, 93};
   }

   private static byte[] kuewhhewrshurhj() {
      return new byte[]{-75, -17, 47, 10, 10, 94, 115, 67, 43, 75, 17, 83, 74, 60, 60, 0, 18, 121, 112, 6, 25, 102, 64, 121, 29, 37, 19, 123, 43, 7, 76, 80, 81, 75, 3, 11, 4, 16, 52, 65, 4, 29, 20, 117, 1, 63, 39, 51, 89, 55, 127, 63, 1, 39, 83, 65};
   }

   private static byte[] xplrwdbrskrtkvy() {
      return new byte[]{-77, -30, 43, 9, 5, 80, 116, 65, 45, 92, 28, 80, 74, 34, 57, 10, 21, 105, 118, 86, 29, 119, 79, 60, 26, 50, 21, 113, 38, 5, 76, 80, 84, 65};
   }

   private static byte[] ashcqydrdeyzmno() {
      return new byte[]{-77, -30, 43, 74, 5, 11, 116, 96, 45, 87, 28, 70, 74, 36, 57, 16, 21, 44, 118, 102, 29, 107, 79, 119, 26, 53, 21, 108};
   }

   private static byte[] kojttznvsykrnaj() {
      return new byte[]{-75, -17, 43, 8, 10, 85, 122, 66, 44, 90, 17, 80, 75, 45, 60, 4, 22, 104, 112, 91, 29, 118, 64, 57, 20, 55, 20, 123, 43, 0, 77, 70, 81, 67, 7, 27, 4, 6, 48, 25, 4, 64, 29, 113, 6, 35, 39, 59, 88, 60, 127, 41, 5, 54, 83, 76, 37, 43, 90, 56};
   }

   private static byte[] mxgfnwevallqrvi() {
      return new byte[]{-80, -29, 33, 8, 0, 80, 117, 69, 47, 90, 24, 87, 67, 37, 58, 13, 19, 104, 115, 87, 31, 115, 64, 61, 30, 54, 22, 123, 36, 4, 77, 83, 93, 75, 7, 30, 6, 28, 52, 88, 12, 94, 29, 120};
   }

   private static byte[] btszyvbafofjfbo() {
      return new byte[]{-80, -29, 33, 9, 0, 81, 117, 79, 47, 74, 24, 81, 67, 53, 58, 8, 19, 125, 115, 71, 31, 104, 64, 97, 30, 35, 22, 48, 36, 19, 77, 80, 93, 70, 7, 8, 6, 29, 52, 82, 12, 89, 29, 115, 1, 38, 41, 37, 94, 118, 123, 50, 15, 56, 84, 93, 32, 32, 84, 57, 34, 107, 70, 124, 43, 8};
   }

   private static byte[] oidxjjmabqivygl() {
      return new byte[]{-78, -27, 43, 1, 0, 81, 116, 73, 45, 93, 27, 80, 66, 39, 56, 10, 29, 105, 119, 81, 29, 127, 74, 61, 26, 39, 21, 119, 33, 5, 68, 92, 85, 86, 12, 11, 3, 12, 48, 77, 14, 64, 19, 50, 7, 53, 45, 57, 81, 50, 123, 57, 14, 37, 84, 65, 37, 41, 80, 127, 36, 108, 74, 107, 42, 10, 11, 83, 114, 81};
   }

   private static byte[] sdxcdzheetrcsnj() {
      return new byte[]{-73, -27, 47, 29, 0, 95, 123, 69, 46, 84, 27, 85, 73, 106, 61, 8, 17, 97, 114, 67, 25, 98, 74, 122, 21, 39, 22, 120};
   }

   private static byte[] ensjxmnfbwpeepq() {
      return new byte[]{-80, -25, 42, 9, 2, 83, 112, 68, 43, 92, 24, 83, 72, 36, 56, 14, 22, 105, 119, 81, 31, 119, 75, 60, 28, 38, 19, 109, 32, 31, 77, 73, 86, 80, 5, 67, 3, 29, 48, 82, 12, 71, 22, 97, 3, 51, 44, 34, 90, 115, 123, 54, 4, 47, 86, 79, 37, 34, 80, 61, 34, 110, 77, 124};
   }

   private static byte[] ichcuxnkncmuyln() {
      return new byte[]{-74, -31, 33, 54, 10, 121, 122, 105, 47, 121, 31, 107, 67, 26, 59, 76, 21, 107, 115, 94, 23, 126, 64, 98, 20, 39, 23, 66, 37, 18, 69, 71, 86, 79, 4, 7, 7, 30, 58, 28, 4, 113, 29, 69, 5, 29, 41, 17, 80, 117, 120, 62, 6, 41, 80, 69, 47, 57, 90, 37, 42, 84, 72, 122, 46, 11, 10, 83, 113, 73, 40, 78, 30, 68, 67, 38, 48, 2, 28, 122, 115, 83, 24, 42, 64, 76, 31, 7, 16, 88, 36, 38, 69, 118, 93, 1, 13, 24, 7, 25, 53, 85, 4, 88, 22, 62, 2, 111, 40, 115, 80, 106};
   }

   private static byte[] mkssdkoyepgmwzz() {
      return new byte[]{-73, -29, 47, 11, 7, 65, 113, 89, 43, 79, 29, 71, 72, 28, 62, 14, 29, 126, 114, 65, 25, 108, 77, 102};
   }

   private static byte[] axizhneccccgrsv() {
      return new byte[]{-75, -31, 40, 32, 11, 115, 114, 117, 43, 122, 31, 115, 79, 27, 58, 68, 22, 69, 112, 116, 30, 38, 65, 67, 28, 0, 19, 78, 37, 62, 73, 115, 87, 97, 7, 43, 4, 77, 51, 121, 5, 120, 21, 64, 1, 30, 41, 117, 92, 48, 121, 61, 5, 44, 83, 94, 38, 52, 91, 15, 34, 109, 76, 114, 46, 8, 6, 83, 112, 86, 43, 91, 29, 79, 74, 39, 49, 21, 20, 126, 119, 4, 24, 43, 76, 111, 30, 50, 19, 112, 39, 16, 76, 19, 92, 0, 5, 11, 3, 23, 53, 65, 8, 79, 23, 119, 1, 9, 43, 58, 89, 45, 114, 53, 7, 47, 84, 90, 32, 108, 86, 123, 32, 92, 76, 90, 44, 38, 3, 110, 123, 99, 41, 107, 26, 5, 76, 111, 60, 82, 22, 36, 119, 3, 26, 58, 73, 62};
   }

   private static byte[] dmjylfqcrcevqbz() {
      return new byte[]{-80, -30, 42, 42, 0, 123, 123, 97, 45, 126, 24, 112, 72, 0, 58, 69, 29, 71, 113, 114, 31, 73, 75, 93, 30, 102, 24, 118, 38, 29, 77, 81, 86, 84, 7, 25, 8, 60, 54, 80, 12, 94, 22, 113, 1, 48, 39, 47, 92, 63, 123, 62, 4, 38, 84, 94, 46, 57, 86, 115, 34, 89, 77, 82, 43, 41, 11, 100, 118, 96, 41, 30, 27, 86, 73, 50, 49, 4, 16, 109, 117, 5, 28, 60, 74, 50, 21, 113};
   }

   private static byte[] ekcacpqhuigqlbl() {
      return new byte[]{-80, -30, 46, 44, 1, 117, 114, 116, 45, 118, 24, 118, 76, 26, 59, 64, 20, 66, 113, 102, 31, 82, 79, 84, 31, 99, 17, 124, 38, 21, 77, 81, 82, 95, 6, 28, 1, 54, 54, 88, 12, 94, 18, 122, 0, 53, 46, 37, 92, 55, 123, 62, 0, 45, 85, 91, 39, 51, 86, 123, 34, 38, 73, 100, 42, 28, 2, 85, 118, 73, 41, 18, 31, 8, 72, 39, 56, 31, 16, 117, 117, 87, 24, 107, 75, 72, 28, 45, 21, 102, 34, 18, 74, 94, 86, 85, 5, 70, 5, 67, 50, 102, 11, 125, 22, 94, 3, 2, 42, 24, 88, 10, 124, 122, 4, 108, 86, 16, 35, 97, 82, 118, 37, 61, 77, 52, 41, 78, 6, 121, 114, 110, 46, 18, 27, 96, 75, 16, 60, 61, 20, 64, 114, 96, 28, 69, 72, 81, 24, 26, 17, 90, 37, 91, 78, 116, 85, 100, 1, 60, 1, 78, 53, 105, 15, 96, 21, 81, 7, 28, 46, 4, 95, 16, 120, 118, 7, 38, 82, 93, 39, 52, 85, 40, 33, 111, 78, 69, 45, 13, 2, 79, 117, 73, 42, 83, 24, 80, 79, 111, 56, 93, 19, 32, 118, 115, 31, 64, 76, 86, 28, 22, 22, 86, 33, 36, 77, 16, 81, 78, 5, 16, 6, 22, 49, 66, 12, 86, 17, 64, 3, 57, 41, 40, 91, 60, 123, 60, 3, 58, 86, 1};
   }

   private static byte[] zmxkwhqrcwhzsbe() {
      return new byte[]{-77, -31, 47, 63, 5, 123, 116, 111, 46, 124, 31, 101, 74, 21, 57, 66, 19, 121, 118, 71, 25, 109, 79, 123, 26, 44, 22, 116, 37, 20, 76, 99, 84, 77, 2, 31, 2, 8, 52, 88, 11, 70, 19, 49, 4, 17, 41, 0, 89, 21, 122, 25, 0, 103, 85, 79, 33, 42, 85, 61, 36, 120, 73, 110, 46, 52, 3, 93, 115, 76, 46, 89, 27, 66, 77, 53, 63, 6, 18, 103, 114, 71, 24, 119, 73, 96, 29, 97, 22, 75, 33, 60, 75, 127, 82, 113, 3, 46, 6, 73, 53, 71, 13, 70, 20, 121, 4, 55, 45, 115, 94, 97, 124, 115, 1, 120};
   }

   private static byte[] igcvpbkmuywfowu() {
      return new byte[]{-80, -32, 45, 26, 0, 93, 112, 73, 43, 85, 24, 74, 79, 43, 58, 6, 22, 84, 119, 78, 31, 112, 76, 119, 30, 41, 19, 107};
   }

   private static byte[] qwvheftyilhscqt() {
      return new byte[]{-80, -26, 32, 34, 4, 116, 116, 115, 47, 121, 24, 114, 66, 20, 62, 65, 18, 69, 115, 105, 31, 86, 65, 90, 26, 98, 23, 123, 36, 26, 77, 85, 92, 81, 3, 29, 7, 49, 52, 87, 12, 90, 28, 116, 5, 52, 40, 34, 94, 56, 123, 58, 14, 35, 80, 90, 33, 52, 84, 116, 34, 34, 71, 106, 47, 29, 4, 82, 116, 70, 41, 22, 17, 6, 77, 38, 62, 24, 18, 122, 117, 83, 22, 101, 78, 73, 26, 42, 23, 105, 34, 22, 68, 80, 83, 84, 3, 68, 7, 76, 50, 66, 5, 83, 19, 125, 5, 57, 40, 62, 88, 49, 114, 53, 1, 26, 80, 65, 33, 54, 82, 55, 43, 97, 72, 111, 47, 64, 4, 25, 114, 114, 32, 125, 30, 105, 77, 23, 62, 39, 20, 91, 124, 7, 25, 47, 78, 40, 26, 109, 17, 59, 43, 74, 75, 18, 83, 6, 3, 85, 1, 67, 59, 18, 10, 126, 19, 92, 5, 114, 46, 16, 81, 14, 125, 7, 1, 8, 80, 99, 39, 7, 91, 21, 36, 91, 72, 88, 47, 75, 2, 116, 123, 103, 47, 102, 30, 4, 77, 21, 56, 52, 29, 74, 115, 101, 25, 82, 78, 80, 28, 103, 24, 107, 36, 23, 75, 81, 83, 77, 5, 0, 8, 0, 52, 80, 10, 111, 19, 121, 3, 32, 39, 55, 94, 53, 125, 37, 1, 102, 86, 17, 46, 98, 84, 1, 36, 79, 72, 83, 41, 56, 11, 124, 116, 114, 47, 22, 30, 80, 75, 39, 49, 12, 18, 100, 115, 73, 25, 104, 72, 114, 21, 30, 23, 119, 36, 3, 75, 88, 85, 79, 12, 25, 7, 70};
   }

   private static byte[] ocsutjhfuosflwt() {
      return new byte[]{-71, -17, 40, 63, 1, 105, 119, 99, 47, 114, 17, 117, 76, 0, 62, 65, 23, 106, 124, 71, 30, 107, 75, 96, 25, 48, 23, 77, 43, 23, 74, 86, 83, 67, 6, 15, 8, 17, 51, 80, 15, 90, 16, 112, 5, 46, 39, 33, 95, 126, 125, 4, 4, 3, 95, 113, 38, 99, 81, 34, 39, 104, 72, 126, 32, 5, 5, 80, 116, 77, 42, 93, 17, 118, 74, 40, 59, 22, 17, 110, 115, 69, 22, 112, 79, 48, 26, 127, 18, 61, 43, 69, 76, 28, 86, 115, 0, 39, 7, 38, 59, 103, 11, 114, 19, 51, 0, 39, 39, 40, 89, 51, 120, 48, 2, 99, 80, 24, 46, 101, 85, 110};
   }

   private static byte[] fxnzxgdjmcgylea() {
      return new byte[]{-80, -25, 40, 34, 10, 113, 119, 126, 42, 120, 24, 115, 74, 20, 48, 68, 17, 78, 118, 116, 31, 35, 73, 71, 20, 2, 20, 66, 33, 56, 77, 123, 84, 103, 13, 41, 4, 67, 49, 122, 12, 123, 20, 68, 11, 27, 43, 125, 91, 62, 123, 60, 6, 40, 94, 89, 34, 57, 81, 10, 34, 110, 79, 113, 33, 9, 7, 83, 113, 81, 41, 88, 25, 78, 67, 35, 61, 30, 23, 123, 117, 0, 30, 44, 64, 102, 25, 59, 18, 117, 34, 22, 76, 17, 93, 2, 0, 0, 2, 21, 50, 65, 13, 64, 29, 119, 6, 2, 45, 58, 88, 40, 122, 49, 15, 45, 83, 86, 36, 111, 82, 115, 35, 122, 70, 120, 44, 10, 1, 81, 114, 73, 40, 80, 16, 65, 78, 16, 59, 10, 20, 125, 116, 66, 23, 111, 77, 105, 31, 105, 17, 58, 35, 35, 69, 122, 80, 103, 6, 62, 1, 46, 51, 97, 4, 20, 16, 55, 0, 108, 46, 121, 89, 123, 115, 109, 2, 101, 85, 11, 39, 122, 83, 125};
   }

   private static byte[] efwexxbbxpgmwpo() {
      return new byte[]{-71, -31, 42, 51, 1, 125, 123, 73, 40, 93, 31, 86, 78, 49, 62, 40, 22, 103, 124, 66, 28, 98, 75, 103, 21, 6, 16, 122, 37, 21, 72, 75, 83, 95, 7, 48, 8, 77, 49, 112, 15, 94, 28, 120, 2, 125, 41, 56, 93, 46, 125, 62, 5, 47, 95, 11, 36, 36, 81, 58, 43, 108, 79, 117, 46, 28, 7, 28, 116, 78, 43, 83, 17, 66, 72, 48, 59, 22, 29, 121, 116, 8, 24, 114, 77, 113, 26, 56, 19, 127, 43, 16, 78, 16};
   }

   private static int quvzakhjalouinli(int var0, int var1) {
      return var0 ^ var1;
   }
}
