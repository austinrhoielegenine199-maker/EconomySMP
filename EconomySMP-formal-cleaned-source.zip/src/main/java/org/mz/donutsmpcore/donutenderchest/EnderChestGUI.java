package org.mz.donutsmpcore.donutenderchest;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Lidded;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import skido.KKo0KoOoOK;
import skido.KKoOoOo0oOK;
import skido.oOo0KKoOoOK;
import skido.oOoOo0KKoOK;

public class EnderChestGUI implements Listener {
   private final EnderChestComponent manager;

   public EnderChestGUI() {
      EnderChestComponent var2 = EnderChestComponent.getInstance();
      this.manager = var2;
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerInteract(PlayerInteractEvent var1) {
      int var49 = 354047301 ^ 811629836 ^ 1080587257;
      var49 = 1605044963 ^ var49;
      EnderChestComponent var8 = this.manager;
      byte var9 = var8.isEnabled();
      if (var9 == (985223507 ^ var49)) {
         var49 = 437223222 ^ var49;
      } else {
         var49 = 1023359888 ^ var49;
         Action var11 = var1.getAction();
         Action var3 = Action.RIGHT_CLICK_BLOCK;
         if (var11 != var3) {
            var49 = 615369257 ^ var49;
         } else {
            var49 = 1873281404 ^ var49;
            EquipmentSlot var13 = var1.getHand();
            EquipmentSlot var39 = EquipmentSlot.HAND;
            if (var13 != var39) {
               var49 = 986305037 ^ var49;
            } else {
               var49 = 551330026 ^ var49;
               Block var15 = var1.getClickedBlock();
               var49 = 1595766923 ^ var49;
               if (var15 != null) {
                  var49 = 650818423 ^ var49;
                  Material var18 = var15.getType();
                  Material var40 = Material.ENDER_CHEST;
                  if (var18 == var40) {
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var49)) {
                           case 247169442:
                              var49 ^= 1858515259;
                           case 18825066:
                              Player var20 = var1.getPlayer();
                              var49 = 426429804 ^ var49;
                              EnderChestComponent var22 = this.manager;
                              byte var23 = var22.hasEnderChestAccess(var20);
                              if (var23 == (1195998462 ^ var49)) {
                                 var49 = 940635922 ^ var49;
                                 return;
                              }

                              label67:
                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var49)) {
                                    case 169747813:
                                       var49 ^= 1852840859;
                                       break label67;
                                    case 463164158:
                                       break;
                                    case 1180706234:
                                    default:
                                       throw new RuntimeException();
                                    case 1292460700:
                                       break label67;
                                 }
                              }

                              PlayerInventory var25 = var20.getInventory();
                              ItemStack var26 = var25.getItemInMainHand();
                              var49 = 732390750 ^ var49;
                              byte var28 = var20.isSneaking();
                              if (var28 != (43909691 ^ var49)) {
                                 var49 = 459733812 ^ var49;
                                 Material var30 = var26.getType();
                                 Material var42 = Material.AIR;
                                 if (var30 != var42) {
                                    var49 = 1910305966 ^ var49;
                                    Material var32 = var26.getType();
                                    byte var33 = var32.isBlock();
                                    if (var33 != (1747193249 ^ var49)) {
                                       var49 = 2109765794 ^ var49;
                                       return;
                                    }

                                    var49 = npjkqavsxyxfrwcm(var49, 291953585);
                                 } else {
                                    var49 = npjkqavsxyxfrwcm(var49, 1622814495);
                                 }
                              } else {
                                 label56:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var49)) {
                                       case 41164937:
                                          var49 ^= 2078069803;
                                          break label56;
                                       case 904396507:
                                       default:
                                          throw new RuntimeException();
                                       case 1354744256:
                                          break label56;
                                       case 1515713552:
                                    }
                                 }
                              }

                              EnderChestComponent var35 = this.manager;
                              UUID var44 = var20.getUniqueId();
                              byte var36 = var35.hasOpenChest(var44);
                              if (var36 != (2034423312 ^ var49)) {
                                 var49 = 1070236299 ^ var49;
                                 return;
                              }

                              var49 = 1932685404 ^ var49;
                              byte var45 = (byte)(175154765 ^ var49);
                              var1.setCancelled((boolean)var45);
                              var49 = 1273718832 ^ var49;
                              this.openCustomEnderChest(var20, var15);
                              var49 = 1175658874 ^ var49;
                              return;
                           case 273192552:
                           default:
                              throw new RuntimeException();
                           case 1702803452:
                        }
                     }
                  }

                  var49 = 1662562842 ^ var49;
               } else {
                  var49 = npjkqavsxyxfrwcm(var49, 1171390829);
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onInventoryOpen(InventoryOpenEvent var1) {
      int var45 = 153621211 ^ 711898825 ^ 1080587257;
      var45 = 1964352702 ^ var45;
      EnderChestComponent var7 = this.manager;
      byte var8 = var7.isEnabled();
      if (var8 == (372994901 ^ var45)) {
         var45 = 1377980519 ^ var45;
      } else {
         var45 = npjkqavsxyxfrwcm(var45, 961364519);
         EnderChestComponent var10 = this.manager;
         byte var11 = var10.interceptCommandOpens();
         if (var11 == (796275058 ^ var45)) {
            var45 = 143335883 ^ var45;
         } else {
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var45)) {
                  case 200593594:
                     var45 ^= 781909912;
                     break;
                  case 629829966:
                  default:
                     throw new RuntimeException();
                  case 1431793501:
                     break;
                  case 1952036157:
                     continue;
               }

               HumanEntity var13 = var1.getPlayer();
               byte var15 = var13 instanceof Player;
               if (var15 != (32296682 ^ var45)) {
                  var45 = 1794090774 ^ var45;
                  Player var17 = (Player)var13;
                  var45 = 1203520484 ^ var45;
                  var45 = 1245826475 ^ var45;
                  Inventory var19 = var1.getInventory();
                  InventoryType var20 = var19.getType();
                  InventoryType var3 = InventoryType.ENDER_CHEST;
                  if (var20 != var3) {
                     var45 = 1036108541 ^ var45;
                     return;
                  }

                  var45 = 1687556556 ^ var45;
                  Inventory var22 = var1.getInventory();
                  InventoryHolder var23 = var22.getHolder();
                  var45 = 1655309494 ^ var45;
                  if (var23 != null) {
                     var45 = 1449030396 ^ var45;
                     byte var26 = var23 instanceof Player;
                     if (var26 == (916226101 ^ var45)) {
                        var45 = 340187912 ^ var45;
                        byte var28 = var23 instanceof EnderChestStorage;
                        if (var28 == (584735549 ^ var45)) {
                           var45 = 1854211060 ^ var45;
                           return;
                        }

                        label64:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var45)) {
                              case 59191836:
                                 var45 ^= 870645714;
                                 break label64;
                              case 85677400:
                              default:
                                 throw new RuntimeException();
                              case 1139181399:
                                 break label64;
                              case 1909251538:
                           }
                        }
                     } else {
                        var45 = 664937690 ^ var45;
                     }
                  } else {
                     label55:
                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var45)) {
                           case 132465212:
                              break label55;
                           case 192534183:
                              var45 ^= 1912362534;
                              break label55;
                           case 631072628:
                           default:
                              throw new RuntimeException();
                           case 1780190048:
                        }
                     }
                  }

                  EnderChestComponent var30 = this.manager;
                  byte var31 = var30.hasEnderChestAccess(var17);
                  if (var31 == (289318127 ^ var45)) {
                     var45 = 971193829 ^ var45;
                     return;
                  }

                  var45 = npjkqavsxyxfrwcm(var45, 1963716967);
                  EnderChestComponent var33 = this.manager;
                  UUID var39 = var17.getUniqueId();
                  byte var34 = var33.hasOpenChest(var39);
                  if (var34 != (1681216904 ^ var45)) {
                     var45 = 760831445 ^ var45;
                     return;
                  }

                  var45 = npjkqavsxyxfrwcm(var45, 830050916);
                  byte var40 = (byte)(1431095277 ^ var45);
                  var1.setCancelled((boolean)var40);
                  var45 = 1753352464 ^ var45;
                  Object var4 = null;
                  this.openCustomEnderChest(var17, (Block)var4);
                  var45 = 1514834484 ^ var45;
                  return;
               }

               var45 = 1640870311 ^ var45;
               return;
            }
         }
      }
   }

   private void openCustomEnderChest(Player var1, Block var2) {
      UUID var12;
      byte var29;
      Location var33;
      int var61;
      label164: {
         var61 = 964468845 ^ 36420107 ^ 1080587257;
         var61 = 941350571 ^ var61;
         var12 = var1.getUniqueId();
         var61 = 1049524058 ^ var61;
         if (var2 != null) {
            var61 = 1896239554 ^ var61;
            var33 = var2.getLocation();

            label131:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var61)) {
                  case 143546001:
                     var61 ^= 809236729;
                     break label131;
                  case 335381728:
                     break;
                  case 373169968:
                     break label131;
                  case 1217336295:
                  default:
                     throw new IllegalAccessException();
               }
            }
         } else {
            var61 = 1991660342 ^ var61;
            var33 = null;
            var61 = 931920397 ^ var61;
         }

         var61 = 1988697284 ^ var61;
         if (var33 != null) {
            label139: {
               var61 = 176999304 ^ var61;
               String var4 = gmidwwegan(otgirtztilgmvha(), jdsolkprmjvrrhg(), var61);
               Sound var5 = Sound.BLOCK_ENDER_CHEST_OPEN;
               float var6 = 0.5F;
               float var7 = 1.0F;
               KKo0KoOoOK.play(var1, var4, var5, var6, var7);
               var61 = 203470146 ^ var61;

               label117: {
                  try {
                     BlockState var17 = var2.getState();
                     var61 = 1322351924 ^ var61;
                     byte var19 = var17 instanceof Lidded;
                     if (var19 != (40072815 ^ var61)) {
                        var61 = 638671506 ^ var61;
                        Lidded var21 = (Lidded)var17;
                        var21.open();
                        var61 = 1824938403 ^ var61;
                        break label117;
                     }
                  } catch (Exception var48) {
                     switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var61)) {
                        case 320582520 -> var61 = 1869612376 ^ var61;
                        case 596731881 -> var61 = npjkqavsxyxfrwcm(var61, 1231118282);
                        case 1703959258 -> var61 = npjkqavsxyxfrwcm(var61, 564230252);
                        default -> throw new IllegalAccessException("Error in hash");
                     }

                     var61 = 909852838 ^ var61;

                     while(true) {
                        switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var61)) {
                           case 10336448:
                              var61 ^= 2039322518;
                              break label139;
                           case 778072026:
                           default:
                              throw new IllegalAccessException();
                           case 1610333029:
                              break;
                           case 1922371431:
                              break label139;
                        }
                     }
                  }

                  var61 = 1255605041 ^ var61;
               }

               label107:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var61)) {
                     case 215870418:
                        var61 ^= 1779552601;
                     case 1631930984:
                        break label107;
                     case 1968185505:
                     default:
                        throw new IllegalAccessException();
                     case 2131061649:
                  }
               }
            }
         } else {
            label87:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var61)) {
                  case 261835222:
                     var61 ^= 235485743;
                  case 1198593722:
                     break label87;
                  case 1935015966:
                  default:
                     throw new IllegalAccessException();
                  case 2146992121:
               }
            }

            String var36 = gmidwwegan(yqaogcazinpuwgx(), jdsolkprmjvrrhg(), var61);
            Sound var38 = Sound.BLOCK_ENDER_CHEST_OPEN;
            float var40 = 0.5F;
            float var42 = 1.0F;
            KKo0KoOoOK.play(var1, var36, var38, var40, var42);
            var61 = 1723001785 ^ var61;
         }

         EnderChestComponent var23 = this.manager;
         byte var24 = var23.isCrossServerEnabled();
         if (var24 != (581280775 ^ var61)) {
            var61 ^= 1359706772;
            oOoOo0KKoOK var25 = oOoOo0KKoOK.getInstance();
            if (var25 != null) {
               var61 = 1133423420 ^ var61;
               oOoOo0KKoOK var26 = oOoOo0KKoOK.getInstance();
               byte var27 = var26.isConnected();
               if (var27 != (807433647 ^ var61)) {
                  var61 = 1791150144 ^ var61;
                  var29 = (byte)(1524809198 ^ var61);

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var61)) {
                        case 1512733:
                           var61 ^= 1504632419;
                           break label164;
                        case 110732256:
                        default:
                           throw new IllegalAccessException();
                        case 1970297478:
                           break;
                        case 2108039114:
                           break label164;
                     }
                  }
               }

               var61 = 756927987 ^ var61;
            } else {
               label66:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var61)) {
                     case 2276498:
                        var61 ^= 1855153871;
                        break label66;
                     case 1206457475:
                        break;
                     case 1313183427:
                     default:
                        throw new IllegalAccessException();
                     case 1589302118:
                        break label66;
                  }
               }
            }
         } else {
            label76:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var61)) {
                  case 52481896:
                     var61 ^= 1066933339;
                  case 252701686:
                     break label76;
                  case 1091529488:
                  default:
                     throw new IllegalAccessException();
                  case 1930340068:
               }
            }
         }

         var29 = (byte)(490584156 ^ var61);
         var61 = 510778320 ^ var61;
      }

      var61 = 2028625366 ^ var61;
      KKoOoOo0oOK var28 = KKoOoOo0oOK.getInstance();
      Runnable var35 = () -> {
         int var62 = 1968177594 ^ 1896079975 ^ 1080587257;
         var62 = 1853647454 ^ var62;
         if (var29 != (709360250 ^ var62)) {
            var62 = 1719049649 ^ var62;
            oOoOo0KKoOK var18 = oOoOo0KKoOK.getInstance();
            var62 = 259994820 ^ var62;
            String var20 = var18.tryAcquireLock(var12);
            var62 = 1365052783 ^ var62;
            if (var20 != null) {
               var62 = 729703485 ^ var62;
               String var43 = var18.getServerId();
               byte var23 = var20.equals(var43);
               if (var23 == (963459677 ^ var62)) {
                  var62 = 204212456 ^ var62;
                  byte var25 = var18.requestRemoteCloseAndWait(var12);
                  var62 = 1444281363 ^ var62;
                  if (var25 == (1666502310 ^ var62)) {
                     var62 = 1487780973 ^ var62;
                     KKoOoOo0oOK var41 = KKoOoOo0oOK.getInstance();
                     Runnable var57 = () -> {
                        int var8 = 60419935 ^ 258895582 ^ 1281345111;
                        var8 = 1233888062 ^ var8;
                        byte var3 = var1.isOnline();
                        if (var3 != (153347304 ^ var8)) {
                           var8 = 1592491580 ^ var8;
                           String var2 = gmidwwegan(qrdznbdgegpnlui(), jdsolkprmjvrrhg(), var8);
                           String var5 = oOo0KKoOoOK.color(var2);
                           var1.sendMessage(var5);
                           var8 = 1156045619 ^ var8;
                        } else {
                           var8 = 437036303 ^ var8;
                        }

                     };
                     var41.runAtEntity(var1, var57);
                     var62 = 461675651 ^ var62;
                     return;
                  }

                  var62 = npjkqavsxyxfrwcm(var62, 1633618191);
                  String var28 = var18.tryAcquireLock(var12);
                  var62 = 837248833 ^ var62;
                  if (var28 != null) {
                     var62 = 1599432867 ^ var62;
                     String var47 = var18.getServerId();
                     byte var31 = var28.equals(var47);
                     if (var31 == (1824114763 ^ var62)) {
                        var62 = 27068666 ^ var62;
                        KKoOoOo0oOK var32 = KKoOoOo0oOK.getInstance();
                        Runnable var53 = () -> {
                           int var8 = 2012073148 ^ 1855386242 ^ 1281345111;
                           var8 = 901517945 ^ var8;
                           byte var3 = var1.isOnline();
                           if (var3 != (1620634128 ^ var8)) {
                              var8 = 1458943533 ^ var8;
                              String var2 = gmidwwegan(izwbhkgkqztkvfr(), jdsolkprmjvrrhg(), var8);
                              String var5 = oOo0KKoOoOK.color(var2);
                              var1.sendMessage(var5);
                              var8 = 82340964 ^ var8;
                           } else {
                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var8)) {
                                    case 187180519:
                                       var8 = 1377688137 ^ var8;
                                       return;
                                    case 782089776:
                                       break;
                                    case 1381427946:
                                       return;
                                    case 2092825007:
                                    default:
                                       throw new IllegalAccessException();
                                 }
                              }
                           }
                        };
                        var32.runAtEntity(var1, var53);
                        var62 = 1472150002 ^ var62;
                        return;
                     }

                     var62 = 1683462170 ^ var62;
                  } else {
                     var62 = npjkqavsxyxfrwcm(var62, 990048441);
                  }
               } else {
                  var62 = npjkqavsxyxfrwcm(var62, 830695948);
               }
            } else {
               label54:
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var62)) {
                     case 50697417:
                        var62 ^= 452791857;
                        break label54;
                     case 656621816:
                     default:
                        throw new IllegalAccessException();
                     case 704476147:
                        break label54;
                     case 1834993924:
                  }
               }
            }
         } else {
            var62 = npjkqavsxyxfrwcm(var62, 581544491);
         }

         EnderChestComponent var34 = this.manager;
         ItemStack[] var35 = var34.loadExtraItemsSync(var12);
         var62 = 1487282073 ^ var62;
         ItemStack[] var40;
         if (var29 == (1346916296 ^ var62)) {
            var62 = npjkqavsxyxfrwcm(var62, 827489229);
            var40 = null;
            var62 = 547265204 ^ var62;
         } else {
            var62 = 995756520 ^ var62;
            EnderChestComponent var38 = this.manager;
            var40 = var38.loadVanillaItemsSync(var12);

            label44:
            while(true) {
               switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var62)) {
                  case 259198156:
                     var62 ^= 714533009;
                  case 703532231:
                     break label44;
                  case 962432207:
                     break;
                  case 1053000576:
                  default:
                     throw new IllegalAccessException();
               }
            }
         }

         var62 = 1077836426 ^ var62;
         KKoOoOo0oOK var39 = KKoOoOo0oOK.getInstance();
         Runnable var55 = () -> {
            int var105 = 1391871848 ^ 1104351933 ^ 1080587257;
            var105 = 2069136297 ^ var105;
            byte var17 = var1.isOnline();
            if (var17 == (672769413 ^ var105)) {
               var105 = 1360486655 ^ var105;
               if (var29 != (2031011194 ^ var105)) {
                  var105 = 1843803741 ^ var105;
                  KKoOoOo0oOK var63 = KKoOoOo0oOK.getInstance();
                  Runnable var86 = () -> {
                     int var5 = 79502844 ^ 127027625 ^ 1281345111;
                     var5 = 304672798 ^ var5;
                     oOoOo0KKoOK var1 = oOoOo0KKoOK.getInstance();
                     var1.releaseLock(var12);
                     var5 = 967923523 ^ var5;
                  };
                  var63.runAsync(var86);
                  var105 = 275041986 ^ var105;
               } else {
                  var105 = npjkqavsxyxfrwcm(var105, 2105735327);
               }

            } else {
               while(true) {
                  switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var105)) {
                     case 229742760:
                        var105 ^= 1935317604;
                     case 300914711:
                        EnderChestComponent var19 = this.manager;
                        byte var20 = var19.hasOpenChest(var12);
                        if (var20 != (1531133921 ^ var105)) {
                           var105 = 1861078509 ^ var105;
                           return;
                        }

                        var105 = npjkqavsxyxfrwcm(var105, 1185378494);
                        EnderChestStorage var21 = new EnderChestStorage(var12);
                        var105 = 1152727250 ^ var105;
                        EnderChestComponent var23 = this.manager;
                        String var24 = var23.getTitle();
                        var105 = 94333243 ^ var105;
                        byte var64 = (byte)(1557012096 ^ var105);
                        Inventory var26 = Bukkit.createInventory(var21, var64, var24);
                        Inventory var13 = var26;
                        var105 = 2046441274 ^ var105;
                        var21.setInventory(var26);
                        var105 = 1655944567 ^ var105;
                        if (var29 != (1200069883 ^ var105)) {
                           var105 = 1976849377 ^ var105;
                           if (var40 == null) {
                              var105 = npjkqavsxyxfrwcm(var105, 296848489);
                           } else {
                              var105 = 1958326803 ^ var105;
                              byte var30 = (byte)(1189772553 ^ var105);
                              int var14 = var30;
                              var105 = 805013225 ^ var105;

                              label152:
                              while(true) {
                                 int var67 = var40.length;
                                 if (var14 >= var67) {
                                    var105 = npjkqavsxyxfrwcm(var105, 1257486483);
                                    break;
                                 }

                                 var105 = 1544082256 ^ var105;
                                 byte var68 = (byte)(890841259 ^ var105);
                                 if (var14 >= var68) {
                                    var105 = npjkqavsxyxfrwcm(var105, 385575875);
                                    break;
                                 }

                                 var105 = 1789423546 ^ var105;
                                 ItemStack var34 = var40[var14];
                                 if (var34 != null) {
                                    var105 = 2010253151 ^ var105;
                                    ItemStack var89 = var40[var14];
                                    var13.setItem(var14, var89);
                                    var105 = 305844620 ^ var105;
                                 } else {
                                    var105 = npjkqavsxyxfrwcm(var105, 1709758163);
                                 }

                                 var14 += 978948568 ^ var105;

                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var105)) {
                                       case 17674445:
                                          var105 ^= 1397254713;
                                          continue label152;
                                       case 329479757:
                                          break;
                                       case 642507881:
                                       default:
                                          throw new IllegalAccessException();
                                       case 1142543368:
                                          continue label152;
                                    }
                                 }
                              }
                           }

                           Inventory var37 = var1.getEnderChest();
                           Inventory var99 = var37;
                           var105 = 586171687 ^ var105;
                           byte var38 = (byte)(17958484 ^ var105);
                           int var15 = var38;
                           var105 = 1155113241 ^ var105;

                           while(true) {
                              byte var71 = (byte)(1170974550 ^ var105);
                              if (var15 >= var71) {
                                 var105 = npjkqavsxyxfrwcm(var105, 936026966);
                                 var105 = 1589204623 ^ var105;
                                 break;
                              }

                              var105 = 1666581643 ^ var105;
                              Object var90 = null;
                              var99.setItem(var15, (ItemStack)var90);
                              var105 = 591781841 ^ var105;
                              var15 += 98073622 ^ var105;
                              var105 = 1075043162 ^ var105;
                           }
                        } else {
                           var105 = npjkqavsxyxfrwcm(var105, 1841244489);
                           Inventory var55 = var1.getEnderChest();
                           Inventory var101 = var55;
                           var105 = 1567244668 ^ var105;
                           byte var56 = (byte)(2001925326 ^ var105);
                           int var102 = var56;
                           var105 = 1818455996 ^ var105;

                           while(true) {
                              byte var82 = (byte)(456235881 ^ var105);
                              if (var102 >= var82) {
                                 var105 = 931776998 ^ var105;
                                 break;
                              }

                              var105 = 1063980007 ^ var105;
                              ItemStack var59 = var101.getItem(var102);
                              var105 = 629503072 ^ var105;
                              if (var59 != null) {
                                 var105 = 1818956733 ^ var105;
                                 ItemStack var96 = var59.clone();
                                 var13.setItem(var102, var96);
                                 var105 = 635981244 ^ var105;
                              } else {
                                 var105 = npjkqavsxyxfrwcm(var105, 1233346049);
                              }

                              var102 += 1214036725 ^ var105;
                              var105 = 1399660934 ^ var105;
                           }
                        }

                        if (var35 != null) {
                           var105 = 920640341 ^ var105;
                           byte var42 = (byte)(442993089 ^ var105);
                           int var100 = var42;
                           var105 = 1971435448 ^ var105;

                           label120:
                           while(true) {
                              int var74 = var35.length;
                              if (var100 >= var74) {
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var105)) {
                                       case 147748588:
                                          var105 ^= 1062424453;
                                       case 1207683421:
                                          break label120;
                                       case 1506594310:
                                       default:
                                          throw new IllegalAccessException();
                                       case 1923006347:
                                    }
                                 }
                              }

                              var105 ^= 399838576;
                              byte var75 = (byte)(2016621330 ^ var105);
                              if (var100 >= var75) {
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var105)) {
                                       case 149113554:
                                          var105 ^= 679887605;
                                          break label120;
                                       case 425633142:
                                          break;
                                       case 1674176269:
                                       default:
                                          throw new IllegalAccessException();
                                       case 1802665475:
                                          break label120;
                                    }
                                 }
                              }

                              var105 = 15771480 ^ var105;
                              ItemStack var52 = var35[var100];
                              if (var52 != null) {
                                 var105 = 1079509468 ^ var105;
                                 byte var92 = (byte)(949720470 ^ var105);
                                 int var81 = var100 + var92;
                                 ItemStack var94 = var35[var100];
                                 var13.setItem(var81, var94);
                                 var105 = 1617935794 ^ var105;
                              } else {
                                 label116:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var105)) {
                                       case 167417759:
                                          var105 ^= 540523630;
                                       case 176843424:
                                          break label116;
                                       case 1717118298:
                                       default:
                                          throw new IllegalAccessException();
                                       case 2144418841:
                                    }
                                 }
                              }

                              var100 += 1492396094 ^ var105;
                              var105 = npjkqavsxyxfrwcm(var105, 923932230);
                           }
                        } else {
                           var105 = 2081235816 ^ var105;
                        }

                        EnderChestComponent var46 = this.manager;
                        var46.trackOpen(var12, var13, var33);
                        var105 = 1611416913 ^ var105;
                        InventoryView var48 = var1.openInventory(var13);
                        var105 = 1788036433 ^ var105;
                        if (var29 != (1512731132 ^ var105)) {
                           var105 = 80663601 ^ var105;
                           oOoOo0KKoOK var50 = oOoOo0KKoOK.getInstance();
                           var50.startLockKeepAlive(var12);
                           var105 = 1423322272 ^ var105;
                           return;
                        }

                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var105)) {
                              case 246572786:
                                 var105 = 1343813777 ^ var105;
                                 return;
                              case 478303658:
                                 break;
                              case 817373898:
                              default:
                                 throw new IllegalAccessException();
                              case 1385506446:
                                 return;
                           }
                        }
                     case 1474470471:
                     default:
                        throw new IllegalAccessException();
                     case 1837245179:
                  }
               }
            }
         };
         var39.runAtEntity(var1, var55);
         var62 = 1972290405 ^ var62;
      };
      var28.runAsync(var35);
      var61 = 187707778 ^ var61;
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onInventoryClose(InventoryCloseEvent var1) {
      int var115 = 1614613529 ^ 2098294065 ^ 1080587257;
      var115 = 1744126576 ^ var115;
      HumanEntity var17 = var1.getPlayer();
      byte var19 = var17 instanceof Player;
      if (var19 == (984699041 ^ var115)) {
         var115 = 147787294 ^ var115;
      } else {
         var115 = 253371187 ^ var115;
         Player var21 = (Player)var17;
         var115 = 129754217 ^ var115;

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var115)) {
               case 16782438:
                  var115 ^= 1287698514;
               case 380497762:
                  Inventory var23 = var1.getInventory();
                  Inventory var105 = var23;
                  var115 = 600824251 ^ var115;
                  InventoryHolder var25 = var23.getHolder();
                  byte var27 = var25 instanceof EnderChestStorage;
                  if (var27 == (1562375698 ^ var115)) {
                     var115 = npjkqavsxyxfrwcm(var115, 505701054);
                     return;
                  }

                  var115 = 1051870502 ^ var115;
                  EnderChestStorage var29 = (EnderChestStorage)var25;
                  var115 = 1258388256 ^ var115;

                  label173:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var115)) {
                        case 248441610:
                           var115 ^= 1910904371;
                           break label173;
                        case 290376614:
                           break;
                        case 579887267:
                        default:
                           throw new RuntimeException();
                        case 1370971019:
                           break label173;
                     }
                  }

                  UUID var31;
                  byte var70;
                  label163: {
                     var31 = var21.getUniqueId();
                     var115 = 394850000 ^ var115;
                     EnderChestComponent var33 = this.manager;
                     byte var34 = var33.isCrossServerEnabled();
                     if (var34 != (1321349367 ^ var115)) {
                        var115 = 346333689 ^ var115;
                        oOoOo0KKoOK var35 = oOoOo0KKoOK.getInstance();
                        if (var35 != null) {
                           var115 ^= 1997910415;
                           oOoOo0KKoOK var36 = oOoOo0KKoOK.getInstance();
                           byte var37 = var36.isConnected();
                           if (var37 != (762519681 ^ var115)) {
                              var115 = 865273870 ^ var115;
                              var70 = (byte)(518006926 ^ var115);

                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var115)) {
                                    case 198332533:
                                       var115 ^= 1840692817;
                                       break label163;
                                    case 1465558948:
                                       break;
                                    case 1562941217:
                                       break label163;
                                    case 1923714685:
                                    default:
                                       throw new RuntimeException();
                                 }
                              }
                           }

                           label159:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var115)) {
                                 case 135209866:
                                    var115 ^= 555216642;
                                    break label159;
                                 case 419340677:
                                 default:
                                    throw new RuntimeException();
                                 case 1352395926:
                                    break;
                                 case 1723026454:
                                    break label159;
                              }
                           }
                        } else {
                           label150:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var115)) {
                                 case 254206829:
                                    var115 ^= 1442995853;
                                    break label150;
                                 case 314986772:
                                    break;
                                 case 1083103181:
                                 default:
                                    throw new RuntimeException();
                                 case 1523702142:
                                    break label150;
                              }
                           }
                        }
                     } else {
                        var115 = 1118240628 ^ var115;
                     }

                     var70 = (byte)(207933315 ^ var115);
                     var115 = 2134006109 ^ var115;
                  }

                  var115 = 144517984 ^ var115;
                  byte var38 = (byte)(2076949925 ^ var115);
                  ItemStack[] var39 = new ItemStack[var38];
                  ItemStack[] var13 = var39;
                  var115 = 1408737823 ^ var115;
                  byte var40 = (byte)(675028897 ^ var115);
                  int var14 = var40;
                  var115 = 1984337794 ^ var115;

                  while(true) {
                     byte var3 = (byte)(1585088568 ^ var115);
                     if (var14 >= var3) {
                        var115 = npjkqavsxyxfrwcm(var115, 1227525561);
                        if (var70 != (391120282 ^ var115)) {
                           var115 = 2069012780 ^ var115;
                           Inventory var44 = var21.getEnderChest();
                           Inventory var107 = var44;
                           var115 = 112912697 ^ var115;
                           byte var45 = (byte)(1790463375 ^ var115);
                           int var15 = var45;
                           var115 = 1641012378 ^ var115;

                           while(true) {
                              byte var71 = (byte)(192385294 ^ var115);
                              if (var15 >= var71) {
                                 label93:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var115)) {
                                       case 104309359:
                                          var115 ^= 1290289051;
                                          break label93;
                                       case 210456694:
                                          break;
                                       case 1201417594:
                                       default:
                                          throw new RuntimeException();
                                       case 1321066616:
                                          break label93;
                                    }
                                 }

                                 var115 = npjkqavsxyxfrwcm(var115, 61404026);
                                 break;
                              }

                              var115 = 411624002 ^ var115;
                              Object var4 = null;
                              var107.setItem(var15, (ItemStack)var4);
                              var115 = 723629765 ^ var115;
                              var15 += 954123667 ^ var115;
                              var115 = 866735239 ^ var115;
                           }
                        } else {
                           var115 = npjkqavsxyxfrwcm(var115, 685124220);
                           Inventory var65 = var21.getEnderChest();
                           Inventory var109 = var65;
                           var115 = 1177518951 ^ var115;
                           byte var66 = (byte)(2041162881 ^ var115);
                           int var112 = var66;
                           var115 = 1619347358 ^ var115;

                           label119:
                           while(true) {
                              byte var82 = (byte)(422374148 ^ var115);
                              if (var112 >= var82) {
                                 var115 = 1562097387 ^ var115;
                                 break;
                              }

                              int var141 = 1247216952 ^ var115;
                              ItemStack var93 = var13[var112];
                              var109.setItem(var112, var93);
                              var115 = 1278236108 ^ var141;
                              var112 += 525057002 ^ var115;

                              while(true) {
                                 switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var115)) {
                                    case 211985244:
                                       var115 ^= 107434228;
                                       continue label119;
                                    case 847157900:
                                    default:
                                       throw new RuntimeException();
                                    case 1182519969:
                                       continue label119;
                                    case 1667826703:
                                 }
                              }
                           }
                        }

                        byte var48 = (byte)(1144479215 ^ var115);
                        ItemStack[] var49 = new ItemStack[var48];
                        ItemStack[] var108 = var49;
                        var115 = 1999823782 ^ var115;
                        byte var50 = (byte)(856014418 ^ var115);
                        int var110 = var50;
                        var115 = 971308166 ^ var115;

                        while(true) {
                           byte var73 = (byte)(182534863 ^ var115);
                           if (var110 >= var73) {
                              var115 = npjkqavsxyxfrwcm(var115, 2113311601);
                              EnderChestComponent var54 = this.manager;
                              Location var55 = var54.getChestBlock(var31);
                              Location var111 = var55;
                              var115 = 431292340 ^ var115;
                              if (var55 != null) {
                                 label184: {
                                    var115 = 2007989457 ^ var115;
                                    String var80 = gmidwwegan(vdywgotglwzzeaq(), jdsolkprmjvrrhg(), var115);
                                    Sound var89 = Sound.BLOCK_ENDER_CHEST_CLOSE;
                                    float var99 = 0.5F;
                                    float var104 = 1.0F;
                                    KKo0KoOoOK.play(var21, var80, var89, var99, var104);
                                    var115 = 2044765319 ^ var115;

                                    try {
                                       KKoOoOo0oOK var62 = KKoOoOo0oOK.getInstance();
                                       Runnable var91 = () -> {
                                          int var16 = 154807217 ^ 670563762 ^ 1281345111;
                                          var16 = 1784839438 ^ var16;
                                          Block var5 = var111.getBlock();
                                          var16 = 1889424168 ^ var16;
                                          Material var7 = var5.getType();
                                          Material var2 = Material.ENDER_CHEST;
                                          if (var7 != var2) {
                                             var16 = 716278107 ^ var16;
                                          } else {
                                             var16 = 645009727 ^ var16;
                                             BlockState var9 = var5.getState();
                                             var16 = 126811952 ^ var16;
                                             byte var11 = var9 instanceof Lidded;
                                             if (var11 != (1502793853 ^ var16)) {
                                                var16 = 686082514 ^ var16;
                                                Lidded var13 = (Lidded)var9;
                                                var13.close();
                                                var16 = 598322822 ^ var16;
                                             } else {
                                                while(true) {
                                                   switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
                                                      case 211369731:
                                                         return;
                                                      case 227289696:
                                                         var16 = 189622100 ^ var16;
                                                         return;
                                                      case 266426422:
                                                         break;
                                                      case 1668725357:
                                                      default:
                                                         throw new IllegalAccessException();
                                                   }
                                                }
                                             }
                                          }

                                       };
                                       var62.runAtLocation(var111, var91);
                                       var115 = 2091889556 ^ var115;
                                    } catch (Exception var116) {
                                       switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var115)) {
                                          case 124236347:
                                             var115 = 1047231699 ^ var115;
                                             var115 = 253351534 ^ var115;
                                             var115 = npjkqavsxyxfrwcm(var115, 556791559);
                                             break label184;
                                          default:
                                             throw new IllegalAccessException("Error in hash");
                                       }
                                    }

                                    var115 = 1827860014 ^ var115;
                                 }
                              } else {
                                 var115 = 1136526260 ^ var115;
                                 String var76 = gmidwwegan(koektfeklctumko(), jdsolkprmjvrrhg(), var115);
                                 Sound var87 = Sound.BLOCK_ENDER_CHEST_CLOSE;
                                 float var97 = 0.5F;
                                 float var102 = 1.0F;
                                 KKo0KoOoOK.play(var21, var76, var87, var97, var102);
                                 var115 = 1571587672 ^ var115;
                              }

                              EnderChestComponent var59 = this.manager;
                              var59.untrackOpen(var31);
                              var115 = 1312148894 ^ var115;
                              KKoOoOo0oOK var60 = KKoOoOo0oOK.getInstance();
                              Runnable var79 = () -> {
                                 int var18 = 2021655767 ^ 1421475641 ^ 1080587257;
                                 var18 = 1320279757 ^ var18;
                                 EnderChestComponent var8 = this.manager;
                                 var8.saveExtraItemsSync(var31, var108);
                                 var18 = 1311018070 ^ var18;
                                 if (var70 != (1824840332 ^ var18)) {
                                    var18 = 598177458 ^ var18;
                                    EnderChestComponent var11 = this.manager;
                                    var11.saveVanillaItemsSync(var31, var13);
                                    var18 = 1273885841 ^ var18;
                                    oOoOo0KKoOK var12 = oOoOo0KKoOK.getInstance();
                                    var12.releaseLock(var31);
                                    var18 = 1077111379 ^ var18;
                                 } else {
                                    while(true) {
                                       switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var18)) {
                                          case 45943723:
                                             var18 = 679078000 ^ var18;
                                             return;
                                          case 1316517546:
                                          default:
                                             throw new IllegalAccessException();
                                          case 1473368050:
                                             return;
                                          case 1775194759:
                                       }
                                    }
                                 }
                              };
                              var60.runAsync(var79);
                              var115 = 599289978 ^ var115;
                              return;
                           }

                           var115 = 29462401 ^ var115;
                           byte var6 = (byte)(186699086 ^ var115);
                           int var96 = var110 + var6;
                           ItemStack var86 = var105.getItem(var96);
                           var108[var110] = var86;
                           var115 = 891325551 ^ var115;
                           var110 += 1040204091 ^ var115;
                           var115 = 887161838 ^ var115;
                        }
                     }

                     var115 = 1171709257 ^ var115;
                     ItemStack var95 = var105.getItem(var14);
                     var13[var14] = var95;
                     var115 = 759569124 ^ var115;
                     var14 += 921325455 ^ var115;
                     var115 = npjkqavsxyxfrwcm(var115, 1754318765);
                  }
               case 663954370:
                  break;
               case 1281612048:
               default:
                  throw new RuntimeException();
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerQuit(PlayerQuitEvent var1) {
      int var99 = 343611873 ^ 341360093 ^ 1080587257;
      var99 = 1067252998 ^ var99;
      Player var16 = var1.getPlayer();
      var99 = 84254543 ^ var99;
      UUID var18 = var16.getUniqueId();
      var99 = 1184810477 ^ var99;
      EnderChestComponent var20 = this.manager;
      byte var21 = var20.hasOpenChest(var18);
      if (var21 == (1011642465 ^ var99)) {
         var99 = 1796360226 ^ var99;
      } else {
         var99 = 397621973 ^ var99;
         EnderChestComponent var23 = this.manager;
         Inventory var24 = var23.getOpenChest(var18);
         Inventory var10 = var24;
         var99 = 1740239518 ^ var99;
         if (var24 == null) {
            var99 = 1752124943 ^ var99;
         } else {
            byte var32;
            label131: {
               var99 = 1283362787 ^ var99;
               EnderChestComponent var27 = this.manager;
               byte var28 = var27.isCrossServerEnabled();
               if (var28 != (3684297 ^ var99)) {
                  var99 = 2122264274 ^ var99;
                  oOoOo0KKoOK var29 = oOoOo0KKoOK.getInstance();
                  if (var29 != null) {
                     var99 = 213692597 ^ var99;
                     oOoOo0KKoOK var30 = oOoOo0KKoOK.getInstance();
                     byte var31 = var30.isConnected();
                     if (var31 != (1929095598 ^ var99)) {
                        var99 = 755605601 ^ var99;
                        var32 = (byte)(1609697742 ^ var99);
                        var99 = npjkqavsxyxfrwcm(var99, 831376769);
                        break label131;
                     }

                     var99 = 217110439 ^ var99;
                  } else {
                     var99 = npjkqavsxyxfrwcm(var99, 5007122);
                  }
               } else {
                  var99 = 2117290432 ^ var99;
               }

               var32 = (byte)(2114682377 ^ var99);
               var99 = 276085319 ^ var99;
            }

            var99 = 1831451642 ^ var99;
            byte var33 = (byte)(56000431 ^ var99);
            ItemStack[] var34 = new ItemStack[var33];
            ItemStack[] var12 = var34;
            var99 = 1437611385 ^ var99;
            byte var35 = (byte)(1457933005 ^ var99);
            int var13 = var35;
            var99 = 860967212 ^ var99;

            while(true) {
               byte var64 = (byte)(1706499066 ^ var99);
               if (var13 >= var64) {
                  ItemStack[] var92;
                  label115:
                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var99)) {
                        case 59933377:
                        default:
                           throw new RuntimeException();
                        case 85107636:
                           var99 ^= 1786265108;
                        case 961337450:
                           break;
                        case 2003837827:
                           continue;
                     }

                     if (var32 != (265233909 ^ var99)) {
                        var99 = 916904369 ^ var99;
                        Inventory var39 = var16.getEnderChest();
                        Inventory var91 = var39;
                        var99 = 1263746995 ^ var99;
                        byte var40 = (byte)(1916453879 ^ var99);
                        int var14 = var40;
                        var99 = 182772436 ^ var99;

                        while(true) {
                           byte var65 = (byte)(2027823416 ^ var99);
                           if (var14 >= var65) {
                              var99 = npjkqavsxyxfrwcm(var99, 1263589151);
                              var99 = 181568118 ^ var99;
                              break;
                           }

                           var99 = 1201980124 ^ var99;
                           Object var81 = null;
                           var91.setItem(var14, (ItemStack)var81);
                           var99 = 485036996 ^ var99;
                           var14 += 596897850 ^ var99;
                           var99 = 1531826456 ^ var99;
                        }
                     } else {
                        var99 = npjkqavsxyxfrwcm(var99, 1134090346);
                        Inventory var58 = var16.getEnderChest();
                        Inventory var93 = var58;
                        var99 = 119863084 ^ var99;
                        byte var59 = (byte)(1265830579 ^ var99);
                        int var96 = var59;
                        var99 = 2048354070 ^ var99;

                        while(true) {
                           byte var74 = (byte)(828665278 ^ var99);
                           if (var96 >= var74) {
                              var99 = 137894383 ^ var99;
                              break;
                           }

                           var99 = 211041254 ^ var99;
                           ItemStack var83 = var12[var96];
                           var93.setItem(var96, var83);
                           var99 = 679728129 ^ var99;
                           var96 += 359891523 ^ var99;
                           var99 = 605548519 ^ var99;
                        }
                     }

                     byte var42 = (byte)(962360401 ^ var99);
                     ItemStack[] var43 = new ItemStack[var42];
                     var92 = var43;
                     var99 = 513255347 ^ var99;
                     byte var44 = (byte)(667669497 ^ var99);
                     int var94 = var44;
                     var99 = 412449871 ^ var99;

                     while(true) {
                        byte var66 = (byte)(1063169965 ^ var99);
                        if (var94 >= var66) {
                           label92:
                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var99)) {
                                 case 180833070:
                                    var99 ^= 2014108263;
                                    break label92;
                                 case 409011706:
                                 default:
                                    throw new RuntimeException();
                                 case 1315670224:
                                    break label92;
                                 case 1671914661:
                              }
                           }

                           EnderChestComponent var47 = this.manager;
                           Location var48 = var47.getChestBlock(var18);
                           Location var95 = var48;
                           var99 = 1342351756 ^ var99;
                           if (var48 != null) {
                              var99 = 486906857 ^ var99;

                              try {
                                 KKoOoOo0oOK var50 = KKoOoOo0oOK.getInstance();
                                 Runnable var77 = () -> {
                                    int var16 = 1292648347 ^ 303032318 ^ 1281345111;
                                    var16 = 1333003301 ^ var16;
                                    Block var5 = var95.getBlock();
                                    var16 = 50920146 ^ var16;
                                    Material var7 = var5.getType();
                                    Material var2 = Material.ENDER_CHEST;
                                    if (var7 == var2) {
                                       var16 = 1634880066 ^ var16;
                                       BlockState var9 = var5.getState();
                                       var16 = 1605875837 ^ var16;
                                       byte var11 = var9 instanceof Lidded;
                                       if (var11 != (1642402554 ^ var16)) {
                                          var16 = 2076230617 ^ var16;
                                          Lidded var13 = (Lidded)var9;
                                          var13.close();
                                          var16 = 1289777740 ^ var16;
                                       } else {
                                          while(true) {
                                             switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
                                                case 229356833:
                                                   var16 = 924889493 ^ var16;
                                                   return;
                                                case 886076436:
                                                default:
                                                   throw new IllegalAccessException();
                                                case 1038766464:
                                                   break;
                                                case 1406846252:
                                                   return;
                                             }
                                          }
                                       }
                                    } else {
                                       while(true) {
                                          switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
                                             case 114107407:
                                                break;
                                             case 139455581:
                                                var16 = 166020010 ^ var16;
                                                return;
                                             case 444341518:
                                                return;
                                             case 1766525614:
                                             default:
                                                throw new IllegalAccessException();
                                          }
                                       }
                                    }
                                 };
                                 var50.runAtLocation(var95, var77);
                                 var99 = 476771576 ^ var99;
                              } catch (Exception var100) {
                                 switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var99)) {
                                    case 1386888608:
                                       var99 = 130637969 ^ var99;
                                       var99 = 946388502 ^ var99;
                                       break label115;
                                    default:
                                       throw new IOException("Error in hash");
                                 }
                              }

                              var99 = 600517247 ^ var99;
                              break label115;
                           }

                           while(true) {
                              switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var99)) {
                                 case 221035940:
                                    var99 ^= 581191022;
                                    break label115;
                                 case 602187931:
                                 default:
                                    throw new RuntimeException();
                                 case 1394861377:
                                    break label115;
                                 case 1715896676:
                              }
                           }
                        }

                        var99 = 545502113 ^ var99;
                        byte var90 = (byte)(534584332 ^ var99);
                        int var87 = var94 + var90;
                        ItemStack var80 = var10.getItem(var87);
                        var92[var94] = var80;
                        var99 = 24359145 ^ var99;
                        var94 += 514764031 ^ var99;
                        var99 = 569377608 ^ var99;
                     }
                  }

                  EnderChestComponent var53 = this.manager;
                  var53.untrackOpen(var18);
                  var99 = 779948725 ^ var99;
                  KKoOoOo0oOK var54 = KKoOoOo0oOK.getInstance();
                  Runnable var71 = () -> {
                     int var18x = 158245937 ^ 62280963 ^ 1080587257;
                     var18x = 286914275 ^ var18x;
                     EnderChestComponent var8 = this.manager;
                     var8.saveExtraItemsSync(var18, var92);
                     var18x = 2057583721 ^ var18x;
                     if (var32 != (554518593 ^ var18x)) {
                        var18x = 640467379 ^ var18x;
                        EnderChestComponent var11 = this.manager;
                        var11.saveVanillaItemsSync(var18, var12);
                        var18x = 1029788022 ^ var18x;
                        oOoOo0KKoOK var12x = oOoOo0KKoOK.getInstance();
                        var12x.releaseLock(var18);
                        var18x = 286382554 ^ var18x;
                     } else {
                        var18x = npjkqavsxyxfrwcm(var18x, 173820191);
                     }

                  };
                  var54.runAsync(var71);
                  var99 = 1349888455 ^ var99;
                  return;
               }

               var99 = 780943972 ^ var99;
               ItemStack var85 = var10.getItem(var13);
               var12[var13] = var85;
               var99 = 1290917266 ^ var99;
               var13 += 130714646 ^ var99;
               var99 = npjkqavsxyxfrwcm(var99, 1652398070);
            }
         }
      }
   }

   public static String gmidwwegan(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] jdsolkprmjvrrhg() {
      return new byte[]{116, 1, 41, 50, 96, 50, 34, 66, 31, 13};
   }

   private static byte[] izwbhkgkqztkvfr() {
      return new byte[]{-77, -49, 26, 37, 83, 103, 21, 43, 46, 91, 69, 71, 24, 115, 86, 37, 18, 22, 38, 82, 71, 84, 26, 97, 87, 112, 19, 91, 46, 93, 69, 90, 31, 96, 80, 112, 27, 7, 44, 28, 71, 94, 30, 113, 81, 43, 19, 30, 46, 78, 66, 83, 25, 109, 89, 35, 17, 28, 44, 85, 67, 17, 24, 106, 81, 111, 19, 30, 41, 78, 68, 88, 16, 102, 83, 113, 17, 84, 40, 78, 69, 93, 24, 115, 81, 119, 20, 16, 47, 78, 77, 30, 26, 35, 83, 80, 21, 0, 46, 77, 69, 18, 24, 96, 86, 98, 18, 18, 38, 85, 71, 94, 26, 36, 87, 107, 19, 21, 46, 30, 69, 83, 31, 37, 80, 110, 27, 28, 44, 81, 71, 82, 30, 108, 81, 127, 19, 95};
   }

   private static byte[] qrdznbdgegpnlui() {
      return new byte[]{-69, -54, 30, 38, 87, 103, 22, 45, 45, 90, 69, 64, 30, 114, 87, 36, 22, 17, 45, 91, 69, 81, 30, 101, 87, 118, 22, 84, 45, 86, 69, 93, 30, 101, 87, 119, 22, 0, 45, 21, 69, 92, 30, 115, 87, 36, 22, 27, 45, 69, 69, 80, 30, 110, 87, 36, 22, 27, 45, 91, 69, 21, 30, 97, 87, 106, 22, 27, 45, 65, 69, 93, 30, 101, 87, 118, 22, 84, 45, 70, 69, 80, 30, 114, 87, 114, 22, 17, 45, 71, 69, 27, 30, 32, 87, 80, 22, 6, 45, 76, 69, 21, 30, 97, 87, 99, 22, 21, 45, 92, 69, 91, 30, 32, 87, 109, 22, 26, 45, 21, 69, 84, 30, 32, 87, 105, 22, 27, 45, 88, 69, 80, 30, 110, 87, 112, 22, 90};
   }

   private static byte[] yqaogcazinpuwgx() {
      return new byte[]{-69, -49, 29, 100, 83, 106, 26, 24, 44, 72, 69, 68, 29, 101, 83, 107, 26, 18, 44, 88, 69, 66, 29, 99, 83, 109, 26, 19, 44, 78, 69, 68, 29, 46, 83, 96, 26, 24, 44, 89, 69, 85, 29, 114, 83, 102, 26, 30, 44, 88, 69, 67, 29, 116, 83, 105, 26, 31, 44, 78, 69, 68, 29, 101, 83, 107, 26, 19, 44, 79, 69, 30, 29, 111, 83, 117, 26, 19, 44, 83, 69, 2};
   }

   private static byte[] otgirtztilgmvha() {
      return new byte[]{-69, -50, 17, 101, 83, 104, 26, 27, 43, 77, 69, 69, 17, 100, 83, 105, 26, 17, 43, 93, 69, 67, 17, 98, 83, 111, 26, 16, 43, 75, 69, 69, 17, 47, 83, 98, 26, 27, 43, 92, 69, 84, 17, 115, 83, 100, 26, 29, 43, 93, 69, 66, 17, 117, 83, 107, 26, 28, 43, 75, 69, 69, 17, 100, 83, 105, 26, 16, 43, 74, 69, 31, 17, 110, 83, 119, 26, 16, 43, 86};
   }

   private static byte[] koektfeklctumko() {
      return new byte[]{-67, -53, 31, 110, 88, 107, 27, 24, 38, 79, 65, 67, 17, 111, 86, 101, 22, 31, 40, 93, 66, 75, 17, 103, 89, 110, 27, 16, 42, 72, 76, 77, 31, 37, 84, 110, 21, 25, 41, 81, 76, 82, 16, 116, 89, 102, 23, 28, 39, 80, 66, 75, 29, 127, 87, 107, 20, 19, 39, 72, 77, 65, 16, 96, 85, 106, 26, 31, 41, 70, 64, 22, 30, 100, 86, 102, 26, 27, 38, 74, 77, 83, 28, 54};
   }

   private static byte[] vdywgotglwzzeaq() {
      return new byte[]{-66, -52, 25, 100, 83, 101, 18, 29, 41, 76, 70, 69, 27, 100, 88, 108, 19, 16, 43, 90, 68, 65, 26, 105, 80, 107, 20, 19, 45, 78, 70, 70, 17, 44, 81, 97, 22, 30, 47, 91, 71, 92, 25, 113, 86, 101, 16, 26, 45, 91, 76, 66, 24, 112, 84, 108, 18, 25, 44, 70, 68, 68, 31, 99, 82, 108, 16, 20, 39, 79, 69, 25, 29, 99, 80, 108, 17, 21, 47, 79, 66, 80};
   }

   private static int npjkqavsxyxfrwcm(int var0, int var1) {
      return var0 ^ var1;
   }

   static {
   }
}
