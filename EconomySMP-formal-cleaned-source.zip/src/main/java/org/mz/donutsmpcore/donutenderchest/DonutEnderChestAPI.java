package org.mz.donutsmpcore.donutenderchest;

import iuvsqhjjgpealibh.yjnwrxjydcilvuqp;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import skido.KKoOoOo0oOK;

public final class DonutEnderChestAPI {
   public static final int VANILLA_SIZE = 27;
   public static final int EXTRA_SLOTS = 27;
   public static final int TOTAL_SIZE = 54;
   private static byte[] wefiwswpnm;

   private DonutEnderChestAPI() {
   }

   public static boolean isFeatureEnabled() {
      int var4 = 1409716821 ^ 1056979715 ^ 1374138599;
      var4 = 34495053 ^ var4;
      EnderChestComponent var0 = EnderChestComponent.getInstance();
      boolean var1 = var0.isEnabled();
      return var1;
   }

   public static boolean playerHasExpandedAccess(Player var0) {
      int var11 = 1156080164 ^ 393589625 ^ 1374138599;
      var11 = 2062653284 ^ var11;
      EnderChestComponent var1 = EnderChestComponent.getInstance();
      var11 = 1881043122 ^ var11;
      byte var5 = var1.isEnabled();
      byte var8;
      if (var5 != (144017004 ^ var11)) {
         var11 = 1606667435 ^ var11;
         byte var7 = var1.hasEnderChestAccess(var0);
         if (var7 != (1465273031 ^ var11)) {
            var11 = 626678025 ^ var11;
            var8 = (byte)(1913394127 ^ var11);
            var11 = gdzszolfntecifvr(var11, 1616868294);
            return (boolean)var8;
         }

         label24:
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var11)) {
               case 154625975:
                  var11 ^= 143346149;
                  break label24;
               case 987818998:
               default:
                  throw new RuntimeException();
               case 1243536115:
                  break label24;
               case 1830057568:
            }
         }
      } else {
         var11 = 1464370510 ^ var11;
      }

      var8 = (byte)(1608319778 ^ var11);
      var11 = 1301177130 ^ var11;
      return (boolean)var8;
   }

   public static boolean hasOpenChest(UUID var0) {
      int var6 = 1326008648 ^ 1715321455 ^ 1374138599;
      var6 = 2094459303 ^ var6;
      EnderChestComponent var1 = EnderChestComponent.getInstance();
      boolean var3 = var1.hasOpenChest(var0);
      return var3;
   }

   public static ItemStack[] peekLiveFullInventory(UUID var0) {
      int var26 = 792305614 ^ 868776784 ^ 1374138599;
      var26 = 1383997368 ^ var26;
      EnderChestComponent var1 = EnderChestComponent.getInstance();
      Inventory var8 = var1.getOpenChest(var0);
      Inventory var4 = var8;
      var26 = 1087392198 ^ var26;
      if (var8 == null) {
         var26 = 347981126 ^ var26;
         Object var10 = null;
         return (ItemStack[])var10;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var26)) {
               case 158653525:
                  var26 ^= 655507452;
               case 1246389084:
                  byte var11 = (byte)(2024422861 ^ var26);
                  ItemStack[] var12 = new ItemStack[var11];
                  ItemStack[] var5 = var12;
                  var26 = 1512042852 ^ var26;
                  byte var13 = (byte)(582339743 ^ var26);
                  int var6 = var13;
                  var26 = 2142894088 ^ var26;

                  while(true) {
                     byte var19 = (byte)(1561080993 ^ var26);
                     if (var6 >= var19) {
                        var26 = 712424899 ^ var26;
                        return var5;
                     }

                     var26 = 1461856184 ^ var26;
                     ItemStack var16 = var4.getItem(var6);
                     var26 = 207781642 ^ var26;
                     ItemStack var23;
                     if (var16 != null) {
                        var26 = gdzszolfntecifvr(var26, 721079662);
                        var23 = var16.clone();
                        var26 = 528929805 ^ var26;
                     } else {
                        var26 = 1530366978 ^ var26;
                        var23 = null;

                        label35:
                        while(true) {
                           switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var26)) {
                              case 86007600:
                                 var26 ^= 1850447201;
                                 break label35;
                              case 281504239:
                                 break;
                              case 902671672:
                                 break label35;
                              case 1099353646:
                              default:
                                 throw new RuntimeException();
                           }
                        }
                     }

                     var5[var6] = var23;
                     var26 = 1316471135 ^ var26;
                     var6 += 2101851160 ^ var26;
                     var26 = gdzszolfntecifvr(var26, 541819022);
                  }
               case 445661713:
               default:
                  throw new RuntimeException();
               case 917407561:
            }
         }
      }
   }

   public static ItemStack[] peekLiveExtraItems(UUID var0) {
      int var28 = 267486038 ^ 692566447 ^ 1374138599;
      var28 = 1420290567 ^ var28;
      EnderChestComponent var1 = EnderChestComponent.getInstance();
      Inventory var8 = var1.getOpenChest(var0);
      Inventory var4 = var8;
      var28 = 910110798 ^ var28;
      if (var8 == null) {
         var28 = 850412117 ^ var28;
         Object var18 = null;
         return (ItemStack[])var18;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var28)) {
               case 171318881:
                  var28 ^= 1927354625;
               case 829859985:
                  byte var10 = (byte)(1730693453 ^ var28);
                  ItemStack[] var11 = new ItemStack[var10];
                  ItemStack[] var5 = var11;
                  var28 = 1787591482 ^ var28;
                  byte var12 = (byte)(228864620 ^ var28);
                  int var6 = var12;
                  var28 = 505129468 ^ var28;

                  while(true) {
                     byte var19 = (byte)(331324299 ^ var28);
                     if (var6 >= var19) {
                        var28 = gdzszolfntecifvr(var28, 2004805606);
                        return var5;
                     }

                     var28 = 1057806842 ^ var28;
                     byte var3 = (byte)(749945457 ^ var28);
                     int var21 = var6 + var3;
                     ItemStack var16 = var4.getItem(var21);
                     var28 = 462087735 ^ var28;
                     ItemStack var25;
                     if (var16 == null) {
                        var28 = 138563729 ^ var28;
                        var25 = null;
                        var28 = 312731388 ^ var28;
                     } else {
                        var28 = gdzszolfntecifvr(var28, 917159412);
                        var25 = var16.clone();
                        var28 = 743115673 ^ var28;
                     }

                     var5[var6] = var25;
                     var28 = 1382383611 ^ var28;
                     var6 += 2143120842 ^ var28;
                     var28 = gdzszolfntecifvr(var28, 1812133467);
                  }
               case 1641812084:
                  break;
               case 1965721260:
               default:
                  throw new IllegalAccessException();
            }
         }
      }
   }

   public static ItemStack[] getExtraItemsSync(UUID var0) {
      int var6 = 218800643 ^ 656005982 ^ 1374138599;
      var6 = 1832738066 ^ var6;
      EnderChestComponent var1 = EnderChestComponent.getInstance();
      ItemStack[] var3 = var1.loadExtraItemsSync(var0);
      return var3;
   }

   public static void getExtraItemsAsync(UUID var0, Consumer<ItemStack[]> var1) {
      int var8 = 1860257400 ^ 661652663 ^ 1374138599;
      var8 = 1196192943 ^ var8;
      KKoOoOo0oOK var2 = KKoOoOo0oOK.getInstance();
      Runnable var5 = () -> {
         int var16 = 684672069 ^ 1557407668 ^ 1374138599;
         var16 = 1128950691 ^ var16;
         EnderChestComponent var2 = EnderChestComponent.getInstance();
         ItemStack[] var6 = var2.loadExtraItemsSync(var0);
         ItemStack[] var4 = var6;
         var16 = 262960626 ^ var16;

         try {
            var1.accept(var4);
            var16 = 1707294471 ^ var16;
         } catch (Throwable var17) {
            switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var16)) {
               case 1222011451:
                  var16 = 832948935 ^ var16;
                  var16 = 1170820363 ^ var16;
                  Logger var9 = Bukkit.getLogger();
                  String var12 = var17.getMessage();
                  String var13 = "[DonutEnderChest API] async callback threw: " + var12;
                  var9.severe(var13);
                  var16 = 1802102646 ^ var16;
                  return;
               default:
                  throw new IOException("Error in hash");
            }
         }

         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
               case 149309829:
                  var16 = 2059820989 ^ var16;
                  return;
               case 387856896:
               default:
                  throw new IllegalAccessException();
               case 467403327:
                  return;
               case 1829413742:
            }
         }
      };
      var2.runAsync(var5);
      var8 = 758218434 ^ var8;
   }

   public static void setExtraItemsSync(UUID var0, ItemStack[] var1) {
      int var17 = 666042091 ^ 206164505 ^ 1374138599;
      var17 = 1007995464 ^ var17;
      if (var1 == null) {
         var17 = 1280671605 ^ var17;
         String var3 = yaktljlsgy(zvlvtdwbajogsek(), var17);
         IllegalArgumentException var4 = new IllegalArgumentException(var3);
         throw var4;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var17)) {
               case 72510218:
                  break;
               case 128999772:
                  var17 ^= 629217557;
               case 1566933761:
                  int var6 = var1.length;
                  byte var9 = (byte)(1669943123 ^ var17);
                  if (var6 != var9) {
                     var17 = 1448260296 ^ var17;
                     int var13 = var1.length;
                     String var14 = "extraItems must have length 27 (got " + var13 + ")";
                     IllegalArgumentException var8 = new IllegalArgumentException(var14);
                     throw var8;
                  }

                  var17 = 863288025 ^ var17;
                  EnderChestComponent var7 = EnderChestComponent.getInstance();
                  var7.saveExtraItemsSync(var0, var1);
                  var17 = 355676057 ^ var17;
                  return;
               case 1937727866:
               default:
                  throw new IOException();
            }
         }
      }
   }

   public static void setExtraItemsAsync(UUID var0, ItemStack[] var1, Runnable var2) {
      int var34 = 218535122 ^ 1045782741 ^ 1374138599;
      var34 = 1573797752 ^ var34;
      if (var1 == null) {
         var34 = 1300498648 ^ var34;
         String var28 = yaktljlsgy(jmxnkqgqkkhauor(), var34);
         IllegalArgumentException var18 = new IllegalArgumentException(var28);
         throw var18;
      } else {
         while(true) {
            switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var34)) {
               case 178326580:
                  break;
               case 184381452:
                  var34 ^= 1994889794;
               case 1248887675:
                  int var10 = var1.length;
                  byte var4 = (byte)(1235083713 ^ var34);
                  if (var10 != var4) {
                     var34 = 34901971 ^ var34;
                     String var5 = yaktljlsgy(mbsrnvpqfrkynfh(), var34);
                     IllegalArgumentException var11 = new IllegalArgumentException(var5);
                     throw var11;
                  }

                  while(true) {
                     switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var34)) {
                        case 245476363:
                           var34 ^= 558223628;
                        case 1365941172:
                           byte var12 = (byte)(1758998733 ^ var34);
                           ItemStack[] var13 = new ItemStack[var12];
                           ItemStack[] var7 = var13;
                           var34 = 235556396 ^ var34;
                           byte var14 = (byte)(1725071098 ^ var34);
                           int var8 = var14;
                           var34 = 1009894187 ^ var34;

                           while(true) {
                              byte var19 = (byte)(1524874698 ^ var34);
                              if (var8 >= var19) {
                                 var34 = 1078288324 ^ var34;
                                 KKoOoOo0oOK var16 = KKoOoOo0oOK.getInstance();
                                 Runnable var21 = () -> {
                                    int var16 = 594182306 ^ 1201211331 ^ 1374138599;
                                    var16 = 953472051 ^ var16;
                                    EnderChestComponent var3 = EnderChestComponent.getInstance();
                                    var3.saveExtraItemsSync(var0, var7);
                                    var16 = 1926423072 ^ var16;
                                    if (var2 != null) {
                                       var16 = 708098990 ^ var16;

                                       try {
                                          var2.run();
                                          var16 = 1819852125 ^ var16;
                                       } catch (Throwable var17) {
                                          switch (yjnwrxjydcilvuqp.tsjdxnsrdcocpulc(var16)) {
                                             case -1456090662:
                                                var16 = gdzszolfntecifvr(var16, 1135646578);
                                                var16 = 1589717027 ^ var16;
                                                Logger var10 = Bukkit.getLogger();
                                                String var12 = var17.getMessage();
                                                String var13 = "[DonutEnderChest API] completion callback threw: " + var12;
                                                var10.severe(var13);
                                                var16 = 1205236210 ^ var16;
                                                return;
                                             default:
                                                throw new RuntimeException("Error in hash");
                                          }
                                       }

                                       var16 = gdzszolfntecifvr(var16, 920613886);
                                    } else {
                                       while(true) {
                                          switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var16)) {
                                             case 103980034:
                                                var16 = 1888711949 ^ var16;
                                                return;
                                             case 831800698:
                                                break;
                                             case 1627886841:
                                             default:
                                                throw new IllegalAccessException();
                                             case 2138975409:
                                                return;
                                          }
                                       }
                                    }
                                 };
                                 var16.runAsync(var21);
                                 var34 = 1825404807 ^ var34;
                                 return;
                              }

                              var34 = 2050731454 ^ var34;
                              ItemStack var25 = var1[var8];
                              ItemStack var29;
                              if (var25 == null) {
                                 var34 = 278936205 ^ var34;
                                 var29 = null;
                                 var34 = 534706958 ^ var34;
                              } else {
                                 label37:
                                 while(true) {
                                    switch (yjnwrxjydcilvuqp.spofafzueqkpsodo(var34)) {
                                       case 262323983:
                                          var34 ^= 1982574281;
                                       case 833183547:
                                          break label37;
                                       case 1091383431:
                                          break;
                                       case 1415709804:
                                       default:
                                          throw new RuntimeException();
                                    }
                                 }

                                 ItemStack var27 = var1[var8];
                                 var29 = var27.clone();
                                 var34 = 2035642186 ^ var34;
                              }

                              var7[var8] = var29;
                              var34 = 1257055181 ^ var34;
                              var8 += 1699476000 ^ var34;
                              var34 = 1067995120 ^ var34;
                           }
                        case 1635780750:
                        default:
                           throw new RuntimeException();
                        case 1663494397:
                     }
                  }
               case 1890248097:
               default:
                  throw new RuntimeException();
            }
         }
      }
   }

   public static String yaktljlsgy(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = wefiwswpnm;
         byte[] var34 = wefiwswpnm;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   static {
      wefiwswpnm = xcipmgupcbkepxt();
   }

   private static byte[] xcipmgupcbkepxt() {
      return new byte[]{104, 7, 24, 39, 126, 101, 51, 89, 28, 90, 97, 9, 62, 1, 30, 98, 107, 49, 11, 93, 120, 110, 58, 38, 29, 16, 118, 33};
   }

   private static byte[] zvlvtdwbajogsek() {
      return new byte[]{-89, -49, 43, 122, 73, 42, 6, 25, 40, 25, 86, 91, 6, 127, 41, 35, 95, 96, 58, 7, 75, 37, 13, 49, 40, 69, 66, 98, 95, 70, 32, 113, 73, 41, 7, 77, 45, 0, 82, 68, 9, 69, 43, 34, 95, 32, 60, 0, 64, 54, 13, 103, 41, 4, 71, 116, 91, 90, 47, 48, 75, 63, 7, 29, 43, 5, 89, 82};
   }

   private static byte[] jmxnkqgqkkhauor() {
      return new byte[]{-89, -63, 42, 123, 76, 42, 11, 31, 43, 26, 80, 81, 12, 113, 44, 33, 83, 102, 60, 2, 73, 36, 8, 63, 47, 70, 78, 97, 95, 71, 41, 127, 76, 37, 1, 78, 36, 5, 86, 78, 15, 75, 44, 47, 89, 38, 51, 1, 79, 51, 11, 107, 47, 9, 68, 116, 80, 80, 47, 53, 79, 50, 1, 21, 46, 1, 89, 87};
   }

   private static byte[] mbsrnvpqfrkynfh() {
      return new byte[]{-89, -54, 46, 117, 76, 36, 4, 21, 44, 25, 80, 90, 8, 127, 44, 47, 92, 108, 59, 1, 73, 47, 12, 49, 47, 68, 65, 108, 88, 69, 41, 97, 72, 114, 1, 8, 43, 3, 81, 78, 15, 86, 40, 117, 89, 100, 60, 0, 72, 49, 11, 115, 43, 83, 68, 112, 95, 31, 40, 36, 79, 96};
   }

   private static int gdzszolfntecifvr(int var0, int var1) {
      return var1 ^ var0;
   }
}
