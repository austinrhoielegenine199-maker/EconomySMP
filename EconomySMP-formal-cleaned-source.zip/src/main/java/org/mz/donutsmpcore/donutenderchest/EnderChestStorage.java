package org.mz.donutsmpcore.donutenderchest;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class EnderChestStorage implements InventoryHolder {
   private final UUID playerUuid;
   private Inventory inventory;

   public EnderChestStorage(UUID var1) {
      this.playerUuid = var1;
   }

   public Inventory getInventory() {
      int var5 = 628119239 ^ 563430496 ^ 1575178269;
      var5 = 948553746 ^ var5;
      Inventory var2 = this.inventory;
      return var2;
   }

   public void setInventory(Inventory var1) {
      int var6 = 1665050844 ^ 175092449 ^ 1575178269;
      var6 = 433951207 ^ var6;
      this.inventory = var1;
      var6 = 659626048 ^ var6;
   }

   public UUID getPlayerUuid() {
      int var5 = 1518574467 ^ 2089998822 ^ 1575178269;
      var5 = 798495228 ^ var5;
      UUID var2 = this.playerUuid;
      return var2;
   }

   public static String eazxvnmoem(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] chhzystlsdyvslb() {
      return new byte[]{125};
   }

   static {
   }
}
