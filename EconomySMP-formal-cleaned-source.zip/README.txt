DonutSMPCore decompiled source cleanup

Contents:
- src/main/java/: 63 decompiled project Java files from org/mz/donutsmpcore, excluding bundled libs.
- src/main/resources/: YAML/YML configuration files.

Removed from this source package:
- third-party/dependency Java sources (including SQLite, Google/Gson, Adventure, SLF4J, MongoDB bundled libraries)
- skido package and other unrelated top-level packages.

Important:
- Decompiled class names that were already obfuscated remain obfuscated. Original names cannot be reliably recovered without original source or mapping files.
- This is decompiled source, not guaranteed to compile. External dependency imports may need to be added to the build configuration.
