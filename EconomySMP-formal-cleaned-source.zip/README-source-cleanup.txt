DonutSMPCore decompiled source cleanup

Contents: src/main/java and src/main/resources.
Obfuscated top-level class names were renamed heuristically based on package and code patterns.
These names are best-effort labels, not guaranteed original names. Internal references were updated consistently.
Decompiler output may still contain obfuscated identifiers, control-flow noise, and references to removed third-party/obfuscated dependencies; this is not guaranteed to compile as-is.
